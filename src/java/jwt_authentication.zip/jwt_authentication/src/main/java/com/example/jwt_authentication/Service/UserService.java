package com.example.jwt_authentication.Service;

import org.apache.commons.codec.digest.DigestUtils;

import com.example.jwt_authentication.Model.User;

import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.auth.jwt.JWTAuth;
import io.vertx.ext.jdbc.JDBCClient;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowSet;
import io.vertx.sqlclient.Tuple;

public class UserService {
	
    private final MySQLPool pool;
    private final JWTAuth jwtAuth;
    
    passwordAESEncoder passowrdencoder=new passwordAESEncoder();

    public UserService(MySQLPool pool,JWTAuth jwtAuth) {
        this.pool = pool;
        this.jwtAuth=jwtAuth;
        //this.jdbcClient=jdbcClient;
        //System.out.println("JDBCClient UserService:"+jdbcClient);

    }
    

	public Future<Void> addUser(User user) {
        Promise<Void> promise = Promise.promise(); // Create a new Promise instance

        pool.getConnection().compose(conn ->
            conn
                .preparedQuery("INSERT INTO user(name, emailId, userId, roles,address,password,contactnumber) VALUES (?, ?, ?, ?,?,?,?)")
                .execute(Tuple.of(user.getName(), user.getEmailId(), user.getUserId(), user.getRoles(),user.getAddress(),passowrdencoder.encrypt(user.getPassword()),user.getContactNumber()))
                .onSuccess(result -> {
                    conn.close(); // Close the connection after successful execution
                    promise.complete(); // Complete the promise indicating success
                })
                .onFailure(error -> {
                    conn.close(); // Close the connection in case of failure
                    promise.fail(error); // Fail the promise with the error
                })
        );

        return promise.future(); // Return the Future associated with the promise
    }
	
	public Future<JsonObject> authenticateUser(String username, String password) {
	    System.out.println("IN authenticatedUser username:" + username);
	    System.out.println("IN authenticatedUser password:" + password);

	    Promise<JsonObject> promise = Promise.promise();

	    String query = "SELECT * FROM user WHERE name = ?";
	    pool.preparedQuery(query)
	        .execute(Tuple.of(username), ar -> {
	            if (ar.succeeded()) {
	                RowSet<Row> rows = ar.result();
	                System.out.println("row size:" + rows.size());
	                if (rows.size() == 1) {
	                    Row row = rows.iterator().next();
	                    String encryptedPassword = row.getString("password"); // Retrieve encrypted password from the database
	                    String decryptedPassword = passowrdencoder.decrypt(encryptedPassword); // Decrypt the stored password
	                    if (decryptedPassword != null && decryptedPassword.equals(password)) {
	                        // Passwords match, authentication successful
	                        JsonObject userJson = new JsonObject()
	                            .put("username", row.getString("name"))
	                            .put("password", decryptedPassword)
	                            .put("roles", row.getString("roles"))
	                            .put("emailId",row.getString("emailId"));
	                        promise.complete(userJson);
	                    } else {
	                        // Passwords don't match, authentication failed
	                        JsonObject errorJson = new JsonObject()
	                            .put("error", "Passwords don't match");
	                        promise.complete(errorJson);
	                    }
	                } else {
	                    // User not found
	                    JsonObject errorJson = new JsonObject()
	                        .put("error", "User not found");
	                    promise.complete(errorJson);
	                }
	            } else {
	                // Failed to execute the query
	                ar.cause().printStackTrace();
	                promise.fail(ar.cause());
	            }
	        });

	    return promise.future();
	}
}
