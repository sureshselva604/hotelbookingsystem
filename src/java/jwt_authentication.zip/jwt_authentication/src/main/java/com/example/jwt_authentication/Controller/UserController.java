package com.example.jwt_authentication.Controller;


import com.example.jwt_authentication.Model.User;
import com.example.jwt_authentication.Service.UserService;

import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.auth.JWTOptions;
import io.vertx.ext.auth.jwt.JWTAuth;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class UserController {
    private final UserService userService;
    private final JWTAuth jwtAuth;

	
	public UserController(Vertx vertx, UserService userService,JWTAuth jwtAuth) {
        this.userService = userService;
        this.jwtAuth=jwtAuth;
        Router router = Router.router(vertx);
        router.route().handler(BodyHandler.create());
        router.post("/api/employees").handler(this::addUser);
        router.post("/api/login").handler(this::generateToken);
        
        
        
        vertx.createHttpServer()
        .requestHandler(router)
        .listen(8080, result -> {
            if (result.succeeded()) {
                System.out.println("HTTP server started on port number:8080");
            } else {
                System.err.println("Failed to start HTTP server: " + result.cause());
            }
        });
    }
	
	@SuppressWarnings("deprecation")
	private void addUser(RoutingContext context) {
     
        JsonObject errorJson = new JsonObject();
        
        @SuppressWarnings("deprecation")
		JsonObject requestBody = context.getBodyAsJson();
        
        User user = new User();
        user.setUserId(requestBody.getString("userId"));
        user.setName(requestBody.getString("name"));
        user.setEmailId(requestBody.getString("emailId"));
        user.setRoles(requestBody.getString("roles"));
        user.setAddress(requestBody.getString("address"));
        user.setPassword(requestBody.getString("password"));
        user.setContactNumber(requestBody.getString("contactNumber"));

        userService.addUser(user).onComplete(ar -> {
            if (ar.succeeded()) {
            	errorJson.put("status", "success");
                context.response().setStatusCode(200).end(errorJson.encode());
            } else {
            	errorJson.put("error", ar.cause().getMessage());
                context.response().setStatusCode(500).end(errorJson.encode());
            }
        });
    }
	
	 private void generateToken(RoutingContext context) {
	        JsonObject requestBody = context.getBodyAsJson();

	        String username = requestBody.getString("name");
	        String password = requestBody.getString("password");
	        
	        System.out.println("userName:"+username);
	        System.out.println("password:"+password);

	        

	        // Authenticate the user (e.g., check credentials against database)
	        userService.authenticateUser(username, password)
	        .compose(authResult -> {
	            if (authResult != null && !authResult.containsKey("error")) {
	            	
	            	String name = authResult.getString("username");
	                String roles = authResult.getString("roles");
	                // Authentication successful
	                String token = jwtAuth.generateToken(new JsonObject()
	                        .put("username", username)
	                        .put("roles", roles), new JWTOptions());
	                JsonObject responseJson = new JsonObject().put("token", token);
	                return Future.succeededFuture(responseJson);
	            } else {
	                // Authentication failed
	                String errorMessage = (authResult != null) ? authResult.getString("error") : "Authentication failed";
	                return Future.failedFuture(errorMessage);
	            }
	        })
	        .onComplete(authenticationResult -> {
	            if (authenticationResult.succeeded()) {
	                // Authentication successful, send the token in the response
	                context.response().setStatusCode(200).end(authenticationResult.result().encode());
	            } else {
	                // Authentication failed, send an error response
	                JsonObject errorJson = new JsonObject().put("error", authenticationResult.cause().getMessage());
	                context.response().setStatusCode(401).end(errorJson.encode());
	            }
	        });


}
}
