package com.example.jwt_authentication.Service;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class passwordDESEncoder {
	
	// Generate a static DES key (for demonstration purposes only)
	String mySecretKey="HelloALL";
    byte[] staticKeyBytes = mySecretKey.getBytes(); 
    // 8-byte key for DES
    SecretKey staticDesKey = new SecretKeySpec(staticKeyBytes, "DES");
    public String Encryption(String plainText)
    {
    try
    {
    Cipher desCipher = Cipher.getInstance("DES");
    desCipher.init(Cipher.ENCRYPT_MODE, staticDesKey);
    byte[] encryptedBytes = desCipher.doFinal(plainText.getBytes());
    String encryptedText = Base64.getEncoder().encodeToString(encryptedBytes);
    System.out.println("Encrypted Text: " + encryptedText);
    return encryptedText;
    }
    catch(Exception ex)
    {
    	ex.printStackTrace();
    }
    return null;
    }
    
    public String Decryption(String encryptedText)
    {
    // Decryption
    	try
    	{
    Cipher desCipher = Cipher.getInstance("DES");
    desCipher.init(Cipher.DECRYPT_MODE, staticDesKey);
    byte[] decryptedBytes = desCipher.doFinal(Base64.getDecoder().decode(encryptedText));
    String decryptedText = new String(decryptedBytes);
    System.out.println("Decrypted Text: " + decryptedText);
	return decryptedText;
    	}
    	catch(Exception ex)
    	{
    		ex.printStackTrace();
    	}
    	return null;
    }
    
    public static void main(String[] args)
    {
    	passwordDESEncoder passwordDes=new passwordDESEncoder();
    	passwordDes.Decryption(passwordDes.Encryption("Hello"));
    }

}
