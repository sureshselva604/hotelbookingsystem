package com.example.jwt_authentication.Service;


import com.example.jwt_authentication.Model.User;

import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.auth.jwt.JWTAuth;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowSet;
import io.vertx.sqlclient.SqlConnection;
import io.vertx.sqlclient.Tuple;

public class UserService {
	
    private final MySQLPool pool;
    private final JWTAuth jwtAuth;
    
    passwordAESEncoder passowrdencoder=new passwordAESEncoder();
    passwordDESEncoder passwordDes=new passwordDESEncoder();

    public UserService(MySQLPool pool,JWTAuth jwtAuth) {
        this.pool = pool;
        this.jwtAuth=jwtAuth;
        //this.jdbcClient=jdbcClient;
        //System.out.println("JDBCClient UserService:"+jdbcClient);

    }
    

	public Future<Void> addUser(User user) {
		System.out.println("User Password:"+user.getPassword());
        Promise<Void> promise = Promise.promise(); // Create a new Promise instance

       
        
        pool.getConnection().compose(conn ->
            conn
                .preparedQuery("INSERT INTO user(name, emailId, userId, roles,address,password,contactnumber) VALUES (?, ?, ?, ?,?,?,?)")
                .execute(Tuple.of(user.getName(), user.getEmailId(), user.getUserId(), user.getRoles(),user.getAddress(),passwordDes.Encryption(user.getPassword()),user.getContactNumber()))
                .onSuccess(result -> {
                    conn.close(); // Close the connection after successful execution
                    promise.complete(); // Complete the promise indicating success
                })
                .onFailure(error -> {
                    conn.close(); // Close the connection in case of failure
                    promise.fail(error); // Fail the promise with the error
                })
        );

        return promise.future(); // Return the Future associated with the promise
    }
	
	public Future<JsonObject> authenticateUser(String username, String password) {

	    Promise<JsonObject> promise = Promise.promise();

	    String query = "SELECT * FROM user WHERE name = ?";
	    pool.preparedQuery(query)
	        .execute(Tuple.of(username), ar -> {
	            if (ar.succeeded()) {
	                RowSet<Row> rows = ar.result();
	                if (rows.size() == 1) {
	                    Row row = rows.iterator().next();
	                    String encryptedPassword = row.getString("password"); // Retrieve encrypted password from the database
	                    String decryptedPassword = passwordDes.Decryption(encryptedPassword); // Decrypt the stored password
	                    if (decryptedPassword != null && decryptedPassword.equals(password)) {
	                        // Passwords match, authentication successful
	                        JsonObject userJson = new JsonObject()
	                            .put("username", row.getString("name"))
	                            .put("password", decryptedPassword)
	                            .put("roles", row.getString("roles"))
	                            .put("emailId",row.getString("emailId"));
	                        promise.complete(userJson);
	                    } else {
	                        // Passwords don't match, authentication failed
	                        JsonObject errorJson = new JsonObject()
	                            .put("error", "Passwords don't match");
	                        promise.complete(errorJson);
	                    }
	                } else {
	                    // User not found
	                    JsonObject errorJson = new JsonObject()
	                        .put("error", "User not found");
	                    promise.complete(errorJson);
	                }
	            } else {
	                // Failed to execute the query
	                ar.cause().printStackTrace();
	                promise.fail(ar.cause());
	            }
	        });

	    return promise.future();
	}
	public Future<JsonObject> getUserById(String userId) {
		//Promise Represents the Write Side of the asynchronous result;
	    Promise<JsonObject> promise = Promise.promise();

        String query = "SELECT * FROM user WHERE userId=?";
        pool.getConnection().onComplete(connAr -> {
            if (connAr.succeeded()) {
                connAr.result().preparedQuery(query).execute(Tuple.of(userId), queryAr -> {
                    if (queryAr.succeeded()) {
                        RowSet<Row> rows = queryAr.result();
                        if (rows.size()==1) {
                            Row firstRow = rows.iterator().next();
                            JsonObject userJson = new JsonObject()
                                    .put("username", firstRow.getString("name"))
                                    .put("userId", firstRow.getString("userId"))
                                    .put("roles", firstRow.getString("roles"))
                                    .put("emailId", firstRow.getString("emailId"))
                                    .put("address", firstRow.getString("address"))
                                    .put("contactNumber", firstRow.getString("contactnumber"));
                            promise.complete(userJson);
                        } else {
                            // User not found
                        	promise.fail("User not found for ID: " + userId);
                        }
                    } else {
                        // Database query failed
                    	promise.fail("Failed to fetch user details: " + queryAr.cause().getMessage());
                    }
                });
            } else {
                // Failed to get connection
            	promise.fail("Failed to get database connection: " + connAr.cause().getMessage());
            }
        });

        return promise.future();
    }

	

	
	}
