package com.example.jwt_authentication.Model;

public class User {

    private String name;
    private String emailId;
    private String userId;
    private String password;
    private String contactNumber;
    private String address;
    private String roles;

    // Constructors
    public User() {
    }

    public User(String name, String emailId, String userId, String password, String contactNumber, String address, String roles) {
        this.name = name;
        this.emailId = emailId;
        this.userId = userId;
        this.password = password;
        this.contactNumber = contactNumber;
        this.address = address;
        this.roles = roles;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    // toString method
    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", emailId='" + emailId + '\'' +
                ", userId='" + userId + '\'' +
                ", password='" + password + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", address='" + address + '\'' +
                ", roles='" + roles + '\'' +
                '}';
    }
}

