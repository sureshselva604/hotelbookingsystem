package com.example.jwt_authentication;

import java.nio.charset.StandardCharsets;

import com.example.jwt_authentication.Controller.UserController;
import com.example.jwt_authentication.Service.UserService;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.auth.JWTOptions;
import io.vertx.ext.auth.PubSecKeyOptions;
import io.vertx.ext.auth.jwt.JWTAuth;
import io.vertx.ext.auth.jwt.JWTAuthOptions;
import io.vertx.ext.jdbc.JDBCClient;
import io.vertx.mysqlclient.MySQLBuilder;
import io.vertx.mysqlclient.MySQLConnectOptions;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.Pool;
import io.vertx.sqlclient.PoolOptions;

public class MainVerticle extends AbstractVerticle {
	private Pool pool;
    private static final String SECRET_KEY = "cGFzc3dvcmQxMjM0NTY="; 
    long expirationInSeconds = 3600;


	@SuppressWarnings("deprecation")
	@Override
    public void start(Promise<Void> startPromise) throws Exception {
        MySQLConnectOptions connectOptions = new MySQLConnectOptions()
                .setPort(3306)
                .setHost("192.168.7.77")
                .setDatabase("suresh")
                .setUser("rduser")
                .setPassword("password@123");
        
        
        
       
        
        @SuppressWarnings("deprecation")
        JWTAuthOptions jwtAuthOptions = new JWTAuthOptions()
        .addPubSecKey(new io.vertx.ext.auth.PubSecKeyOptions()
                .setAlgorithm("HS256")
                //.setSecretKey(SECRET_KEY)
                //.setId("myKeyId")
                .setBuffer(SECRET_KEY));
        
        
        JWTAuth jwtAuth = null;
        try {
            jwtAuth = JWTAuth.create(vertx, jwtAuthOptions);
        } catch (Exception e) {
            System.err.println("Error creating JWTAuth instance: " + e.getMessage());
            e.printStackTrace();
        }

        MySQLPool pool = MySQLPool.pool(vertx, connectOptions, new PoolOptions().setMaxSize(5));

        UserService userService = new UserService(pool, jwtAuth);
        
        UserController userController = new UserController(vertx, userService, jwtAuth);

        startPromise.complete();
    }

    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();
        vertx.deployVerticle(new MainVerticle());
    }
}
