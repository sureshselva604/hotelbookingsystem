package com.seind.rc.services.user.data;


import lombok.Data;

@Data
public class StatusMessage {
	private Boolean status;
	private String message;
	private String value;
	private Boolean captchaRequired;
	private String invalidCount;
	private String userMode;	
}