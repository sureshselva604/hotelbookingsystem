package com.seind.rc.services.user.data;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HospitalPracticeApptInfo {
	
	private Long hospitalId;
	private String code;
	private String name;
	private String mode;
	private Boolean directClient;
	private Boolean availSecurity;
	private String clienttype;
	private Long hospitalPracticeid;
	private Integer admissionId;
	private Long userAccountKey;
	private Long otherAppmntHspMasterId;
	private String otherAppmntHspMasterName;

}
