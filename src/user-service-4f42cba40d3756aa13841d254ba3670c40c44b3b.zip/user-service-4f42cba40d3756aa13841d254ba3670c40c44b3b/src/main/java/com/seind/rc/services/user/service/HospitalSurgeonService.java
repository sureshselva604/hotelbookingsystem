package com.seind.rc.services.user.service;

import com.seind.rc.services.user.data.HospitalSurgeonDeviceData;
import com.seind.rc.services.user.entities.HospitalSurgeon;

public interface HospitalSurgeonService {

	//HospitalSurgeon getHospitalSurgeonById(Long hospitalSurgeonId);

	//HospitalSurgeon getHospitalSurgeonByHospitalId(Long userAccountKey);

	HospitalSurgeonDeviceData getHospitalSurgeonInfoByPatientId(Long patientId);

	HospitalSurgeon getHospitalSurgeonByPatientId(Long patientId);

}
