package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TempPatientStageworkflow {
	private Long patientSwfId;
}
