package com.seind.rc.services.user.data;

import org.springframework.data.domain.Sort;

import lombok.Data;

@Data
public class Pagination {
	private int pageNumber=0;
	private int pageSize=10;
	private String sortBy="dos";
	private Sort.Direction sortDirection = Sort.Direction.DESC;
	private Boolean isPageable=false;
}