package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.entities.PasswordHistory;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecResultDetails;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.PasswordHistoryRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserSecResDetRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.UserSecTransAuditService;

@Service
public class UserSecTransAuditServiceImpl implements UserSecTransAuditService {

	private static final Logger LOGGER = LogManager.getLogger(UserSecTransAuditServiceImpl.class);

	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepo;

	@Autowired
	private PasswordHistoryRepository passwordHistRepo;

	@Autowired
	private UserSecResDetRepository userSecResDetRepo;

	@Autowired
	private UserAccountRepository userRepo;

	/**
	 * M01
	 */
	public List<UserSecTransAudit> fetchTopFirstRandidByUserAccountId(Long userAccountId) {
		List<UserSecTransAudit> resultList = new ArrayList<>();
		try {
			String mode = "adduser";
			List<UserSecTransAudit> userSecTransAuditList = userSecTransAuditRepo
					.findTop1ByModeAndUserAccount_UserAccountIdOrderByUserSecTransAuditIdDesc(mode, userAccountId);

			if (!userSecTransAuditList.isEmpty()) {
				for (UserSecTransAudit audit : userSecTransAuditList) {
					UserSecTransAudit userSecTransAudit = new UserSecTransAudit();
					userSecTransAudit.setUserSecTransAuditId(audit.getUserSecTransAuditId());
					userSecTransAudit.setUserAccount(audit.getUserAccount());
					userSecTransAudit.setRandomId(audit.getRandomId());
					userSecTransAudit.setMode(audit.getMode());
					userSecTransAudit.setIsActive(audit.getIsActive());
					resultList.add(userSecTransAudit);
				}
			} else {
				UserSecTransAudit userSecTransAudit = new UserSecTransAudit();
				UserAccount userAccount = new UserAccount();
				userAccount.setUserAccountId(userAccountId);
				userSecTransAudit.setUserAccount(userAccount);
				userSecTransAudit.setRandomId("");
				userSecTransAudit.setMode("");
				userSecTransAudit.setIsActive(true);
				resultList.add(userSecTransAudit);
			}
			return resultList;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return new ArrayList<>();
		}
	}

	/**
	 * M02
	 */
	@Override
	public void savePasswordHistory(PasswordHistory pwdHistory) {
		try {
			passwordHistRepo.save(pwdHistory);
			List<Long> pwdHistoryList = passwordHistRepo
					.findTop5ByUserAccount_UserAccountIdOrderByPwdIdDesc(pwdHistory.getUserAccount().getUserAccountId())
					.stream().map(PasswordHistory::getPwdId).toList();
			if (pwdHistoryList.size() >= 5) {
				passwordHistRepo.deleteByUserAccount_UserAccountIdAndPwdIdNotIn(
						pwdHistory.getUserAccount().getUserAccountId(), pwdHistoryList);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M03
	 */
	@Override
	public void saveUserSecTransAudit(UserSecTransAudit secTransAudit) {
		try {
			List<UserSecTransAudit> userSecTransAuditList = userSecTransAuditRepo
					.findByUserAccount_UserAccountIdAndModeAndIsActive(
							secTransAudit.getUserAccount().getUserAccountId(), secTransAudit.getMode(), true);
			if (userSecTransAuditList != null && !userSecTransAuditList.isEmpty()) {
				userSecTransAuditRepo.userSecTransAuditRandomIdUpdate(secTransAudit.getRandomId(),
						secTransAudit.getUserAccount().getUserAccountId(), secTransAudit.getMode());
			} else {
				userSecTransAuditRepo.save(secTransAudit);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M04
	 */
	@Override
	public UserSecResultDetails validateSelectedQuestnAnsByUser(Long userAccountId, Long questionId, String answer) {
		try {
			UserSecResultDetails userSecResult = userSecResDetRepo.findByUserAccountId(userAccountId).stream().findAny().orElse(null);
			if (userSecResult != null && Objects.equals(userSecResult.getQuestion1(), questionId) && userSecResult.getAnswer1().equalsIgnoreCase(answer)) {
				return userSecResult;
			} else if (userSecResult != null && Objects.equals(userSecResult.getQuestion2(), questionId)
					&& userSecResult.getAnswer2().equalsIgnoreCase(answer)) {
				return userSecResult;
			} else if (userSecResult != null && Objects.equals(userSecResult.getQuestion3(), questionId)
					&& userSecResult.getAnswer3().equalsIgnoreCase(answer)) {
				return userSecResult;
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	/**
	 * M05
	 */
	@Override
	public UserSecTransAudit getUserSecTransAuditByRandomId(String randId) {
		UserSecTransAudit transAudit = null;
		try {
			transAudit = userSecTransAuditRepo.findByRandomId(randId);
//            if (!userSecTransAuditList.isEmpty()) {
//                transAudit = userSecTransAuditList.get(0);
//            }
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return transAudit;
	}

	/**
	 * M06
	 */
	@Override
	public void updateWelcomeflagForSecurityQuestion(UserAccount uacc) {
		UserAccount user = null;
		try {
//            List<UserAccount> user= userRepo.findByEmail(null);
			if (StringUtils.isNotBlank(uacc.getEmail())) {
//                userList= userRepo.findByEmail(uacc.getEmail()).get(0);
				user = userRepo.findByEmail(uacc.getEmail()).get(0);
				user.setWelcomeFlag(false);
				userRepo.save(user);
			} else if (StringUtils.isNotBlank(uacc.getTeleCode()) && StringUtils.isNotBlank(uacc.getPhone())) {
				user = userRepo.findByPhoneAndTeleCode(uacc.getPhone(), uacc.getTeleCode()).get(0);
				user.setWelcomeFlag(false);
				userRepo.save(user);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M07
	 */
	@Override
	public UserSecTransAudit fetchIPCaptureActiveUserSecTransAudit(Long userAccountId, String mode) {
		UserSecTransAudit transAudit = null;
		try {
			List<UserSecTransAudit> userSecTransAuditList = userSecTransAuditRepo
					.findByUserAccount_UserAccountIdAndModeAndIsActive(userAccountId, mode, true);
			if (!userSecTransAuditList.isEmpty()) {
				transAudit = userSecTransAuditList.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return transAudit;
	}

	/**
	 * M08
	 */
	@Override
	public void updateUserSecTransAudit(Long userSecTransAuditId) {
		try {
			userSecTransAuditRepo.userSecTransAuditActiveUpdate2(userSecTransAuditId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

}
