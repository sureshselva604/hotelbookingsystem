package com.seind.rc.services.user.data;

public class BrowserInfo {
	
		public String getBrowserInfo(String information) {
			String browsername = "";
			String browserversion = "";
			String browser = information;
			if (browser.contains("MSIE")) {
				String subsString1 = browser.substring(browser.indexOf("MSIE"));
				String[] info1 = (subsString1.split(";")[0]).split(" ");
				browsername = info1[0];
				browserversion = info1[1];
			} else if (browser.contains("Firefox")) {

				String subsString2 = browser.substring(browser.indexOf("Firefox"));
				String[] info2 = (subsString2.split(" ")[0]).split("/");
				browsername = info2[0];
				browserversion = info2[1];
			} else if (browser.contains("Chrome")) {

				String subsString3 = browser.substring(browser.indexOf("Chrome"));
				String[] info3 = (subsString3.split(" ")[0]).split("/");
				browsername = info3[0];
				browserversion = info3[1];
			} else if (browser.contains("Opera")) {

				String subsString4 = browser.substring(browser.indexOf("Opera"));
				String[] info4 = (subsString4.split(" ")[0]).split("/");
				browsername = info4[0];
				browserversion = info4[1];
			} else if (browser.contains("Safari")) {

				String subsString5 = browser.substring(browser.indexOf("Safari"));
				String[] info5 = (subsString5.split(" ")[0]).split("/");
				browsername = info5[0];
				browserversion = info5[1];
			}
			return browsername + "-" + browserversion;
		}

}
