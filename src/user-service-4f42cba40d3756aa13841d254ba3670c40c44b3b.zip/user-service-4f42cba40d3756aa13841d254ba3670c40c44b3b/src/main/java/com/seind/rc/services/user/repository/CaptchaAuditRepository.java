package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.seind.rc.services.user.entities.CaptchaAudit;

import jakarta.transaction.Transactional;
@Transactional
public interface CaptchaAuditRepository extends JpaRepository<CaptchaAudit,Long> {
	
	@Modifying
    @Query(value = "update CaptchaAudit set LockStatus=:active,UnlockedDate=GETDATE(),UnlockedBy=1 where UserId=:userAccountId",nativeQuery = true)
    int captchaAuditUpdate(@Param("active")Boolean active,
    		                           @Param("userAccountId") Long userAccountId);

}
