package com.seind.rc.services.user.entities;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "HospitalSurgeon")
public class HospitalSurgeon {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HospitalSurgeonId")
	private Long hospitalSurgeonId;

	private Long hospitalId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SurgeonId")
	private Surgeon surgeon;

	private Boolean active;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	private Long createdBy;
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	private Long modifiedBy;

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "HospitalId",referencedColumnName = "hospitalId",insertable = false, updatable = false)
//	private List<HospitalPractice> hospitalPractice;

//	@OneToMany(mappedBy = "hospitalSurgeon")
//    private List<HospitalPractice> hospitalPracticeList;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "hospitalPractice", joinColumns = @JoinColumn(name = "HospitalId"), inverseJoinColumns = @JoinColumn(name = "hospitalId"))
	private List<HospitalPractice> hospitalPractice;

	@ManyToMany(mappedBy = "hospitalSurgeon")
	private List<HospitalPractice> hospitalPracticeList;

}
