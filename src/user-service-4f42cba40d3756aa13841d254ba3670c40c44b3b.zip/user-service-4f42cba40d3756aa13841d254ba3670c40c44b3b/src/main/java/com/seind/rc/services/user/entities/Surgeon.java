package com.seind.rc.services.user.entities;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
@Table(name = "Surgeon")
@JsonIgnoreProperties({ "active", "isdelete", "logo", "createdDate", "createdBy", "lastModifiedDate", "lastModifiedBy",
		"salutation", "surgeonNPI" })
public class Surgeon {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long surgeonId;
	private String degree;
	@Column(name = "FirstName", nullable = false)
	private String firstName;
	@Column(name = "LastName", nullable = false)
	private String lastName;
	private String title;
	private String email;
	private Boolean active;
	private Boolean isdelete;
	private String logo;

	@OneToMany(mappedBy = "surgeon")
	private List<HospitalSurgeon> hospitalsurgeon;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CreatedBy")
	private UserAccount createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date lastModifiedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LastModifiedBy")
	private UserAccount lastModifiedBy;

	private String salutation;
	private Boolean customWorkflow;
	private Long surgeonNPI;

	@Transient
	private String imagePath;

	public String getImagePath() {
		return logo;
	}

}