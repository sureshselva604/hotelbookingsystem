package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PhoneTypeData {
	
	private Long phoneTypeId;
	private String phoneTypeDesc;
	private Integer seqNo;
	private Boolean active;

}
