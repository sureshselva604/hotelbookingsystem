package com.seind.rc.services.user.service.servicesimp;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.entities.CNSugProcPayer;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.repository.CNSugProcPayerRepository;
import com.seind.rc.services.user.service.CNSugProcPayerService;

@Service
public class CNSugProcPayerServiceImpl implements CNSugProcPayerService {

	private static final Logger LOGGER = LogManager.getLogger(CNSugProcPayerServiceImpl.class);

	@Autowired
	private CNSugProcPayerRepository cNSugProcPayRepo;

	/**
	 * M01
	 */
	@Override
	public List<CNSugProcPayer> getCNSugProcPayerBypayorAndtypeAndSurgeonUaIdAndpracticeid(PatientStageWorkflow patSWF,
			Long userAccountKey) {
		List<CNSugProcPayer> cNSugProc = null;
		try {
			cNSugProc = cNSugProcPayRepo.findByproceduretypeAndPayoridAndSurgeonUaIdAndPracticeid(
					patSWF.getProcedureType(), patSWF.getPayorId(), patSWF.getHspSurgId(), userAccountKey);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return cNSugProc;
	}

}
