package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserExistsReqData {
	
	@Default
	private String oldEmail= "";
	@Default
	private String newEmail = "";
	@Default
	private String oldPhone = "";
	@Default
	private String newPhone = "";
	@Default
	private String addOrEdit = "";
	private Long updatingProfileRole;

}
