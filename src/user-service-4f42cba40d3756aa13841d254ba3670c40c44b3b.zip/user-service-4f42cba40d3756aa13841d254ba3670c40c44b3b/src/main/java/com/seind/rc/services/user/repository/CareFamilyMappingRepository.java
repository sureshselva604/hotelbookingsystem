package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.CareFamilyMapping;

public interface CareFamilyMappingRepository extends JpaRepository<CareFamilyMapping, Long>{
	
	List<CareFamilyMapping> findByHospitalIdAndActiveTrue(Long hospitalId);

	List<CareFamilyMapping> findByUserAccIdOrUserAccIdIsNullAndHospitalIdOrHospitalIdIsNullAndPayorTypeIdOrPayorTypeIdIsNullAndProcedureTypeOrProcedureTypeIsNullAndActiveTrueAndClientId(
			Long hspSurgId, Long hospitalId, Long payorId, String procedureType, Long practiceId);

}
