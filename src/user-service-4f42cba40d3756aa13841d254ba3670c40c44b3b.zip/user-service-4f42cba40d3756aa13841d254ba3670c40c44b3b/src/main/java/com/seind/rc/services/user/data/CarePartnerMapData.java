package com.seind.rc.services.user.data;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CarePartnerMapData {
	
	private Long carePartnerMapId;
	private Long userAccountId;
	private Long patientId;
	private Boolean verified;
	

}
