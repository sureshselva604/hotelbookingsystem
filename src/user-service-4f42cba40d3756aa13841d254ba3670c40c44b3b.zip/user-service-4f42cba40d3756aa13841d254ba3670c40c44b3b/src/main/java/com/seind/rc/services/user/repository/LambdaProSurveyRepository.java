package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.LambdaProSurvey;

public interface LambdaProSurveyRepository extends JpaRepository<LambdaProSurvey, Long>{

	List<LambdaProSurvey> findByZoneIdOrderByPatientSWFId(Long zoneId);
}