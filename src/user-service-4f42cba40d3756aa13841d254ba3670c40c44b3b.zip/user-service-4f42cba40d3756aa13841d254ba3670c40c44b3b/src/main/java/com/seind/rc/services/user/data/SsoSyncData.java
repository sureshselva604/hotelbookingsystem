package com.seind.rc.services.user.data;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class SsoSyncData {
	private String userName;
	private String firstName;
	private String lastName;
	private String phNum;
	private String userPwd;
	private int count;
	private String secretKey;
	private String rcHspName;
	private String rcAccType;
	private String rcHspId;
	private Long rcAccountId;
	private Long quesId1;
	private Long quesId2;
	private Long quesId3;
	private String ans1;
	private String ans2;
	private String ans3;
	private boolean status;
	private boolean welcomeFlag;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date activatedDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date modifiedDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date expDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date userPwdCreatedOn;
	private String title;
	private Long onBoardId;
	private Long hroId;
	private String teleCode;
	private String fromPortal;
	private String apiName;
	private String error;
}
