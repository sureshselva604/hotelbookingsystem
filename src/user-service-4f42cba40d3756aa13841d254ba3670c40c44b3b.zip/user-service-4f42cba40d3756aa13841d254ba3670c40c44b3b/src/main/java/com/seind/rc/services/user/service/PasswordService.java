package com.seind.rc.services.user.service;

import com.seind.rc.services.user.data.ChangePasswordData;
import com.seind.rc.services.user.data.ForgotPwdUserDatas;
import com.seind.rc.services.user.data.PasswordUpdateData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SecurityQuestionAnswerData;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.UserSecQuesObjData;
import com.seind.rc.services.user.data.ValidateDobData;
import com.seind.rc.services.user.entities.UserAccount;

public interface PasswordService {

	ResponseMessage resetPassword(String emailId);

	void updatePwdForBothSingleOrMultiRoleUserAcctByEmailOrPhone(UserAccount userAcct, String flag);

	PasswordUpdateData updateUserPassWord(UpdatePwdData pwdData, PasswordUpdateData passwordData);

	ResponseMessage saveSecurityQuestions(UserSecQuesObjData secQuesObjData);
	
	ResponseMessage validateSelectedQuestnAnsByUser(SecurityQuestionAnswerData payload, ResponseMessage response);

	ResponseMessage getForgotSecurityAnswerByUser(String randId);

	ResponseMessage isValidSecurityDict(String encodedSecurityDict);

	ResponseMessage isLastUsedPassword(String userPassword , Long userId);

	ResponseMessage isAccountActiveORBlocked(String randomId);

	ForgotPwdUserDatas getForgotPasswordInfo(UserRequestData payload);

	ResponseMessage savePasswordHistory(String userPassword, Long userId);

	ResponseMessage validateDOB(ValidateDobData request);
	
	ResponseMessage changePassword(ChangePasswordData changePasswordData, Long userId);

}