package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class ProfileQuestionsList {
	
	private List<ProfileQuestionsDetails> profileQuestions;

}
