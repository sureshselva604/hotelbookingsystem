package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.seind.rc.services.user.data.HospitalOverlapSurgeonsData;
import com.seind.rc.services.user.entities.HospitalSurgeon;

import feign.Param;

public interface HospitalSurgeonRepository extends JpaRepository<HospitalSurgeon, Long> {

	List<HospitalSurgeon> findByHospitalId(Long hospitalId);

	List<HospitalSurgeon> findBySurgeon_SurgeonIdAndHospitalIdOrderByHospitalSurgeonIdDesc(Long surgeonId,
			Long hospitalId);

	List<HospitalSurgeon> findBySurgeon_SurgeonId(Long userAccountKey);

	List<HospitalSurgeon> findDistinctBySurgeon_SurgeonIdOrderByHospitalSurgeonIdDesc(Long userAccountKey);

	HospitalSurgeon findFirstByHospitalId(Long hospitalId);

	// TODO todo Service
	List<HospitalSurgeon> findDistinctByHospitalPractice_practiceIdAndHospitalPractice_IsOverLapTrue(Long practiceId);

	List<HospitalSurgeon> findDistinctByHospitalIdAndSurgeon_SurgeonIdNotIn(Long practiceId, List<Long> surgeonIds);
	
	List<HospitalSurgeon> findByHospitalPractice_PracticeId(Long practiceId);

	List<HospitalSurgeon> findDistinctByHospitalIdAndSurgeon_SurgeonIdIn(Long hospitalId,List<Long> surgeonIdList);
	
	@Query(value = "select distinct hs.surgeonId from HospitalPractice hp "
			+ " join HospitalSurgeon hs on hs.hospitalId = hp.practiceId "
			+ " join HospitalPractice hpp on hpp.practiceId = hp.practiceId "
			+ " join Hospital h on hp.hospitalId=h.hospitalId and h.directClient = 1"
			+ " join Surgeon s on s.surgeonId = hs.surgeonId "
			+ " join UserAccount ua on ua.userAccountKey = hs.surgeonId "
			+ " join HospitalSurgeon hss on hss.hospitalId = hpp.hospitalId and hs.surgeonId = hss.surgeonId "
			+ " join Hospital p on p.hospitalId = hp.practiceId and p.directClient = 1 "
			+ " join Hospital oh on oh.hospitalId = hp.hospitalId and oh.directClient = 1 "
			+ " where hpp.practiceId = :practiceId and hpp.hospitalId in :raHospitalIds and hpp.isOverlap = 1", nativeQuery = true)
	List<HospitalSurgeon> fetchRaHospitalIsOverlap(@Param("practiceId") Long practiceId,
			@Param("raHospitalIds") List<Long> raHospitalIds);


	@Query(value = " SELECT NEW com.seind.rc.services.user.data.HospitalOverlapSurgeonsData(hs.surgeon.surgeonId,ua.userAccountId,s.firstName,s.lastName,s.salutation,h.name as oLPracName,h.name as oLHspName, "
			+ " false as isOverLap,false as practiceId,h.hospitalId )" + " from HospitalSurgeon  hs  "
			+ " join  Surgeon s on s.surgeonId = hs.surgeon.surgeonId  "
			+ " join Hospital h on h.hospitalId = hs.hospitalId  "
			+ " join UserAccount ua on ua.userAccountKey = hs.surgeon.surgeonId "
			+ " where hs.hospitalId = :hsHospitalId and "
			+ " hs.surgeon.surgeonId not in ( select  distinct hs2.surgeon.surgeonId from HospitalSurgeon hs2  "
			+ " join HospitalPractice hp on hp.practiceId= hs2.hospitalId and hp.isOverLap=true "
			+ " where  hp.hospitalId = :hpHospitalId ) "
			+ " and hs.surgeon.surgeonId not in(select distinct hnsmm.surgeonId from HospitalNavigatorSugMapping  hnsmm  "
			+ " join  UserAccount ua on ua.userAccountId = hnsmm.hNUserid and ua.userAccountKey = :userAccountKey and ua.userGroupId = 33) ")
	List<HospitalOverlapSurgeonsData> getRaHospitalOverlapSurgeonsThree(@Param("hsHospitalId") Long hsHospitalId,
			@Param("hpHospitalId") Long hpHospitalId, @Param("userAccountKey") Long userAccountKey);

	HospitalSurgeon findDistinctBySurgeon_SurgeonIdAndHospitalIdNotAndSurgeon_SurgeonIdNot(Long surgeonId,
			Long hospitalId, Long defaultSurgeonId);
}
