package com.seind.rc.services.user.entities;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "UserGroupHspPracMap")
public class UserGroupHspPracMap {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserGroupHspPracMapId", unique = true, nullable = false)
	private Long userGroupHspPracMapId;
	private Long userGroupId;
	@Column(name="HospitalPracticeId")
	private Long hospitalPracticeId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="HospitalPracticeId",insertable = false,updatable = false)
	private HospitalPractice hspPractice;
	
	

}
