package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class ForgotAttemptData {
	
	
	private String userName;
	private Long userAccountId;
	private Integer forgotattemptFailed;
	private Boolean accountBlocked;
	private Boolean isForgotSecurityQuest;	

	
}
