package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class CountryCodeMapData {
	private String countryCode;
	private String countryName;
	private Long countryCodeId;
	private String teleCode;

}
