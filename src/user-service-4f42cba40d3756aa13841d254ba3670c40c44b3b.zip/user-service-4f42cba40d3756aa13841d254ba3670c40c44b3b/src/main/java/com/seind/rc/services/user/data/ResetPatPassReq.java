package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class ResetPatPassReq {
	
	private String userName;
	private String password;
	private String randomId;

}
