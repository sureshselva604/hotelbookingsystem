package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "CNSurgeon")
public class CNSurgeon {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cnsurgeonId", unique = true, nullable = false)
	private int cNSurgeonId;
	private int practiceId;
	private int cnAccountId;
	private int surgeonId;
	private int surgeonAccountId;
	private int createdBy;
	private Date createdDate;

}
