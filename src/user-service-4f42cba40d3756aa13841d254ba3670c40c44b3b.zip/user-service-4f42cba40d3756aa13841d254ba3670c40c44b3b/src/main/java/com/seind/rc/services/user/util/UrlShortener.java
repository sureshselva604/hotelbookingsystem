package com.seind.rc.services.user.util;

import java.nio.charset.StandardCharsets;
import java.util.ResourceBundle;

import org.apache.commons.validator.routines.UrlValidator;
import org.apache.logging.log4j.LogManager;  import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.hash.Hashing;
import com.seind.rc.services.user.entities.ShortURL;
import com.seind.rc.services.user.repository.ShortURLRepository;

@Component
public class UrlShortener {
	Logger logger = LogManager.getLogger(UrlShortener.class);
	
	@Autowired
	private ShortURLRepository shortURLRepo;
	

	public String shortenUrlDummy(String longURL) {
		return longURL;
	}

	ResourceBundle rb = ResourceBundle.getBundle("application");

	public String shortenURL(String longURL, Long userAccountId) {
		logger.debug("longURL : {}" , longURL);
		final String url = longURL;
		final UrlValidator urlValidator = new UrlValidator(new String[] { "http", "https" });
		if (urlValidator.isValid(url)) {
			final String shortKey = Hashing.murmur3_32().hashString(url, StandardCharsets.UTF_8).toString();
			logger.debug("{}--{}" ,shortKey, url);
			insertIfNotyExist(shortKey, url, userAccountId);
			return rb.getString("pserverurl") + shortKey;
		} else {
			return longURL;
		}
	}
	
	public Boolean insertIfNotyExist(String shortKey, String longURL, Long userAccountId) {
		Boolean isExist = false;
		ShortURL sURL = null;
		try {
			sURL = shortURLRepo.findByShortKey(shortKey);

			if (sURL != null) {
				isExist = true;
			}

		} catch (Exception e) {
			logger.error("Select ShortURL - 1 ", e);
		}
		if (!isExist) {
			try {
				sURL.setLongURL(longURL);
				sURL.setShortKey(shortKey);
				sURL.setUserAccountId(userAccountId);
				shortURLRepo.save(sURL);
			} catch (Exception e) {
				logger.error("Insert ShortURL - 2  ", e);
			}

		}
		return isExist;
	}

	

}