package com.seind.rc.services.user.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.InetAddressValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.BrowserInfo;
import com.seind.rc.services.user.data.ContactData;
import com.seind.rc.services.user.entities.Settings;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.SettingsRepository;
import com.twilio.Twilio;

import jakarta.servlet.http.HttpServletRequest;

@Component
public class RCUserUtil {

	@Autowired
	private SettingsRepository settingsRepository;

	private static final Logger logger = LogManager.getLogger(RCUserUtil.class);
	private static final ResourceBundle uriRB = ResourceBundle.getBundle("messages.uri");
	private static final ResourceBundle rs = ResourceBundle.getBundle("application");
	static String accessKey = rs.getString("accessKey");
	static String secretKey = rs.getString("secretKey");
	static String bucketName = rs.getString("bucketname");
	private static final String S3URL = rs.getString("awsS3RealPath");
	public static Map<String, List<Settings>> settingsMap = null;

	public static final String ACCOUNT_SID = "ACc95a891f79515c829b90be09194bf278";
	public static final String AUTH_TOKEN = "3c4f482abe6cce0ed32163d1d523d34b";

	public static String getStringValue(String data) {
		return data != null && !data.isBlank() ? data : "";
	}

	public static boolean getBoolean(String key) {
		return key == null ? true : false;
	}

	public static Long getLong(Long data) {
		return data != null ? data : 0L;
	}

	@SuppressWarnings("rawtypes")
	public static boolean isNullOrEmptyList(List li) {
		return li == null || li.isEmpty();
	}

	public static String getString(String string) {
		return string != null ? string : "";
	}

	public static String getStringNull(String string) {
		return string != null ? string : null;
	}

	public static boolean stringContains(String data) {
		return data != null && !data.isBlank() ? true : false;
	}

	public static String getUserContactDetail(String data) {
		return data != null && !data.isBlank() ? data.trim() : null;
	}

	public static Random getRandom() throws NoSuchAlgorithmException {
		return SecureRandom.getInstanceStrong();
	}

	public static String getStringIsEmpty(String userTitle) {
		return !userTitle.isEmpty() ? userTitle : null;
	}

	public static String getDefaultImgPath(String gender) {
		String imgPath;
		if (gender.equalsIgnoreCase("Male"))
			imgPath = uriRB.getString("defaultMaleImgPath");
		else
			imgPath = uriRB.getString("defaultFemaleImgPath");
		return imgPath;
	}

	public static void makeFpDirectory(File fileFolder) {
		if (!fileFolder.exists()) {
			fileFolder.mkdirs();
		}
	}

	public static AmazonS3Client getS3Client() {
		logger.debug("S3Client");
		AWSCredentials creds = null;
		String s3Bucket = rs.getString("S3Bucket");
		if (s3Bucket.equalsIgnoreCase("Live")) {
			creds = new BasicAWSCredentials(accessKey, secretKey);
			return (AmazonS3Client) AmazonS3Client.builder().withCredentials(new AWSStaticCredentialsProvider(creds))
					.build();
		} else {
			creds = new BasicAWSCredentials(accessKey, secretKey);
			return (AmazonS3Client) AmazonS3ClientBuilder.standard()
					.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(
							S3URL.replaceAll(bucketName, ""), Regions.US_EAST_2.name()))
					.withPathStyleAccessEnabled(true).withCredentials(new AWSStaticCredentialsProvider(creds)).build();
		}
	}

	public static Boolean isPhoneNotNull(UserAccount userAccount) {
		Boolean result = false;
		if (userAccount != null && userAccount.getTeleCode() != null && !userAccount.getTeleCode().isEmpty()
				&& userAccount.getPhone() != null && !userAccount.getPhone().isEmpty()) {
			result = true;
		}
		return result;
	}

	public static String changeFirstLetterCaps(String data) {
		String firstLetter = data.substring(0, 1).toUpperCase();
		String restLetters = data.substring(1);
		return (firstLetter + restLetters).trim();
	}

	public static String getComType(String email, String phone) {
		String comType = "NONE";
		if (email != null && !email.isEmpty() && !email.contains(CommonConstant.MYRECOVERYCOACH_MAIL) && phone != null
				&& !phone.isEmpty()) {
			comType = "BOTH";
		} else if (email != null && !email.isEmpty() && !email.contains(CommonConstant.MYRECOVERYCOACH_MAIL)
				&& (phone == null || phone.isEmpty())) {
			comType = CommonConstant.EMAIL;
		} else if (email != null && email.isEmpty() && phone != null && !phone.isEmpty()) {
			comType = "SMS";
		} else {
			comType = "NONE";
		}
		return comType;
	}

	public static String getNonEmptyString(String data) {
		return data != null && !data.isBlank() ? data : null;
	}

	public static String rcEncrypt(String value) {
		try {
			value = new StringEncrypter("DES").encrypt(value);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return value;
	}

	public static Cipher getCipher(String encryptionScheme) throws NoSuchAlgorithmException, NoSuchPaddingException {
		return Cipher.getInstance(encryptionScheme);
	}

	public static String replaceNullValueIntoEmpty(String input) {
		return input.replace(":null", ":\"\"");
	}

	public static boolean ValidatePhone(String phone, String countyCode) {
		String errorcode = "";
		try {
			Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
			com.twilio.rest.lookups.v1.PhoneNumber phoneNumber = com.twilio.rest.lookups.v1.PhoneNumber
					.fetcher(new com.twilio.type.PhoneNumber(phone)).setCountryCode(countyCode)/*** IND,US ***/
					.setType(Arrays.asList("carrier")).fetch();
			// logger.debug(phoneNumber.getCarrier());
			Map<String, String> mss1 = phoneNumber.getCarrier();
			errorcode = mss1.get(" ");
			if (errorcode == null) {
				return true;
			}
		} catch (Exception e) {
			logger.error(e);
			errorcode = e.getMessage();
			if (errorcode.contains(" was not found")) {
				return false;
			}
			return false;
		}
		return false;
	}

	public static String rcDecrypt(String value) {
		try {
			value = new StringEncrypter("DES").decrypt(value);
		} catch (Exception e) {
			logger.error(e);
		}
		return value;
	}

	public static String setUserName(String email) {
		String defaultUserName = GenerateOTP.getAlphaNumericForUserName();
		if (email.isEmpty()) {
			return defaultUserName;
		} else {
			return email;
		}
	}

	public static Boolean setIsOnboardLink(String email, String phone) {
		if ((!email.isEmpty() && !email.contains(CommonConstant.MYRECOVERYCOACH_MAIL)) || !phone.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static String getStringNullOrEmpty(String string) {
		return string != null && !string.isEmpty() ? string : "";
	}

	public static String[] returnPhoneValues(String phoneValue) {
//		logger.info(phoneValue + "phoneValue");
		String[] phoneWCodes = phoneValue.split("-");
		String telCode = phoneWCodes[0];
		String phoneNumber = phoneWCodes[1];
		telCode = "+" + telCode.replace("+", "");
		return new String[] { telCode, phoneNumber };
	}

	public static String getNonEmptyWithBlank(String input) {
		return (input == null || StringUtils.trim(input).isEmpty()) ? "" : input;
	}

	public void threadShutdown(ExecutorService executorService) {
		if (executorService != null) {
			executorService.shutdown();
			try {
				if (!executorService.awaitTermination(800, TimeUnit.MILLISECONDS)) {
					executorService.shutdownNow();
				}
			} catch (Exception e) {
				executorService.shutdownNow();
				logger.error(CommonConstant.EXCEPTION, e);
			}
		}
	}

	public static String getPhoneWithCode(UserAccount userAccount) {
		String phone = "";
		if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(userAccount))) {
			phone = userAccount.getTeleCode().concat("-").concat(userAccount.getPhone());
		}
		return phone;
	}

	public static boolean isValidEmailAddress(String email) {
		boolean result = true;
		try {
			if (email != null && !email.isBlank()) {
				String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
						+ "A-Z]{2,7}$";
				Pattern pat = Pattern.compile(emailRegex);
				result = pat.matcher(email).matches();
			}
		} catch (Exception ex) {
			result = false;
		}
		return result;
	}

	public static Boolean isValidMobileNo(String phoneNoWithOutTelecode, Long length) {
		boolean setTrueStatus = true;
		String regex = "\\d{" + length + "}";
		return phoneNoWithOutTelecode != null && !phoneNoWithOutTelecode.isBlank()
				? phoneNoWithOutTelecode.matches(regex)
				: setTrueStatus;
	}

	public static String singleStrCondition(boolean condtionExp, String trueValue, String falseValue) {
		return condtionExp ? trueValue : falseValue;
	}

	public void saveLoginHistory(String userName, String passWord, String mode, HttpServletRequest request) {
		try {
			String ipAddress = "";
			String browser = "";
			if ((mode.equalsIgnoreCase("web") || mode.equalsIgnoreCase("captcha")) && request != null) {
				ipAddress = getClientIPAddressV1(request);
				String browserType = request.getHeader("User-Agent");
				BrowserInfo browserInfo = new BrowserInfo();
				browser = browserInfo.getBrowserInfo(browserType);
			} else {
				ipAddress = "Device";
				browser = "App";
			}

			saveLoginHistory(userName, passWord, mode, ipAddress, browser);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	public void saveLoginHistory(String userName, String passWord, String mode, String ipAddress, String browser) {
		try {/**
				 * UserAccount user =
				 * userService.validateUserNew(userName).stream().findFirst().orElse(null);
				 * String encryptedPassword = user.getUserPwd(); Boolean passwordValid =
				 * passWord.equalsIgnoreCase(encryptedPassword) ? true : false; LoginHistory
				 * login = new LoginHistory(); login.setUserName(userName);
				 * login.setPassword(passWord); login.setMode(mode);
				 * login.setIPAddress(ipAddress); login.setBrowser(browser);
				 * login.setPasswordValid(passwordValid); login.setUserAccountId(user);
				 * loginRepo.save(login);
				 **/
		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
		}
	}

	public static boolean userAllowedforList(List<Long> listAlready, UserAccount userAcct) {
		return userAcct != null && userAcct.getCareFamilyShow() != null
				&& (userAcct.getUserGroup().getUserGroupId() == 9l || userAcct.getUserGroup().getUserGroupId() == 17)
				&& userAcct.getCareFamilyShow() && !listAlready.isEmpty()
				&& !listAlready.contains(userAcct.getUserAccountId());
	}

	public static List<String> getModeList() {
		List<String> modeList = new ArrayList<String>();
		modeList.add("ForgetPassword");
		modeList.add("Blocked-Login");
		modeList.add("Blocked-SecurityAnswer");
		modeList.add("UnBlocked-SecurityAnswer");
		modeList.add("Reset-SecurityQA");
		modeList.add("NewlySet-SecurityQA");
		return modeList;
	}

	public String getServerPath() {
		String filePath = "";
		try {
			String pathselection = rs.getString("PathSelection");
			if (pathselection.equalsIgnoreCase("DB")) {
				String hostedModel = rs.getString("HostedModel");
				filePath = getSettingValue(hostedModel, "DeviceStorage");
			} else {
				filePath = rs.getString("LocalPath");
			}
		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
		}
		return filePath;
	}

	public static void copyFolderbyFile(File sourceFile, File destFile) {
		try {
			if (sourceFile.exists())
				FileUtils.copyFile(sourceFile, destFile);
		} catch (FileNotFoundException fn) {
			logger.error("File Not Found Exception ...{}", fn.getMessage());
		} catch (IOException e) {
			logger.error("Error .... {}", e.getMessage());
		} catch (Exception e) {
			logger.error("Error .... ", e);
		}
	}

	public String getSettingValue(String name, String category) {
		loadSettingsMap(false);
		List<Settings> settingsList = settingsMap.getOrDefault(category, new ArrayList<>());
		Optional<Settings> settings = settingsList.stream().filter(s -> name.equalsIgnoreCase(s.getName())).findAny();
		// logger.info(name + "-" + category + ":" + (settings.isPresent() ?
		// settings.get().getValue() : ""));
		return settings.isPresent() ? settings.get().getValue() : "";
	}

	public String getSettingsValue(String category, String name) {
		String value = "";
		try {
			value = getSettingValue(name, category);
		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
		}
		return value;
	}

	public void loadSettingsMap(Boolean forceLoad) {
		if (settingsMap == null || forceLoad) {
			settingsMap = settingsRepository.findAll().stream().collect(Collectors.groupingBy(Settings::getCategory));
		}
	}

	public static String emailAndPhoneUpdateCheck(ContactData data, String welcomeOnboardLink) {
		boolean phoneCheck = (data.getOldPhone() == null && !data.getNewPhone().isBlank())
				|| (data.getOldPhone() != null && !data.getOldPhone().equals(data.getNewPhone()));

		boolean emailCheck = (data.getOldEmail() == null && !data.getNewEmail().isBlank())
				|| (welcomeOnboardLink.equalsIgnoreCase("Y") && data.getOldEmail() != null
						&& !data.getOldEmail().equals(data.getNewEmail()));

		return phoneCheck && emailCheck ? "Both" : (phoneCheck ? "Phone" : (emailCheck ? "Email" : ""));
	}

	public boolean emailAndPhoneCheck(String oldEmail, String newEmail, String oldPhone, String newPhone,
			String welcomeOnboardLink) {
		boolean exists = false;

		if (!welcomeOnboardLink.equalsIgnoreCase("Y") && oldEmail != null && !oldEmail.equals(newEmail)
				&& oldPhone != null && oldPhone.equals(newPhone)) {
			exists = true;
		}
		if (oldPhone != null && oldPhone.isBlank()) {
			exists = true;
		}
		return exists;
	}

	public static String getExistEmailandUpdatedEmailEqual(String willSendOnBoardWelcomeLink,
			String existEmailAndNewEqual, String oldPhone, String phone) {
		if (willSendOnBoardWelcomeLink.equalsIgnoreCase("Y") && existEmailAndNewEqual.equalsIgnoreCase("true")
				&& oldPhone != null && !oldPhone.equals(phone)) {
			existEmailAndNewEqual = CommonConstant.FALSE;
		}
		return existEmailAndNewEqual;
	}

	public static String getExistPhoneandUpdatedPhoneEqual(String oldPhone, String phone,
			String existPhoneAndNewEqual) {
		if (oldPhone == null && RCUserUtil.getNonEmptyString(phone) != null) {
			existPhoneAndNewEqual = CommonConstant.FALSE;
		}
		return existPhoneAndNewEqual;
	}

	public static UserAccount inActiveMailSmsTrack(UserAccount userAccount, String oldEmailId, String oldPhone,
			String email, String phone) {
		if (oldPhone != null && phone != null && !oldPhone.equals(phone)) {
			userAccount.setPhoneValid(false);
		}
		if (oldEmailId != null && email != null && !oldEmailId.equals(email)) {
			userAccount.setEmailValid(false);
		}
		return userAccount;
	}

	public static String passwordDecoder(String password) {
		byte[] decodedBytes = Base64.getDecoder().decode(password);
		String decodedBytePwd = new String(decodedBytes);
		return decodedBytePwd;
	}

	public static List<UserAccount> getUserAccountsIfStringContains(String value,
			Function<String, List<UserAccount>> accountRetrievalFunction) {
		return RCUserUtil.stringContains(value) ? accountRetrievalFunction.apply(value) : Collections.emptyList();
	}
	
	public static String getClientIPAddressV1(HttpServletRequest request) {
        String remoteAddr = "InValid IP";
        if (request != null) {
            remoteAddr = request.getHeader("X-FORWARDED-FOR")==null?request.getHeader("X-FORWARDED-HOST"):request.getHeader("X-FORWARDED-FOR");
            if (remoteAddr == null || "".equals(remoteAddr)) {
                remoteAddr = request.getRemoteHost();
            }
        }
        if (remoteAddr.contains(",")) {
            String[] s = remoteAddr.split(",");
            remoteAddr = s[0];
        }
        boolean ipFlag = false;
        InetAddressValidator validator = InetAddressValidator.getInstance();
         
        if (validator.isValidInet4Address(remoteAddr)) {
            ipFlag=true;
        }else if(validator.isValidInet6Address(remoteAddr)) {
            ipFlag=true;
        }
        if(ipFlag) {
            return remoteAddr;
        }
        return remoteAddr;
    }
	
	public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
		Map<Object, Boolean> seen = new ConcurrentHashMap<>();
		return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}
}
