package com.seind.rc.services.user.service;

import java.util.List;
import java.util.Optional;

import com.seind.rc.services.user.data.CarePlanAssesmentsUserData;
import com.seind.rc.services.user.data.CarePlanUserOrchAssessment;
import com.seind.rc.services.user.data.ConfigurableData;
import com.seind.rc.services.user.data.CountryDischargeMapData;
import com.seind.rc.services.user.data.CustomTodoForMultiPatient;
import com.seind.rc.services.user.data.DashBoardCarePlanUserData;
import com.seind.rc.services.user.data.DashboardTodoInfoBean;
import com.seind.rc.services.user.data.DashboardTransactionBean;
import com.seind.rc.services.user.data.DashboardTransactionData;
import com.seind.rc.services.user.data.DownloadSummaryPatientData;
import com.seind.rc.services.user.data.HospitalData;
import com.seind.rc.services.user.data.HospitalOverlapData;
import com.seind.rc.services.user.data.HospitalOverlapSurgeonsData;
import com.seind.rc.services.user.data.HospitalPraticeData;
import com.seind.rc.services.user.data.PacPostValidationBean;
import com.seind.rc.services.user.data.PacPreValidationBean;
import com.seind.rc.services.user.data.PatientData;
import com.seind.rc.services.user.data.PatientDetails;
import com.seind.rc.services.user.data.PatientReadmissionShowData;
import com.seind.rc.services.user.data.PatientStageWorkflowData;
import com.seind.rc.services.user.data.PracticeOverlapViewData;
import com.seind.rc.services.user.data.PreRequisiteTodoRaDTO;
import com.seind.rc.services.user.data.RaTodoOverlapPreRequisiteBean;
import com.seind.rc.services.user.data.TodoInfoBean;
import com.seind.rc.services.user.data.TodoRACareUserBean;
import com.seind.rc.services.user.data.TodoRAPracticeOverlapHospital;
import com.seind.rc.services.user.data.TodoReAssignUserBean;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.NonOverlapViewOnDemand;
import com.seind.rc.services.user.entities.OverlapViewOnDemand;
import com.seind.rc.services.user.entities.PatientInfoAllTodoView;
import com.seind.rc.services.user.entities.UserAccount;

public interface TodoService {
	public List<PatientInfoAllTodoView> fetchPatientSwfInfoForFetchingAllTodo(Long clientId,
			List<PatientInfoAllTodoView> clientLevelPatLists);

	Long findHospitalIdBySurgeonId(Long userAccountKey);

	Long findSelectedCnUaId(List<Long> loginUserGroupIdStr1List, TodoInfoBean todoInfoBean1);

	public List<Long> fetchRaTodoOverlapHospitalFilterOnSurgeonsBasis(Long userAccountKey, String raHospitalIds,
			boolean raHospitalIsOverlap);

	public Optional<UserAccount> getUserAccountByUserAccountId(Long loginUserAccountId);

	public List<UserAccount> getUserAccountBycnIds(List<Long> loginUserAccountId);

	public Optional<Hospital> fetchHospitalByLoginCredential(Long loginPracticeOrHspId1);


	public List<Long> getCNListByPSG(Long hospitalId, Long ugid, UserAccount userAccount);

	PatientStageWorkflowData getPatientStageWorkflowByPatientSWFId(Long patientSWFId);

	public PatientData getPatientStageWorkflowByPatient(Long patientId);

	public HospitalData getHospitalDataByHospitalId(Long hospitalId);

	public String getHospitalAndPracticeById(Long hospitalPracticeId);

	public UserAccountData getUserAccountDataByPatientd(Long patientId);

	public List<CountryDischargeMapData> getCountryDischargeMapByCountryCodeId(Long countryCodeId);

	public HospitalPraticeData findHospitalPracticeById(Long hospitalPracticeId);

	public PatientDetails getCarePatnerDetails(Long patientId);

	public OverlapViewOnDemand getOverLapPatientDetails(Long patientSWFId);

	public NonOverlapViewOnDemand getNonOverLapPatientDetails(Long patientSWFId);

	public String getPatientStageWorkflowDetails(Long patientSWFId);

	public List<TodoRACareUserBean> fetchRACareUserListForTodoPracticeOverlap(HospitalOverlapData practiceOverlapData);

	public List<TodoRACareUserBean> fetchHospitalOverlapData(HospitalOverlapData hospitalOverlapData);

	List<HospitalOverlapSurgeonsData> fetchTodoRAHospitalOverlapSurgeons(Long loginUaId);

	public boolean fetchRaTodoOverlapPreRequisiteInfo(RaTodoOverlapPreRequisiteBean raTodoOverlapPreRequisiteBean);

	public List<TodoRAPracticeOverlapHospital> getTodoRAPracticeOverlapHospitals(Long loginUaId);

	public DashBoardCarePlanUserData fetchDashBoardUserDataByPatientSwfId(Long patientSwfId);

	public DashboardTodoInfoBean preRequisiteDashboardMyTodo(DashboardTodoInfoBean dashboardTodoInfoBean);

	public CarePlanAssesmentsUserData fetchCarePlanUsersDataByPatientSwfId(Long patientSwfId);

	public PacPostValidationBean executeIfOpLocationMapIsNotNull(PacPreValidationBean preValidationBean);

	public DownloadSummaryPatientData fetchDashboardCarePlanList(DashboardTransactionData dt);

	public ConfigurableData getHospitalDataByPatientStageWorkflowDetails(Long patientSWFId);

	public PatientReadmissionShowData willReAdmissionBeShown(Long patientSWFId);

	public String saveDashboardTransaction(DashboardTransactionBean dashboardTransactionBean);

	public CarePlanUserOrchAssessment fetchHospitalDataByloginCnUaId(Long loginUaId, Long patientswfId);

	public CustomTodoForMultiPatient saveCustomTodoForMultiPatients(List<Long> patientSwfIdList);

	public List<PatientDetails> getCarePatnerDetailsByPatientIds(List<Long> patientId);

	public TodoReAssignUserBean reassingTodo(TodoReAssignUserBean todoReAssignUserBean);

	public List<PatientInfoAllTodoView> buildClientLevelPatListWhenSearch(String search,
			List<PatientInfoAllTodoView> clientLevelPatList, Long clientId,String pracOrHsp);

	public List<PatientInfoAllTodoView> buildClientLevelPatListWhenFilter(TodoInfoBean todoInfoBean1,
			List<PatientInfoAllTodoView> clientLevelPatList);
	
	public PreRequisiteTodoRaDTO   draftOverlapLoopNotCompleted(PreRequisiteTodoRaDTO preRequisiteTodoRaDTO);

}
