package com.seind.rc.services.user.service;

import com.seind.rc.services.user.data.CheckValidationData;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.WelcomeInfoData;

public interface OnboardService {

	WelcomeInfoData getPatientWelcomeInfo(UpdatePwdData pwdData, WelcomeInfoData welcomeInfoData);

	CheckValidationData checkUserValidation(UserRequestData payload);

}
