package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class PSWFNotifyData{

	private Long PatientSWFId;
	private Long PatientId;
	private Long HSP_CC_Id;
	private Date DOS;
	private Long servicelineId;
	private String laterality;
}
