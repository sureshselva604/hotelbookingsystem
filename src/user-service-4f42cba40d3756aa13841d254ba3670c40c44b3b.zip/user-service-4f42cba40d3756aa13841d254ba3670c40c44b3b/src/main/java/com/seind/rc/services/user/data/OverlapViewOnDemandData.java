package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class OverlapViewOnDemandData {
	private Long patientSwfId;
	private Long uaCcHspOrPracId;
	private Long uaSecCcHspOrPracId;
	private Long hospitalPracticeId;
	private Long hspSugId;
	private Long servicelineId;
	private Long payorType;
	private String procedureType;

}
