package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class CarePlanAssesmentsUserData {
	
	private Long hSpCcId;
	private Long useraccountKey;
	private Integer countryCodeId;
	private Long patientId;
	private Long weight;
	private Long height;
	private Long inch;
	private String bmi;
	private String countryCode;
	private Long patientswfId;
	

}