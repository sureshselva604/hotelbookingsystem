package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.AdmissionMaster;


public interface AdmissionMasterRepository extends JpaRepository<AdmissionMaster, Long> {

}
