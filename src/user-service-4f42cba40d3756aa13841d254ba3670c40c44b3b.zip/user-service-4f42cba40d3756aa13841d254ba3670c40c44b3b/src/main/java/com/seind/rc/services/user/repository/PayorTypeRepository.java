package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PayorType;

public interface PayorTypeRepository extends JpaRepository<PayorType, Long>{

	public List<PayorType> findByCountryCodeId(Long countryCodeId);
}
