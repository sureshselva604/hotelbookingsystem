package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class TodoRAPracticeOverlapHospital {

	private String sosCategory;
	private String overlappedClientName;
	private boolean multiStatus;
	private List<TodoRAHospitalBean> reAssignHospitalBeanList;
}
