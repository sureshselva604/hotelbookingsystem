package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class CasSecDetails
{
	private String question;
	private String answer;
	private String password;
	private Date pwdCreatedOn;
	private Long question1;
	private String answer1;
	private Long question2;
	private String answer2;
	private Long question3;
	private String answer3; 
}