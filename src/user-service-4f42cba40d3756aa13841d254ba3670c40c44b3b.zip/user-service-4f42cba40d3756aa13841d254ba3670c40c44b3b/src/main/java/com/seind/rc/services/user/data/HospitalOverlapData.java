package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class HospitalOverlapData {

	private Long loginUaId; 
	private Boolean isSelectedPracticeOverlap;
	private Long overlapSelectedPracticeId;
	private Long nonOverlapSelectedSosId;
	
	private Long careUserUaId;
	private String careUserName;
	private String careUserUgName;
	private Long careUserUgId;
	private String clientName;
	private String userGroupName;
}
