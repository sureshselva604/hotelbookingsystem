package com.seind.rc.services.user.data;

import java.util.List;

import com.seind.rc.services.user.entities.PatientDashBoardTransaction;

import lombok.Data;

@Data	
public class DownloadSummaryPatientData {
	private List<PatientDashBoardTransaction>  patientDashBoardTransaction;
	private String mode;
	private String userGroupName;
	private DownloadSummaryInfoBean downloadBean;
	private Long countryCodeId;
	private String countryCodeDateFormat;
	private List<PatientDetails> carePatnerDetailsList;
	private String filePath;
	

}
