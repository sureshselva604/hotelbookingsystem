package com.seind.rc.services.user.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.seind.rc.services.user.data.TempPatientStageworkflow;
import com.seind.rc.services.user.entities.PatientInfoAllTodoView;
import com.seind.rc.services.user.entities.PatientStageWorkflow;

import feign.Param;

@Repository
public interface PatientStageWorkflowRepository extends JpaRepository<PatientStageWorkflow, Long> {

	List<PatientStageWorkflow> findPatientSWFIdByPatient_PatientId(Long patientId);

	Long countByPswIsActiveAndPatient_PatientId(Boolean active, Long patientId);

	List<PatientStageWorkflow> findByPatient_PatientIdAndPswIsActiveTrueOrderByPatientSWFIdDesc(Long patientId);

	List<PatientStageWorkflow> findByPatient_PatientIdOrderByPatientSWFIdDesc(Long patientId);

	List<PatientStageWorkflow> findByHospitalPractice_HospitalPracticeIdIn(List<Long> hospitlPraticeIdList);
	
	List<PatientStageWorkflow> findByHspCCIdInAndHspCCSecidInAndHospitalPractice_HospitalIdAndHospitalPractice_IsOverLapTrue(
			List<Long> hspccid, List<Long> hspccid1, Long hospitalPracticeId);
	

	List<PatientStageWorkflow> findByHspCCIdInAndHspCCSecidNotInAndHospitalPractice_HospitalIdInAndHospitalPractice_IsOverLapFalse(
			List<Long> hspccid, List<Long> hspccid1, List<Long> hospitalpraticeIdList);
	
	List<PatientStageWorkflow> findByHspCCIdIn(List<Long> useraccountId);

	List<PatientInfoAllTodoView> findByPatientSWFIdAndHospitalPractice_HospitalPracticeIdNot(Long patientSwfId,
			Long firstSOSId);
	
	@Query(value=" select PSW.patientSWFId,PSW.currentPac from PatientStageWorkflow PSW "
				+ "JOIN Patient Pa on PSW.patientId = Pa.patientId "
				+ "JOIN UserAccount UA on (PSW.hspCCId = UA.userAccountId or PSW.hspCCSecid = UA.userAccountId) and UA.userAccountKey= :userAccountkey "
				+ "where PSW.pswIsActive = true ")
	List<Object[]> getDownloadList(@Param("useraccountkey") Long  userAccountkey);
	
	List<PatientStageWorkflow> findByPatient_PatientId(Long patientId);
		
	PatientStageWorkflow findByPatientSWFIdAndHspCCIdIsNotNull(Long patientSWFId);
	
	List<PatientStageWorkflow> findByPayorIdIsNotAndCCUserAccount_UserAccountKeyAndDosBetween(Long payerType,
			Long useraccountkey, Date startdos, Date enddos);

	List<PatientStageWorkflow> findByPayorIdEqualsAndCCUserAccount_UserAccountKeyAndDosBetween(Long payerType,
			Long useraccountkey, Date startdos, Date enddos);

	List<PatientStageWorkflow> findByPswIsActiveTrueAndPatientIdAndCCUserAccount_UserAccountKeyOrSECUserAccount_UserAccountKey(
			Long patientId, Long hospitalId, Long practiceId);
	
	@Query("SELECT DISTINCT NEW com.seind.rc.services.user.data.TempPatientStageworkflow(psw.patientSWFId,psw.currentEpisodeId) " +
	           "FROM PatientStageWorkflow psw " +
	           "JOIN UserAccount ua ON ua.userAccountKey = psw.patientId " +
	           "WHERE psw.pswIsActive = true AND ua.active = True AND ua.welcomeFlag = False")
	List<TempPatientStageworkflow> findDistinctPatientSWF();
	
	List<PatientStageWorkflow> findDistinctByPatientSWFIdInAndHospitalPractice_Hospital_AllowPatNotificationTrueAndHospitalPractice_Hospital_isAppmntOptedTrueAndPswIsActiveTrueAndPatient_ComTypeIsNotNull(
			List<Long> patientswfIdList);

	List<PatientStageWorkflow> findByHospitalPractice_Hospital_HospitalIdAndHospitalPractice_HospitalPracticeIdInAndHspSurgIdInAndBpciAndProcedureTypeInAndDosBetween(
			Long hospitalId, List<Long> hospitalpracticeId, List<Long> surgeonId, String bpcia, List<String> procedureType,
			Date dosFrom, Date dosTo);

	List<PatientStageWorkflow> findByHospitalPractice_Hospital_HospitalIdAndBpciAndDosBetween(
			Long clientId, String bpcia, Date dosFrom, Date dosTo);

	List<PatientStageWorkflow> findByHospitalPractice_Hospital_HospitalIdAndHspSurgIdInAndBpciAndProcedureTypeInAndDosBetween(
			Long clientId, List<Long> surgeonIdList, String bpcia, List<String> procedureTypeList, Date dosFromDate,
			Date dosToDate);
	
	List<PatientStageWorkflow> findByPatientSWFIdIn(List<Long> patientSWFIds);

	List<PatientStageWorkflow> findByHspCCId(Long hspCcId);
}
