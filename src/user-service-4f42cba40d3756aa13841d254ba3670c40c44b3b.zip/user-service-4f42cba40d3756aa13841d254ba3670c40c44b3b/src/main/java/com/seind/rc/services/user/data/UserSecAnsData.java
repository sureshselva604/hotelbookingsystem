package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UserSecAnsData {
	
	private String userPassword;
	private Boolean isCarePartner;
	private Long userAccountId;

}
