package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.seind.rc.services.user.entities.UserSecCodeAudit;

import jakarta.transaction.Transactional;
@Transactional
public interface UserSecCodeAuditRepository extends JpaRepository<UserSecCodeAudit, Long> {

	@Modifying
	@Query(value = "update UserSecCodeAudit set Status=:status where Userid=:userAccountId", nativeQuery = true)
	int userSecCodeAuditUpdate(@Param("status") Boolean status, @Param("userAccountId") Long userAccountId);

	List<UserSecCodeAudit> findByUserAccount_UserAccountIdAndStatus(Long userId, Boolean status);

	List<UserSecCodeAudit> findByUserAccount_UserAccountIdAndStatusAndModeLike(Long userId, Boolean status, String upperCase);
}
