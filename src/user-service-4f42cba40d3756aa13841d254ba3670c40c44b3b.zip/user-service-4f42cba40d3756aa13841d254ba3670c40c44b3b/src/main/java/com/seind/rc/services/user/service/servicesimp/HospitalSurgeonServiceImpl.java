package com.seind.rc.services.user.service.servicesimp;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.data.HospitalSurgeonDeviceData;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.service.HospitalSurgeonService;

@Service
public class HospitalSurgeonServiceImpl implements HospitalSurgeonService {

	private static final Logger LOGGER = LogManager.getLogger(HospitalSurgeonServiceImpl.class);

	@Autowired
	private PatientStageWorkflowRepository pswfRepo;

	@Autowired
	private HospitalSurgeonRepository hspSugRepo;

	/**
	 * M01
	 */
//	@Override
//	public HospitalSurgeon getHospitalSurgeonById(Long hospitalSurgeonId) {
//		Optional<HospitalSurgeon> hspSug = null;
//		try {
//			hspSug = hspSugRepo.findById(hospitalSurgeonId);
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return hspSug.isPresent() ? hspSug.get() : null;
//	}

	/**
	 * M02 HospitalSurgeonDeviceData for device firstTimeSync
	 */
	@Override
	public HospitalSurgeonDeviceData getHospitalSurgeonInfoByPatientId(Long patientId) {
		HospitalSurgeonDeviceData hspSugDeviceData = new HospitalSurgeonDeviceData();
		try {
			List<PatientStageWorkflow> pswf = pswfRepo.findByPatient_PatientId(patientId);
			if (!pswf.isEmpty()) {
				if (pswf.get(0).getHospitalSurgeonId() != null) {
					hspSugDeviceData.setSurgeonId(pswf.get(0).getHospitalSurgeon().getSurgeon().getSurgeonId());
					hspSugDeviceData.setHospitalId(pswf.get(0).getHospitalSurgeon().getHospitalId());
					hspSugDeviceData.setHospitalSurgeonId(pswf.get(0).getHospitalSurgeonId());
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return hspSugDeviceData;
	}

	/**
	 * M03
	 */
	@Override
	public HospitalSurgeon getHospitalSurgeonByPatientId(Long patientId) {
		HospitalSurgeon hospitalSurgeon = null;
		try {
			List<PatientStageWorkflow> pswf = pswfRepo.findByPatient_PatientId(patientId);
			hospitalSurgeon = hspSugRepo.findById(pswf.get(0).getHospitalSurgeonId()).orElse(null);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return hospitalSurgeon;
	}

}
