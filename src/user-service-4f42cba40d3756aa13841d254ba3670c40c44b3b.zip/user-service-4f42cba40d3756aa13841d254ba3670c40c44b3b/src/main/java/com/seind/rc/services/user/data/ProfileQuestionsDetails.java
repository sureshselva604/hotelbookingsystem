package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class ProfileQuestionsDetails {
	
	private String questionId;
	private String question;
	private String answer;

}
