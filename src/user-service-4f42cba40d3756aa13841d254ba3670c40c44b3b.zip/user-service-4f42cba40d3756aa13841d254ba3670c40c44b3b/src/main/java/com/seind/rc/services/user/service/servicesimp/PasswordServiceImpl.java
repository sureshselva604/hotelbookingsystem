package com.seind.rc.services.user.service.servicesimp;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.config.KafkaConfiguration;
import com.seind.rc.services.user.constants.CasCommonConstant;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.NotificationConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.ChangePasswordData;
import com.seind.rc.services.user.data.ForgotPwdUserDatas;
import com.seind.rc.services.user.data.NotifyReqData;
import com.seind.rc.services.user.data.PasswordUpdateData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.ResponseMessageSSO;
import com.seind.rc.services.user.data.SecurityQuestionAnswerData;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.UserSecQuesObjData;
import com.seind.rc.services.user.data.ValidateDobData;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.MenuConfiguration;
import com.seind.rc.services.user.entities.PasswordHistory;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.entities.UserPwdAudit;
import com.seind.rc.services.user.entities.UserRequestAudit;
import com.seind.rc.services.user.entities.UserSecResultDetails;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.MenuConfigurationRepository;
import com.seind.rc.services.user.repository.PasswordHistoryRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.SecurityDictRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserGroupRepository;
import com.seind.rc.services.user.repository.UserPwdAuditRepository;
import com.seind.rc.services.user.repository.UserRequestAuditRepository;
import com.seind.rc.services.user.repository.UserSecCodeAuditRepository;
import com.seind.rc.services.user.repository.UserSecResDetRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.CarePartnerMapService;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.HospitalSurgeonService;
import com.seind.rc.services.user.service.NotificationService;
import com.seind.rc.services.user.service.PasswordService;
import com.seind.rc.services.user.service.PatientService;
import com.seind.rc.services.user.service.SSOService;
import com.seind.rc.services.user.service.SurgeonService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecResDetService;
import com.seind.rc.services.user.service.UserSecTransAuditService;
import com.seind.rc.services.user.util.DCCPUtil;
import com.seind.rc.services.user.util.DateUtil;
import com.seind.rc.services.user.util.GenerateOTP;
import com.seind.rc.services.user.util.OnBoardUtil;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.SSOSyncUtil;
import com.seind.rc.services.user.util.StringEncrypter;
import com.seind.rc.services.user.util.StringEncrypter.EncryptionException;

@Service
public class PasswordServiceImpl implements PasswordService {

	private static final Logger LOGGER = LogManager.getLogger(PasswordServiceImpl.class);

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private CarePartnerMapService careService;

	@Autowired
	private PatientService patientService;

	@Autowired
	private HospitalSurgeonRepository hspSugRepo;

	@Autowired
	private UserSecResDetService userSecResService;

	@Autowired
	private UserSecTransAuditRepository userSecAuditRepo;

	@Autowired
	private UserRequestAuditRepository userReqAuditRepo;

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private PasswordHistoryRepository passwordHistoryRepo;

	@Autowired
	private SecurityDictRepository securityDictRepo;

	@Autowired
	private UserSecTransAuditService userSecTransAuditService;

	@Autowired
	private SSOService ssoService;

	@Autowired
	private UserAccountRepository userAccountRepo;

	@Autowired
	private HospitalService hspService;

	@Autowired
	private SurgeonService surgService;

	@Autowired
	private MenuConfigurationRepository menuConfigRepo;

	@Autowired
	private UserSecResDetRepository userSecResDetRepo;

	@Autowired
	private HospitalService hospitalService;

	@Autowired
	private UserGroupRepository userGroupRepo;

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private HospitalSurgeonService hospitalSurgeonService;

	@Autowired
	private DCCPUtil dcUtil;

	@Autowired
	private SSOSyncUtil ssoUtil;

	@Autowired
	private OnBoardUtil obUtil;

	@Autowired
	private KafkaConfiguration kafka;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private PatientStageWorkflowRepository pswfRepo;

	@Autowired
	private HospitalRepository hspRepo;

	@Autowired
	private UserPwdAuditRepository userPwdAuditRepo;

	@Autowired
	private UserSecCodeAuditRepository userSecCodeRepo;

	private static final ResourceBundle rs = ResourceBundle.getBundle("application");
	private static final String MODE = "ForgetPassword";
	private static final String RESETVALUE = "ResetPassword";
	private static final String PENDING = "pending";
	private static final String DEACTIVE_ACCOUNT = "deactiveAccount";
	private static final String ACCOUNTBLOCKED = "accountBlocked";
	private static final String ONBOARD = "onboard";
	private static final String SUCCESS = "Success";
	private static final String FAILURE = "Faliure";

	private static final String WRONGANSWER = "WrongAnswer";
	private static final String MMDDYYYY = "MMDDYYYY";
	private static final String SECURITYQUESTIONS = "SecurityQuestions";
	private static final String UNAUTHORIZED_ACCESS = "Unauthorized Access";

	/**
	 * M01
	 * 
	 * User is able to resetPassword based on Conditions
	 */
	@Override
	public ResponseMessage resetPassword(String emailId) {
		ResponseMessage response = new ResponseMessage();
		try {
		
			if (!RCUserUtil.getStringValue(emailId).isEmpty()) {
				UserAccount userAccount = userAccountService.validateUserNew(emailId).stream().findFirst().orElse(null);
				boolean invalidCpLogin = getInvalidCpLogin(userAccount);
				if (userAccount == null) {
					response.setStatus(CommonConstant.FAILURE);
					response.setMessage("Invalid email address!");
				}
				else if(invalidCpLogin){
					response.setStatus(CommonConstant.FAILURE);
					response.setMessage("Care Partner is not active");	
				}
				else {
					boolean resetAllowed = getResetAllowedStatus(userAccount);
					if (resetAllowed) {
						resetPassword(response, userAccount, emailId);
						userSecAuditRepo.userSecTransAuditActiveUpdate(userAccount.getUserAccountId(),
								new ArrayList<>(Arrays.asList("PasswordUpdate")));
					} else {
						response.setStatus(CommonConstant.FAILURE);
						response.setMessage(
								"Your account has been deactivated. If you have any questions, please contact patient care.");
					}
				}
			} else {
				response.setStatus(CommonConstant.FAILURE);
				response.setMessage("Email Required");
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M02
	 * 
	 * @param userAccount
	 * @return true/false CarePartner Login validation
	 */
	private boolean getInvalidCpLogin(UserAccount userAccount) {
		boolean invalidCpLogin = false;
		if (userAccount != null && userAccount.getUserGroup().getUserGroupId() == UserGroupCons.CARE_PARTNER) {
			Boolean multiAcc = false;
			int cpActiveCount = 0;
			List<CarePartnerMap> list = careService.getCarePartnerPatientList(userAccount.getUserAccountId());
			cpActiveCount = list != null ? list.size() : 0;
			List<UserAccount> userList = userAccountService.getUsersByEmailId(userAccount.getEmail(),
					(userAccount.getPhone() != null ? userAccount.getTeleCode() + "-" + userAccount.getPhone() : ""));
			if (userList != null && userList.size() > 1) {
				multiAcc = true;
			}
			if (!multiAcc && cpActiveCount == 0) {
				invalidCpLogin = true;
			}
		}
		return invalidCpLogin;
	}

	/**
	 * M03
	 * 
	 * @param userAccount
	 * @return resetAllowed status getResetAllowedStatus for Patient and CarePartner
	 */
	private boolean getResetAllowedStatus(UserAccount userAccount) {
		boolean resetAllowed = true;
		int activeBodypart = 0;
		if ((userAccount.getUserGroup().getUserGroupId()).equals(UserGroupCons.PATIENT)) {
			activeBodypart = patientService.activeBodypart(userAccount.getUserAccountKey());
			if (activeBodypart == 0) {
				resetAllowed = false;
			}
		} else if ((userAccount.getUserGroup().getUserGroupId()).equals(UserGroupCons.CARE_PARTNER)) {
			boolean bodyPartStatus = false;
			List<PatientStageWorkflow> pswList = pswfRepo.findByPatient_PatientId(userAccount.getWhoseCarePartner());
			bodyPartStatus = pswList.stream().anyMatch(a -> a.getPswIsActive().equals(true));

			if (!bodyPartStatus) {
				activeBodypart = patientService.activePatientBodypartforCP(userAccount.getUserAccountId());
				if (activeBodypart == 0) {
					resetAllowed = false;
				}
			}
		}
		return resetAllowed;
	}

	/**
	 * M04
	 * 
	 * Update random password in sso and notify the user based on conditions
	 */
	private void resetPassword(ResponseMessage response, UserAccount userAccount, String email) {
		String randId = UUID.randomUUID().toString();
		String newPwd = GenerateOTP.getAlphaNumericRandomPwd();
		try {
			String languageCode = userAccountService.getLanguageCode(userAccount);
			if (!userAccount.getIsdelete()) {
				UserSecTransAudit secTransAudit = new UserSecTransAudit();
				secTransAudit.setUserAccount(userAccount);
				secTransAudit.setIsActive(true);
				secTransAudit.setCreatedOn(new Date());
				secTransAudit.setRandomId(randId);
				secTransAudit.setMode("ForgetPassword");
				userSecTransAuditService.saveUserSecTransAudit(secTransAudit);
				Hospital hospital = hospitalService.getHospitalIdForAnyUserAccount(userAccount);
				if (userAccount.getActive()) {
					if (userAccount.getWelcomeFlag()) {
						userAccountRepo.save(userAccount);
						notifyResetPwdUser(userAccount, hospital,response);
						updateSsoDetails(userAccount, newPwd);
					} else {
						resetPwdForActivatedUser(userAccount, response, hospital, randId, languageCode);
					}
				} else {
					response.setMessage(getSettingsValue(ACCOUNTBLOCKED, languageCode));
				}
				response.setStatus(CommonConstant.SUCCESS);
				response.setUserName(email);
				response.setAllowPasswordChange(userAccount.getUserPwdCreatedOn() != null
						&& DateUtil.hoursDiff(userAccount.getUserPwdCreatedOn(), new Date()) >= 24);
				response.setUserGroupId(userAccount.getUserGroup().getUserGroupId());

			} else {
				response.setStatus(CommonConstant.FAILURE);
				response.setMessage(getSettingsValue(DEACTIVE_ACCOUNT, languageCode));

			}
		} catch (Exception e) {
			response.setStatus(CommonConstant.FAILURE);
			response.setMessage("Unexpected error occured! Please try again!");
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M05
	 */
	private void resetPwdForActivatedUser(UserAccount userAccount, ResponseMessage response, Hospital hospital,
			String randId, String languageCode) {
		try {
			if (hospital != null && hospital.getAvailSecurity()) {
				response.setAvailSecurity(hospital.getAvailSecurity());
			} else {
				UserSecResultDetails userSec = userSecResService
						.getUserSecResultDetails(userAccount.getUserAccountId());
				Long userGroupId = userAccount.getUserGroup().getUserGroupId();
				if (userSec == null && !userGroupId.equals(UserGroupCons.PATIENT)
						&& !userGroupId.equals(UserGroupCons.CARE_PARTNER)) {
					saveForgotSecurityAnsLinkDetails(userAccount, "Initiate-SecurityQA");
					response.setMessage(getSettingsValue("resetSecurityQuestionsMail", languageCode));
				} else {
					if (!userGroupId.equals(UserGroupCons.PATIENT) && !userGroupId.equals(UserGroupCons.CARE_PARTNER)) {
						response.setMessage(getSettingsValue("displaySecurityQuestions", languageCode));
						response.setRandId(randId);
						response.setStatus1("showingQueNAns");

					} else {
						response.setStatus1("validateDOB");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M06
	 */
	private void updateSsoDetails(UserAccount userAccount, String newPwd) {
		try {
			String ssoEnabled = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_ENABLED_STATUS);
			if (ssoEnabled.equalsIgnoreCase("Yes")&&UserGroupCons.addUserCheck.contains(userAccount.getUserGroup().getUserGroupId())) {
					String hroUrl = ssoUtil.getSSOAPIURL(CasCommonConstant.HRO_LBL);
					LOGGER.info(hroUrl);
					ssoUtil.passwordUpdateSSO(RCUserUtil.rcEncrypt(userAccount.getEmail()), userAccount.getUserPwd(),
							hroUrl);
				String onBoardAccountId = userAccount.getRcOnBoardId() != null && userAccount.getRcOnBoardId() > 0
						? userAccount.getRcOnBoardId().toString()
						: "";
				LOGGER.info(onBoardAccountId);

				/*** Security ***/
				String onboardUrl = ssoUtil.getSSOAPIURL(CasCommonConstant.ONBOARD);
				LOGGER.info(onboardUrl);
				ResponseMessageSSO body = ssoUtil.checkUserExists(userAccount.getEmail(), onboardUrl);
				LOGGER.info(body.toString());
				if (body.getStatus() != null) {
					if (Boolean.TRUE.equals(body.getStatus())) {
						updatePasswordOfOnboard(RCUserUtil.rcEncrypt(newPwd), userAccount.getEmail());
					}
					updateDccpPwd(RCUserUtil.getStringValue(userAccount.getEmail()), newPwd);
				}
			}
		} catch (Exception e) {
			LOGGER.error("SSO update error : ", e);
		}
	}

	/**
	 * M07
	 */
	public void updatePasswordOfOnboard(String pwd, String userName) {
		try {
			String obUrl = ssoUtil.getSSOAPIURL("onboard");
			ssoUtil.passwordUpdateSSO(new StringEncrypter("DES").encrypt(userName),
					new StringEncrypter("DES").encrypt(pwd), obUrl);
			UserAccount user = ssoService.getSSOUserAccountByUserName(userName);
			ssoService.resetUserSecCodeAudit(user);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M08
	 */
	private void updateDccpPwd(String username, String pwd) {
		try {
			String dccpUserExist = dcUtil.checkUserExistsInDCCP(username);
			if (dccpUserExist != null && dccpUserExist.equalsIgnoreCase("true")) {
				dcUtil.updatePwdInDCCP(username, pwd, "0");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M09
	 */
	private String notifyResetPwdUser(UserAccount userAccount, Hospital hospital,ResponseMessage response) {
		String responseMsg = "";
		try {
			String notifyType = NotificationConstant.FORGOTPWDBEFOREACTIVATION;
			NotifyReqData reqData = new NotifyReqData();
			reqData.setToUser(userAccount.getUserAccountId());
			reqData.setHspId(hospital.getHospitalId());
			reqData.setNotificationType(notifyType);
			response.setNotifyData(List.of(reqData));
			if (userAccount != null) {
				switch (userAccount.getComType()) {
				case "EMAIL":
					responseMsg = "Activation instructions sent to your registered email address";
					break;
				case "SMS":
					responseMsg = "Activation instructions sent to your registered phone number";
					break;
				default:
					responseMsg = "Activation instructions sent to your registered email address and phone Number";
					break;
				}
			}
			response.setMessage("User Not Yet Activated");
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return responseMsg;
	}

	/**
	 * M10
	 */
	@Override
	public ResponseMessage getForgotSecurityAnswerByUser(String randId) {
		ResponseMessage response = new ResponseMessage();
		String languageCode = "default";
		try {
			UserAccount userAccount = getUserAccountByRandomId(randId.trim(), MODE);
			userAccount = userAccount == null ? getUserAccountByRandomId(randId.trim(), RESETVALUE) : userAccount;
			if (userAccount != null && (userAccount.getIsdelete() == null || !userAccount.getIsdelete())) {
				languageCode = userAccountService.getLanguageCode(userAccount);
				String value = getSettingsValue("contactCsrTeam", languageCode);
				response.setSuccess(value);
				saveForgotSecurityAnsLinkDetails(userAccount, "ForgetSecurityAnswer");
			} else {
				response.setFail(getSettingsValue(DEACTIVE_ACCOUNT, languageCode));
			}
		} catch (Exception e) {
			response.setFail(CommonConstant.FAIL);
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M11
	 */
	private UserAccount getUserAccountByRandomId(String randId, String mode) {
		try {
			List<UserSecTransAudit> userAcct = userSecAuditRepo.findByRandomIdAndModeAndIsActive(randId, mode, true);
			if (!userAcct.isEmpty()) {
				return userAcct.get(0).getUserAccount();
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	/**
	 * M13
	 */
	public Long saveForgotSecurityAnsLinkDetails(UserAccount useracc, String mode) {
		List<UserRequestAudit> userRequestAuditList = null;
		try {
			userRequestAuditList = userReqAuditRepo
					.findByUserAccount_UserAccountIdAndModeAndStatus(useracc.getUserAccountId(), mode, PENDING);
			if (userRequestAuditList == null || userRequestAuditList.isEmpty()) {
				UserRequestAudit userReqAudit = new UserRequestAudit();
				userReqAudit.setUserAccount(useracc);
				userReqAudit.setMode(mode);
				userReqAudit.setStatus(PENDING);
				userReqAudit.setCreatedOn(new Date());
				userReqAuditRepo.save(userReqAudit);

				userRequestAuditList = userReqAuditRepo
						.findByUserAccount_UserAccountIdAndModeAndStatus(useracc.getUserAccountId(), mode, PENDING);
				if (!userRequestAuditList.isEmpty()) {
					return userRequestAuditList.get(0).getUserRequestAuditId();
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	/**
	 * M14
	 */
	@Override
	public ResponseMessage isValidSecurityDict(String encodedSecurityDict) {
		ResponseMessage response = new ResponseMessage();
		try {
			String decodedBytePwd = RCUserUtil.passwordDecoder(encodedSecurityDict);
			String securityDict = RCUserUtil.rcEncrypt(decodedBytePwd.trim().toLowerCase());
			response = isValidSecurityDictCount(securityDict);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			response.setStatus(CommonConstant.FAILURE);
			response.setMessage(CommonConstant.INVALID_DATA);
		}
		return response;
	}

	/**
	 * M15
	 */
	private ResponseMessage isValidSecurityDictCount(String decodedFinalPwd) {
		ResponseMessage response = new ResponseMessage();
		try {
			Long count = securityDictRepo.countByIsActiveAndSecurityDictData(true, decodedFinalPwd);
			if (count > 0) {
				String failureData = getSettingsValue("PasswordSecurity", "DictionaryPassword");
				response.setStatus(CommonConstant.FAILURE);
				response.setMessage(failureData);
			} else {
				response.setStatus(CommonConstant.SUCCESS);
				response.setMessage("Valid Security Dict");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M16
	 */
	@Override
	public ResponseMessage isLastUsedPassword(String userPassword, Long userId) {
		ResponseMessage response = new ResponseMessage();
		try {
			List<PasswordHistory> pwdList = passwordHistoryRepo
					.findTop5ByUserAccount_UserAccountIdOrderByPwdIdDesc(userId);
			String decodedBytePwd = RCUserUtil.passwordDecoder(userPassword);
			String password = RCUserUtil.rcEncrypt(decodedBytePwd);
			response.setStatus(CommonConstant.SUCCESS);
			response.setMessage("Password can be used.");

			boolean passCheck = pwdList.stream().anyMatch(a -> a.getUserPwd().equals(password));

			if (passCheck) {
				response.setStatus(CommonConstant.FAILURE);
				response.setMessage(CommonConstant.PASSWORDCHECK);
			}

		} catch (Exception e) {
			LOGGER.error("Error while checking password history...", e);
		}
		return response;
	}

	/**
	 * M17
	 */
	@Override
	public ResponseMessage savePasswordHistory(String userPassword, Long userId) {
		ResponseMessage response = new ResponseMessage();
		try {
			UserAccount userAcct = userAccountRepo.findById(userId).orElse(null);
			if (!UserGroupCons.patientOrCP.contains(userAcct.getUserGroup().getUserGroupId())) {
				String decodedBytePwd = RCUserUtil.passwordDecoder(userPassword);
				String password = RCUserUtil.rcEncrypt(decodedBytePwd);
				PasswordHistory pwdHistory = new PasswordHistory();
				pwdHistory.setUserAccount(userAcct);
				pwdHistory.setUserPwd(password);
				pwdHistory.setCreatedDate(new Date());
				userSecTransAuditService.savePasswordHistory(pwdHistory);
			}
			userAcct.setTempPasswordActive(false);
			userAcct.setWelcomeFlag(false);
			userAcct.setUserActivationStatus(CommonConstant.COMPLETED);
			userAccountRepo.save(userAcct);
			updatePwdForBothSingleOrMultiRoleUserAcctByEmailOrPhone(userAcct, "tempPwdFlag");
			userSecAuditRepo.userSecTransAuditActiveUpdate(userAcct.getUserAccountId(),
					CasCommonConstant.modeListForUserSecTrans);
			response.setStatus(CommonConstant.SUCCESS);
		} catch (Exception e) {
			response.setStatus(CommonConstant.FAILURE);
			LOGGER.error("Error while saving password history...", e);
		}
		return response;
	}

	/**
	 * M18
	 */
	@Override
	public void updatePwdForBothSingleOrMultiRoleUserAcctByEmailOrPhone(UserAccount userAcct, String flag) {
		try {
			if (userAcct.getEmail() != null && !userAcct.getEmail().trim().isEmpty()) {
				if ((flag.equalsIgnoreCase("welcomeFlagChange")) || (flag.equalsIgnoreCase("welcomeFlagNotChange"))
						|| (flag.equalsIgnoreCase("tempPwdFlag"))) {
					updatePassword(userAcct, userAcct.getEmail(), "", "", flag);
				}
			} else if (userAcct.getPhone() != null && !userAcct.getPhone().trim().isEmpty()) {
				if ((flag.equalsIgnoreCase("welcomeFlagChange")) || (flag.equalsIgnoreCase("welcomeFlagNotChange"))
						|| (flag.equalsIgnoreCase("tempPwdFlag"))) {
					updatePassword(userAcct, "", userAcct.getPhone(), userAcct.getTeleCode(), flag);
				}
			}

			userSecCodeRepo.userSecCodeAuditUpdate(false, userAcct.getUserAccountId());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M19
	 */
	private void updatePassword(UserAccount userAcct, String email, String phone, String teleCode, String flag) {
		userAccountRepo.findByEmailOrPhoneWithTeleCode(email, teleCode + "-" + phone).stream()
				.filter(a -> !a.getUserAccountId().equals(userAcct.getUserAccountId())).map(userAccount -> {
					userAccount.setUserPwd(userAcct.getUserPwd());
					userAccount.setActive(userAcct.getActive());
					userAccount.setUserPwdCreatedOn(new Date());
					userAccount.setWrongPwdAttempt(0);
					if (!flag.equalsIgnoreCase("welcomeFlagNotChange")) {
						userAccount.setWelcomeFlag(userAcct.getWelcomeFlag());
					}
					if (flag.equalsIgnoreCase("welcomeFlagChange")) {
						userAccount.setUserActivationStatus(userAcct.getUserActivationStatus());
					}
					if (flag.equalsIgnoreCase("tempPwdFlag")) {
						userAccount.setTempPasswordActive(userAcct.getTempPasswordActive());
					}
					userAccountRepo.save(userAccount);
					return userAccount;
				});
	}

	/**
	 * M20
	 */
	@Override
	public ResponseMessage saveSecurityQuestions(UserSecQuesObjData secQuesObjData) {
		ResponseMessage response = new ResponseMessage();
		try {
//		NotificationUtil notificationUtil = new NotificationUtil();
//		CommonObjectDataV1 objDataV1=RCUtil.getEncJsonDomainV1(objStrValue);
			boolean status = true;
			UserSecTransAudit usta = userSecTransAuditService
					.getUserSecTransAuditByRandomId(secQuesObjData.getRandId().trim());
			UserAccount uacc = getUserAccountByRandomId(secQuesObjData.getRandId().trim(), usta.getMode());
			if (uacc == null) {
				response.setStatus(CommonConstant.FAILURE);
				response.setMessage(CommonConstant.USERVALIDATIONCHECK1);
				return response;
			}
			String userGroupId = String.valueOf(uacc.getUserGroup().getUserGroupId());
			boolean activeFlag = secQuesObjData.isActivation();
			final boolean isActivation = activeFlag;
			userSecTransAuditService.updateWelcomeflagForSecurityQuestion(uacc);
			if (activeFlag) {
				executeInsertOrUpdateUserSecResultDetails(userGroupId, secQuesObjData, uacc, isActivation);
			}
			UserSecTransAudit userSecTransAudit2 = userSecTransAuditService
					.fetchIPCaptureActiveUserSecTransAudit(uacc.getUserAccountId(), usta.getMode());
			userSecTransAuditService.updateUserSecTransAudit(userSecTransAudit2.getUserSecTransAuditId());

			status = uacc.getReenroll() == 1 ? false : true;
			Long hospitalId = hspService.getHospitalIdForAnyUserAccount(uacc).getHospitalId();
			Hospital hospital = hspRepo.findById(hospitalId).orElse(null);

			String notifyType = null;
			if (userGroupId.equals("19")) {
				Surgeon surgeon = surgService.getSurgeonByPatientId(uacc.getUserAccountKey());
//			LOGGER.debug(surgeon);
				if (isActivation) {
					notifyType = NotificationConstant.ACCOUNTACTIVATION;
//				NotificationData notifyObj = new NotificationData(notificationService, userService, notifyType, uacc, hospital);
//				notificationUtil.sendNotification(notifyObj);
				}
				/***
				 * TODO Notification if (usta.getMode().equalsIgnoreCase(ADD_USER)) {
				 * initiateExecutingBySendNotificationIfIsOnBoardLinkSent(uacc); }
				 */
			} else if (ifOtherUserGroupRoles(userGroupId) && isActivation) {
				notifyType = NotificationConstant.ACCOUNTACTIVATION;
//			NotificationDTO notifyObj = new NotificationDTO(notificationService, userService, notifyType, uacc, hospital);
//			notificationUtil.sendNotification(notifyObj);
			} else if (ifUserGroupId1Or2Or3Or4Or21Or22(userGroupId)) {
				if (isActivation) {
					notifyType = NotificationConstant.ACCOUNTACTIVATION;
//				NotificationDTO notifyObj = new NotificationDTO(notificationService, userService, notifyType, uacc, hospital);
//				notificationUtil.sendNotification(notifyObj);
				}
			} else if (userGroupId.equals("20")) {
				if (isActivation) {
					notifyType = NotificationConstant.ACCOUNTACTIVATION;
//				NotificationDTO notifyObj = new NotificationDTO(notificationService, userService, notifyType, uacc, hospital);
//				notificationUtil.sendNotification(notifyObj);
				}
//			sendExerciseNotificationToCP(uacc, hospital);
			}
			executeActivationUpdate(uacc, secQuesObjData);
			draftResponse(status, response);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			response.setStatus(CommonConstant.FAILURE);
		}
		return response;
	}

	/**
	 * M21
	 */
//	private void sendExerciseNotificationToCP(UserAccount uacc, Hospital hospital) {
//		try {
//			if (uacc.getUserGroup().getGroupName().equalsIgnoreCase(CARE_PARTNER)) {
//				List<CarePartnerMap> carePartnerMap = deviceService
//						.getActiveCarePartnerMapbyCpUseraccount(uacc.getUserAccountId());
//				for (CarePartnerMap cpmm : carePartnerMap) {
//					PatientStageWorkflow patSwf = pswfService.getPatientStageWorkflowByPatientId(cpmm.getPatientId()).get(0);
////					List<String> videoCountList = hospitalVideoMappingService
////							.getVideoCountByEpisodeIdAndStageWorkflowId(patSwf.getStageWorkflowId());
//					MenuConfiguration mcf = menuConfigSer.getMenuConfigByHospitalIdAndMenuId(hsp.getHospitalId(), 19l);
//					if (patSwf.getDos() != null && videoCountList.isEmpty() && cpUseracc.getWelcomeFlag() == 0 && mcf != null
//							&& Boolean.TRUE.equals(mcf.getStatus())
//							&& cpUseracc.getUserGroup().getGroupName().equalsIgnoreCase(CARE_PARTNER)) {
//						sendExerciseNotification(patSwf, cpUseracc);
//					}
//				}
//			}
//		} catch (Exception e) {
////			LOGGER.error(CommonConstant.EXCEPTION, e);
//		}
//	
//	}

	/**
	 * M22
	 */
	private boolean ifOtherUserGroupRoles(String userGroupId) {
		List<String> list = Arrays.asList("7", "9", "13", "27", "28", "40", "41", "30", "31", "32", "33", "34", "17",
				"18");
		return list.contains(userGroupId);
	}

	/**
	 * M23
	 */
	private boolean ifUserGroupId1Or2Or3Or4Or21Or22(String userGroupId) {
		List<String> list = Arrays.asList("1", "2", "3", "4", "21", "22");
		return list.contains(userGroupId);
	}

	/**
	 * M24
	 */
	private void executeActivationUpdate(UserAccount uacc, UserSecQuesObjData commonObject) {
		try {
			if (uacc != null) {
				userAccountService.activationUpdate(uacc.getUserAccountId(), commonObject.getActivationMode());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M25
	 */
	private void draftResponse(boolean status, ResponseMessage response) {
		try {
			if (status) {
				response.setStatus(SUCCESS);
				response.setMessage("Profile");
			} else {
				response.setStatus(SUCCESS);
				response.setMessage("Dashboard");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			response.setStatus(CommonConstant.FAILURE);
		}
	}

	/**
	 * M26
	 */
	private void initiateExecutingBySendNotificationIfIsOnBoardLinkSent(UserAccount uacc) {
		try {
//			NotificationUtil notificationUtil = new NotificationUtil();

			Patient pat = patientRepo.findById(uacc.getUserAccountKey()).orElse(null);
			UserAccount cnAccount = userAccountService
					.getUserAccountByUserAccountId(pat.getCreatedBy()/* .getUserAccountId() */);
			Hospital hospital = hspService.getHospitalById(cnAccount.getUserAccountKey());

			MenuConfiguration mcf = menuConfigRepo.findByMenuMenuIdAndHospitalHospitalId(19L, hospital.getHospitalId())
					.stream().findFirst().orElse(null);
			/***
			 * PatientStageWorkflow pswf1 =
			 * patientService.getPatientStageWorkflowByPatientId(pat.getPatientId()).get(0);
			 ***/
//			PatientStageWorkflow pswf1 = pswfService.getPatientStageWorkflowByPatientId(pat.getPatientId()).stream()
//					.filter(PatientStageWorkflow::isPswIsActive).collect(Collectors.toList()).get(0);
//
//			List<String> videoList = hospitalVideoMappingService
//					.getVideoCountByEpisodeIdAndStageWorkflowId(pswf1.getStageWorkflowId());
//			if (uacc.getWelcomeFlag() == 0 && mcf != null && Boolean.TRUE.equals(mcf.getStatus())
//					&& !videoList.isEmpty() && pswf1.getDos() != null) {
//				Surgeon sugTemp = userService.findSurgeonById(pswf1.getHospitalSurgeon().getSurgeon().getSurgeonId());
//				String notifyType = NotificationConstant.EXERCISENOTIFICATION;
//				NotificationData notifyObj = new NotificationDTO(notificationService, userService, notifyType, patUacc, hospital);
//				notifyObj.setSurgeon(sugTemp);
//				notifyObj.setPatient(pat);
//				notificationUtil.sendNotification(notifyObj);

			/*** NEW TYPE NOTIFICATION Starts ***/
			/***
			 * executeSendNotificationIfIsOnBoardLinkSent(patUacc, surgeon, emailContent1,
			 * smsContent, pswf1, hsp);
			 ***/
//			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M27
	 */
	private void executeInsertOrUpdateUserSecResultDetails(String userGroupId, UserSecQuesObjData secQuesVal,
			UserAccount uacc, boolean isActivation) {
		try {
			// LOGGER.debug(isActivation);
			if (!userGroupId.equals("19") && !userGroupId.equals("20")) {
				String questionOne = secQuesVal.getSecQuestionOne();
				String questionTwo = secQuesVal.getSecQuestionTwo();
				String questionThree = secQuesVal.getSecQuestionThree();

				String answerOne = secQuesVal.getSecQusAnswerOne();
				String answerTwo = secQuesVal.getSecQusAnswerTwo();
				String answerThree = secQuesVal.getSecQusAnswerThree();
				UserSecResultDetails userSecResDetail1 = userSecResService
						.getUserSecResultDetails(uacc.getUserAccountId());
				if (userSecResDetail1 == null) {
					userSecResDetail1 = new UserSecResultDetails();
				}
				userSecResDetail1.setUserAccountId(uacc.getUserAccountId());
				userSecResDetail1.setQuestion1(Long.valueOf(questionOne));
				userSecResDetail1.setQuestion2(Long.valueOf(questionTwo));
				userSecResDetail1.setQuestion3(Long.valueOf(questionThree));
				userSecResDetail1.setAnswer1(answerOne.trim());
				userSecResDetail1.setAnswer2(answerTwo.trim());
				userSecResDetail1.setAnswer3(answerThree.trim());
				userSecResDetail1.setCreatedOn(new Date());
				userSecResDetail1.setIrrelevantAns("No");
				userSecResDetail1.setWrongAnswerAttempts(0);
				userSecResDetail1.setMode("Web");
				String[] quesValues = { questionOne, questionTwo, questionThree };
				String[] ansValues = { answerOne, answerTwo, answerThree };
				/*** QA Fixes ***/
//				userAccountService.insertOrUpdateUserSecResultDetails(userSecId, userSecResDetail1);
				userSecResDetRepo.save(userSecResDetail1);

				/*** API Conversion ***/
				/***
				 * casSubFunc(uacc,quesValue,ansValue); obSubFunc(uacc, quesValue, ansValue,
				 * isActivation);
				 ***/
				processOnActivation(uacc, quesValues, ansValues);
				/*** API Conversion ***/
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M28
	 */
	private void processOnActivation(UserAccount uacc, String[] quesValues, String[] ansValues) {
		try {
			SsoSyncData data = new SsoSyncData();
			data.setUserName(uacc.getEmail());
			data.setWelcomeFlag(false);
			data.setUserPwd(uacc.getUserPwd());
			data.setUserPwdCreatedOn(new Date());
			data.setActivatedDate(new Date());
			data.setFromPortal("RC");
			data.setQuesId1(Long.parseLong(quesValues[0]));
			data.setQuesId2(Long.parseLong(quesValues[1]));
			data.setQuesId3(Long.parseLong(quesValues[2]));
			data.setAns1(ansValues[0]);
			data.setAns2(ansValues[1]);
			data.setAns3(ansValues[2]);

			String hroURL = ssoUtil.getSSOAPIURL("hro");
			String onboardURL = ssoUtil.getSSOAPIURL(ONBOARD);
			if (SSOSyncUtil.validSsoUser(uacc)) {
				if (uacc.getRcOnBoardId() == null || uacc.getRcOnBoardId() == 0L) {
					ResponseMessageSSO msgSSO = ssoUtil.checkUserExists(uacc.getEmail(), onboardURL);
					/** SSO Captcha **/
					// if (RCUtil.isJSONValid(body)) {
					boolean status = msgSSO.getStatus();
					if (status) {
						long rcObId = msgSSO.getUserId(); // "onBoardId";
						uacc.setRcOnBoardId(rcObId);
						uacc.setAllowOnboard(true);
						userAccountRepo.save(uacc);
					}
					// }
				}
				if (uacc.getRcOnBoardId() != null && uacc.getRcOnBoardId() != 0L) {
					obUtil.updateOnboardRCAccess(uacc);
				}
				ssoUtil.processOnActivation(data, hroURL);
				ssoUtil.processOnActivation(data, onboardURL);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in ProcessActivation: ", e);
		}
	}

	/**
	 * M29
	 */
	@Override
	public ResponseMessage isAccountActiveORBlocked(String randomId) {
		ResponseMessage response = new ResponseMessage();
		String languageCode = "";
		try {
			UserAccount userAccount = getUserAccountByRandomId(randomId.trim(), MODE);
			languageCode = userAccountService.getLanguageCode(userAccount);
			if (userAccount == null) {
				userAccount = getUserAccountByRandomId(randomId.trim(), RESETVALUE);
				response.setMode(RESETVALUE);
			} else {
				response.setMode(MODE);
			}
			if (userAccount != null && (userAccount.getIsdelete() == null || !userAccount.getIsdelete())) {
				if (userAccount.getActive()) {
					response.setStatus(CommonConstant.ACTIVE);
				} else {
					response.setStatus(CommonConstant.BLOCKED);
				}
			} else {
				response.setStatus(getSettingsValue(DEACTIVE_ACCOUNT, languageCode));
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M30
	 */
	@Override
	public ResponseMessage validateSelectedQuestnAnsByUser(SecurityQuestionAnswerData payload,
			ResponseMessage response) {
		String languageCode = "";
		try {
			UserAccount userAccount = getUserAccountByRandomId(payload.getRandId().trim(), MODE);
			userAccount = userAccount == null ? getUserAccountByRandomId(payload.getRandId().trim(), RESETVALUE)
					: userAccount;
			languageCode = userAccountService.getLanguageCode(userAccount);
			if (userAccount != null && (userAccount.getIsdelete() == null || !userAccount.getIsdelete())) {
				if (userAccount.getActive()) {
					Optional<UserSecResultDetails> userSecResult = userSecResDetRepo
							.findByUserAccountId(userAccount.getUserAccountId()).stream().findAny();
					int count = userSecResult.isPresent() ? userSecResult.get().getWrongAnswerAttempts() : 0;

					UserSecResultDetails userSecResultDetails = userSecTransAuditService
							.validateSelectedQuestnAnsByUser(userAccount.getUserAccountId(), payload.getQuestionId(),
									payload.getAnswer().trim());
					return userSecResValidation(payload, response, userSecResultDetails, count, userAccount,
							languageCode);
				} else {
					response.setStatus("Account Blocked");
					response.setMessage(getSettingsValue(ACCOUNTBLOCKED, languageCode));
				}
			} else {
				response.setStatus("Account De-Activated");
				response.setMessage(getSettingsValue(DEACTIVE_ACCOUNT, languageCode));
			}
		} catch (Exception e) {
			response.setStatus(CommonConstant.ERROR);
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M31
	 */
	private ResponseMessage userSecResValidation(SecurityQuestionAnswerData payload, ResponseMessage response,
			UserSecResultDetails userSecResultDetails, int count, UserAccount userAccount, String languageCode)
			throws EncryptionException, IOException {
		if (userSecResultDetails != null) {
			response.setStatus(CommonConstant.SUCCESS);
			response.setMessage("validation success");
			response.setRandId(payload.getRandId());
			count = 0;
			userAccountService.updateSecurityQuestnAttemptsBothSingleAndMultiRole(userAccount.getUserAccountId(),
					count);
			userAccount.setWrongPwdAttempt(count);
			userAccount.setLastModifiedBy(userAccount.getUserAccountId());
			userAccount.setLastModifiedDate(new Date());
			userAccountRepo.save(userAccount);

			if (UserGroupCons.addUserCheck.contains(userAccount.getUserGroup().getUserGroupId())) {
				SsoSyncData ssoSync = new SsoSyncData();
				ssoSync.setUserName(RCUserUtil.rcEncrypt(userAccount.getUserName()));
				ssoSync.setCount(count);
				String onboardbUrl = ssoUtil.getSSOAPIURL(CasCommonConstant.ONBOARD);
				ssoUtil.updateSecurityAttemptCAS(ssoSync, onboardbUrl);
				String hroUrl = ssoUtil.getSSOAPIURL("hro");
				ssoUtil.updateSecurityAttemptCAS(ssoSync, hroUrl);
				LOGGER.info(userAccount.getUserName() + "" + count);
				dcUtil.updateSecQuestionFailure(userAccount.getUserName(), count);
			}
		} else {
			return securityQuestionAttemptCheck(response, count, languageCode, userAccount, payload);
		}
		return response;
	}

	/**
	 * M32
	 */
	private ResponseMessage securityQuestionAttemptCheck(ResponseMessage response, int count, String languageCode,
			UserAccount userAccount, SecurityQuestionAnswerData payload) {
		try {
			if (count < 3) {
				count++;
				userAccountService.updateSecurityQuestnAttemptsBothSingleAndMultiRole(userAccount.getUserAccountId(),
						count);
				securityQuestionAttempt(count, userAccount, payload);
				return answerAttemptCheck(response, count, languageCode, userAccount);
			} else {
				response.setStatus(WRONGANSWER);
				response.setMessage(getSettingsValue("answerAttemptCompleted", languageCode));
			}
		} catch (Exception e) {
			LOGGER.error("API Call for OB --> resetFailureAttempt", e);
		}
		return response;
	}

	/**
	 * M33
	 */
	private void securityQuestionAttempt(int count, UserAccount userAccount, SecurityQuestionAnswerData payload) {
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		executorService.execute(() -> {
			try {
				if (Boolean.TRUE
						.equals(UserGroupCons.addUserCheck.contains(userAccount.getUserGroup().getUserGroupId()))) {
					SsoSyncData ssoData = new SsoSyncData();
					ssoData.setUserName(RCUserUtil.rcEncrypt(userAccount.getUserName()));
					ssoData.setCount(count);
					ssoData.setQuesId1(payload.getQuestionId());
					ssoData.setAns1(payload.getAnswer());
					String onboardbUrl = ssoUtil.getSSOAPIURL("onboard");
					ssoUtil.updateSecurityAttemptCAS(ssoData, onboardbUrl);
					String hroUrl = ssoUtil.getSSOAPIURL("hro");
					ssoUtil.updateSecurityAttemptCAS(ssoData, hroUrl);
					dcUtil.updateSecQuestionFailure(userAccount.getUserName(), count);
				}
			} catch (Exception e) {
				LOGGER.error("API Call for OB --> securityQuestionAttempt", e);
			}
		});
		/*** ThreadShutdown ***/
		new RCUserUtil().threadShutdown(executorService);
	}

	/**
	 * M34
	 */
	private ResponseMessage answerAttemptCheck(ResponseMessage response, int count, String languageCode,
			UserAccount userAccount) {
		if (count == 1) {
			response.setStatus(WRONGANSWER);
			response.setMessage(getSettingsValue("answerAttempt2", languageCode));
		} else if (count == 2) {
			response.setStatus(WRONGANSWER);
			response.setMessage(getSettingsValue("answerAttempt1", languageCode));
		} else if (count == 3) {
			response = blockUserAccountByWrongAnswer(userAccount.getUserName(), response);
			response.setStatus(WRONGANSWER);
			response.setMessage(CommonConstant.BLOCKED);
		}
		return response;
	}

	/**
	 * M35
	 */
	private ResponseMessage blockUserAccountByWrongAnswer(String userName, ResponseMessage response) {
		try {
			UserAccount userAcct = userAccountService.getUserAccountByUserNameAndEmail(userName);
			userAcct.setActive(false);
			userAcct.setLockedDate(new Date());
			userAccountService.updateUserAccountActivationStatusForBothSingleOrMultiRoleUaByEmailOrPhone(userAcct);
			userAccountRepo.save(userAcct);

			saveForgotSecurityAnsLinkDetails(userAcct, "Blocked-SecurityAnswer");
			response = accountLockedNotificationAtSecurityLevel(userAcct, response);

			SsoSyncData ssoData = new SsoSyncData();
			ssoData.setUserName(RCUserUtil.rcEncrypt(userAcct.getUserName()));
			String obUrl = ssoUtil.getSSOAPIURL("onboard");
			ssoUtil.updateAccountLock(ssoData, obUrl);
			String hroUrl = ssoUtil.getSSOAPIURL("hro");
			ssoUtil.updateAccountLock(ssoData, hroUrl);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M36
	 */
	private ResponseMessage accountLockedNotificationAtSecurityLevel(UserAccount userAcct, ResponseMessage response) {
		try {
			Long hospitalId = hospitalService.getHospitalIdForAnyUserAccount(userAcct).getHospitalId();
			NotifyReqData phoneNotifyData = new NotifyReqData();
			phoneNotifyData.setToUser(userAcct.getUserAccountId());
			phoneNotifyData.setHspId(hospitalId);
			response.setNotifyData(new ArrayList<>(Arrays.asList(phoneNotifyData)));
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M37
	 * 
	 * This method is used to check the business logic and update the password
	 */
	@Override
	public PasswordUpdateData updateUserPassWord(UpdatePwdData pwdData, PasswordUpdateData passwordData) {
		UserAccount userAccount = null;
		String languageCode = "";
		String message = "False";
		HospitalSurgeon hospitalSurgeon = null;
		Long surgeonId = 0l;
		UserGroup surUserGroup = null;
		UserAccount surUserAcc = null;
		Surgeon surgeonDetail = null;
		String surgeonName = "";
		String surgeonImage = "";
		try {
			String randId = pwdData.getRandId();
			String newPassword = pwdData.getNewPassword();

			byte[] decodedBytes = Base64.getDecoder().decode(newPassword);
			String decodedPwd = new String(decodedBytes);

			UserSecTransAudit usta = userSecAuditRepo.findByRandomId(randId.trim());
			if (usta != null && usta.getIsActive() && "PasswordUpdate".equalsIgnoreCase(usta.getMode())) {
				userAccount = getUserAccountByRandomId(randId, usta.getMode());
				boolean isActivation = userAccount.getWelcomeFlag() != false;
				languageCode = userAccountService.getLanguageCode(userAccount);
				if (userAccount.getIsdelete() == null || !userAccount.getIsdelete()) {
					String userGroupId = String.valueOf(userAccount.getUserGroup().getUserGroupId());
					String encryptPass = RCUserUtil.rcEncrypt(decodedPwd);
					message = "True";
					hospitalSurgeon = gethspsug(userGroupId, userAccount);
					if (hospitalSurgeon != null) {
						surgeonId = hospitalSurgeon.getSurgeon().getSurgeonId();
						surUserGroup = userGroupRepo.findByGroupName("Surgeon");
						surUserAcc = userAccountRepo
								.findByUserAccountKeyAndUserGroup_UserGroupId(surgeonId, surUserGroup.getUserGroupId())
								.orElse(null);
						surgeonDetail = hospitalSurgeon.getSurgeon();
						surgeonName = surgeonDetail.getSalutation() + surgeonDetail.getFirstName() + " "
								+ surgeonDetail.getLastName();
						surgeonImage = surUserAcc.getImagePath();
					}
					passwordData.setUserAccountId(userAccount.getUserAccountId());
					passwordData.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
					passwordData.setUserEmail(getAccountUserName(userAccount));
					passwordData.setUserName(userAccount.getFirstName() + " " + userAccount.getLastName());
					passwordData.setSurgeonName(surgeonName);
					passwordData.setSurgeonImage(surgeonImage);
					passwordData.setSurUserGroup(surUserGroup != null ? surUserGroup.getGroupName() : "");
					passwordData.setMessage(message);
					passwordData.setNotifyData(null);
					userAccount.setUserPwd(encryptPass);
					userAccount.setUserPwdCreatedOn(new Date());
					userAccount.setPHIAckDate(new Date());
					userAccount.setActive(true);
					if(userAccount.getUserGroupId().compareTo(19L)==0) {
						List<PatientStageWorkflow> pswList = pswfRepo.findByPatient_PatientId(userAccount.getUserAccountKey());
						passwordData.setPatientSwfIds(pswList.stream().map(PatientStageWorkflow::getPatientSWFId).toList());
					}
					updatePwdForBothSingleOrMultiRoleUserAcctByEmailOrPhone(userAccount, "welcomeFlagNotChange");
					userAccountService
							.updateSecurityQuestnAttemptsBothSingleAndMultiRole(userAccount.getUserAccountId(), 0);
					initiatePasswordUpdation(userAccount, decodedPwd, isActivation, passwordData);
					updatePasswordInOnboardForFailureAttempt(userAccount);
					initiateUpdatePwdInDCCP(userAccount, decodedPwd);
					if(userAccount.getUserGroupId().compareTo(19L)==0) {
						
					}
					
					/*** Security ***/
					List<UserSecTransAudit> userSecTrans = userSecAuditRepo
							.findByUserAccount_UserAccountIdAndMode(userAccount.getUserAccountId(), "password-otp");
					userSecAuditRepo.saveAll(userSecTrans.stream().map(a -> {
						a.setIsActive(false);
						return a;
					}).collect(Collectors.toList()));
				} else {
					passwordData.setMessage(getSettingsValue(DEACTIVE_ACCOUNT, languageCode));
				}
			} else {
				passwordData.setMessage(UNAUTHORIZED_ACCESS);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return passwordData;
	}

	/**
	 * M38
	 */
	public HospitalSurgeon gethspsug(String userGroupIdStr, UserAccount userAccount) {
		HospitalSurgeon hospitalSurgeon = null;
		if (userGroupIdStr.equals("19")) {
			hospitalSurgeon = hospitalSurgeonService.getHospitalSurgeonByPatientId(userAccount.getUserAccountKey());
		} else if (userGroupIdStr.equals("20")) {
			hospitalSurgeon = hospitalSurgeonService.getHospitalSurgeonByPatientId(userAccount.getWhoseCarePartner());
		} else if (userGroupIdStr.equals("17") || userGroupIdStr.equals("9") || userGroupIdStr.equals("7")) {
			hospitalSurgeon = hspSugRepo.findFirstByHospitalId(userAccount.getUserAccountKey());
		}
		return hospitalSurgeon;
	}

	/**
	 * M39
	 */
	public String getAccountUserName(UserAccount userAccount) {
		String usernamevalue = "";
		if (userAccount.getEmail() != null) {
			usernamevalue = userAccount.getUserName();
		} else {
			if (userAccount.getPhone() != null && userAccount.getTeleCode() != null) {
				usernamevalue = (userAccount.getTeleCode() != null && userAccount.getTeleCode().contains("+"))
						? userAccount.getTeleCode().replace("+", "") + "-" + userAccount.getPhone()
						: userAccount.getTeleCode();
			} else {
				usernamevalue = "";
			}
		}
		return usernamevalue;
	}

	/**
	 * M40
	 * 
	 * @param passwordData
	 */
	private void initiatePasswordUpdation(UserAccount userAccount, String decodedBytePwd, boolean isActivation,
			PasswordUpdateData passwordData) {
		if (!isActivation) {
			passwordUpdatedNotification(userAccount, passwordData);
		}
		/*** Security ***/
		updatePasswordOfHro(decodedBytePwd, userAccount);
	}

	/**
	 * M41
	 */
	private PasswordUpdateData passwordUpdatedNotification(UserAccount userAccount, PasswordUpdateData passwordData) {
		Long hspId = hospitalService.getHospitalIdForAnyUserAccount(userAccount).getHospitalId();
		try {
			List<NotifyReqData> notifyDatas = new ArrayList<>();
			NotifyReqData notifyData = new NotifyReqData();
			notifyData.setHspId(hspId);
			notifyData.setToUser(userAccount.getUserAccountId());
			notifyDatas.add(notifyData);
			passwordData.setNotifyData(notifyDatas);
			// String notifyType = NotificationConstant.PASSWORDUPDATEDNOTIFICATION;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return passwordData;
	}

	/**
	 * M42
	 */

	private void updateSSOpassword(String newPassword, UserAccount userAccount) {
		try {
			/*** API Conversion ***/
			if (UserGroupCons.addUserCheck.contains(userAccount.getUserGroupId())) {
				String rcUserName = userAccount.getUserName();
				String apiURL = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_HRO_SYNCURL);
				ssoUtil.passwordUpdateSSO(new StringEncrypter("DES").encrypt(rcUserName),
						new StringEncrypter("DES").encrypt(newPassword), apiURL);
			}
		} catch (Exception e) {
			LOGGER.error(" Exception : ", e);
		}
	}

	/**
	 * M43
	 */
	private void updatePasswordInOnboardForFailureAttempt(UserAccount userAccount) {
		try {
			String onBoardAccountId = ((userAccount.getRcOnBoardId() + "").equals("")) ? ""
					: userAccount.getRcOnBoardId() + "";
			if (!onBoardAccountId.isEmpty()) {
				obUtil.updatePasswordInOnboardForFailureAttempt(userAccount.getUserName(), userAccount.getUserPwd());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M44
	 */
	private void initiateUpdatePwdInDCCP(UserAccount userAccount, String newpswd) {
		try {
			String dccpUserExist = dcUtil
					.checkUserExistsInDCCP(RCUserUtil.getNonEmptyWithBlank(userAccount.getUserName()));
			if (dccpUserExist != null && dccpUserExist.equalsIgnoreCase("true")) {
				dcUtil.updatePwdInDCCP(userAccount.getUserName(), newpswd, "0");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M45
	 */
	@Override
	public ForgotPwdUserDatas getForgotPasswordInfo(UserRequestData payload) {
		ForgotPwdUserDatas userData = new ForgotPwdUserDatas();
		userData.setMessage(CommonConstant.USERVALIDATIONCHECK3);
		userData.setStatus(CommonConstant.FAILURE);
		try {

			String hostModel = rs.getString("HostedModel");
			String url = "";
			url = getUrl(hostModel);
			UserAccount userAccount = userAccountService.validateUserNew(payload.getUserName()).stream().findFirst()
					.orElse(null);
			if (userAccount != null) {
				userData.setUserId(userAccount.getUserAccountId());
				userData.setFirstName(userAccount.getFirstName());
				userData.setLastName(userAccount.getLastName());
				userData.setGroupName(userAccount.getUserGroup().getGroupName());
				userData.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
				userData.setPatientId(0L);
				userData.setPhone(userAccount.getPhone());
				userData.setUserName(userAccount.getEmail());

				Boolean isStaff = false;
				UserAccount staffAccount = null;
				List<UserAccount> userList = userAccountService.getUsersByEmailId(userAccount.getEmail(),
						(userAccount.getPhone() != null ? userAccount.getTeleCode() + "-" + userAccount.getPhone()
								: ""));
				for (UserAccount ua : userList) {
					if (ua.getUserGroup().getUserGroupId() != 19L && ua.getUserGroup().getUserGroupId() != 20L) {
						userData.setUserId(ua.getUserAccountId());
						userData.setGroupName(ua.getUserGroup().getGroupName());
						userData.setUserGroupId(ua.getUserGroup().getUserGroupId());
						isStaff = true;
						staffAccount = ua;
						break;
					}
				}
				userData = getUserData1(userData, userAccount, isStaff);
				userData.setStatus(CommonConstant.SUCCESS);
				userData.setAllowPasswordChange(userAccount.getUserPwdCreatedOn() != null
						&& DateUtil.hoursDiff(userAccount.getUserPwdCreatedOn(), new Date()) >= 24);
				String userGroupIdStr = userData.getUserGroupId() + "";
				userData.setDateFormat(MMDDYYYY);
				userData.setCountryCode("USA");
				userData.setMessage(SECURITYQUESTIONS);
				userData = getUsersData2(userData, url, userAccount, staffAccount, userGroupIdStr);
			}
		} catch (Exception e) {
			LOGGER.error("Error validating User for forgot password", e);
		}
		return userData;
	}

	/**
	 * M46
	 */
	private String getUrl(String hostModel) {
		String url;
		if (hostModel.equalsIgnoreCase("CLOUD")) {
			url = rs.getString("awsS3RealPath");
		} else {
			url = rs.getString("VMURL");
		}
		return url;
	}

	/**
	 * M47
	 */
	private ForgotPwdUserDatas getUserData1(ForgotPwdUserDatas userData, UserAccount userAccount, Boolean isStaff) {
		if (Boolean.FALSE.equals(isStaff) && userAccount.getUserGroup().getUserGroupId() == 20L) {
			List<CarePartnerMap> cpList = careService.getCarePartnerPatientList(userAccount.getUserAccountId());
			if (cpList != null && !cpList.isEmpty()) {
				userData.setPatientId(cpList.get(0).getPatientId());
				Patient pat = patientRepo.findById(cpList.get(0).getPatientId()).orElse(null);
				userData.setPatFirstName(pat.getFirstName());
				userData.setPatLastName(pat.getLastName());
			}
		}
		return userData;
	}

	/**
	 * M48
	 */
	private ForgotPwdUserDatas getUsersData2(ForgotPwdUserDatas userData, String url, UserAccount userAccount,
			UserAccount staffAccount, String userGroupIdStr) {
		if (userGroupIdStr.equals("1") || userGroupIdStr.equals("2") || userGroupIdStr.equals("3")
				|| userGroupIdStr.equals("4") || userGroupIdStr.equals("21") || userGroupIdStr.equals("22")) {
			userData.setDateFormat(MMDDYYYY);
			userData.setMessage(SECURITYQUESTIONS);
		} else if (userGroupIdStr.equals("19")) {
			Hospital hsp = getHospitalByPatientId(userAccount.getUserAccountKey());
			userData.setDateFormat(hsp != null ? hsp.getCountryCode().getDateFormat() : MMDDYYYY);
			userData.setMessage("ValidateDOB");
			userData.setAllowPasswordChange(!(staffAccount != null && staffAccount.getUserPwdCreatedOn() != null
					&& DateUtil.hoursDiff(staffAccount.getUserPwdCreatedOn(), new Date()) < 24));
			return getUsersData3(userData, url, hsp);
		} else if (userGroupIdStr.equals("20")) {
			Hospital hsp = getHospitalByPatientId(userData.getPatientId());
			userData.setDateFormat(hsp != null ? hsp.getCountryCode().getDateFormat() : MMDDYYYY);
			userData.setMessage("ValidateDOB");
			userData.setAllowPasswordChange(!(staffAccount != null && staffAccount.getUserPwdCreatedOn() != null
					&& DateUtil.hoursDiff(staffAccount.getUserPwdCreatedOn(), new Date()) < 24));
			return getUsersData3(userData, url, hsp);
		} else {
			Hospital hsp = hspRepo.findById(userAccount.getUserAccountKey()).orElse(null);
			userData.setDateFormat(hsp != null ? hsp.getCountryCode().getDateFormat() : MMDDYYYY);
			userData.setMessage(SECURITYQUESTIONS);
			return getUsersData3(userData, url, hsp);
		}
		return userData;
	}

	/**
	 * M48
	 */
	private Hospital getHospitalByPatientId(Long patientId) {
		Hospital hsp = null;
		try {
			List<PatientStageWorkflow> pswList = pswfRepo.findByPatient_PatientId(patientId);
			if (pswList != null && !pswList.isEmpty()) {
				UserAccount ccUa = userAccountRepo.findById(pswList.get(0).getHspCCId()).orElse(null);
				if (ccUa != null) {
					hsp = hspRepo.findById(ccUa.getUserAccountKey()).orElse(null);
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return hsp;
	}

	/**
	 * M49
	 */
	private ForgotPwdUserDatas getUsersData3(ForgotPwdUserDatas userData, String url, Hospital hsp) {
		if (hsp != null) {
			userData.setCountryCode(hsp.getCountryCode().getCountryCode());
			userData.setClientLogoPath(url + hsp.getLogo());
		}
		return userData;
	}

	/**
	 * M50
	 */
	private String getSettingsValue(String category, String name) {
		String value = "";
		try {
			value = rcUserUtil.getSettingValue(name, category);
			LOGGER.info(value);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return value;
	}

	/**
	 * M51
	 */
	private void updatePasswordOfHro(String newPassword, UserAccount userAccount) {
		String ssoEnable = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_ENABLED_STATUS);
		if (ssoEnable.equalsIgnoreCase("Yes")) {
			LOGGER.debug("Forgot link......");
			updateSSOpassword(newPassword, userAccount);
		}
	}

	/**
	 * M52
	 * 
	 * Validate DOB for CarePartner/Patient to resetPassword
	 */
	@Override
	public ResponseMessage validateDOB(ValidateDobData request) {
		ResponseMessage response = new ResponseMessage();

		try {
			SimpleDateFormat sdf = new SimpleDateFormat(CommonConstant.DateFormatRC.YYYY_MM_DD);
			response.setStatus(FAILURE);
			response.setMessage("DOB did not match. Please enter correct DOB.");
			if (!request.getUserName().isEmpty()) {
				UserAccount userAccount = userAccountService.validateUserNew(request.getUserName()).stream().findFirst()
						.orElse(null);
				String patDob = "";
				if (request.getPatientId() > 0L) {
					UserAccount patUA = userAccountRepo.findByUserAccountKey(request.getPatientId()).stream()
							.findFirst().orElse(null);
					patDob = patUA != null ? sdf.format(patUA.getDob()) : "";
				} else {
					patDob = sdf.format(userAccount.getDob());
				}
				if (userAccount != null && patDob.equalsIgnoreCase(request.getDob())) {
					response.setStatus(SUCCESS);
					response.setMessage("DOB matched.");
					response.setValue(userAccount.getUserAccountId() + "");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error validating DOB", e);
		}
		return response;
	}

	@Override
	public ResponseMessage changePassword(ChangePasswordData changePasswordData, Long userId) {
		String languageCode = "";
		ResponseMessage response = new ResponseMessage();
		try {
			UserAccount userAccount = userAccountRepo.findById(userId).orElse(null);
			if (userAccount != null) {
				String oldPassword = RCUserUtil.passwordDecoder(changePasswordData.getOldPassword());
				String newPassword = RCUserUtil.passwordDecoder(changePasswordData.getNewPassword());
				String confirmPassword = RCUserUtil.passwordDecoder(changePasswordData.getConfirmPassword());
				languageCode = userAccountService.getLanguageCode(userAccount);
				if (userAccount.getIsdelete() == null || !userAccount.getIsdelete()) {
					response.setStatus(CommonConstant.FAILURE);
					updateRCpassword(oldPassword, newPassword, confirmPassword, response, userAccount);
				} else {
					response.setMessage(getSettingsValue(DEACTIVE_ACCOUNT, languageCode));
				}
			} else {
				response.setStatus(CommonConstant.FAILURE);
				response.setMessage(CommonConstant.ACCESS_ERR_MSG);
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	private ResponseMessage updateRCpassword(String oldPassword, String newPassword, String confirmPassword,
			ResponseMessage response, UserAccount userAccount) {
		try {
			if (userAccount != null && userAccount.getUserPwd().equals(RCUserUtil.rcEncrypt(oldPassword))) {
				boolean validatePwd = (UserGroupCons.patientOrCP.contains(userAccount.getUserGroupId())
						|| !oldPassword.equals(newPassword)) ? true : false;
				List<UserAccount> userList = userAccountService.getUsersByEmailId(userAccount.getEmail(),
						(userAccount.getPhone() != null ? userAccount.getTeleCodeWithPhone() : ""));

				for (UserAccount userAcct : userList) {
					if (validatePwd) {
						changePasswordUserData(newPassword, confirmPassword, userAccount, userAcct, response);
					} else {
						response.setMessage(CommonConstant.PASSWORD_RULE);
					}
				}
			} else {
				response.setMessage(CommonConstant.PASSWORD_MISMATCH);
			}
		} catch (Exception e) {
			response.setMessage(CommonConstant.FAILED_PASSWORD_CHANGE);
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;

	}

	private ResponseMessage changePasswordUserData(String newPassword, String confirmPassword, UserAccount userAccount,
			UserAccount userAcct, ResponseMessage response) {

		if (newPassword.equals(confirmPassword)) {
			userAcct.setUserPwd(RCUserUtil.rcEncrypt(newPassword));
			userAcct.setUserPwdCreatedOn(new Date());
			userAcct.setActive(true);
			userAcct.setWrongPwdAttempt(0);
			userAcct.setTempPasswordActive(false);
			userAcct.setCredResetRequired(false);
			userAccountRepo.save(userAcct);

			UserPwdAudit userPwdAudit = new UserPwdAudit();
			userPwdAudit.setCreatedBy(userAccount.getUserAccountId());
			userPwdAudit.setCreatedDate(new Date());
			userPwdAudit.setUserAccountId(userAccount);
			userPwdAudit.setUserPwd(userAcct.getUserPwd());
			userPwdAuditRepo.save(userPwdAudit);
			updateSSOPassword(userAccount, userAcct, newPassword, confirmPassword);
			response.setMessage(CommonConstant.SUCCESS_PASSWORD_CHANGE);
			response.setStatus(CommonConstant.SUCCESS);

			updatePasswordNotification(userAccount, response);
		} else {
			response.setMessage(CommonConstant.PASSWORD_NOT_MATCH);
		}
		return response;
	}

	private void updateSSOPassword(UserAccount userAccount, UserAccount userAcct, String newPassword,
			String confirmPassword) {
		ExecutorService executorService1 = Executors.newFixedThreadPool(5);
		executorService1.execute(() -> {
			try {
				updatePasswordOfHro(confirmPassword, userAccount);
				userSecCodeRepo.userSecCodeAuditUpdate(false, userAccount.getUserAccountId());
				String onBoardAccountId = ((userAcct.getRcOnBoardId() + "").equals("")) ? ""
						: userAcct.getRcOnBoardId() + "";
				LOGGER.debug(onBoardAccountId);
				String onboardUrl = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_RCOB_SYNCURL);
				LOGGER.info(onboardUrl);
				ResponseMessageSSO body = ssoUtil.checkUserExists(userAccount.getEmail(), onboardUrl);
				LOGGER.info(body.toString());
				/*** Security ***/
				if (body.getStatus() != null) {
					if (body.getStatus()) {
						updatePasswordOfOnboard(newPassword, userAccount.getEmail());
					}
				}
				initiateUpdatePwdInDCCP(userAccount, newPassword);
			} catch (Exception e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
			}
		});
		/*** ThreadShutdown ***/
		new RCUserUtil().threadShutdown(executorService1);
	}

	private ResponseMessage updatePasswordNotification(UserAccount userAcct, ResponseMessage response) {
		List<NotifyReqData> notifyDatas = new ArrayList<>();
		try {
			Long hospital = hospitalService.getHospitalIdForAnyUserAccount(userAcct).getHospitalId();
			NotifyReqData notifyData = new NotifyReqData();
			notifyData.setToUser(userAcct.getUserAccountId());
			notifyData.setHspId(hospital);
			notifyDatas.add(notifyData);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		response.setNotifyData(notifyDatas);
		return response;
	}
}
