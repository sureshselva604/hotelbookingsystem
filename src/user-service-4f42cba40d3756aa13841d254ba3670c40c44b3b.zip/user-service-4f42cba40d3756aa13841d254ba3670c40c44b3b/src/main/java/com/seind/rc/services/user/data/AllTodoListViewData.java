package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class AllTodoListViewData {
	
	private Long todoPKId;
	private Long patientSwfId;
	private Long todoCategoryId;
	private String todoCategoryName;
	private Long todoBRTypeId;
	private Date todoAssignedOn;
}