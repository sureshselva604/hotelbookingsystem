package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class SurgeonDetailsData {
	private String name;
	private String userImagePath;
	private String userRole;
}
