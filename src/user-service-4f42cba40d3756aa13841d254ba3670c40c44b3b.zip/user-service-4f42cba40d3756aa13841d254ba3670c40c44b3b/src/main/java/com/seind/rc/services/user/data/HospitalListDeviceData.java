package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class HospitalListDeviceData {
	
	private Long hospitalId;
	private String name;
	private Long patientId;
	private Long admissionId;

}
