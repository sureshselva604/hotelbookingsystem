package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TodoRAPracticeOverlapHospitalsData {

	private Long hospitalId;
	
	private String name;
	
	private String practiceName;
	
	private Boolean isOverLap;
	
	private Long secHospitalId;
	
}
