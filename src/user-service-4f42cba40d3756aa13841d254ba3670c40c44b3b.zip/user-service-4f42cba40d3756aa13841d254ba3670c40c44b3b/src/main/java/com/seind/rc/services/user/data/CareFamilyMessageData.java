package com.seind.rc.services.user.data;

import java.util.List;


import lombok.Data;

@Data
public class CareFamilyMessageData {

	public List<CareFamilyMessageMap> careNavigatorDetails;

	@Data
	public static class CareFamilyMessageMap {
		private Long cnId;
		private Long patientSWfId;
	}

}
