package com.seind.rc.services.user.data;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseMessage {
	private String updateStatus;
	private String message;
	private String saveStatus;
	private String status;
	private String popUpStatus;
	private String conflictStatus;
	private String userExistInSystem;
	private String success;
	private String fail;
	private Boolean availSecurity;
	private Boolean sendEmailUpdateNotifiCation;
	private Boolean sendPhoneUpdateNotifiCation;
	private Boolean sendWelcomeInviteNotification;
	private String randId;
	private String userName;
	private String mode;
	private Long deviceId;
	private String status1;
	private String value;
	private Long userGroupId;
	private Boolean allowPasswordChange;
	private Long hospitalId;
	private List<NotifyReqData> notifyData;	
}