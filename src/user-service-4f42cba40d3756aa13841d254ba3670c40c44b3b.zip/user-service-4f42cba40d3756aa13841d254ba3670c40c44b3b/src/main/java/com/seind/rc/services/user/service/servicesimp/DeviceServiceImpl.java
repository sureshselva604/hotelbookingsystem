package com.seind.rc.services.user.service.servicesimp;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.NotificationConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.AuditLogData;
import com.seind.rc.services.user.data.CareFamilyGroupData;
import com.seind.rc.services.user.data.CareFamilyGroupData.CareFamilyGroup;
import com.seind.rc.services.user.data.CareFamilyMessageData;
import com.seind.rc.services.user.data.CareFamilyMessageData.CareFamilyMessageMap;
import com.seind.rc.services.user.data.CarePartnerMapData;
import com.seind.rc.services.user.data.CarePartnerMapRequestData;
import com.seind.rc.services.user.data.DeviceActivationData;
import com.seind.rc.services.user.data.DeviceLoginData;
import com.seind.rc.services.user.data.EmailExistsData;
import com.seind.rc.services.user.data.FcmTokenData;
import com.seind.rc.services.user.data.ForgotAttemptData;
import com.seind.rc.services.user.data.ForgotSecQuesData;
import com.seind.rc.services.user.data.HospitalDeviceData;
import com.seind.rc.services.user.data.LogDeviceTransAuditData;
import com.seind.rc.services.user.data.MenuConfigData;
import com.seind.rc.services.user.data.NotificationData;
import com.seind.rc.services.user.data.PhoneTypeData;
import com.seind.rc.services.user.data.ProfileQuestionsData;
import com.seind.rc.services.user.data.ProfileResultDetailsData;
import com.seind.rc.services.user.data.ResetPatPassReq;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SecurityCredentialData;
import com.seind.rc.services.user.data.StatusResponse;
import com.seind.rc.services.user.data.TimeZoneData;
import com.seind.rc.services.user.data.UpdateCarePartnerMapData;
import com.seind.rc.services.user.data.UpdatePatientData;
import com.seind.rc.services.user.data.UpdateUserDeviceData;
import com.seind.rc.services.user.data.UserDeviceData;
import com.seind.rc.services.user.data.UserGroupData;
import com.seind.rc.services.user.data.UserSecAnsData;
import com.seind.rc.services.user.entities.CNSugProcPayer;
import com.seind.rc.services.user.entities.CareFamilyMapping;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.DeviceVersion;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.HospitalContact;
import com.seind.rc.services.user.entities.HospitalNavigatorSugMapping;
import com.seind.rc.services.user.entities.MenuConfiguration;
import com.seind.rc.services.user.entities.PasswordHistory;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientDevice;
import com.seind.rc.services.user.entities.PatientEpisodeCareCircle;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.PhoneType;
import com.seind.rc.services.user.entities.PracticeCoordinatorHSPMapping;
import com.seind.rc.services.user.entities.ProfileQuestions;
import com.seind.rc.services.user.entities.ProfileResultDetails;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.TimeZone;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.entities.UserLoginAudit;
import com.seind.rc.services.user.entities.UserRequestAudit;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.CNSugProcPayerRepository;
import com.seind.rc.services.user.repository.CareFamilyMappingRepository;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.DeviceVersionRepository;
import com.seind.rc.services.user.repository.HospitalContactRepository;
import com.seind.rc.services.user.repository.HospitalNavigatorSugMappingRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.MenuConfigurationRepository;
import com.seind.rc.services.user.repository.PatientDeviceRepository;
import com.seind.rc.services.user.repository.PatientEpisodeCareCircleRespository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.PhoneTypeRepository;
import com.seind.rc.services.user.repository.PracticeCoordinatorHSPMappingRepository;
import com.seind.rc.services.user.repository.ProfileQuestionsRepository;
import com.seind.rc.services.user.repository.ProfileResultDetailsRepository;
import com.seind.rc.services.user.repository.TimeZoneRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserGroupRepository;
import com.seind.rc.services.user.repository.UserLoginAuditRepository;
import com.seind.rc.services.user.repository.UserRequestAuditRepository;
import com.seind.rc.services.user.repository.UserSecResDetRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.CarePartnerMapService;
import com.seind.rc.services.user.service.DeviceService;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.PasswordService;
import com.seind.rc.services.user.service.PatientService;
import com.seind.rc.services.user.service.ProfileResultDetailsService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserRequestAuditService;
import com.seind.rc.services.user.service.UserSecTransAuditService;
import com.seind.rc.services.user.util.GenerateOTP;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.RCUtil;
import com.seind.rc.services.user.util.StringEncrypter;
import com.seind.rc.services.user.util.StringEncrypter.EncryptionException;
import com.seind.rc.services.user.util.UserValidationUtil;

import jakarta.servlet.http.HttpServletRequest;

@Service
public class DeviceServiceImpl implements DeviceService {

	private static final Logger LOGGER = LogManager.getLogger(DeviceServiceImpl.class);

	private static final ResourceBundle uriRB = ResourceBundle.getBundle("messages.uri");
	private static final String DEFAULT_MALE_IMG_PATH = uriRB.getString("defaultMaleImgPath");
	private static final String DEFAULT_FEMALE_IMG_PATH = uriRB.getString("defaultFemaleImgPath");
	private static final String DAM_COMMON_PATH = uriRB.getString("damCommonPath");
	private static final ResourceBundle applicationProp = ResourceBundle.getBundle("application");
	private static final String HOSTED_MODEL = "HostedModel";
	public static final String CLOUD = "cloud";
	private static final String LOG_DEVICE_EXCEPTION = " Device Exception ";
	private static final String DEVICE_IOS = "Device-Ios";
	private static final String LOGIN = "login";
	private static final String DEVICE_ACTIVATION = "deviceActivation";
	private static final String INCORRECT_USERNAME = "You have entered an incorrect username. Please try your email or phone number";
	private static final String FAILURE = "Failure";
	private static final String SUCCESS = "success";
	private static final String PASSWORDUPDATE = "PasswordUpdate";
	private static final String DEVICE = "Device";
	private static final String DEVICE_ANDROID = "Device-Android";

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private DeviceVersionRepository deviceVersionRepository;

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private ProfileResultDetailsService profileRDService;

	@Autowired
	private PatientService patientService;

	@Autowired
	private HospitalService hospitalService;

	@Autowired
	private CarePartnerMapService carePartnerMapService;

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;

	@Autowired
	private CareFamilyMappingRepository careFamilyMapRepo;

	@Autowired
	private PatientStageWorkflowRepository pswfRepo;

	@Autowired
	private CNSugProcPayerRepository cNSugProcPayerRepository;

	@Autowired
	private UserAccountRepository userRepository;

	@Autowired
	private HospitalNavigatorSugMappingRepository hspNavSugMappingRepository;

	@Autowired
	private PracticeCoordinatorHSPMappingRepository praCCHspMappingRepository;

	@Autowired
	private PatientEpisodeCareCircleRespository patEpisodeCCRepo;

	@Autowired
	private PatientStageWorkflowRepository patientSWFRepo;

	@Autowired
	private PhoneTypeRepository phoneTypeRepo;

	@Autowired
	private TimeZoneRepository timeZoneRepo;

	@Autowired
	private UserGroupRepository userGroupRepo;

	@Autowired
	private UserRequestAuditService userReqAuditService;

	@Autowired
	private UserRequestAuditRepository userReqAuditRepo;

	@Autowired
	private PracticeCoordinatorHSPMappingRepository practiceHSPMapRepo;

	@Autowired
	private HospitalNavigatorSugMappingRepository hspNavigatorSugMapRepo;

	@Autowired
	private UserLoginAuditRepository userLoginRepo;

	@Autowired
	private UserSecTransAuditService userSecTransAuditService;

	@Autowired
	private UserSecResDetRepository userSecResDetRepo;

	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepo;

	@Autowired
	private PasswordService passwordService;

	@Autowired
	private UserLoginAuditRepository loginAuditRepository;

	@Autowired
	private MenuConfigurationRepository menuConfigRepo;

	@Autowired
	private PatientDeviceRepository deviceRepository;

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private HospitalRepository hspRepo;

	@Autowired
	private ProfileResultDetailsRepository profileRDRepo;

	@Autowired
	private ProfileQuestionsRepository profileQuesRepo;

	@Autowired
	private UserRequestAuditRepository userReqRepo;
	
	@Autowired
	private HospitalContactRepository hospitalContactRepository;

	@Override
	public List<ProfileQuestionsData> getBiographyQuestionData() {
		List<ProfileQuestionsData> profileQuestionsData = new ArrayList<ProfileQuestionsData>();
		try {
			List<ProfileQuestions> bioProfileQuesList = profileQuesRepo.findAll();
			profileQuestionsData = bioProfileQuesList.stream().map(a -> modelMapper.map(a, ProfileQuestionsData.class))
					.toList();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return profileQuestionsData;
	}

	@Override
	public List<ProfileResultDetailsData> getBiographyQuestionAnswerData(Long patientId) {
		List<ProfileResultDetailsData> profileResultDetailsData = new ArrayList<ProfileResultDetailsData>();
		try {
			UserAccount userAccount = userRepository.findByUserAccountKey(patientId).stream().findFirst().orElse(null);
			List<ProfileResultDetails> profileRDList = profileRDService
					.getProfileResultDetailsByPatientId(userAccount.getUserAccountId());
			profileResultDetailsData = profileRDList.stream()
					.map(a -> modelMapper.map(a, ProfileResultDetailsData.class)).toList();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return profileResultDetailsData;
	}

	@Override
	public HospitalDeviceData getHopsitalDetailsByPatientId(Long patientId) {
		HospitalDeviceData hospitalData = null;
		try {
			Patient patient = patientRepo.findById(patientId).orElse(null);
			UserAccount userAccount = userAccountService
					.getUserAccountByUserAccountId(patient.getCreatedBy() != null ? patient.getCreatedBy() : 0l);

			Long userAccountKey = userAccount != null ? userAccount.getUserAccountKey() : 0l;
			Hospital hospital = hspRepo.findById(userAccountKey).orElse(null);
			modelMapper.getConfiguration().setAmbiguityIgnored(true);
			hospitalData = modelMapper.map(hospital, HospitalDeviceData.class);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return hospitalData;
	}

	@Override
	public List<PhoneTypeData> getPhoneType() {
		List<PhoneTypeData> phoneTypeData = null;
		try {
			List<PhoneType> phoneTypeList = phoneTypeRepo.findAllByOrderBySeqNoAsc();
			phoneTypeData = phoneTypeList.stream().map(a -> modelMapper.map(a, PhoneTypeData.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		return phoneTypeData;
	}

	@Override
	public List<TimeZoneData> getTimeZone() {
		List<TimeZoneData> timeZoneData = null;
		try {
			List<TimeZone> timeZoneList = timeZoneRepo.findAll();
			timeZoneData = timeZoneList.stream().map(a -> modelMapper.map(a, TimeZoneData.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return timeZoneData;
	}

	@Override
	public List<UserGroupData> getAllUserGroup() {
		List<UserGroupData> userGroupData = null;
		try {
			List<UserGroup> userGroupList = userGroupRepo.findAll();
			userGroupData = userGroupList.stream().map(a -> modelMapper.map(a, UserGroupData.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userGroupData;
	}

	@Override
	public List<CarePartnerMapData> getActiveCarePartnerMap(Boolean isCarePartner, Long carePartnerId, Long patientId) {
		List<CarePartnerMapData> carePartnerMapData = new ArrayList<>();
		try {
			List<CarePartnerMap> carePartnerList = null;

			if (carePartnerId > 0) {
				carePartnerList = carePartnerMapRepo
						.findByActiveIsTrueAndUserAccount_userAccountIdAndUserAccount_UserGroup_UserGroupId(
								carePartnerId, 20l);
			} else {
				carePartnerList = carePartnerMapRepo.findByPatientId(patientId);
			}
			carePartnerMapData = carePartnerList.stream().map(a -> mapToCarePartnerMap(a)).collect(Collectors.toList());

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		return carePartnerMapData;
	}

	private CarePartnerMapData mapToCarePartnerMap(CarePartnerMap a) {
		return CarePartnerMapData.builder().carePartnerMapId(a.getCarePartnerMapId())
				.userAccountId(a.getUserAccount().getUserAccountId()).patientId(a.getPatient().getPatientId())
				.verified(a.getVerified()).build();
	}

	@Override
	public ResponseMessage setForgetSucessAnswer(ForgotSecQuesData forgotData) {
		ResponseMessage response = new ResponseMessage();

		Long patientId = forgotData.getPatientId();
		UserAccount userAccount = null;
		if (forgotData.getIsForgotSecurityQuest()) {
			try {
				userAccount = patientService.getUserAccountDetailsByPatientIdAndUserGroupId(patientId);
				UserRequestAudit userRequestAudit = userReqRepo
						.findByUserAccount_UserAccountIdAndModeAndStatus(userAccount.getUserAccountId(),
								"ForgetSecurityAnswer", "Pending")
						.stream().findFirst().orElse(null);
				if (userRequestAudit != null) {
					UserRequestAudit userReq = userReqAuditRepo.findById(userRequestAudit.getUserRequestAuditId())
							.orElse(null);
					userReq.setStatus("Completed");
					userReqAuditRepo.save(userReq);
				}
				userReqAuditService.saveForgotSecurityAnsLinkDetails(userAccount, "Initiate-SecurityQA");
				response.setStatus("Success");
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				response.setStatus("Failure");
			}
		}
		return response;
	}

	@Override
	public ResponseMessage setForgotattemptFailed(ForgotAttemptData forgotData) {
		ResponseMessage response = new ResponseMessage();
		try {
			UserAccount userAccount = userRepository.findById(forgotData.getUserAccountId()).orElse(null);
			if (userAccount != null) {
				int count = forgotData.getForgotattemptFailed();
				userAccountService.updateSecurityQuestionAttempts(userAccount.getUserAccountId(), count);
				if (forgotData.getAccountBlocked()) {
					accountBlockbyUseraccount(userAccount);
					response.setStatus("Success");
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.LOG_DEVICE_ERROR, e);
			response.setStatus("Failure");
		}
		return response;
	}

	private void accountBlockbyUseraccount(UserAccount blockUser) {
		String username1 = null;
		if (blockUser.getEmail() != null && !blockUser.getEmail().isEmpty()) {
			username1 = blockUser.getEmail();
		} else if (blockUser.getPhone() != null && !blockUser.getPhone().isEmpty()) {
			username1 = blockUser.getTeleCode() + "-" + blockUser.getPhone();
		}
		if (username1 != null) {
			blockUserAccountByWrongAnswer(username1);
		}
	}

	private void blockUserAccountByWrongAnswer(String userName) {
		try {
			UserAccount useraccount = userAccountService.getUserAccountByUserNameAndEmail(userName);
			if (useraccount != null) {
				List<UserAccount> useraccList = new ArrayList<UserAccount>();
				useraccList.addAll(userAccountService.validateUserNew(userName));

				for (UserAccount userAcc : useraccList) {
					/**** userAc.setActive(false); //RC Summer 2021 ****/
					userAcc.setWrongPwdAttempt(3);
					userRepository.save(userAcc);
				}
				userReqAuditService.saveForgotSecurityAnsLinkDetails(useraccount, "Blocked-SecurityAnswer");

			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	@Override
	public List<UserDeviceData> getUsersInfoByPatientId(Long patientId) {

		List<UserDeviceData> usersData = null;

		try {
			CarePartnerMap carepm = carePartnerMapService.getActiveCarePartnerMapByPatient(patientId);
			List<UserAccount> userAccountList = new ArrayList<>();
			UserAccount patUserAccount = userRepository.findByUserAccountKey(patientId).stream().findFirst()
					.orElse(null);
			userAccountList.add(patUserAccount);
			userAccountList.addAll(careGiverList(patientId));
			List<PatientStageWorkflow> pswList = pswfRepo.findByPatient_PatientId(patientId);

			for (PatientStageWorkflow psw : pswList) {

				UserAccount ccUa = userRepository.findById(patUserAccount.getCreatedBy()).orElse(null);
				List<UserAccount> userAccList = getAllGroupBasedUserAccountListByPatientSwfId(ccUa.getUserAccountKey(),
						patUserAccount.getUserAccountId(), psw.getPatientSWFId());
				if (ccUa.getCareFamilyShow()) {
					userAccountList.add(ccUa);
				}
				if (userAccList.isEmpty()) {
					userAccList = userRepository.findByUserAccountKeyAndCareFamilyShowTrue(ccUa.getUserAccountKey());
				}
				userAccountList.addAll(userAccList);
				userAccountList.addAll(getCareFamilyByUserAccId(psw));
				List<UserAccount> uaList = patEpisodeCCRepo
						.findByPatientStageWorkflow_PatientSWFIdAndUserAccount_UserGroup_GroupNameIn(
								psw.getPatientSWFId(),
								new ArrayList<>(Arrays.asList("Care Outcomes Manager", "Care Coordinator", "Surgeon'")))
						.stream().map(PatientEpisodeCareCircle::getUserAccount).collect(Collectors.toList());
				userAccountList.addAll(uaList);
				userAccountList.add(userRepository.findById(psw.getHspSurgId()).orElse(null));

				userAccountList.addAll(careFamilyMapRepo
						.findByUserAccIdOrUserAccIdIsNullAndHospitalIdOrHospitalIdIsNullAndPayorTypeIdOrPayorTypeIdIsNullAndProcedureTypeOrProcedureTypeIsNullAndActiveTrueAndClientId(
								psw.getHspSurgId(), psw.getHospitalPractice().getHospitalId(), psw.getPayorId(),
								psw.getProcedureType(), ccUa.getUserAccountKey())
						.stream().map(CareFamilyMapping::getCareGiverUa).collect(Collectors.toList()));

				usersData = subGetUserInfoByPatientId(patientId, carepm, userAccountList, psw);
			}

			// usersData.removeIf(a->a.e)

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return usersData.stream().distinct().toList();

	}

	private List<UserDeviceData> subGetUserInfoByPatientId(Long patientId, CarePartnerMap carepm,
			List<UserAccount> userAccountList, PatientStageWorkflow psw) {
		return userAccountList.stream().map(a -> {
			return mapUserAccountData(a, patientId, carepm);
		}).toList();
	}

	private UserDeviceData mapUserAccountData(UserAccount userAccount, Long patientId, CarePartnerMap carepm) {
		UserDeviceData userDeviceData = new UserDeviceData();
		try {
			StringEncrypter se = new StringEncrypter("DES");
			SimpleDateFormat sdfdob = new SimpleDateFormat(CommonConstant.STR_MM_DD_YYYY);
			modelMapper.getConfiguration().setAmbiguityIgnored(true);
			userDeviceData = modelMapper.map(userAccount, UserDeviceData.class);
			String userPassword = userAccount.getUserGroup().getUserGroupId().equals(19L)
					? se.decrypt(userAccount.getUserPwd())
					: "";
			userDeviceData.setUserPassword(userPassword);
			userDeviceData.setDob(userAccount.getDob() != null ? sdfdob.format(userAccount.getDob()) : "");
			userDeviceData.setPatientId(patientId);
			userDeviceData.setOtherPhoneType(
					userAccount.getOtherPhoneType() != null ? userAccount.getOtherPhoneType().getPhoneTypeDesc() : "");
			userDeviceData.setUserGroupName(userAccount.getUserGroup().getGroupName());
			userDeviceData.setSequenceNo(userAccount.getUserGroup().getSeqno());
			if (carepm != null && carepm.getUserAccount().getUserAccountId().equals(userAccount.getUserAccountId())) {
				userDeviceData.setPrimaryCarePartner(true);
			} else {
				userDeviceData.setPrimaryCarePartner(false);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userDeviceData;
	}

	public List<UserAccount> getCareFamilyByUserAccId(PatientStageWorkflow psw) {
		return careFamilyMapRepo
				.findByUserAccIdOrUserAccIdIsNullAndHospitalIdOrHospitalIdIsNullAndPayorTypeIdOrPayorTypeIdIsNullAndProcedureTypeOrProcedureTypeIsNullAndActiveTrueAndClientId(
						psw.getHspSurgId(), psw.getHospitalPractice().getHospitalId(), psw.getPayorId(),
						psw.getProcedureType(), psw.getHospitalPractice().getPracticeId())
				.stream().filter(a -> a.getCareGiverUa().getCareFamilyShow()).map(CareFamilyMapping::getCareGiverUa)
				.collect(Collectors.toList());

	}

	private List<UserAccount> getAllGroupBasedUserAccountListByPatientSwfId(Long hospitalId, Long userAccountId,
			Long patientSWFId) {

		List<UserAccount> userAccountList = null;
		try {
			userAccountList = new ArrayList<>();

			PatientStageWorkflow pswf = patientSWFRepo.findById(patientSWFId).orElse(null);

			List<Long> groupBasedCn = cNSugProcPayerRepository
					.findByproceduretypeAndPayoridAndSurgeonUaIdAndPracticeid(pswf.getProcedureType(),
							pswf.getPayorId(), pswf.getHspSurgId(), hospitalId)
					.stream().map(CNSugProcPayer::getCnUser).map(UserAccount::getUserAccountId).toList();

			if (!groupBasedCn.isEmpty()) {

				userAccountList = userRepository.findByUserAccountIdInAndCareFamilyShowTrue(groupBasedCn);
			} else {

				int cnMappingSize = cNSugProcPayerRepository.findTop1ByPracticeidAndAssignedHspTo(hospitalId, 0L)
						.size();
				if (cnMappingSize > 0) {
					userAccountList = userRepository.findByUserAccountIdInAndCareFamilyShowTrue(
							new ArrayList<>(Arrays.asList(pswf.getHspCCId())));
					addHNPCInCNMappingCase(hospitalId, userAccountList, pswf);
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userAccountList;

	}

	private List<UserAccount> addHNPCInCNMappingCase(Long hospitalId, List<UserAccount> userAccountList,
			PatientStageWorkflow psw) {
		try {
			List<Long> userAccountIds = new ArrayList<>();
			Hospital hospital = hspRepo.findById(hospitalId).orElse(null);
			if (hospital != null && hospital.getMode().equalsIgnoreCase("H")) {
				userAccountIds = hspNavSugMappingRepository
						.findBySurgeonAccountIdAndHNUserAccount_CareFamilyShowTrueAndActiveTrue(psw.getHspSurgId())
						.stream().map(HospitalNavigatorSugMapping::getHNUserid).toList();
			} else if (hospital != null && hospital.getMode().equalsIgnoreCase("P")) {
				userAccountIds = praCCHspMappingRepository

						.findByHospitalPracticeIdAndPcUserAccount_CareFamilyShowTrueAndActiveTrue(
								psw.getHospitalPractice().getHospitalPracticeId())
						.stream().map(PracticeCoordinatorHSPMapping::getPcUserid).toList();
			}

			userAccountList.addAll(userRepository.findByUserAccountIdIn(userAccountIds));

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userAccountList;
	}

	public List<UserAccount> careGiverList(Long patientId) {
		List<UserAccount> userAccountList = new ArrayList<>();
		try {
			List<CarePartnerMap> cpList = carePartnerMapRepo.findByPatientId(patientId);
			userAccountList = cpList.stream().filter(a -> a.getUserAccount().getCareFamilyShow())
					.map(a -> a.getUserAccount()).collect(Collectors.toList());

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userAccountList;
	}

	@Override
	public CareFamilyGroupData getCareFamilyGroup(Long patientId, Long loginUserAccountId) {
		CareFamilyGroupData careFamilyGrp = new CareFamilyGroupData();
		try {
			List<PatientStageWorkflow> patSWFList = patientSWFRepo
					.findByPatient_PatientIdOrderByPatientSWFIdDesc(patientId);
			for (PatientStageWorkflow patientSWF : patSWFList) {

				Hospital hospital = hspRepo.findById(patientSWF.getCCUserAccount().getUserAccountKey()).orElse(null);

//				List<PatientEpisodeCareCircle> patCareCircleList = patEpisodeCCRepo
//						.findByPatientStageWorkflow_PatientSWFIdAndEpisodeIdAndUserAccount_CareFamilyShowTrueAndUserAccount_UserGroup_UserGroupIdNotIn(
//								patientSWF.getPatientSWFId(), patientSWF.getCurrentEpisodeId(),
//								UserGroupCons.UserCheck);

				List<UserAccount> userAccList = getAllGroupBasedUserAccountListByPatientSwfId(hospital.getHospitalId(),
						loginUserAccountId, patientSWF.getPatientSWFId());

				if (userAccList.isEmpty()) {
					userAccList = userRepository
							.findByUserAccountKeyAndCareFamilyShowTrueAndActiveTrue(hospital.getHospitalId());

				}
				List<CareFamilyMapping> careFamilyList = careFamilyMapRepo
						.findByUserAccIdOrUserAccIdIsNullAndHospitalIdOrHospitalIdIsNullAndPayorTypeIdOrPayorTypeIdIsNullAndProcedureTypeOrProcedureTypeIsNullAndActiveTrueAndClientId(
								patientSWF.getHspSurgId(), patientSWF.getHospitalPractice().getHospitalId(),
								patientSWF.getPayorId(), patientSWF.getProcedureType(),
								patientSWF.getCCUserAccount().getUserAccountKey());
				List<UserAccount> careGriverUaList=careFamilyList.stream().map(CareFamilyMapping::getCareGiverUa).toList();
				//userAccList = careFamilyUserList(careFamilyList, userAccList);
				userAccList.addAll(careGriverUaList);

				careFamilyGrp = careFamilyListUsersToAdd(careFamilyGrp, patientSWF.getPatientSWFId(), hospital,
						patientSWF.getCCUserAccount(), userAccList);

//				careFamilyGrp = getPatientEpisodeCareCirclebyList(patCareCircleList, hospital,
//						patientSWF.getPatientSWFId(), patientSWF.getCCUserAccount().getUserAccountId(), careFamilyGrp);

				careFamilyGrp = addHospitalCareNavigatorDetailBycfs(careFamilyGrp, patientSWF.getPatientSWFId(),
						careFamilyList);
			}

			List<CareFamilyGroup> careNavigatorDetails = patSWFList.stream()
					.filter(a -> a.getSurgeonUserAccount().getCareFamilyShow())
					.map(a -> careFamilyGroupDetails(a.getSurgeonUserAccount().getUserAccountId(), a.getPatientSWFId(), a.getSurgeonUserAccount().getUserGroup().getSeqno(),
							 a.getSurgeonUserAccount().getFirstName(),  a.getSurgeonUserAccount().getLastName(), a.getSurgeonUserAccount().getImagePath(), a.getCCUserAccount().getHospital().getName(),
							 a.getSurgeonUserAccount().getUserGroup().getGroupName(),  a.getSurgeonUserAccount().getTitle()))
					.toList();
			careFamilyGrp.setCareNavigatorDetails(careNavigatorDetails);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return careFamilyGrp;
	}

	public CareFamilyGroup careFamilyGroupDetails(Long userAccountId, Long patientSWFId, Integer seqNo,
			String firstName, String lastName, String imagePath, String clientName, String groupName, String title) {
		CareFamilyGroup careFamilyGroup = new CareFamilyGroup();
		careFamilyGroup.setUserAccountId(userAccountId);
		careFamilyGroup.setPatientStageWorkFlowId(patientSWFId);
		careFamilyGroup.setSequenceNo(seqNo);
		careFamilyGroup.setFirstName(firstName);
		careFamilyGroup.setLastName(lastName);
		careFamilyGroup.setImagePath(imagePath);
		careFamilyGroup.setClientname(clientName);
		careFamilyGroup.setGroupName(groupName);
		return careFamilyGroup;
	}

	private CareFamilyGroupData addHospitalCareNavigatorDetailBycfs(CareFamilyGroupData careFamilyGrp,
			Long patientSWFId, List<CareFamilyMapping> careFamilyMappingList) {
		List<CareFamilyGroup> hspCareNavigatorList = careFamilyGrp.getHospitalCareNavigatorDetails();
		careFamilyMappingList.stream().filter(careFamily -> careFamily.getCareGiverUa().getCareFamilyShow())
				.map(care -> {
					CareFamilyGroup careFamilyGroup = careFamilyGroupDetails(care.getCareGiver(), patientSWFId,
							care.getCareGiverUa().getUserGroup().getSeqno(), care.getCareGiverUa().getFirstName(),
							care.getCareGiverUa().getLastName(), care.getCareGiverUa().getImagePath(),
							care.getCareGiverUa().getHospital().getName(),
							care.getCareGiverUa().getUserGroup().getGroupName(), care.getCareGiverUa().getTitle());
					hspCareNavigatorList.add(careFamilyGroup);
					return care;
				});
		careFamilyGrp.setHospitalCareNavigatorDetails(hspCareNavigatorList);
		return careFamilyGrp;
	}

//	private CareFamilyGroupData getPatientEpisodeCareCirclebyList(List<PatientEpisodeCareCircle> patCareCircleList,
//			Hospital hospital, Long patientSWFId, Long cnUserAccountId, CareFamilyGroupData careFamilyGrp) {
//		List<CareFamilyGroup> careFamilyGroupList = patCareCircleList.stream()
//				.map(a -> userRepository.findById(a.getUserAccountId()).orElse(null))
//				.filter(a -> checkIfCareFamilyFilterforHosUser(hospital, a, cnUserAccountId))
//				.map(a -> careFamilyGroupDetails(a.getUserAccountId(), patientSWFId, a.getUserGroup().getSeqno(),
//						a.getFirstName(), a.getLastName(), a.getImagePath(), hospital.getName(),
//						a.getUserGroup().getGroupName(), a.getTitle()))
//				.collect(Collectors.toList());
//
//		careFamilyGrp.setCareNavigatorDetails(careFamilyGroupList); 
//
//		return careFamilyGrp;
//
//	}

//	private Boolean checkIfCareFamilyFilterforHosUser(Hospital hospital, UserAccount userAccount,
//			Long cnUserAccountId) {
//		Boolean isCareFamFilter = true;
//		if (userAccount != null && (userAccount.getUserGroup().getUserGroupId() == 32
//				|| userAccount.getUserGroup().getUserGroupId() == 33)) {
//			isCareFamFilter = careFamilyMapRepo.findByHospitalIdAndActiveTrue(hospital.getHospitalId()).isEmpty()
//					? false
//					: true;
//		} else {
//			isCareFamFilter = true;
//		}
//		return isCareFamFilter;
//	}

	private CareFamilyGroupData careFamilyListUsersToAdd(CareFamilyGroupData careFamilyGrp, Long patientSWFId,
			Hospital hospital, UserAccount ccUserAcct, List<UserAccount> userAccList) {
		List<CareFamilyGroup> careFamilyGroupList = new ArrayList<>();
		for (UserAccount userAccount : userAccList) {
			if (userAccount.getUserGroup().getUserGroupId() == 32
					|| userAccount.getUserGroup().getUserGroupId() == 33) {
				boolean flag = findHNPCforCarefamily(patientSWFId, userAccount.getUserGroup().getUserGroupId());
				if (flag) {

					CareFamilyGroup careFamilyGroup = careFamilyGroupDetails(userAccount.getUserAccountId(),
							patientSWFId, userAccount.getUserGroup().getSeqno(), userAccount.getFirstName(),
							userAccount.getLastName(), userAccount.getImagePath(), userAccount.getHospital().getName(),
							userAccount.getUserGroup().getGroupName(), userAccount.getTitle());
					careFamilyGroupList.add(careFamilyGroup);
				}
			} else if (userAccount.getUserGroup().getUserGroupId() == 9
					|| userAccount.getUserGroup().getUserGroupId() == 17) {

				CareFamilyGroup careFamilyGroup = careFamilyGroupDetails(userAccount.getUserAccountId(), patientSWFId,
						userAccount.getUserGroup().getSeqno(), userAccount.getFirstName(), userAccount.getLastName(),
						userAccount.getImagePath(), userAccount.getHospital().getName(),
						userAccount.getUserGroup().getGroupName(), userAccount.getTitle());

				careFamilyGroupList.add(careFamilyGroup);
			}
		}
		careFamilyGrp.setHospitalCareNavigatorDetails(careFamilyGroupList);

		return careFamilyGrp;
	}

//	private List<UserAccount> careFamilyUserList(List<CareFamilyMapping> careFamilyList,
//			List<UserAccount> userAccList) {
//		careFamilyList.stream().map(cfm -> {
//			UserAccount carefamily = userRepository.findById(cfm.getCareGiver()).orElse(null);
//			userAccList.add(carefamily);
//			return cfm;
//		});
//		return userAccList;
//	}

	@Override
	public boolean findHNPCforCarefamily(Long patientSWFId, Long userGroupId) {
		PatientStageWorkflow patientSWF = patientSWFRepo.findById(patientSWFId).orElse(null);
		if (userGroupId == 32) {
			List<PracticeCoordinatorHSPMapping> practiceHSPMap = practiceHSPMapRepo
					.findDistinctByHospitalPracticeIdAndActiveTrue(
							patientSWF.getHospitalPractice().getHospitalPracticeId());
			return !practiceHSPMap.isEmpty();

		} else if (userGroupId == 33) {
			List<HospitalNavigatorSugMapping> hspSugMap = hspNavigatorSugMapRepo
					.findDistinctBySurgeonAccountIdAndActiveTrue(patientSWF.getHspSurgId());
			return !hspSugMap.isEmpty();

		}
		return false;
	}

	@Override
	public CareFamilyMessageData getCareFamilyByMessageSent(CarePartnerMapRequestData careRequestData) {
		List<CareFamilyMessageMap> careFamilyMessge = new ArrayList<>();
		CareFamilyMessageData response = new CareFamilyMessageData();
		try {
			LOGGER.info("------------------getCareFamilyByMessageSent Json -----------------");
			List<PatientStageWorkflow> patSWFList = patientSWFRepo
					.findByPatient_PatientIdOrderByPatientSWFIdDesc(careRequestData.getPatientId());
			for (PatientStageWorkflow patientSWF : patSWFList) {
				List<Long> careFamilyList = getCareFamilyByMessageSentId(patientSWF,
						careRequestData.getLoginUserAccountId());
				careFamilyList = getAllNavigatorList(careRequestData.getLoginUserAccountId(), patientSWF,
						careFamilyList);
				careFamilyMessge = careFamilyList.stream().map(a -> {
					CareFamilyMessageMap careFamily = new CareFamilyMessageMap();
					careFamily.setCnId(a);
					careFamily.setPatientSWfId(patientSWF.getPatientSWFId());
					return careFamily;
				}).toList();
			}
			response.setCareNavigatorDetails(careFamilyMessge);

		} catch (Exception e) {
			LOGGER.error(LOG_DEVICE_EXCEPTION, e);
		}
		return response;
	}

	private List<Long> getAllNavigatorList(Long loginUserAccountId, PatientStageWorkflow patientSWF,
			List<Long> careFamilyList) {
		Long hospitalId = patientSWF.getCCUserAccount().getUserAccountKey();
		List<UserAccount> userAccList = getAllGroupBasedUserAccountListByPatientSwfId(hospitalId, loginUserAccountId,
				patientSWF.getPatientSWFId());
		if (userAccList.isEmpty()) {
			userAccList = userRepository.findByUserAccountKeyAndCareFamilyShowTrueAndActiveTrue(hospitalId);
		}
		if (!userAccList.isEmpty()) {
			for (UserAccount userAcct : userAccList) {
				if (userAcct.getUserGroup().getUserGroupId() == 32 || userAcct.getUserGroup().getUserGroupId() == 33) {
					boolean flag = findHNPCforCarefamily(patientSWF.getPatientSWFId(),
							userAcct.getUserGroup().getUserGroupId());
					if (flag && !careFamilyList.isEmpty() && !careFamilyList.contains(userAcct.getUserAccountId())) {
						careFamilyList.add(userAcct.getUserAccountId());
					}
				} else {
					if (RCUserUtil.userAllowedforList(careFamilyList, userAcct)) {
						careFamilyList.add(userAcct.getUserAccountId());
					}
				}
			}
		}
		return careFamilyList;
	}

	private List<Long> getCareFamilyByMessageSentId(PatientStageWorkflow patientSWF, Long loginUserAccountId) {
		List<Long> userAccountIds = new ArrayList<>();
		try {
			UserAccount loginUserAccount = userRepository.findById(loginUserAccountId).orElse(null);
			if (loginUserAccount != null && (loginUserAccount.getUserGroup().getUserGroupId() == 20L
					|| loginUserAccount.getUserGroup().getUserGroupId() == 19L)) {

				loginUserAccount = patientSWF.getCCUserAccount();
			}
			List<Long> groupBasedCn = cNSugProcPayerRepository
					.findByproceduretypeAndPayoridAndSurgeonUaIdAndPracticeid(patientSWF.getProcedureType(),
							patientSWF.getPayorId(), patientSWF.getHspSurgId(), loginUserAccount.getUserAccountKey())
					.stream().map(CNSugProcPayer::getCnUser).map(UserAccount::getUserAccountId).toList();
			if (!groupBasedCn.isEmpty()) {
				userAccountIds = userRepository.findDistinctByCareFamilyShowTrueAndUserAccountIdIn(groupBasedCn)
						.stream().map(UserAccount::getUserAccountId).toList();
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userAccountIds;
	}

	@Override
	public ResponseMessage saveUserLoginAudit(DeviceLoginData deviceLoginData) {
		ResponseMessage response = new ResponseMessage();
		try {
			UserAccount userAccount = null;
			String browser = DEVICE_IOS;
			UserLoginAudit userLoginAudit = new UserLoginAudit();

			if (deviceLoginData.getCarePartnerId() != null && deviceLoginData.getCarePartnerId() != 0) {
				userLoginAudit.setUserAccountId(deviceLoginData.getCarePartnerId());
			} else {
				userAccount = userRepository
						.findByUserAccountKeyAndUserGroup_UserGroupId(deviceLoginData.getPatientId(), 19L).orElse(null);
				userLoginAudit.setUserAccountId(userAccount.getUserAccountId());
			}
			browser = !deviceLoginData.getModeOfLogin().isBlank() ? deviceLoginData.getModeOfLogin() : browser;
			userLoginAudit.setIpAddress("");
			userLoginAudit.setCreatedDate(deviceLoginData.getIsLoginTime());
			userLoginAudit.setMode(LOGIN);
			userLoginAudit.setBrowser(browser);
			userLoginAudit.setAppVersion(RCUserUtil.getNonEmptyString(deviceLoginData.getAppVersion()));
			userLoginAudit.setOsVersion(RCUserUtil.getNonEmptyString(deviceLoginData.getOsVersion()));
			userLoginRepo.save(userLoginAudit);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		response.setMessage(CommonConstant.SUCCESS);
		return response;
	}

	@Override
	public ResponseMessage saveUserSecTransAudit(DeviceActivationData deActiveData) {
		ResponseMessage response = new ResponseMessage();
		try {
			UserAccount userAccount = userRepository.findById(deActiveData.getUserAccountId()).orElse(null);
			UserSecTransAudit userSecTransAudit = new UserSecTransAudit();
			userSecTransAudit.setCreatedOn(new Date());
			userSecTransAudit.setMode(DEVICE_ACTIVATION);
			userSecTransAudit.setIsDeviceActivation(deActiveData.getIsDeviceActivation());
			userSecTransAudit.setUserAccount(userAccount);
			userSecTransAudit.setIsActive(true);
			userSecTransAuditRepo.save(userSecTransAudit);
			setActivationUpdate(deActiveData, deActiveData.getIsDeviceActivation());

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		response.setStatus(CommonConstant.SUCCESS);
		return response;
	}

	private void setActivationUpdate(DeviceActivationData deActiveData, boolean isDeviceActivation) {

		if (isDeviceActivation) {
			String activationMode = RCUserUtil.stringContains(deActiveData.getActivationMode())
					? deActiveData.getActivationMode()
					: "D";
			if (deActiveData.getCarePartnerId() != 0) {
				UserAccount cpUserAccount = userRepository.findById(deActiveData.getCarePartnerId()).orElse(null);
				if (cpUserAccount != null) {
					userRepository.userAccountActivationModeAndDateUpdate(cpUserAccount.getUserAccountId(),
							activationMode);
				}
			} else if (deActiveData.getUserAccountId() != null) {
				userRepository.userAccountActivationModeAndDateUpdate(deActiveData.getUserAccountId(), activationMode);
			}
		}
	}

	@Override
	public String getDeviceVersion(JsonObject obj, HttpServletRequest request) {
		String returnValue = "";
		StatusResponse msg = new StatusResponse();
		try {
			String mode = RCUtil.getJsonStringValue(obj, "appmode", "");
			String value = RCUtil.getValueByString(RCUtil.getJsonStringValue(obj, "cversion", ""), "0");

			float cversion = 0.0f;
			if (!value.isEmpty()) {
				cversion = Float.parseFloat(value);
			} else {
				cversion = -1;
			}
			if (!mode.isEmpty()) {
				DeviceVersion version = deviceVersionRepository.findFirstByAppmodeOrderByVersionIdDesc(mode);
				version.setPopupShow(
						cversion == -1 ? 1l : cversion >= Float.parseFloat(version.getAppVersionCode()) ? 0l : 1l);
				if (version != null) {
					if (cversion == -1) {
						version.setForceUpdate(true);
					} else {
						float codeVersion = cversion;
						List<DeviceVersion> deviceVersions = deviceVersionRepository
								.findByAppmodeOrderByVersionIdDesc(mode);
						deviceVersions.stream().filter(a -> (Float.parseFloat(a.getAppVersionCode()) > codeVersion))
								.collect(Collectors.toList());

						version.setForceUpdate(deviceVersions.stream().anyMatch(a -> a.getForceUpdate()));
					}
					returnValue = version.toString();
				}
			} else {
				msg.setMessage(CommonConstant.SOMETHINGWNT);
				msg.setStatus(CommonConstant.FAILURE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}

	@Override
	public ResponseMessage saveProfileResultDetails(List<ProfileResultDetailsData> profileResDataList) {
		ResponseMessage response = new ResponseMessage();
		try {
			int suFlag = 0;
			String mode = "";
			for (ProfileResultDetailsData profileResData : profileResDataList) {
				ProfileResultDetails profileAnswerSave = new ProfileResultDetails();
				Long useraccountId = profileResData.getUserAccountId();

				ProfileResultDetails profileAnswer = profileRDRepo.findByUserAccount_UserAccountId(useraccountId);

				UserAccount useraccount = userRepository.findById(useraccountId).orElse(null);
				if (profileAnswer != null) {
					profileAnswer.setUserAccountId(useraccountId);
					profileAnswer.setQuestionIds(profileResData.getQuestionIds());
					profileAnswer.setAnswers(profileResData.getAnswers());
					profileAnswer.setRandomId(RCUserUtil.getUserContactDetail(profileResData.getRandomId()));
					profileRDRepo.save(profileAnswer);
					useraccount.setProfileResultDetailId(profileAnswer.getProfileResultDetailId());
					suFlag = 1;
					mode = "Edit";
				} else {
					profileAnswerSave.setUserAccountId(useraccountId);
					profileAnswerSave.setQuestionIds(profileResData.getQuestionIds());
					profileAnswerSave.setAnswers(profileResData.getAnswers());
					profileAnswerSave.setRandomId(RCUserUtil.getUserContactDetail(profileResData.getRandomId()));
					profileRDRepo.save(profileAnswerSave);
					useraccount.setProfileResultDetailId(profileAnswerSave.getProfileResultDetailId());
					suFlag = 0;
					mode = "Add";
				}
				userRepository.save(useraccount);

				AuditLogData auditLog = new AuditLogData();
				auditLog.setTableName("ProfileResultDetails");
				if (suFlag == 0) {
					auditLog.setIdValue(profileAnswerSave.getProfileResultDetailId());
				} else {
					auditLog.setIdValue(profileAnswer.getProfileResultDetailId());
				}

				if (suFlag == 0)
					auditLog.setOperation("CREATE");
				else
					auditLog.setOperation("EDIT");

				auditLog.setPatient(profileResData.getPatientId());

				List<PatientStageWorkflow> pswf = patientSWFRepo
						.findByPatient_PatientIdAndPswIsActiveTrueOrderByPatientSWFIdDesc(
								profileResData.getPatientId());
				if (!pswf.isEmpty()) {
					LogDeviceTransAuditData logData = UserValidationUtil.deviceLoginAudit(
							pswf.get(0).getPatient().getPatientId(), pswf.get(0).getPatientSWFId(), "MYPROFILE", mode,
							"About me details");
				}

			}
			response.setMessage("Profile result details saved successfully");
			response.setSaveStatus(SUCCESS);
		} catch (Exception e) {
			response.setMessage("error in saving profile result details ");
			response.setSaveStatus(FAILURE);
			LOGGER.error("error in saving profile result details ", e);
		}
		return response;
	}

	@Override
	public ResponseMessage setForgotattemptFailedUnregisteredUSer(List<ForgotAttemptData> forgotAttemtDataList) {
		ResponseMessage response = new ResponseMessage();
		try {

			for (ForgotAttemptData forgotAttemtData : forgotAttemtDataList) {

				List<UserAccount> uaccList = userRepository.findByEmailOrPhone(forgotAttemtData.getUserName(),
						forgotAttemtData.getUserName());
				UserAccount uacc = !uaccList.isEmpty() ? uaccList.get(0) : null;
				if (uacc != null) {
					int count = forgotAttemtData.getForgotattemptFailed();
					Long userSecId = userAccountService.getUserSecResultDetailsAlreadyExist(uacc.getUserAccountId());

					userSecResDetRepo.updateSecurityQuestionAttemptsBothSingleAndMultiRole(userSecId, count);

					if (forgotAttemtData.getAccountBlocked()) {
						accountBlockbyUseraccount(uacc);
					}
				}
				if (forgotAttemtData.getIsForgotSecurityQuest()) {
					UserRequestAudit userRequestAudit = uacc != null
							? userReqRepo.findByUserAccount_UserAccountIdAndModeAndStatus(uacc.getUserAccountId(),
									"ForgetSecurityAnswer", "Pending").stream().findFirst().orElse(null)
							: null;
					if (userRequestAudit != null) {
						userRequestAudit.setStatus("Completed");
						userReqAuditRepo.save(userRequestAudit);
					}
					userReqAuditService.saveForgotSecurityAnsLinkDetails(uacc, "Initiate-SecurityQA");
				}
			}
			response.setStatus(SUCCESS);
			response.setMessage("Save forgot attempt success");

		} catch (Exception e) {
			response.setStatus(FAILURE);
			response.setMessage("Device Error to save forgot attempt");
			LOGGER.error("Device Error", e);
		}

		return response;
	}

	@Override
	public ResponseMessage resetPatientPassword(ResetPatPassReq patPassReq) {
		ResponseMessage response = new ResponseMessage();
		if (RCUserUtil.stringContains(patPassReq.getUserName())) {
			response = executeResetPatientPassword(patPassReq.getUserName(), patPassReq.getPassword(),
					patPassReq.getRandomId(), response);
		} else {
			response.setMessage(INCORRECT_USERNAME);
			response.setStatus(FAILURE);
		}

		return response;
	}

	private ResponseMessage executeResetPatientPassword(String userName, String password, String randomId,
			ResponseMessage response) {

		try {
			UserAccount useracc = userRepository.findByEmailOrPhone(userName, userName).stream().findFirst()
					.orElse(null);

			StringEncrypter stringEncrypter = new StringEncrypter("DES");
			if (password != null) {
				UserSecTransAudit usta = userSecTransAuditRepo.findByRandomId(randomId.trim());
				if (usta != null && usta.getIsActive() && usta.getMode().equalsIgnoreCase(PASSWORDUPDATE)) {
					String userValue = "0";
					if (RCUserUtil.stringContains(useracc.getEmail())) {
						userValue = useracc.getEmail();
					} else if (RCUserUtil.stringContains(useracc.getPhone())) {
						userValue = useracc.getTeleCode() + "-" + useracc.getPhone();
					}
					List<UserAccount> multiUserAccList = userAccountService.validateUserNew(userValue);
					for(UserAccount ua : multiUserAccList) {
						try {
							LOGGER.info(stringEncrypter.encrypt(password));
							ua.setUserPwd(stringEncrypter.encrypt(password));
						} catch (EncryptionException e) {
							LOGGER.info(CommonConstant.EXCEPTION, e);
						}
						ua.setUserPwdCreatedOn(new Date());
						ua.setTempPasswordActive(false);
						userRepository.save(ua);
					}
					savePasswordHistory(useracc, password);
					sendPasswordUpdateNotification(useracc);
					response.setMessage("Your password has been saved");
					response.setStatus(SUCCESS);
					usta.setIsActive(false);
					userSecTransAuditRepo.save(usta);
				}

			}
		} catch (EncryptionException e) {
			LOGGER.error("Device Error", e);
		}
		return response;

	}

	public ResponseMessage savePasswordHistory(UserAccount userAccn, String pwd) {
		ResponseMessage statusMsg = new ResponseMessage();
		try {
			PasswordHistory pwdHistory = new PasswordHistory();

			if (userAccn.getUserGroup().getUserGroupId() != 19L && userAccn.getUserGroup().getUserGroupId() != 20L) {
				String encPwd = new StringEncrypter("DES").encrypt(pwd);
				pwdHistory.setUserAccount(userAccn);
				pwdHistory.setUserPwd(encPwd);
				pwdHistory.setCreatedDate(new Date());
				userSecTransAuditService.savePasswordHistory(pwdHistory);
				passwordService.updatePwdForBothSingleOrMultiRoleUserAcctByEmailOrPhone(userAccn, "tempPwdFlag");
				userSecTransAuditRepo.userSecTransAuditActiveUpdate(userAccn.getUserAccountId(),
						new ArrayList<>(Arrays.asList("login-otp", "password-otp", "activation-otp", "activationotp")));
				statusMsg.setStatus(SUCCESS);
			}
		} catch (Exception e) {
			statusMsg.setStatus(FAILURE);
			LOGGER.error("Error while saving password history...", e);
		}
		return statusMsg;
	}

	private void sendPasswordUpdateNotification(UserAccount userAccount) {
		Long hspId = hospitalService.getHospitalIdForAnyUserAccount(userAccount).getHospitalId();
		try {
			String notifyType = NotificationConstant.PASSWORDUPDATEDNOTIFICATION;
			NotificationData notificationData = new NotificationData();
			notificationData.setHspId(hspId);
			notificationData.setNotificationType(notifyType);
			notificationData.setToUser(userAccount.getUserAccountId());
			// TODO Notification
			// notificationUtil.sendNotification(notifyDTO);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	@Override
	public ResponseMessage saveLoginAuditForLater(DeviceActivationData deviceActivationData) {
		ResponseMessage response = new ResponseMessage();
		try {
			UserAccount userAccount = userRepository.findById(deviceActivationData.getUserAccountId()).orElse(null);
			UserSecTransAudit userSecTransAudit = new UserSecTransAudit();
			userSecTransAudit.setCreatedOn(new Date());
			userSecTransAudit.setMode(DEVICE_ACTIVATION);
			userSecTransAudit.setIsDeviceActivation(deviceActivationData.getIsDeviceActivation());
			userSecTransAudit.setUserAccount(userAccount);
			userSecTransAudit.setIsActive(true);
			userSecTransAuditRepo.userSecTransAuditActiveUpdate(userAccount.getUserAccountId(),
					new ArrayList<>(Arrays.asList(DEVICE_ACTIVATION)));
			userSecTransAuditRepo.save(userSecTransAudit);
			if (deviceActivationData.getIsDeviceActivation() && userAccount != null) {
				String activationMode = deviceActivationData.getActivationMode() != null
						? deviceActivationData.getActivationMode()
						: "D";
				userAccountService.activationUpdate(userAccount.getUserAccountId(), activationMode);
			}

			String androidCheck = deviceActivationData.getActivationMode().equalsIgnoreCase("A") ? DEVICE_ANDROID
					: DEVICE;
			String iosCheck = deviceActivationData.getActivationMode().equalsIgnoreCase("A") ? DEVICE_IOS
					: androidCheck;
			UserLoginAudit userLoginAudit = new UserLoginAudit();
			userLoginAudit.setIpAddress("");
			userLoginAudit.setCreatedDate(new Date());
			userLoginAudit.setMode(LOGIN);
			userLoginAudit.setBrowser(iosCheck);
			userLoginAudit.setUserAccountId(userAccount.getUserAccountId());
			userLoginAudit.setAppVersion(deviceActivationData.getAppVersion());
			userLoginAudit.setOsVersion(deviceActivationData.getOsVersion());
			loginAuditRepository.save(userLoginAudit);
			response.setStatus(SUCCESS);
			response.setMessage("Save DeviceActivation success");
		} catch (Exception e) {
			response.setStatus(FAILURE);
			response.setMessage("Error in DeviceActivation " + e.getMessage());
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}

		return response;
	}

	@Override
	public ResponseMessage getPassWordUpdatebyPatient(UserSecAnsData userSecAnsData) {
		ResponseMessage response = new ResponseMessage();

		try {

			UserAccount userAccount = userRepository.findById(userSecAnsData.getUserAccountId()).orElse(null);
			executeCurrentUser(userSecAnsData.getUserPassword(), userAccount.getWelcomeFlag(), userAccount);
			if (!userSecAnsData.getIsCarePartner()) {
				PatientStageWorkflow patSWF = pswfRepo.findByPatient_PatientId(userAccount.getUserAccountKey()).stream()
						.findFirst().orElse(null);
				// allOnDemandSPUtility.updatePatientStatusInPatientStageWorkflow(patSWF.getPatientSWFId());

			}
			Hospital hospital = hospitalService.getHospitalIdForAnyUserAccount(userAccount);

			String notifyType = NotificationConstant.ACCOUNTACTIVATION;
			NotificationData notificationData = new NotificationData();

			notificationData.setToUser(userAccount.getUserAccountId());
			notificationData.setHspId(hospital.getHospitalId());
			notificationData.setNotificationType(notifyType);
			if (((userAccount.getUserGroup().getUserGroupId()).equals(UserGroupCons.PATIENT))
					&& userAccount.getComType() != null) {

				if (!userAccount.getWelcomeFlag()) {
					notificationData.setNotificationType(NotificationConstant.PASSWORDUPDATEDNOTIFICATION);
				}
				// TODO Notification
				// notificationUtil.sendNotification(notifyDTOobj);
				sendPatientExerciseNotification(userAccount, hospital);

			} else if ((userAccount.getUserGroup().getUserGroupId()).equals(UserGroupCons.CARE_PARTNER)
					&& userAccount.getComType() != null) {
				if (!userAccount.getWelcomeFlag()) {

					notificationData.setNotificationType(NotificationConstant.PASSWORDUPDATEDNOTIFICATION);
				}
				// TODO Notification
				// notificationUtil.sendNotification(notifyDTOobj);
				executeFurtherCpToGetPassWordUpdatebyPatient(userAccount, hospital);
			}
			response.setStatus(SUCCESS);
			response.setMessage("Save userSecAnswer success");

		} catch (Exception e) {
			response.setStatus(FAILURE);
			response.setMessage("Error in UserSecAnswer " + e.getMessage());
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}

		return response;
	}

	private void executeCurrentUser(String password, Boolean isActivation, UserAccount currentUa) {
		try {
			StringEncrypter encrypter = new StringEncrypter("DES");
			String encrptedMessage = encrypter.encrypt(password);

			if (currentUa != null) {
				String phoneNo = (currentUa.getTeleCode() != null) ? currentUa.getTeleCode() : "";
				if (phoneNo != null && !phoneNo.isEmpty()) {
					phoneNo = (currentUa.getPhone() != null) ? phoneNo + "-" + currentUa.getPhone() : "";
				}
				List<UserAccount> ulist = userAccountService.getUsersByEmailId(currentUa.getEmail(), phoneNo);
				currentUa.setWelcomeFlag(false);
				ulist.stream().map(ua -> {
					ua.setUserPwd(encrptedMessage);
					ua.setUserPwdCreatedOn(new Date());
					ua.setWelcomeFlag(false);
					ua.setTempPasswordActive(false);
					if (isActivation) {
						ua.setPHIAckDate(new Date());
					}
					userRepository.save(ua);
					return ua;
				});

				savePasswordHistory(currentUa, password);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	private void sendPatientExerciseNotification(UserAccount userAccount, Hospital hsp) {
		try {
			Patient pat = patientRepo.findById(userAccount.getUserAccountKey()).orElse(null);
			UserAccount cnAccount = userAccountService
					.getUserAccountByUserAccountId(pat.getCreatedByUa().getUserAccountId());
			Hospital hospital = hospitalService.getHospitalById(cnAccount.getUserAccountKey());
			MenuConfiguration mcf = menuConfigRepo.findByMenuMenuIdAndHospitalHospitalId(19L, hospital.getHospitalId())
					.stream().findFirst().orElse(null);
			PatientStageWorkflow patientSWF = pswfRepo.findByPatient_PatientId(pat.getPatientId()).stream().findFirst()
					.orElse(null);
			// TODO workflow
			List<String> videoList = null;
			// hospitalVideoMappingService.getVideoCountByEpisodeIdAndStageWorkflowId(patientSWF.getStageWorkflowId());
			Surgeon sugtemp = patientSWF.getHospitalSurgeon().getSurgeon();

			if (mcf != null && mcf.getStatus() && !videoList.isEmpty() && patientSWF.getDos() != null) {
				String stageCategory = "";
//				Date today = new Date();
//				MaterialDateCalculator mdc = new MaterialDateCalculator();
//				int dayDiff = 0;
//								
//
//				if (patientSWF.getDos() != null && today.compareTo(patientSWF.getDos()) >= 0) {
//					dayDiff = mdc.daysDiff(today, patientSWF.getDos());
//					if (dayDiff <= 90) {
//						stageCategory = POST_OP;
//					} else {
//						stageCategory = POST_OP_ADVANCED;
//					}
//				} else if (patientSWF.getDos() != null && today.compareTo(patientSWF.getDos()) < 0) {
//					stageCategory = "Pre-Op";
//				}
				subSendPatientExerciseNotification(userAccount, hsp, sugtemp, stageCategory);
				//// TODO PushNotification
				// sendExercisePushNotification4(userAccount,patientSWF,"EXERCISENOTIFY");
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	private void subSendPatientExerciseNotification(UserAccount userAccount, Hospital hsp, Surgeon sugeon,
			String stageCategory) {
		try {

			if (!userAccount.getWelcomeFlag() && userAccount.getComType() != null) {

				String notifyType = NotificationConstant.EXERCISENOTIFICATION;
				NotificationData notificationData = new NotificationData();
				notificationData.setToUser(userAccount.getUserAccountId());
				notificationData.setHspId(hsp.getHospitalId());
				notificationData.setNotificationType(notifyType);
				notificationData.setSurgeonId(sugeon.getSurgeonId());
				// TODO Notification
				// notificationUtil.sendNotification(notifyObj);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	private void executeFurtherCpToGetPassWordUpdatebyPatient(UserAccount userAccount, Hospital hsp) {
		try {

			List<CarePartnerMap> cpmList = carePartnerMapRepo
					.findByActiveIsTrueAndUserAccount_userAccountIdAndUserAccount_UserGroup_UserGroupId(
							userAccount.getUserAccountId(), UserGroupCons.CARE_PARTNER);
			for (CarePartnerMap cpm : cpmList) {
				PatientStageWorkflow patSwf = pswfRepo.findByPatient_PatientId(cpm.getPatientId()).stream().findFirst()
						.orElse(null);
				//// TODO workflow
				List<String> videoList = null;
				// hospitalVideoMappingService.getVideoCountByEpisodeIdAndStageWorkflowId(patSwf.getStageWorkflowId());
				MenuConfiguration mcf = menuConfigRepo.findByMenuMenuIdAndHospitalHospitalId(19L, hsp.getHospitalId())
						.stream().findFirst().orElse(null);
				if (!videoList.isEmpty() && !userAccount.getWelcomeFlag() && mcf != null
						&& Boolean.TRUE.equals(mcf.getStatus())) {
					sendExerciseNotification(patSwf, userAccount);
				}
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	private void sendExerciseNotification(PatientStageWorkflow patSwf, UserAccount useracc) {
		if (patSwf != null && patSwf.getDos() != null) {
			try {
				List<UserAccount> carePartnerUaList = carePartnerMapService
						.carePartnerList(patSwf.getPatient().getPatientId());
				carePartnerUaList.stream().map(a -> {
					String notifyType = NotificationConstant.EXERCISENOTIFICATION;
					NotificationData notificationData = new NotificationData();
					notificationData.setNotificationType(notifyType);
					notificationData.setHspId(patSwf.getCCUserAccount().getUserAccountKey());
					notificationData.setPatientId(patSwf.getPatient().getPatientId());
					notificationData.setSurgeonId(patSwf.getSurgeonUserAccount().getUserAccountKey());
					notificationData.setToUser(a.getUserAccountId());
					// TODO Notification
					// notificationUtil.sendNotification(notifyDTO);
					return notifyType;

				});

			} catch (Exception e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
			}
		}
	}

	@Override
	public ResponseMessage saveFcmToken(FcmTokenData fcmToken) {
		ResponseMessage response = new ResponseMessage();
		try {
			if (fcmToken.getFcmToken() != null) {
				deviceRepository.findByTokenId(fcmToken.getFcmToken()).stream().map(existPd -> {
					existPd.setValidToken(2);
					existPd.setTokenId(existPd.getDeviceId() + "_" + fcmToken);
					deviceRepository.save(existPd);
					response.setDeviceId(existPd.getDeviceId());
					return existPd;
				});

				PatientDevice patDevice = deviceRepository.findByHandshakeKey(fcmToken.getHandShakeKey()).stream()
						.findFirst().orElse(null);
				patDevice.setTokenId(fcmToken.getFcmToken());
				patDevice.setValidToken(1);
				patDevice.setAppVersion(fcmToken.getAppVersion());
				patDevice.setOsVersion(fcmToken.getOsVersion());
				deviceRepository.save(patDevice);
				UserAccount notifyUpdateUa = userRepository.findByUserAccountKey(patDevice.getPatient().getPatientId())
						.stream().findFirst().orElse(null);

				if (patDevice.getCarePartnerId() > 0)
					notifyUpdateUa = userRepository.findById(patDevice.getCarePartnerId()).orElse(null);

				if (notifyUpdateUa != null)
					getMultiTokenUserUpdatebyUserAccount(notifyUpdateUa);

				response.setStatus(SUCCESS);
				response.setMessage("update fcmToken in patient Device");
			}

		} catch (Exception e) {
			response.setStatus(FAILURE);
			response.setMessage("Error in fcmToken " + e.getMessage());
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	private void getMultiTokenUserUpdatebyUserAccount(UserAccount notifyUpdate) {
		try {
			String username = RCUserUtil.getString(notifyUpdate.getEmail());
			if (username.isEmpty()) {
				username = RCUserUtil.stringContains(notifyUpdate.getPhone())
						&& RCUserUtil.stringContains(notifyUpdate.getTeleCode())
								? notifyUpdate.getTeleCode().concat("-").concat(notifyUpdate.getPhone())
								: "";
			}

			if (!username.isEmpty()) {
				List<UserAccount> userActList = userAccountService.validateUserNew(username);
				userActList.stream().map(ua -> {
					ua.setPushNotification(true);
					userRepository.save(ua);
					return ua;
				});

			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	@Override
	public ResponseMessage updateUserDataDeviceSync(List<UpdateUserDeviceData> userDatas) {
		ResponseMessage response = new ResponseMessage();
		try {
			String resultFilePatImagePath = "" + "/images/user";
			String patImageFolderPath = "" + "WEB-INF/classes/public";
			fileExist(patImageFolderPath);
			String existingPassword = "";
			UserAccount userAccount = new UserAccount();
			String defaultUserName = GenerateOTP.getAlphaNumericForUserName();
			Hospital hospital = null;
			for(UpdateUserDeviceData userData : userDatas) {
				UserGroup usergroup = userGroupRepo.findById(userData.getUserGroup()).orElse(null);
				if (userData.getIsEditStatus()) {
					userAccount = userRepository.findById(userData.getUserAccountId()).orElse(null);
					existingPassword = userAccount != null ? userAccount.getUserPwd() : "";
					userAccount = RCUserUtil.stringContains(userData.getRandomId())
							? userRepository.findByRandomId(userData.getRandomId()).stream().findFirst().orElse(null)
							: userAccount;
					if (userAccount != null) {

						String oldEmail = RCUserUtil.getString(userAccount.getEmail());
						String oldPhone = RCUserUtil.getString(userAccount.getPhone());
						String userValue = userData.getUserName();
						userValue = (userValue ==null || userValue.isBlank()) ? userData.getTeleCode() +"-"+userData.getPhone() : userValue;
						otherAccountUpdate(userValue, userData, resultFilePatImagePath, patImageFolderPath, oldPhone,
								defaultUserName);
						userAccount.setUserGroup(usergroup);
						String email = RCUserUtil.getUserContactDetail(userData.getEmail());
						userAccount = setUserAccountValues(userData, userAccount, resultFilePatImagePath,
								patImageFolderPath);
						userAccount.setUserName(setUserName(email, oldEmail, defaultUserName, userAccount));
						userAccount.setPushNotification(userData.getPushNotification());
						boolean onhalf = userData.getActive();
						String languageCode = userAccountService.getLanguageCode(userAccount);
						hospital = hospitalService.getHospitalIdForAnyUserAccount(userAccount);
						String willSendOnBoardWelcomeLink = userAccountService.willSendOnBoardWelcomeLink(
								userAccount.getUserAccountId(), userData.getEmail(), userData.getPhone());
						deactivtaeSub(willSendOnBoardWelcomeLink, userAccount, userData.getWhoseCarePartner(), onhalf);

						userAccount = setPhoneValues(userData, userAccount);

						userAccount.setDob(setdob(userData));
						String oldPassword = (new StringEncrypter("DES").decrypt(userAccount.getUserPwd()));
						String password = userData.getPassword();
						userAccount.setUserPwd(new StringEncrypter("DES").encrypt(password));
						//userAccountService.updateUserProfileAccount(userAccount, oldEmail, oldPhone, true, defaultUserName);

						if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(userAccount))) {
							userAccountService.contactPreValidation(userAccount);
						}
						if (userAccount != null && userAccount.getWelcomeFlag() && password != null && !password.isEmpty()
								&& !oldPassword.equals(password)) {
							sendPasswordUpdateNotification(userAccount);
						}

						if (onhalf && userAccount.getUserGroup().getUserGroupId() != null
								&& userAccount.getUserGroup().getUserGroupId().toString().equalsIgnoreCase("20")) {
							sendNotification(languageCode, userAccount, userData, onhalf, hospital,
									willSendOnBoardWelcomeLink);
						}
						cpUpdatesub(userData.getWhoseCarePartner(), userAccount, onhalf, userData.getTitle());

					}

				} else {
					String email = userData.getEmail();
					String phone = userData.getPhone();
					String teleCode = userData.getTeleCode();

					EmailExistsData data = emailExists(phone, email);
					boolean carePartnerExistFlag = data.getCarePartnerExists();
					userAccount = data.getUseraccount();
					String password = userData.getFirstName() + "@123";

					userAccount.setUserPwd(new StringEncrypter("DES").encrypt(password));
					userAccount.setUserGroup(usergroup);
					userAccount = setUserAccountValues(userData, userAccount, resultFilePatImagePath, patImageFolderPath);
					userAccount.setCreatedBy(userData.getCreatedBy());
					userAccount.setWhoseCarePartner(userData.getWhoseCarePartner());
					userAccount.setCreatedDate(new Date());
					userAccount.setWelcomeFlag(true);
					userAccount = getExisitngUserWelcomeFlag(userAccount, email, teleCode + "-" + phone);
					userAccount.setWrongPwdAttempt(0);
					boolean onhalf = userData.getActive();
					hospital = hospitalService.getHospitalIdForAnyUserAccount(userAccount);
					String willSendOnBoardWelcomeLink = userAccountService
							.willSendOnBoardWelcomeLink(userData.getCreatedBy(), userData.getEmail(), userData.getPhone());
					userAccount = UserValidationUtil.getUserAccOnboardLinkon(userAccount, willSendOnBoardWelcomeLink);
					userAccount = userNameMultiRoleCheck(existingPassword, userAccount, email, defaultUserName,
							carePartnerExistFlag);

					// userAccountService.updateUserProfileAccount(userAccount, oldEmail, oldPhone,
					// true, defaultUserName);

					userAccount.setActive(true);
					// notificationSendSub2(rb, userAccount, jsonObj, onhalf, hospital,
					// willSendOnBoardWelcomeLink);
					UserAccount multiRoleDob = userAccountService
							.getUsersByEmailId(userAccount.getEmail(),
									userAccount.getTeleCode() + "-" + userAccount.getPhone())
							.stream().findFirst().orElse(null);
					userAccount.setDob(multiRoleDob != null ? multiRoleDob.getDob() : null);
					userAccount = setPhoneValues(userData, userAccount);
					userRepository.save(userAccount);
					if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(userAccount))) {
						userAccountService.contactPreValidation(userAccount);
					}
					LOGGER.info("RC9 CarePartner Map - New  for  Mobile ");
					CarePartnerMap caremap = new CarePartnerMap();
					caremap = cmpActive(onhalf, userData.getWhoseCarePartner(), userAccount, caremap);
					caremap.setPatientId(userAccount.getWhoseCarePartner());
					caremap.setUserAccount(userAccount);
					caremap.setCreatedBy(userAccount.getCreatedBy());
					caremap.setVerified(false);
					caremap.setCreatedDate(new Date());
					caremap.setRelationShip(userAccount.getTitle());
					carePartnerMapRepo.save(caremap);
					LOGGER.info("RC9 CarePartner Map True End");
					// notifiySendSub1(userAccount,hospital);
					LOGGER.info("Care Partner was added successfully !");

				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;

	}

	private UserAccount setPhoneValues(UpdateUserDeviceData userData, UserAccount userAccount) {
		String otherPhone = RCUserUtil.getStringNull(userData.getOtherPhone());
		String otherTeleCode = RCUserUtil.getStringNull(userData.getOtherTeleCode());
		String otherTeleCountryCode = RCUserUtil.getStringNull(userData.getOtherTeleCountryCode());
		Long otherPhoneTypeId = RCUserUtil.getLong(userData.getOtherPhoneType());

		userAccount.setOtherPhone(otherPhone);
		userAccount.setOtherTeleCode(otherTeleCode);
		userAccount.setOtherTeleCountryCode(otherTeleCountryCode);
		userAccount.setOtherPhoneType(getPhoneType(otherPhoneTypeId));
		return userAccount;
	}

	private UserAccount setUserAccountValues(UpdateUserDeviceData userData, UserAccount userAccount,
			String resultFilePatImagePath, String patImageFolderPath) {

		userAccount.setFirstName(userData.getFirstName());
		userAccount.setLastName(userData.getLastName());
		userAccount.setRandomId(userData.getRandomId());
		// userAccount.setDescription(userData.getDescription());
		String email = RCUserUtil.getUserContactDetail(userData.getEmail());
		userAccount.setEmail(email);
		userAccount.setTeleCode(userData.getTeleCode());
		userAccount.setTeleCountryCode(userData.getTeleCountryCode());
		userAccount.setGender(userData.getGender());
		userAccount.setTitle(userData.getTitle());
		userAccount.setCareFamilyShow(true);
		userAccount.setTodoPrivilege(true);
		String phonenumber = RCUserUtil.getUserContactDetail(userData.getPhone());
		userAccount.setPhone(phonenumber);
		String comTypevalue = RCUserUtil.stringContains(userData.getComType()) ? userData.getComType().toUpperCase()
				: RCUserUtil.getComType(email, phonenumber);
		userAccount.setComType(comTypevalue);
		userAccount.setImagePath(getImagePath(userData, resultFilePatImagePath, patImageFolderPath));

		return userAccount;
	}

	private CarePartnerMap cmpActive(Boolean onhalf, Long whoseCarePartner, UserAccount useracc, CarePartnerMap cpm) {
		if (onhalf) {
			cpm.setActive(true);
			carePartnerMapRepo.updateCarePartnerActive(whoseCarePartner,
					new ArrayList<>(Arrays.asList(useracc.getUserAccountId())));
		} else {
			cpm.setActive(false);
		}
		return cpm;
	}

	private void cpUpdatesub(Long whoseCarePartner, UserAccount userAccount, boolean onhalf, String relationShip) {
		if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.CARE_PARTNER)) {
			carePartnerMapRepo
					.findByUserAccount_UserAccountIdAndPatientId(userAccount.getUserAccountId(), whoseCarePartner)
					.stream().findFirst().map(a -> {
						a.setActive(onhalf);
						a.setRelationShip(relationShip);
						carePartnerMapRepo.save(a);
						return null;
					});
		}
	}

	private void otherAccountUpdate(String userValue, UpdateUserDeviceData userData, String resultFilePatImagePath,
			String patImageFolderPath, String oldPhone, String defaultUserName) {

		List<UserAccount> uaList = userAccountService.validateUserNew(userValue);
		for (UserAccount ua : uaList) {
			try {
				String password = userData.getPassword();
				ua.setUserPwd(new StringEncrypter("DES").encrypt(password));
			} catch (Exception e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
			}

			String oldEmail = RCUserUtil.getString(ua.getEmail());
			ua.setLastName(userData.getLastName());
			ua.setFirstName(userData.getFirstName());

			String email = RCUserUtil.getUserContactDetail(userData.getEmail());
			ua.setEmail(email);

			boolean existFlag = userAccountService.checkIfPatientEmailExists(0l, email);

			String usernameValue = setUserName(existFlag, ua, oldEmail, email, defaultUserName);
			ua.setUserName(usernameValue);
			ua.setGender(userData.getGender());
			String phone = RCUserUtil.getUserContactDetail(userData.getPhone());
			ua.setPhone(phone);
			if (phone != null && !phone.equals(oldPhone)) {
				ua.setTeleCode(userData.getTeleCode());
				ua.setTeleCountryCode(userData.getTeleCountryCode());
			}
			ua.setDob(setdob(userData));
			String comTypevalue = RCUserUtil.stringContains(userData.getComType()) ? userData.getComType().toUpperCase()
					: RCUserUtil.getComType(email, ua.getPhone());
			ua.setComType(comTypevalue);
			ua = setPhoneValues(userData, ua);
			ua.setImagePath(getImagePath(userData, resultFilePatImagePath, patImageFolderPath));
			userRepository.save(ua);
			updatePatientonprofileUpdate(ua, userData);
		}

	}

	private String getImagePath(UpdateUserDeviceData userData, String resultFilePatImagePath,
			String patImageFolderPath) {
		String localImagePath = "";

		if (RCUserUtil.stringContains(userData.getImagePath())) {
			String imgUrl = userData.getImagePath();
			String imgName = imgUrl.substring(imgUrl.lastIndexOf('/'), imgUrl.length());
			if (imgName.startsWith("/")) {
				localImagePath = DAM_COMMON_PATH + imgName;
			} else {
				localImagePath = DAM_COMMON_PATH + "/" + imgName;
			}

//			String hostedModel = applicationProp.getString(HOSTED_MODEL);
//			if (hostedModel.equalsIgnoreCase(CLOUD)) {
//				RestCloudService cloudservce = new RestCloudService();
//				cloudservce.filePathbyFolder(resultFilePatImagePath, localImagePath);
//			} else {
//				File appointSourcefolder = new File(resultFilePatImagePath + imgName);
//				File appointDestfolder = new File(patImageFolderPath + localImagePath);
//				RCUserUtil.copyFolderbyFile(appointSourcefolder, appointDestfolder);
//			}
		} else if (userData.getGender().equalsIgnoreCase("male")) {
			localImagePath = DEFAULT_MALE_IMG_PATH;
		} else {
			localImagePath = DEFAULT_FEMALE_IMG_PATH;
		}
		return localImagePath;
	}

	private void updatePatientonprofileUpdate(UserAccount userAct, UpdateUserDeviceData userData) {
		try {
			if (userAct.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)) {
				Patient patt = patientRepo.findById(userAct.getUserAccountKey()).orElse(null);
				patt.setFirstName(userAct.getFirstName());
				patt.setLastName(userAct.getLastName());
				patt.setDob(setdob(userData));
				patt.setEmail(RCUserUtil.getUserContactDetail(userAct.getEmail()));
				patt.setComType(userAct.getComType());
				patt.setPhone(userAct.getPhone());
				patt.setImagePath(userAct.getImagePath());
				patientRepo.save(patt);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	private Date setdob(UpdateUserDeviceData userData) {
		Date dob = null;
		try {
			if (userData.getDob() != null && !userData.getDob().isEmpty()) {
				SimpleDateFormat fmt = new SimpleDateFormat(CommonConstant.STR_YYYY_MM_DD);
				dob = fmt.parse(userData.getDob());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}

		return dob;
	}

	public String setUserName(boolean existFlag, UserAccount ua, String oldEmail, String email,
			String defaultUserName) {
		String usernamelcl = "";
		if (existFlag && ua.getEmail() != null) {
			usernamelcl = ua.getUserName().replace(oldEmail, email);
		} else {
			if (email != null && !email.isEmpty()) {
				usernamelcl = email;
			} else {
				usernamelcl = defaultUserName;
			}
		}
		return usernamelcl;
	}

	private PhoneType getPhoneType(Long otherPhoneTypeId) {
		return (otherPhoneTypeId != 0 ? phoneTypeRepo.findById(otherPhoneTypeId).orElse(null) : null);
	}

	private void fileExist(String filePath) {
		if (!new File(filePath).exists()) {
			new File(filePath).mkdirs();
		}
	}

	public boolean emailCheck(String email) {
		boolean rsValue = false;
		if (email != null && email.contains("@")) {
			rsValue = true;
		}
		return rsValue;
	}

	public String setUserName(String email, String oldEmailid, String defaultUserName, UserAccount useracc) {
		String usernamelcl = "";
		if (emailCheck(email)) {
			usernamelcl = useracc.getUserName().replace(oldEmailid, email);
		} else if (!emailCheck(email)) {
			usernamelcl = RCUserUtil.stringContains(email) ? email : defaultUserName;
		}
		return usernamelcl;
	}

	private void deactivtaeSub(String willSendOnBoardWelcomeLink, UserAccount useracc, Long whoseCarePartner,
			boolean onhalf) {
		if (willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P")) {
			useracc.setIsOnBoardLinkSent(true);
			useracc.setOnBoardLinkSentOn(new Date());
		}
		if (onhalf && useracc.getUserGroup().getUserGroupId() != null
				&& useracc.getUserGroup().getUserGroupId().toString().equalsIgnoreCase("20")) {
			carePartnerMapRepo.updateCarePartnerActive(whoseCarePartner,
					new ArrayList<>(Arrays.asList(useracc.getUserAccountId())));
		}
	}

	private EmailExistsData emailExists(String phone, String email) {
		EmailExistsData data = new EmailExistsData();
		String emailExistslcl = null;
		Boolean carePartnerExistFlaglcl = false;
		UserAccount carePartnerUser = null;
		if (email != null && !email.isEmpty()) {
			emailExistslcl = userRepository.findByEmailAndUserGroup_UserGroupId(email, UserGroupCons.CARE_PARTNER)
					.isPresent() ? "true" : "false";
			if (emailExistslcl.equalsIgnoreCase("true")) {
				carePartnerExistFlaglcl = true;
				carePartnerUser = userAccountService.getUserByUserNameAndUserGroup(phone, "EM",
						new ArrayList<>(Arrays.asList(20L, 19L)));

			}
		} else if (phone != null && !phone.isEmpty()) {
			carePartnerUser = userAccountService.getUserByUserNameAndUserGroup(phone, "PN",
					new ArrayList<>(Arrays.asList(20L, 19L)));
			if (carePartnerUser != null
					&& carePartnerUser.getUserGroup().getUserGroupId().toString().equalsIgnoreCase("20")) {
				carePartnerExistFlaglcl = true;
			}
		}
		data.setEmailExists(emailExistslcl);
		data.setCarePartnerExists(carePartnerExistFlaglcl);
		data.setUseraccount(carePartnerUser == null ? new UserAccount() : carePartnerUser);
		return data;

	}

	private UserAccount getExisitngUserWelcomeFlag(UserAccount useraccount, String email, String phone) {
		if ((email != null && !email.isEmpty()) || (phone != null && !phone.isEmpty())) {
			String username = email != null ? email : phone;
			UserAccount existUser = userAccountService.getUserAccountByUserNameAndEmail(username);
			if (existUser != null && !existUser.getWelcomeFlag()) {
				useraccount.setWelcomeFlag(existUser.getWelcomeFlag());
				useraccount.setUserPwd(existUser.getUserPwd());
			}
		}
		return useraccount;
	}

	private UserAccount userNameMultiRoleCheck(String existingPassword, UserAccount useraccount, String email,
			String defaultUserName, boolean carePartnerExistFlag) {
		boolean existFlag = false;
		Boolean emailExistsAfter;
		UserAccount useracc;
		if (useraccount.getEmail() != null) {
			emailExistsAfter = userAccountService.checkIfPatientEmailExists(0l, useraccount.getEmail());
			if (emailExistsAfter) {
				existFlag = true;
				useraccount.setActive(true);
			}
		}

		useraccount.setIsdelete(false);

		if (email != null && !email.isEmpty()) {
			useraccount.setUserName(email);
		} else {
			useraccount.setUserName(defaultUserName);
		}
		if (carePartnerExistFlag) {
			userRepository.save(useraccount);
			useracc = useraccount;
		} else {
			useracc = userRepository.save(useraccount);
		}
		setUsername(existFlag, useracc, email, defaultUserName, existingPassword);
		return useracc;
	}

	private void setUsername(boolean existFlag, UserAccount useracc, String email, String defaultUserName,
			String existingPassword) {
		if (existFlag) {
			String updateString = useracc.getEmail() + "$$" + useracc.getUserAccountId();
			if (email != null && !email.isEmpty()) {
				useracc.setUserName(updateString);
			} else {
				useracc.setUserName(defaultUserName);
			}

			if (existingPassword != null && !existingPassword.trim().isEmpty() && !useracc.getWelcomeFlag()) {
				useracc.setUserPwd(existingPassword);
			}
		} else {
			String cpUserName = (email != null && !email.isEmpty()) ? email : defaultUserName;
			useracc.setUserName(cpUserName);
		}
	}

	private void sendNotification(String languageCode, UserAccount userAccount, UpdateUserDeviceData userData,
			boolean onhalf, Hospital hospital, String willSendOnBoardWelcomeLink) {

//		
//		try {			
//			if (onhalf) {				
//				Long patientId = userData.getWhoseCarePartner();
//				String helpdeskno = hospital.getCountryCode().getHelpDeskNo();
//				UserGroup userGroup = patientService.findUserGroupByGroupName(CARE_PARTNER);
//				
//				Patient pat = patientService.getPatientByPatientId(patientId);
//				String relationShip = userData.getTitle();
//
//				if ((willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P"))) {
//					userAccount.setActive(true);
//					userRepository.save(userAccount);
//					patientService.deActivateOtherCareGiverUserAcc(patientId);
//					UserSecTransAudit userSecTransAuditLatest = userSecTransAuditService
//							.getUserAccIdByuserSecTransAudit(userAccount.getUserAccountId());
//
//					if (userSecTransAuditLatest != null) {
//						userSecTransAuditLatest.setIsActive(false);
//						userSecTransAuditService
//								.updateUserSecTransAudit(userSecTransAuditLatest.getUserSecTransAuditId());
//					}
//				}
//
//				if (willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P")) {
//					String[] notifyContents = setEmailConent(hsp, useracc, rb);
//					String smsMsgTxt = notifyContents[0];
//					String emailContent = notifyContents[1];
//					String emailMsgTxtNew = emailContent;
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<pat_email>>", useracc.getEmail());
//					PatientStageWorkflow patientSWF = getPswValue(userGroup, useracc);
//					UserAccount surgeonUserAcc = userAccountService.getUserAccountByUserAccountId(patientSWF.gethSpSurgId());
//					Surgeon surgeon = surgeonService.getSurgeonById(surgeonUserAcc.getUserAccountKey());
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<surgeon_name>>", surgeon.getSalutation()
//							+ surgeonUserAcc.getFirstName() + " " + surgeonUserAcc.getLastName());
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<hsp_name>>", hsp.getName());
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<hsp_URL>>", "CareCoach-nearmc.memorial.me ");
//
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<pat_name>>", pat.getFirstName());
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<cpfirstname>>",
//							useracc.getFirstName() + " " + useracc.getLastName());
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<helpdeskno>>", helpdeskno);
//
//					String displayReleationship = careService
//							.cpReleationShipText(hsp.getCountryCode().getCountryCodeId(), relationShip);
//					displayReleationship = getReleationshipSub(displayReleationship);
//
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<Relationship>>", displayReleationship);
//
//					smsMsgTxt = smsMsgTxt.replaceAll("<<Relationship>>", displayReleationship);
//					smsMsgTxt = smsMsgTxt.replaceAll("<<cpfirstname>>",
//							useracc.getFirstName() + " " + useracc.getLastName());
//					smsMsgTxt = smsMsgTxt.replaceAll("<<pat_name>>", pat.getFirstName());
//
//					String serverUrl = applicationProp.getString(CommonConstant.STR_SERVER_URL);
//					String randId = UUID.randomUUID().toString();
//
//					String onboardURL = serverUrl + INTRO + randId;
//
//					onboardURL = new UrlShortener().shortenURL(onboardURL, useracc.getUserAccountId());
//					smsMsgTxt = smsMsgTxt.replace("<hsp_name>", hsp.getName());
//
//					smsMsgTxt = smsMsgTxt.replace("<onboardURL>", onboardURL);
//					smsMsgTxt = smsMsgTxt.replace("<Pat_FirstName>", useracc.getFirstName());
//					smsMsgTxt = smsMsgTxt.replaceAll("<surgeon_name>",
//							surgeon.getSalutation() + surgeon.getFirstName() + " " + surgeon.getLastName());
//
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<server_url>>", serverUrl);
//					emailMsgTxtNew = emailMsgTxtNew.replaceAll("<<randomId>>", INTRO + randId);
//
//					emailMsgTxtNew = getEmailMessageTextNew(useracc, patientSWF, emailMsgTxtNew, serverUrl);
//
//					logger.info("RC9 CarePartner Map - New ");
//
//					sendWelcomEmailAndSms(surgeonUserAcc, useracc, hsp, rb, randId, smsMsgTxt, emailMsgTxtNew);
//				}
//			}
//		} catch (Exception e) {
//			LOGGER.error("Inside notification method");
//		}
//

	}

	@Override
	public ResponseMessage updateCarePartnerMap(UpdateCarePartnerMapData updateCP) {
		ResponseMessage response = new ResponseMessage();
		try {
			if (updateCP.isVerified()) {
				CarePartnerMap carePartnerMap = carePartnerMapRepo
						.findByUserAccount_UserAccountIdAndPatientId(updateCP.getUserAccountId(),
								updateCP.getPatientId())
						.stream().findFirst().get();
				carePartnerMap.setVerified(true);
				carePartnerMap.setLastModifiedBy(updateCP.getCarePartnerId());
				carePartnerMap.setLastModifiedDate(new Date());
				carePartnerMapRepo.save(carePartnerMap);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		response.setStatus(CommonConstant.SUCCESS);
		return response;
	}

	@Override
	public ResponseMessage deactivateSecurityCredentialsByMode(SecurityCredentialData secCredential) {
		ResponseMessage response = new ResponseMessage();
		try {

			PatientDevice patientDevice = deviceRepository.findByHandshakeKey(secCredential.getHandShakeKey()).stream()
					.findFirst().orElse(null);
			if (patientDevice != null) {
				userSecTransAuditRepo.updateUserSecTransAudit(secCredential.getUserAccountId(), "password-otp");
				response.setStatus(CommonConstant.SUCCESS);
				return response;
			} else {
				response.setStatus(CommonConstant.FAILURE);
				return response;
			}
		} catch (Exception e) {
			LOGGER.error("Exception on deactivateSecurityCredentialsByMode", e);
			response.setStatus(CommonConstant.FAILURE);
			response.setMessage("Something went wrong");
			return response;
		}
	}

	@Override
	public ResponseMessage updatePatient(List<UpdatePatientData> updatePatients) {
		ResponseMessage response = new ResponseMessage();
		try {
			for(UpdatePatientData updatePatient : updatePatients) {
				if (updatePatient.getPatientId() >= 1L) {
					Patient patient = patientRepo.findById(updatePatient.getPatientId()).orElse(null);
					patient.setLastModifiedDate(new Date());
					patient.setLastModifiedBy(updatePatient.getLastModifiedBy());
					patient.setFirstName(updatePatient.getFirstName());
					patient.setLastName(updatePatient.getLastName());
					
//					patient.setCode(updatePatient.getCode());
					patient.setComType(comTypeGet(updatePatient.getComType()));
					patient.setDob(updatePatient.getDob());
//					patient.setHasCarePartner(updatePatient.getHasCarePartner());
					patient.setActive(updatePatient.getActive());
					patient.setGender(updatePatient.getGender());
					patient.setLastModifiedDate(updatePatient.getLastModifiedDate());
//					patient.setNotificationId(updatePatient.getNotificationId());
//					patient.setDescription(updatePatient.getDescription());
					patient.setEditStatus(updatePatient.getIsEditStatus());
					patient.setLastModifiedDate(new Date());

					UserAccount patientUserAcct = userRepository.findByUserAccountKey(patient.getPatientId()).stream()
							.findFirst().orElse(null);
					if (patientUserAcct != null) {
						patientUserAcct.setPushNotification(updatePatient.getPushNotification());
						patientUserAcct.setActive(updatePatient.getActive());
						if(updatePatient.getEmail() != null && !updatePatient.getEmail().isBlank()) {
							patient.setEmail(updatePatient.getEmail());
							patientUserAcct.setEmail(updatePatient.getEmail());
							patientUserAcct.setUserName(updatePatient.getEmail());	
						}
						userRepository.save(patientUserAcct);
					}
//					patient.setRandomId(updatePatient.getRandomId() != null && !updatePatient.getRandomId().equals("")
//							? updatePatient.getRandomId()
//							: "");
					imageUploadToUpdatePatient(updatePatient, patient);
					patient.setIsImageUploadDone(updatePatient.getIsImageUploadDone());
					patient.setIsProfileDone(updatePatient.getIsProfileDone());
					patient.setIsSupportDone(updatePatient.getIsSupportDone());

					executeIfEditStatusToUpdatePatient(updatePatient, patient, patientUserAcct);

					AuditLogData auditLog = new AuditLogData();
					auditLog.setTableName("Patient");
					auditLog.setIdValue(patient.getPatientId());
					auditLog.setOperation("EDIT");
					auditLog.setPatient(patient.getPatientId());
					PatientDevice patientDevice = deviceRepository.findByPatient_PatientId(patient.getPatientId()).stream()
							.findFirst().orElse(null);
					auditLog.setPatientDeviceId(patientDevice != null ? patientDevice.getDeviceId() : null);
					updateUserAccountUsingPatient(patient, updatePatient);
				}
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		response.setUpdateStatus(CommonConstant.SUCCESS);
		return response;
	}
	
	@Override
	public String getContactUsHtml(Long patientId) {
		String htmlContent = uriRB.getString("htmlcontent");
		try {
			List<UserAccount> users = userRepository.findByUserAccountKey(patientId);
			if(!users.isEmpty()) {
				UserAccount userAccount = users.get(0);
				Hospital hospital = hospitalService.getHospitalIdForAnyUserAccount(userAccount);
				if(hospital.getContacttype()==2L) {
					List<HospitalContact> hospitalContactlist = hospitalContactRepository.findByHospitalId(hospital.getHospitalId());
					if(!hospitalContactlist.isEmpty()) {
						String deviceContacttext = hospitalContactlist.get(0).getDeviceContacttext();
						htmlContent = deviceContacttext == null ? htmlContent : deviceContacttext;
					}
				}else {
					htmlContent = htmlContent.replace("{{contactData.name}}", RCUserUtil.getStringValue(hospital.getName()))
							.replace("{{contactData.address1}}",RCUserUtil.getStringValue(hospital.getAddress1()))
							.replace("{{contactData.address2}}", RCUserUtil.getStringValue(hospital.getAddress2()))
							.replace("{{contactData.state}}", RCUserUtil.getStringValue(hospital.getShortState()))
							.replace("{{contactData.city}}", RCUserUtil.getStringValue(hospital.getCity()))
							.replace("{{contactData.country}}", RCUserUtil.getStringValue(hospital.getCountry()))
							.replace("{{contactData.zipcode}}", RCUserUtil.getStringValue(hospital.getZipcode()))
							.replace("{{contactData.phone}}", RCUserUtil.getStringValue(hospital.getPhone()))
							.replace("{{contactData.email}}", RCUserUtil.getStringValue(hospital.getEmail()))
							.replace("{{contactData.bgimg}}", RCUserUtil.getStringValue(getImagenameByHospital(hospital)));
				}
			}
			return htmlContent;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
			return htmlContent;
		}
	}
	
	public List<MenuConfigData> getContactUsJson(Long patientId) {
		try {
			List<UserAccount> users = userRepository.findByUserAccountKey(patientId);
			if(!users.isEmpty()) {
				UserAccount userAccount = users.get(0);
				List<MenuConfiguration> menuConfig = menuConfigRepo.findByHospitalHospitalId(userAccount.getCreatedByUa().getUserAccountKey());
				return menuConfig.stream().map(a -> {
					MenuConfigData m = new MenuConfigData();
					m.setMenuId(a.getMenu().getMenuId());
					m.setName(a.getMenu().getName());
					m.setRefName(a.getMenu().getRefName());
					m.setStatus(a.getStatus());
					return m;
				}).toList();
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
			return List.of();
		}
		return List.of();
	}
	
	private String getImagenameByHospital(Hospital hsp) {
		String defImgName = "";
		if (hsp.getBackdropImage() != null) {
			String imgUrl = hsp.getBackdropImage();
			defImgName = imgUrl.substring(imgUrl.lastIndexOf('/'), imgUrl.length());
			defImgName = defImgName.replace("/", "");
		} else {
			defImgName = "bg_img.jpg";
		}
		return defImgName;
	}

	private void imageUploadToUpdatePatient(UpdatePatientData updatePatient, Patient patient) {
		if (updatePatient.getImagePath() != null && !updatePatient.getImagePath().equals("")
				&& !updatePatient.getImagePath().contains("dam/common")) {

			patient.setImagePath(updatePatient.getImagePath());
		} else {
			patient.setImagePath(RCUserUtil.getDefaultImgPath(updatePatient.getGender()));
		}
	}

	private void updateUserAccountUsingPatient(Patient patient, UpdatePatientData updatePatient) {
		try {
			UserAccount userAccount = userRepository.findByUserAccountKey(patient.getPatientId()).stream().findFirst()
					.orElse(null);
			String oldPassword = userAccount.getUserPwd();
			String password = updatePatient.getPassword();
			String encryptedPassword = password != null && !(password.trim().isEmpty()) ? RCUserUtil.rcEncrypt(password)
					: "";

			List<UserAccount> uaList = userAccountService.getUsersByEmailId(userAccount.getEmail(),
					userAccount.getTeleCode() + "-" + userAccount.getPhone());

			for (UserAccount userAcct : uaList) {
				userAcct.setFirstName(patient.getFirstName());
				userAcct.setLastName(patient.getLastName());
				userAcct.setDob(patient.getDob());
				userAcct.setComType(patient.getComType());
				userAcct.setGender(patient.getGender());
				userAcct.setNotificationId(patient.getNotificationId());
				userAcct.setImagePath(patient.getImagePath());
				userAcct.setPushNotification(updatePatient.getPushNotification());

				if (password != null && !(password.trim().isEmpty()) && !userAcct.getWelcomeFlag()) {
					userAcct.setUserPwd(encryptedPassword);
				}

				userAcct.setCreatedDate(new Date());
				userAcct.setImagePath(patient.getImagePath());

				if (patient.getEditStatus().equalsIgnoreCase("1")) {
					userRepository.save(userAcct);
				}
			}

			if (patient.getEditStatus().equalsIgnoreCase("true") && userAccount != null && !userAccount.getWelcomeFlag()
					&& password != null && !password.isEmpty() && !oldPassword.equals(encryptedPassword)) {
				sendPasswordUpdateNotification(userAccount);
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	private void executeIfEditStatusToUpdatePatient(UpdatePatientData updatePatient, Patient patient,
			UserAccount patientUserAcct) {
		try {
			if (updatePatient.getIsEditStatus().equals("true")) {
				patient.setPhone(RCUserUtil.getUserContactDetail(updatePatient.getPhone()));
				patient.setTeleCode(RCUserUtil.getUserContactDetail(updatePatient.getTeleCode()));
				patient.setTeleCountryCode(RCUserUtil.getUserContactDetail(updatePatient.getTeleCountryCode()));

				patientRepo.save(patient);

				String defaultUserName = GenerateOTP.getAlphaNumericForUserName();
				Long otherPhoneTypeId = updatePatient.getOtherPhoneType() != null ? updatePatient.getOtherPhoneType()
						: 0;
				PhoneType otherPhoneType = otherPhoneTypeId != 0 ? phoneTypeRepo.findById(otherPhoneTypeId).orElse(null)
						: null;
				patientUserAcct.setOtherPhone(RCUserUtil.getString(updatePatient.getOtherPhone()));
				patientUserAcct.setOtherTeleCode(RCUserUtil.getString(updatePatient.getOtherTeleCode()));
				patientUserAcct.setOtherTeleCountryCode(RCUserUtil.getString(updatePatient.getOtherTeleCountryCode()));
				patientUserAcct.setOtherPhoneType(otherPhoneType);
				patientUserAcct.setPhone(RCUserUtil.getUserContactDetail(updatePatient.getPhone()));
				patientUserAcct.setTeleCode(RCUserUtil.getUserContactDetail(updatePatient.getTeleCode()));
				patientUserAcct.setTeleCountryCode(RCUserUtil.getUserContactDetail(updatePatient.getTeleCountryCode()));
				patientUserAcct.setComType(patient.getComType());

				patientUserAcct.setFirstName(updatePatient.getFirstName());
				patientUserAcct.setLastName(updatePatient.getLastName());
				patientUserAcct.setGender(updatePatient.getGender());
				patientUserAcct.setDob(updatePatient.getDob());
				patientUserAcct.setImagePath(patient.getImagePath());

				if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(patientUserAcct))) {
					// userAccountService.contactPreValidation(patientUserAcct);
				}

				userAccountService.updateUserProfileAccount(patientUserAcct, patientUserAcct.getEmail(),
						patientUserAcct.getPhone(), true, defaultUserName);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	public String comTypeGet(String comType) {
		if (comType.equalsIgnoreCase("text") || comType.equalsIgnoreCase("sms"))
			return "SMS";
		else if (comType.equalsIgnoreCase(CommonConstant.EMAIL))
			return CommonConstant.EMAIL;
		else if (comType.equalsIgnoreCase("both"))
			return "BOTH";
		else
			return "NONE";
	}

}
