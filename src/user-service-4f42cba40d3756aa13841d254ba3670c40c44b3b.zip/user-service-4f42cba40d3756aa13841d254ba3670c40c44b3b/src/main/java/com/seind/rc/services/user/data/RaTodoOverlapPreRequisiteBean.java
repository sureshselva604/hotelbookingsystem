package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class RaTodoOverlapPreRequisiteBean {
	private Long loginClientId;
	private String loginClientMode;
	private Long loginUserAccountId;
	private String raTodoHospitalIds;
	private String raTodoSurgeonIds;	
}
