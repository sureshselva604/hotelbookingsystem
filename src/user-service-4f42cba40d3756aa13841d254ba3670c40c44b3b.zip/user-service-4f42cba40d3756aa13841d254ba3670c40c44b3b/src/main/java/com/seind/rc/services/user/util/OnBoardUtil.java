package com.seind.rc.services.user.util;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.seind.rc.services.user.constants.CasCommonConstant;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.entities.UserAccount;

@Component
public class OnBoardUtil {

	public static final Logger logger = LogManager.getLogger(OnBoardUtil.class);

	private static final String LOG_ON_BOARD_UTIL = " OnBoardUtil ";

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private SSOSyncUtil ssosyncUtil;

	public void insertOrUpdateSecQues(UserAccount act, Long quesOne, Long quesTwo, Long quesThree, String ansOne,
			String ansTwo, String ansThree) {
		SsoSyncData ssoSyncData = new SsoSyncData();
		ssoSyncData.setUserName(RCUserUtil.rcEncrypt(act.getEmail()));
		ssoSyncData.setQuesId1(quesOne);
		ssoSyncData.setQuesId2(quesTwo);
		ssoSyncData.setQuesId3(quesThree);
		ssoSyncData.setAns1(ansOne);
		ssoSyncData.setAns2(ansTwo);
		ssoSyncData.setAns3(ansThree);
		String onboardUrl = rcUserUtil.getSettingValue(CommonConstant.ON_BOARD, CasCommonConstant.SSOSYNC);
		new SSOSyncUtil().updateSecQuestions(ssoSyncData, onboardUrl);
	}

	public void updatePasswordInOnboardForFailureAttempt(String rcUserName, String rcPwd) throws SQLException {
		try {
			String apiURL = rcUserUtil.getSettingValue(CommonConstant.ON_BOARD, CasCommonConstant.SSOSYNC);
			new SSOSyncUtil().passwordUpdateSSO(new StringEncrypter("DES").encrypt(rcUserName), rcPwd, apiURL);
		} catch (Exception e) {
			logger.error(LOG_ON_BOARD_UTIL, e);
		}
	}

	public void updateOnboardRCAccess(UserAccount account) {
		SsoSyncData ssoSyncData = new SsoSyncData();
		ssoSyncData.setUserName(/* RCUtil.rcEncrypt( */account.getEmail());
		ssoSyncData.setOnBoardId(account.getRcOnBoardId());
		ssoSyncData.setRcAccountId(account.getUserAccountId());
		String onboardURL = ssosyncUtil.getSSOAPIURL(CommonConstant.ON_BOARD);
		onboardRCAccess(ssoSyncData, onboardURL);
	}

	public void onboardRCAccess(SsoSyncData data, String ssoUrl) {
		try {
			apiCall(data, ssoUrl, "updateOnboardRCAccess");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	private void apiCall(SsoSyncData data, String ssoUrl, String serviceName)
			throws SQLException, ClassNotFoundException, IOException {
		logger.debug("postCheck ---> {}, data ---> {}, ssoUrl ---> {}", serviceName, data, ssoUrl);
		String ssoEnabled = rcUserUtil.getSettingValue(CasCommonConstant.SSO_ENABLED_STATUS, CasCommonConstant.SSOSYNC);
		if (!ssoUrl.isEmpty() && ssoEnabled != null && !ssoEnabled.isEmpty() && ssoEnabled.equalsIgnoreCase("Yes")) {
			CloseableHttpClient httpClient = null;
			try {
				String ssoSecKey = rcUserUtil.getSettingValue(CasCommonConstant.SSOSECKEY, CasCommonConstant.SSOSYNC);
				logger.debug(" ssoSecKey ->> {}", ssoSecKey);
				data.setSecretKey(ssoSecKey);
				HttpPost postReq = new HttpPost(ssoUrl + serviceName);
				data.setApiName(postReq.toString());
				String newDocBody = data.toString();
				postReq.setEntity(new StringEntity(newDocBody));
				httpClient = HttpClients.createDefault();
				httpClient.execute(postReq);
				logger.debug(" postReq ->> {}", postReq);
				// TODO saveSSOAudit
				// saveSSOAuditLog(data);
			} catch (Exception e) {
				data.setError(e.getMessage());
				// TODO saveSSOAudit
				// saveSSOAuditLog(data);
				logger.error(e.getMessage());
			} finally {
				if (httpClient != null)
					httpClient.close();
			}
		}
	}
}
