package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;
@Data
public class DashboardTransactionData {
	private Long clientId;
	private Long requestedBy;
	private Date requestedDate;
	private Boolean completed;
	private Date completedDate;
	private Date dosFrom;
	private Date dosTo;
	private String hospitalPracticeId;
	private String hspSugId;
	private String bpcia;
	private String procedureType;
	private String filePath;
	private Boolean viewStatus;
	private String pacEventName;
	private String groupName;
}
