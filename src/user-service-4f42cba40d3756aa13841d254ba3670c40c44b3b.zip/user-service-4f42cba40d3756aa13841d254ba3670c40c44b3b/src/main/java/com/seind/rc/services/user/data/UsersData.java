package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.seind.rc.services.user.util.RCUserUtil;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class UsersData {

	private Long userId;
	private String userName;
	private String firstName;
	private String lastName;
	private String groupName;
	private Integer status;
	private String address;
	private String city;
	private String state;
	private String practiceName;
	private String description;
	private String phone ;
	private String imagePath;
	private String userShow;
	private boolean careFamilyShow;
	private boolean isActive;
	private boolean isdelete;
	private boolean welcomeFlag;
	
	private String message;
	private Long userGroupId;
	private Long patientId;
	private String patFirstName;
	private String patLastName;
	private String dateFormat;
	private Boolean allowPasswordChange;
	private String countryCode;
	private String clientLogoPath;
	
	
	public UsersData(String userName, String firstName, String lastName,boolean isActive, String groupName, String practiceName,
			Long userId,String city, String state, String address ,String description, String phone, String imagePath,
			boolean welcomeFlag,boolean careFamilyShow, boolean isdelete) {
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.isActive = isActive;
		this.groupName = groupName;
		this.practiceName = practiceName;
		this.userId = userId;
		this.city = city;
		this.state = state;
		this.address = address;
		this.description = description;
		this.phone = phone;
		this.imagePath = imagePath;
		this.welcomeFlag=welcomeFlag;
		this.careFamilyShow = careFamilyShow;
		this.isdelete = isdelete;
	}

	
	public String getPhone() {
		return RCUserUtil.getStringValue(phone);
	}
	
	public String getAddress() {
		return RCUserUtil.getStringValue(address);
	}
	public String getCity() {
		return RCUserUtil.getStringValue(city);
	}
	public String getState() {
		return RCUserUtil.getStringValue(state);
	}
	
	public String getDescription() {
		return RCUserUtil.getStringValue(description);
	}
	
	public Integer getStatus() {
		
		if (isdelete) {
			return 3;
		} else if (welcomeFlag) { 
			return 0;
		} else {
			if (isActive) { 
				return 1;
			} else {
				return 4;
			}
		} 	
	}
	
	
	public String getUserShow() {
		String status ="";
		if (groupName.equalsIgnoreCase("Physician Assistant")) {
			if (welcomeFlag) {
				status = "Yes";
			} else {
				status = "No";
			}
		}
		return status;
	}
}
