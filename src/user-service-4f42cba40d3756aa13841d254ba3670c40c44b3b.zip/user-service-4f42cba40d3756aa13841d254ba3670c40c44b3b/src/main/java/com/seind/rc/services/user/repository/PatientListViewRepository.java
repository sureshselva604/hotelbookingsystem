package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PatientInfoAllTodoView;

public interface PatientListViewRepository extends JpaRepository<PatientInfoAllTodoView, Long> {
	public List<PatientInfoAllTodoView> findByHospitalId(Long clientId);

	List<PatientInfoAllTodoView> findByHospitalIdOrSugFirstNameLikeOrSugLastNameLikeOrPatFirstnameLikeOrPatLastnameLikeOrPatientStatusLikeOrBpciLike(
			Long hopsitalId, String sugFirstName, String sugLastName, String PatFirstName, String patLastName,
			String patientStatus, String Bpci);

	List<PatientInfoAllTodoView> findByPracticeIdOrSugFirstNameLikeOrSugLastNameLikeOrPatFirstnameLikeOrPatLastnameLikeOrPatientStatusLikeOrBpciLike(
			Long practiceId, String sugFirstName, String sugLastName, String PatFirstName, String patLastName,
			String patientStatus, String Bpci);

	List<PatientInfoAllTodoView> findBySurgicalStageAndProcedureTypeAndFirstSOSName(String surgicalStage,
			String procedureType, String sosName);

	public List<PatientInfoAllTodoView> findByHospitalIdAndSugFirstNameLikeOrSugLastNameLikeOrPatFirstnameLikeOrPatLastnameLikeOrPatientStatusLikeOrBpciLike(
			Long clientId, String searchKey, String searchKey2, String searchKey3, String searchKey4, String searchKey5,
			String searchKey6);

	public List<PatientInfoAllTodoView> findByPracticeIdAndSugFirstNameLikeOrSugLastNameLikeOrPatFirstnameLikeOrPatLastnameLikeOrPatientStatusLikeOrBpciLike(
			Long clientId, String searchKey, String searchKey2, String searchKey3, String searchKey4, String searchKey5,
			String searchKey6);

	public PatientInfoAllTodoView findByPatientSWFId(Long patientSwfId);

	public List<PatientInfoAllTodoView> findByPatientSWFIdIn(List<Long> patSwfIdList);

	public List<PatientInfoAllTodoView> findByPracticeId(Long clientId);

}
