package com.seind.rc.services.user.data;

import lombok.Data;
@Data
public class CarePlanAssessment {
	
	private Long patientSwfId;
	private Long loginCnUaId;
	private String stykerAdminId;
	private Long clientId;
	private String surveyName;
	//private List<CarePlanAssesmentDetail> carePlanAssesmentDetailList;
	
}
