package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserSecQuestionsData {
	
	private Long userSecQuestionsId;
	private String question ;

}
