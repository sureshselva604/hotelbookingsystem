package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.RKUserAccount;

public interface RKUserAccountRepository extends JpaRepository<RKUserAccount, Long> {
	
	List<RKUserAccount> findByTeleCodeAndPhoneAndLatestIsTrue(String telecode, String phone);

	List<RKUserAccount> findByUserNameAndLatestIsTrue(String username);
}
