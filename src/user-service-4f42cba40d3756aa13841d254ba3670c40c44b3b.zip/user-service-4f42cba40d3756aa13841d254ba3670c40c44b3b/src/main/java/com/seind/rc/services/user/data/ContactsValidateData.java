package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;
@Data
public class ContactsValidateData {
	private Long usersContactValidateid;
	private String countryCode;
	private String contactValue;
	private String mode;
	private boolean validstatus;
	private Date createdDate;
	private Long createdBy;
}
