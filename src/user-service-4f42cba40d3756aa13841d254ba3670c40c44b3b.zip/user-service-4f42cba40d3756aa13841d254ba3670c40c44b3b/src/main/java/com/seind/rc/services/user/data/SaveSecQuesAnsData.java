package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SaveSecQuesAnsData {
	private Long secQuestionOne;
	private Long secQuestionTwo;
	private Long secQuestionThree;
	private String secAnswerOne;
	private String secAnswerTwo;
	private String secAnswerThree;
}
