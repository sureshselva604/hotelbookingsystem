package com.seind.rc.services.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


@Entity
@Data
@Table(name = "NotifyAllPatsGoodByeMsg")
public class NotifyAllPatsGoodByeMsg {

	@Id
	private Long Id;
	private String pat_email;
	private String pat_phone;
	private String comType;
	private String teleCode;
	private Long patientId;
	private Boolean pswIsActive;
	private Long patientSWFId;
	private String firstName;
	private String lastName;
	private String patientStatus;
	private Long currentEpisodeId;
	private Long hospitalPracticeId;
	private String procedureType;
	private Long hospitalId;
	private String hospitalName;
	private String hospitalCode;
	private Boolean allowPatNotification;
	private Long hSP_CC_Id;
	private Long patUaId;
	private String patGender;
	private Long hSP_Surg_Id;
	private String surgFirstName;
	private String surgLastName;
	private String surgGender;
	private String salutation;
	private Long cpaccountid;
	private String cpfirstname;
	private String cplastname;
	private String cpemail;
	private String cptelecode;
	private String cpphone;
	private String cpcomtype;
	private Boolean cpavailable;
	private String relationship;	
	private Long zoneId;
	private Long servicelineId;
	
}
