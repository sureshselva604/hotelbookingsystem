package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class MessageApptData {
	
	private Long sentBy;
	private Long receivedBy;
	private Long patientId;
	private Long hospitalId;
	private String content;
	private Boolean enabled;
	private Long patientSwfId;
	private Long episodeId;
	private Long strykerAdminId;
	private Boolean strykerProcess;
	private String dateFormat;
	private String title;
	private List<NotifyReqData> notifyDatas;

}
