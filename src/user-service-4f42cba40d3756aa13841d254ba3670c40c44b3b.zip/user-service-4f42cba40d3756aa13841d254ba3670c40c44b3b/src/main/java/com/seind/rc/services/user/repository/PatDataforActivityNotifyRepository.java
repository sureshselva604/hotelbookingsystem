package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PatDataforActivityNotify;

public interface PatDataforActivityNotifyRepository extends JpaRepository<PatDataforActivityNotify, Long> {
	
	
	List<PatDataforActivityNotify> findByCountryCodeIdAndZoneId(Long countryCodeId,Long zoneId);

}
