package com.seind.rc.services.user.service.servicesimp;

import java.io.File;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.TempPatientStageworkflow;
import com.seind.rc.services.user.entities.Cardstatus;
import com.seind.rc.services.user.repository.CardStatusRepo;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.service.NightJobService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class NightJobServiceImpl implements NightJobService{

	private static final ResourceBundle uriRB = ResourceBundle.getBundle("messages.uri");
	
	private static final Logger logger = LogManager.getLogger(NightJobServiceImpl.class);
	
	private final PatientStageWorkflowRepository patientStageWorkflowRepository;
	
	private final CardStatusRepo cardStatusRepo;
	
	private final ObjectMapper objectMapper;
	
	@Override
	public String getCurrentPatientSwfIds() {
		File file = new File(uriRB.getString("nightJobPath")+"TempPatientStageworkflow.json");
		try {
			List<TempPatientStageworkflow> distinct = patientStageWorkflowRepository.findDistinctPatientSWF();
			objectMapper.writeValue(file, distinct);
		} catch (Exception e) {
			logger.info(CommonConstant.EXCEPTION,e);
		}
		return file.getAbsolutePath();
	}

	@Override
	public void saveCardStatus(List<Cardstatus> cardStatus) {
		try {
			cardStatusRepo.truncateTable();
			cardStatusRepo.saveAll(cardStatus);
			cardStatusRepo.updateCardStatus();
		} catch (Exception e) {
			logger.info(CommonConstant.EXCEPTION,e);
		}
		
	}
	
}
