package com.seind.rc.services.user.service;

import com.seind.rc.services.user.entities.UserAccount;

public interface UserRequestAuditService {

	Long saveForgotSecurityAnsLinkDetails(UserAccount userAccount, String string);

}
