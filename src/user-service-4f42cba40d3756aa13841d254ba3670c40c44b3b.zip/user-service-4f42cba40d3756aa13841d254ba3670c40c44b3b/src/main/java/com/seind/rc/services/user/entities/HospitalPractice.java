package com.seind.rc.services.user.entities;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "HospitalPractice")
public class HospitalPractice {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long hospitalPracticeId;
	private Long practiceId;
    @Column(name = "HospitalId")
	private Long hospitalId;
	private Boolean active;
	private Boolean isOverLap;
	private Date createdDate;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CreatedBy")
	private UserAccount createdBy;
	private Date lastModifiedDate;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LastModifiedBy")
	private UserAccount lastModifiedBy;
	@Column(name="SecHospitalId")
	private Long secHospitalId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SecHospitalId",insertable = false, updatable = false)
	private Hospital secHospital;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HospitalId",insertable = false, updatable = false)
	private Hospital hospital;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "practiceId",insertable = false, updatable = false)
	private Hospital practice;
	

//	@OneToMany(mappedBy = "hospitalPractice",cascade = CascadeType.ALL)
//    private List<HospitalSurgeon> hospitalSurgeonList;
//	
//	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "PracticeId",referencedColumnName = "hospitalId",insertable = false, updatable = false)
//	private HospitalSurgeon hospitalSurgeon;
	
	@ManyToMany(mappedBy = "hospitalPractice")
    private List<HospitalSurgeon> hospitalSurgeonList;
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(
            name = "hospitalSurgeon",
            joinColumns = @JoinColumn(name = "PracticeId"),
            inverseJoinColumns = @JoinColumn(name = "hospitalId"))
	private List<HospitalSurgeon> hospitalSurgeon;
	

}
