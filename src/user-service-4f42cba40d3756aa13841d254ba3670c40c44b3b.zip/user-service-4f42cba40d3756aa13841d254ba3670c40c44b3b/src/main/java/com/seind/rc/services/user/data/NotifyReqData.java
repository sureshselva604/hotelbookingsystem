package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class NotifyReqData {
	
	private Long toUser = 0L;
	private Long patientId = 0L;
	private Long cpUserId = 0L;
	private Long surgeonId= 0L;
	private Long patientSwfId = 0L;
	private Long hspId = 0L;
	private Long staffUser = 0L;
	private String notificationType;
    private String notificationMode;
    private String relationShip;
    private String randId;    
    private Long count;
    private String serverUrl;
}
