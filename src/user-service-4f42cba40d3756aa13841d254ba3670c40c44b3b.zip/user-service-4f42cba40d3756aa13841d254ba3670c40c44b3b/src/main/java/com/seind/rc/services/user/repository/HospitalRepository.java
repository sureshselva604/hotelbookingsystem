package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.seind.rc.services.user.data.TodoHospitalOverlapBean;
import com.seind.rc.services.user.entities.Hospital;

import feign.Param;

@Repository
public interface HospitalRepository extends JpaRepository<Hospital, Long> {

	String findCountryCodeDateFormatByHospitalId(Long hospitalId);

	Hospital findByHospitalIdInAndDirectClient(List<Long> hospitalIds, boolean b);

	List<Hospital> findByDirectClient(boolean b);

	List<Hospital> findByModeAndDirectClientAndSuperClientIdPk(String mode, boolean b, int superClientId);

	List<Hospital> findByHospitalIdIn(List<Long> hospitalIds);

	// Hospital findByHospitalIdAndClientTypeMaster_ClientTypeLike(Long hospitalId,
	// String client);

	@Query(value = "SELECT NEW com.seind.rc.services.user.data.TodoHospitalOverlapBean(ua.userAccountId,ua.firstName ,ua.lastName,ua.userGroupId,ug.groupName,1 as isCareCoordinator,h.name) "
			+ "from HNSurgMapToClient hns  "
			+ "join HospitalNavigatorSugMapping hn on hn.hnsugMappingid = hns.hNSurgMapId "
			+ "join UserAccount ua on ua.userAccountId = hn.hNUserid and ua.userAccountKey = :userAccountKey "
			+ "join UserGroup ug on  ug.userGroupId = ua.userGroupId "
			+ "join hospital h on h.hospitalId = hns.hospitalId " + "where hns.hospitalId = :hopistalId ")
	List<TodoHospitalOverlapBean> RaHospitalOverlapHnsugMap(@Param("userAccountKey") Long userAccountKey,
			@Param("hopistalId") Long hopistalId);

	@Query(value = " SELECT NEW com.seind.rc.services.user.data.TodoHospitalOverlapBean(ua.userAccountId,ua.firstName,ua.lastName,ua.userGroupId,ug.groupName,0 as isCareCoordinator,h.name) "
			+ " from HNSurgMapToClient hnsmc join HospitalNavigatorSugMapping hnsm on hnsm.hnsugMappingid = hnsmc.hNSurgMapId  "
			+ " join HospitalSurgeon hs on hs.surgeon.surgeonId = hnsm.surgeonId  "
			+ " join HospitalPractice hp on hp.practiceId = hs.hospitalId "
			+ " join UserAccount ua on ua.userAccountKey = hp.practiceId and ua.userGroupId in (17)  "
			+ " join UserGroup ug on ug.userGroupId = ua.userGroupId  "
			+ " join Hospital h on h.hospitalId = ua.userAccountKey "
			+ " where hnsmc.hospitalId = :hospitalId  order by isCareCoordinator desc  ")
	List<TodoHospitalOverlapBean> hospitalOverlapRa(@Param("hospitalId") Long hospitalId);

	Hospital findByHospitalIdAndClientTypeMaster_ClientTypeLike(Long hospitalId, String client);

	Hospital findByName(String name);

}
