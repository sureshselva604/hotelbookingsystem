package com.seind.rc.services.user.data;


import lombok.Data;

@Data
public class HospitalData {
	private String phoneFormat;
	private String logo;
	private String zoneCode;
	private Long hospitalId;
	private String name;
	private Long countryCodeId;
	private Boolean commercialType;
	private String clientType;
	private String dateFormat;
	private String countryCode;
	private String language;
	private String mode;
}
