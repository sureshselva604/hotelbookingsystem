package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserSecQuesObjData {

	private long patientSurveyMappingId;
	private Long pswfId;
	private int mode;
	private Long oldResultId;
	private String materialType;
	private Long mappingId;
	private String randId;
	private Long questionId;
	private String answer;
	private String pass;
	private String confPass;
	private Long workflowId;
	private Long epidosdeId;
	private String status;
	private String clientcode;
	private String userAccountName;
	private String dob;
	private String activationMode;
	private String secQuestionOne;
	private String secQuestionThree;
	private String secQuestionTwo;
	private String secQusAnswerOne;
	private String secQusAnswerThree;
	private String secQusAnswerTwo;
	private boolean activation;

}