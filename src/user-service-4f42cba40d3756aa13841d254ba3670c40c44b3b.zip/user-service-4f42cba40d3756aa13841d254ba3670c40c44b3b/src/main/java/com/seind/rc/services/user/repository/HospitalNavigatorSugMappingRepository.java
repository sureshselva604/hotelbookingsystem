package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.HospitalNavigatorSugMapping;

public interface HospitalNavigatorSugMappingRepository extends JpaRepository<HospitalNavigatorSugMapping,Long>{

	List<HospitalNavigatorSugMapping> findBysurgeonAccountId(Long hspSurgId);
	List<HospitalNavigatorSugMapping> findDistinctBySurgeonAccountIdAndActiveTrue(Long surgeonUserAcctId);

	List<HospitalNavigatorSugMapping> findBySurgeonAccountIdAndHNUserAccount_CareFamilyShowTrueAndActiveTrue(
			Long hspSurgId);
	
	List<HospitalNavigatorSugMapping> findByHNUserAccount_UserAccountId(Long hnUserId);

	List<HospitalNavigatorSugMapping> findByHnsugMappingidIn(List<Long> hnSugmapId);

}
