package com.seind.rc.services.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@Table(name = "PracticeRaTodoOverlapInfo")
@NoArgsConstructor
@AllArgsConstructor
public class PracticeRaTodoOverlapInfo {
	
	@Id
	private Long HospitalId;
	
	private String OverLapHospital;
	
	private String PracticeName;
	
	private Integer IsOverLap;
	
	private Long SecHospitalId;
	
	private Long PracticeId;
	
	private Long pCUserid;

}
