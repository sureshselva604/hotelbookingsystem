package com.seind.rc.services.user.data;

import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.UserAccount;

import lombok.Data;

@Data
public class PatientCtrlDTO {

	private Long userAccountId;
	private PatientStageWorkflow patientSWF;
	private ResponseMessage response;
	private Patient patient;
	private Hospital hospital;
	private CarePartnerMap activeCareMap;
	private AddCarePartner updateCarePartner;
	private String saveStatus;
	private String existingPassword;
	private String oldPhone;
	private String email;
	private String phone;
	private boolean onBehalf;
	private Surgeon surgeon;
	private UserAccount patientUserAcct;
}
