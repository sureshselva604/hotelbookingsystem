package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "PatientDashBoardTransaction")
public class PatientDashBoardTransaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long patientSwfId;
	private String lastName;
	private String firstName;
	
	private String surgeonName;
	private String hospital;
	private Date dos;
	
	private String plannedDischargeDate;
	private String actualDischargeDate;
	private String recommendedDischarge;

	private String plannedAdmissionDate;
	private String actualAdmissionDate;
	private String salutation;
	private Long patientId;
	private Integer age; 
	private String gender;
	private Long hospitalPracticeId;
	private Long hspSurgId;
	private String bpci;
	private Long userAccountKey;
	private String procedureType;
	private Long countryCodeId;
	private Long payorType;
	private Boolean commercialType;
	/** need to add in view**/
	private Long hospitalId;
	private Integer plannedDischargeHospitalMasterId;
	private Integer actualDischargeHospitalMasterId;
	private String laterality;
	private Integer plannedDischargeId;
	private Integer actualDischargeId;
	private Date plannedSnfDischargeDate;
	private String dateFormat;
	private String dischargeType;
	private String dischargeTo;
	private Float youScore;
	private Float healthScore;
	private Float partialYouScore;
	private Float partialHealthScore;
	private Integer plannedLOS;
	private Integer actualLOS;
	
	

}
