package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class UserExistsResponse {

	private String status;
	private String popUpStatus;
	private String message;
	private String firstName;
	private String lastName;
	private String gender;
	private Long userGroupId;
	private String groupName;
	private String email;
	private String teleCountryCode;
	private String teleCode;
	private String phone;
	private String otherPhone;
	private String otherTeleCode;
	private String otherTeleCountryCode;
	private String otherPhoneType;
	private String imagePath;
	private Date dob;
	private String comType;
	private String title;
	private String notificationFrequency;
	private boolean realTimeAlert;
	private boolean realTimeMessage;
}
