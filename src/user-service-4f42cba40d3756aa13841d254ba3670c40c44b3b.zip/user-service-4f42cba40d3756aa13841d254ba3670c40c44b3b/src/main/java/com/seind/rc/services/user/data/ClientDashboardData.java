package com.seind.rc.services.user.data;

import java.util.List;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClientDashboardData {
	
	private int patientCount;
	private Long serviceLineCount;
	private Long specialityCount;
	private int userCount;
	private Long hospitalId;
	private List<GraphData> graphData;

}
