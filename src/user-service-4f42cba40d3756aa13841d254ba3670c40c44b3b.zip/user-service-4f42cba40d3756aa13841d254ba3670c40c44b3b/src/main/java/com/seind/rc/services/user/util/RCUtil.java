package com.seind.rc.services.user.util;

import com.google.gson.JsonObject;

public class RCUtil {

	
	public static String getJsonStringValue(JsonObject jObj, String key, String defaultValue)
	{
		if(jObj.get(key) == null)
		{
			return defaultValue;
		}
		return jObj.get(key).isJsonNull() ? defaultValue : jObj.get(key).getAsString();
	}
	
	public static String getValueByString(String input, String defaultValue) {
		return input == null ? defaultValue : input;
	}
}
