package com.seind.rc.services.user.data;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ValidateDobData {
	
	private Long patientId;
	@NotBlank(message = "Username Can't empty")
	private String userName;
	private String dob;

}
