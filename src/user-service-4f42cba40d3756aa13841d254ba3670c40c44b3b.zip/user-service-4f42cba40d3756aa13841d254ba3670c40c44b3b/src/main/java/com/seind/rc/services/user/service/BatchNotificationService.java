package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.DownloadCareplanBean;
import com.seind.rc.services.user.data.LambdaBean;
import com.seind.rc.services.user.data.LambdaCcTodoCountBean;
import com.seind.rc.services.user.data.LambdaProSurveyBean;
import com.seind.rc.services.user.data.LambdaWelcomeMailData;
import com.seind.rc.services.user.data.NotifyAllPatsGoodByeMsgBean;
import com.seind.rc.services.user.data.PatDataforActivityNotifyBean;
import com.seind.rc.services.user.data.PdfLambdaBean;
import com.seind.rc.services.user.data.RemainderNotificaitonData;
import com.seind.rc.services.user.entities.PatientStageWorkflow;

public interface BatchNotificationService {

	
	List<LambdaBean> fetchAllPatientsOneDayBeforeAppointmentsUserList(List<Long> patientswfIdList);

	List<LambdaBean> fetchCareCardNotificationUserData(List<Long> patientswfIdList);

	List<LambdaBean> fetchExerciseVideoUserData(List<Long> patientswfIdList);

	List<LambdaBean> fetchCareCardEngaementUserData(List<Long> patientswfIdList, Integer timeZoneId);

	List<PdfLambdaBean> fetchDownLoadFullVersion(DownloadCareplanBean downloadCareplanBean);

	List<PatientStageWorkflow> getDownloadFullVersionUserCondition(DownloadCareplanBean setDownloadCareplanBean);
	
	 List<NotifyAllPatsGoodByeMsgBean> executeGoodByeMessageNotification(Long zoneId);

	 void updateGoodByeFlagForDeActivatedPatients(List<Long> deactivatedPatientSWFIdList);

	List<PatDataforActivityNotifyBean> getactivityDataNotification(Long countryCodeId, Long timeZone);

	List<LambdaWelcomeMailData> welcomeMailGenerator(Long timeZoneId, String createddaysdifference);

	List<RemainderNotificaitonData> remainderNotificaiton(Long timeZoneId);

	LambdaCcTodoCountBean fetchLambdaCCList(Long timeZoneId);

	List<LambdaProSurveyBean> fetchAllPatientsTodoPROSurveyReminder(Long timeZoneId);

}
