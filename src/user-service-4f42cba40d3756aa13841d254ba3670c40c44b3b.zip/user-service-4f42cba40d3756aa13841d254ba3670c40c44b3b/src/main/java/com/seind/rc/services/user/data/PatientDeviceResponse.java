package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PatientDeviceResponse {
	
	private String status;
	private String message;
	private String deviceKey;
	private Long patientId;
	private Long carePartnerId;
	private Boolean isTempPasswordActive;
	private Boolean isOfficeStaff;
	private String countryCode;
	private Boolean isCarePartner;
	private String tokenId;

}
