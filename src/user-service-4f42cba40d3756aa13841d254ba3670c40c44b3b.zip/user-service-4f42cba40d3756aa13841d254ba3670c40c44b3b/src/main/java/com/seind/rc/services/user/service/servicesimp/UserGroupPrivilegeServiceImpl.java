package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.UserGroupPrivilegeData;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.UserGroupPrivilegeService;
import com.seind.rc.services.user.service.UserGroupService;

@Service
public class UserGroupPrivilegeServiceImpl implements UserGroupPrivilegeService {

	private static final Logger LOGGER = LogManager.getLogger(UserGroupPrivilegeServiceImpl.class);

	@Autowired
	private UserAccountRepository userRepository;

	@Autowired
	private UserGroupService userGroupService;

	/**
	 * M01
	 * 
	 * User Privilege based on Menu Configuration and GroupId
	 */
	@Override
	public List<UserGroupPrivilegeData> getUserGroupPrivelegeByGroupId(Long userId) {
		List<UserGroupPrivilegeData> PrivilegeList = new ArrayList<>();
		try {
			UserAccount userAcc = userRepository.findById(userId).orElse(null);
			int mflag = 0;
			if (userAcc != null) {
				mflag = userAcc.getMenuconfig();
			}
			if (mflag != 1 && mflag != 2) {
				mflag = 1;
			}
			if (userAcc != null && userAcc.getUserGroup().getUserGroupId() == 1 || mflag == 1) {
				PrivilegeList = draftGetUserGroupPrivelegeByUser(userAcc.getUserGroup().getUserGroupId(),
						PrivilegeList);
			} else {
				PrivilegeList = draftGetUserPrivelegeByUser(userId, PrivilegeList);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return PrivilegeList;
	}

	/**
	 * M02
	 * 
	 * get User Privileges
	 * 
	 * @param userAccountId
	 * @param userPrivilegeList
	 * @return
	 */
	private List<UserGroupPrivilegeData> draftGetUserPrivelegeByUser(Long userAccountId,
			List<UserGroupPrivilegeData> userPrivilegeList) {
		try {
			userPrivilegeList = userGroupService.getUserPrivilegeByUserId(userAccountId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userPrivilegeList;
	}

	/**
	 * M03
	 * 
	 * get User Group Privileges
	 * 
	 * @param userGroupId
	 * @param userGroupPrivilegeList
	 * @return
	 */
	private List<UserGroupPrivilegeData> draftGetUserGroupPrivelegeByUser(Long userGroupId,
			List<UserGroupPrivilegeData> userGroupPrivilegeList) {
		try {
			userGroupPrivilegeList = userGroupService.getUserGroupPrivelegeByGroupId(userGroupId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userGroupPrivilegeList;
	}

}
