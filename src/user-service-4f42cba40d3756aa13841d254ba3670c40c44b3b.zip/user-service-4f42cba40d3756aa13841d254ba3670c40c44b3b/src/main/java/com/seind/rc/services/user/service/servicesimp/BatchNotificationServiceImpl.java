package com.seind.rc.services.user.service.servicesimp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.DownloadCareplanBean;
import com.seind.rc.services.user.data.LambdaBean;
import com.seind.rc.services.user.data.LambdaCcListBean;
import com.seind.rc.services.user.data.LambdaCcTodoCountBean;
import com.seind.rc.services.user.data.LambdaProSurveyBean;
import com.seind.rc.services.user.data.LambdaWelcomeMailData;
import com.seind.rc.services.user.data.NotifyAllPatsGoodByeMsgBean;
import com.seind.rc.services.user.data.PatDataforActivityNotifyBean;
import com.seind.rc.services.user.data.PdfLambdaBean;
import com.seind.rc.services.user.data.RemainderNotificaitonData;
import com.seind.rc.services.user.data.SettingsData;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.ClientEmailCC;
import com.seind.rc.services.user.entities.ExerciseVideoNotification;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.LambdaProSurvey;
import com.seind.rc.services.user.entities.LambdaWelcomeMail;
import com.seind.rc.services.user.entities.NotifyAllPatsGoodByeMsg;
import com.seind.rc.services.user.entities.PatDataforActivityNotify;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientCardStatus;
import com.seind.rc.services.user.entities.PatientDevice;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.Settings;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserRequestAudit;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.ClientEmailCCRepository;
import com.seind.rc.services.user.repository.ExerciseVideoNotificationRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.LambdaProSurveyRepository;
import com.seind.rc.services.user.repository.LambdaWelcomeMailRepo;
import com.seind.rc.services.user.repository.NotifyAllPatsGoodByeMsgRepository;
import com.seind.rc.services.user.repository.PatDataforActivityNotifyRepository;
import com.seind.rc.services.user.repository.PatientCardStatusRepository;
import com.seind.rc.services.user.repository.PatientDeviceRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.SettingsRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserRequestAuditRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.BatchNotificationService;
import com.seind.rc.services.user.util.DateUtil;

@Service
public class BatchNotificationServiceImpl implements BatchNotificationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchNotificationServiceImpl.class);

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static String dosDate = "yyyyMMdd'T'HHmmss'Z'";

	SimpleDateFormat excelsdf = new SimpleDateFormat("MMddyyyy");

	@Autowired
	private PatientStageWorkflowRepository patientStageWorkflowRepo;

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;

	@Autowired
	private UserAccountRepository userAccountRepo;

	@Autowired
	private PatientCardStatusRepository patientCardStatusRepo;

	@Autowired
	private ExerciseVideoNotificationRepository exerciseVideoNotificationRepo;

	@Autowired
	private HospitalRepository hospitalRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PatientRepository patientRepo;
	
	@Autowired
	private NotifyAllPatsGoodByeMsgRepository notifyAllPatsGoodByeMsgRepo;
	
	@Autowired
	private  PatDataforActivityNotifyRepository patDataforActivityNotifyRepo;
	
	@Autowired
	private  SettingsRepository settingsRepo;
	
	@Autowired
	private PatientDeviceRepository patientDeviceRepository;
	
	@Autowired
	private  LambdaWelcomeMailRepo lambdaWelcomeMailRepo;
	
	@Autowired
	private UserSecTransAuditRepository  userSecTransAuditRepo;
	
	@Autowired
	private UserRequestAuditRepository userRequestAuditRepo;
	
	@Autowired
	private ClientEmailCCRepository clientEmailCCRepo;
	
	@Autowired
	private LambdaProSurveyRepository lambdaProSurveyRepo;


	@Override
	public List<LambdaBean> fetchAllPatientsOneDayBeforeAppointmentsUserList(List<Long> patientswfIdList) {
		try {
			// Fetching patient data for appointments
			List<PatientStageWorkflow> patientSwfList = patientStageWorkflowRepo
					.findDistinctByPatientSWFIdInAndHospitalPractice_Hospital_AllowPatNotificationTrueAndHospitalPractice_Hospital_isAppmntOptedTrueAndPswIsActiveTrueAndPatient_ComTypeIsNotNull(
							patientswfIdList);

			// Mapping fetched data to LambdaBean objects
			List<LambdaBean> appointmentDataList = patientSwfList.stream().map(this::mapToAppointmentData)
					.collect(Collectors.toList());

			// Extracting patient IDs
			List<Long> patientIdList = patientSwfList.stream().map(PatientStageWorkflow::getPatientId).toList();

			// Fetching care partner data for the extracted patient IDs
			List<CarePartnerMap> carePartnerMapsList = carePartnerMapRepo.findByPatientIdIn(patientIdList);

			// Setting care partner data for each LambdaBean object
			appointmentDataList = setCarePartnerData(appointmentDataList, carePartnerMapsList);
			return appointmentDataList;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return new ArrayList<>();
	}

	private List<LambdaBean> setCarePartnerData(List<LambdaBean> appointmentDataList,
			List<CarePartnerMap> carePartnerMapsList) {
		return appointmentDataList.stream().filter(a -> a != null).map(a -> {
			Optional<CarePartnerMap> first = carePartnerMapsList.stream().filter(
					b -> b != null && b.getPatientId() != null && b.getPatientId().compareTo(a.getPatientId()) == 0)
					.findFirst();
			if (first.isPresent()) {
				int lastIndexOf = carePartnerMapsList.lastIndexOf(first.get());
				CarePartnerMap carePartnerMap = carePartnerMapsList.get(lastIndexOf);
				a.setCpAccountId(carePartnerMap.getUserAccount().getUserAccountId());
				a.setCpAvailable(carePartnerMap.getActive());
				a.setCpComtype(carePartnerMap.getUserAccount().getComType());
				a.setCpEmail(carePartnerMap.getUserAccount().getEmail());
				a.setCpFirstname(carePartnerMap.getUserAccount().getFirstName());
				a.setCpLastname(carePartnerMap.getUserAccount().getLastName());
				a.setCpPhone(carePartnerMap.getUserAccount().getPhone());
				a.setCpPushNotification(carePartnerMap.getUserAccount().getPushNotification());
				a.setCpTelecode(carePartnerMap.getUserAccount().getTeleCode());
				a.setCpWelcomeflag(carePartnerMap.getUserAccount().getWelcomeFlag());
			}
			return a;
		}).toList();
	}

	private LambdaBean mapToAppointmentData(PatientStageWorkflow psw) {
		try {
			Hospital hospital = psw.getCCUserAccount().getHospital();
			UserAccount sugUserAccount = psw.getSurgeonUserAccount();
			UserAccount ccUserAccount = psw.getCCUserAccount();
			List<UserAccount> patUserAccountList = userAccountRepo
					.findByUserAccountKey(psw.getPatient().getPatientId());
			Patient patient = psw.getPatient();
			LambdaBean appointmentData = new LambdaBean();
			appointmentData.setPatEmail(patient.getEmail());
			appointmentData.setPatPhone(patient.getPhone());
			appointmentData.setPatComType(patient.getComType());
			appointmentData.setPatFirstName(patient.getFirstName());
			appointmentData.setPatLastName(patient.getLastName());
			appointmentData.setPatGender(patient.getGender());
			appointmentData.setPatientId(patient.getPatientId());
			appointmentData.setPatientIdStr(patient.getPatientId().toString());
			appointmentData.setPatientSwfIdStr(psw.getPatientSWFId().toString());
			appointmentData.setPatientStatus(psw.getPatientStatus());
			appointmentData.setPatientSWFId(psw.getPatientSWFId());
			appointmentData.setPatPushNotification(patUserAccountList.get(0).getPushNotification());
			appointmentData.setAllowPatNotification(hospital.getAllowPatNotification());
			appointmentData.setPatTeleCode(patUserAccountList.get(0).getTeleCode());
			appointmentData.setPatUaId(patUserAccountList.get(0).getUserAccountId());
			appointmentData.setSurgFirstName(sugUserAccount.getFirstName());
			appointmentData.setSurgLastName(sugUserAccount.getLastName());
			appointmentData.setSurgGender(sugUserAccount.getGender());
			appointmentData.setHspSurgId(psw.getHspSurgId());
			appointmentData.setHospitalId(hospital.getHospitalId());
			appointmentData.setHospitalName(hospital.getName());
			appointmentData.setHspTriggerComType(hospital.getTriggerComType());
			appointmentData.setHspCcId(psw.getHspCCId());
			appointmentData.setCnFirstName(ccUserAccount.getFirstName());
			appointmentData.setCnLastName(ccUserAccount.getLastName());
			appointmentData.setHospitalPracticeId(psw.getHospitalPractice().getHospitalPracticeId());
			appointmentData.setHspCode(hospital.getCode());
			appointmentData.setCurrentEpisodeId(psw.getCurrentEpisodeId());
			appointmentData.setProcedureType(psw.getProcedureType());
			appointmentData.setServicelineId(psw.getServicelineId());
			appointmentData.setServiceLineName(psw.getLaterality());
			appointmentData.setSalutation(sugUserAccount.getSurgeon().getSalutation());
			appointmentData.setPatWelcomeflag(patUserAccountList.get(0).getWelcomeFlag());
			appointmentData.setEmailAlias(hospital.getEmailAlias());
			return appointmentData;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	@Override
	public List<LambdaBean> fetchCareCardNotificationUserData(List<Long> patientswfIdList) {
		try {
			// Fetching care card notification data
			List<PatientCardStatus> careCardPatSwfIdList = patientCardStatusRepo
					.findByPatientStageWorkflow_PatientSWFIdInAndPatientStageWorkflow_HospitalPractice_Hospital_AllowPatNotificationTrueAndPatientStageWorkflow_PatUserAccount_WelcomeFlagFalseAndPatientStageWorkflow_DosIsNotNull(
							patientswfIdList);

			// Mapping fetched data to LambdaBean objects
			List<LambdaBean> careCardNotificationList = careCardPatSwfIdList.stream().map(this::mapToCareCardData)
					.collect(Collectors.toList());

			// Extracting patient IDs
			List<Long> patientIdList = careCardPatSwfIdList.stream()
					.map(p -> p.getPatientStageWorkflow().getPatientId()).toList();

			// Fetching care partner data for the extracted patient IDs
			List<CarePartnerMap> carePartnerMapsList = carePartnerMapRepo.findByPatientIdIn(patientIdList);

			// Setting care partner data for each LambdaBean object
			careCardNotificationList = setCarePartnerData(careCardNotificationList, carePartnerMapsList);

			return careCardNotificationList;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	private LambdaBean mapToCareCardData(PatientCardStatus careCard) {
		try {
			Hospital hospital = careCard.getPatientStageWorkflow().getCCUserAccount().getHospital();
			UserAccount sugUserAccount = careCard.getPatientStageWorkflow().getSurgeonUserAccount();
			List<UserAccount> patUserAccountList = userAccountRepo
					.findByUserAccountKey(careCard.getPatientStageWorkflow().getPatient().getPatientId());
			Patient patient = careCard.getPatientStageWorkflow().getPatient();
			LambdaBean careCardData = new LambdaBean();
			careCardData.setPatEmail(patient.getEmail());
			careCardData.setPatPhone(patient.getPhone());
			careCardData.setPatComType(patient.getComType());
			careCardData.setPatFirstName(patient.getFirstName());
			careCardData.setPatLastName(patient.getLastName());
			careCardData.setPatGender(patient.getGender());
			careCardData.setPatientId(patient.getPatientId());
			careCardData.setPatientStatus(careCard.getPatientStageWorkflow().getPatientStatus());
			careCardData.setPatientSWFId(careCard.getPatientStageWorkflow().getPatientSWFId());
			careCardData.setPatPushNotification(patUserAccountList.get(0).getPushNotification());
			careCardData.setAllowPatNotification(hospital.getAllowPatNotification());
			careCardData.setPatTeleCode(patUserAccountList.get(0).getTeleCode());
			careCardData.setPatUaId(patUserAccountList.get(0).getUserAccountId());
			careCardData.setSurgFirstName(sugUserAccount.getFirstName());
			careCardData.setSurgLastName(sugUserAccount.getLastName());
			careCardData.setSurgGender(sugUserAccount.getGender());
			careCardData.setHspSurgId(careCard.getPatientStageWorkflow().getHspSurgId());
			careCardData.setHospitalId(hospital.getHospitalId());
			careCardData.setHospitalName(hospital.getName());
			careCardData.setHspCcId(careCard.getPatientStageWorkflow().getHspCCId());
			careCardData.setHospitalPracticeId(
					careCard.getPatientStageWorkflow().getHospitalPractice().getHospitalPracticeId());
			careCardData.setHspCode(hospital.getCode());
			careCardData.setCurrentEpisodeId(careCard.getPatientStageWorkflow().getCurrentEpisodeId());
			careCardData.setProcedureType(careCard.getPatientStageWorkflow().getProcedureType());
			careCardData.setServicelineId(careCard.getPatientStageWorkflow().getServicelineId());
			careCardData.setSalutation(sugUserAccount.getSurgeon().getSalutation());
			careCardData.setPatWelcomeflag(patUserAccountList.get(0).getWelcomeFlag());
			careCardData.setEmailAlias(hospital.getEmailAlias());
			careCardData.setCardOverdueCount(careCard.getOverdueCount());
			careCardData.setCardUptoSpeedCount(careCard.getUptoSpeedCount());
			careCardData.setAssigningTodayCount(careCard.getAssigningTodayCount());
			careCardData.setHasCheckInCheckUp(careCard.getHasCheckInCheckUp());
			return careCardData;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	@Override
	public List<LambdaBean> fetchExerciseVideoUserData(List<Long> patientswfIdList) {
		try {
			List<ExerciseVideoNotification> exVideoList = exerciseVideoNotificationRepo
					.findByPatientSwfIdIn(patientswfIdList);

			return exVideoList.stream().map(exerciseVideoNotification -> {
				LambdaBean lambdaBean = new LambdaBean();
				lambdaBean.setPatFirstName(exerciseVideoNotification.getFirstName());
				lambdaBean.setPatLastName(exerciseVideoNotification.getLastName());
				lambdaBean.setPatEmail(exerciseVideoNotification.getEmail());
				lambdaBean.setPatTeleCode(exerciseVideoNotification.getTeleCode());
				lambdaBean.setPatPhone(exerciseVideoNotification.getPhone());
				lambdaBean.setPatComType(exerciseVideoNotification.getComType());
				lambdaBean.setHspCode(exerciseVideoNotification.getCode());
				lambdaBean.setSurgeonName(exerciseVideoNotification.getSurgeonName());
				lambdaBean.setPatientId(exerciseVideoNotification.getPatientId());
				lambdaBean.setCurrentEpisodeId(exerciseVideoNotification.getCurrentEpisodeId());
				lambdaBean.setPatientSWFId(exerciseVideoNotification.getPatientSwfId());
				lambdaBean.setEmailAlias(exerciseVideoNotification.getEmailAlias());
				lambdaBean.setCpAccountId(exerciseVideoNotification.getCpaccountid());
				lambdaBean.setCpFirstname(exerciseVideoNotification.getCpfirstname());
				lambdaBean.setCpLastname(exerciseVideoNotification.getCplastname());
				lambdaBean.setCpEmail(exerciseVideoNotification.getCpemail());
				lambdaBean.setCpTelecode(exerciseVideoNotification.getCptelecode());
				lambdaBean.setCpPhone(exerciseVideoNotification.getCpphone());
				lambdaBean.setCpComtype(exerciseVideoNotification.getCpcomtype());
				lambdaBean.setPatWelcomeflag(exerciseVideoNotification.getPatwelcomeflag());
				lambdaBean.setCpWelcomeflag(exerciseVideoNotification.getCpwelcomeflag());
				lambdaBean.setPatPushNotification(exerciseVideoNotification.getPushNotification());
				lambdaBean.setCpPushNotification(exerciseVideoNotification.getCpPushNotification());
				lambdaBean.setPatDos(exerciseVideoNotification.getDos());
				return lambdaBean;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return Collections.emptyList(); // return an empty list in case of exception
		}
	}

	@Override
	public List<LambdaBean> fetchCareCardEngaementUserData(List<Long> patientswfIdList, Integer timeZoneId) {
		try {
			List<PatientCardStatus> patientCareCardList = patientCardStatusRepo
					.findByPatientStageWorkflow_PatientSWFIdInAndPatientStageWorkflow_DosIsNotNullAndPatientStageWorkflow_PatUserAccount_WelcomeFlagFalseAndPatientStageWorkflow_HospitalPractice_Hospital_AllowPatNotificationTrueAndPatientStageWorkflow_HospitalPractice_Hospital_TimeZone_ZoneIdAndOverdueCountGreaterThan(
							patientswfIdList, timeZoneId, 0L);
			List<LambdaBean> careCardNotificationList = patientCareCardList.stream().map(this::mapToCareCardData)
					.collect(Collectors.toList());

			List<Long> patientIdList = patientCareCardList.stream().map(p -> p.getPatientStageWorkflow().getPatientId())
					.toList();

			// Fetching care partner data for the extracted patient IDs
			List<CarePartnerMap> carePartnerMapsList = carePartnerMapRepo.findByPatientIdIn(patientIdList);

			// Setting care partner data for each LambdaBean object
			careCardNotificationList = setCarePartnerData(careCardNotificationList, carePartnerMapsList);

			return careCardNotificationList;

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	@Override
	public List<PdfLambdaBean> fetchDownLoadFullVersion(DownloadCareplanBean downloadCareplanBean) {
		try {
			List<PatientStageWorkflow> pswfList = getDownloadFullVersionUserCondition(downloadCareplanBean);
			return setPatientstageworkflowAndUserData(pswfList);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	private List<PdfLambdaBean> setPatientstageworkflowAndUserData(List<PatientStageWorkflow> pswfList) {
		List<PdfLambdaBean> pdfLambdaBeanList = new ArrayList<>();
		for (PatientStageWorkflow psw : pswfList) {
			PdfLambdaBean lambdaBean = modelMapper.map(psw, PdfLambdaBean.class);

			// Set patient details
			Optional<Patient> patList = patientRepo.findById(psw.getPatientId());
			List<UserAccount> patUserAcc = userAccountRepo.findByUserAccountKey(psw.getPatientId());
			patList.ifPresent(patient -> {
				setPatientDetails(lambdaBean, patient, patUserAcc);
			});

			// Set care coordinator details
			Optional<UserAccount> userAcc = userAccountRepo.findById(psw.getHspCCId());
			userAcc.ifPresent(userAccount -> {
				setCarecoordinatorDetails(lambdaBean, userAccount);
			});

			// Set surgeon details
			Optional<UserAccount> sugUseracc = userAccountRepo.findById(psw.getHspSurgId());
			sugUseracc.ifPresent(sugUseraccout -> {
				setSurgeonDetails(psw, lambdaBean, sugUseraccout);
			});

			// Set hospital details
			userAcc.ifPresent(userAccount -> {
				Optional<Hospital> hsp = hospitalRepo.findById(userAccount.getUserAccountKey());
				hsp.ifPresent(hospital -> {
					setHospitalDetails(lambdaBean, hospital);
				});

			});

			// Set CarePartnerMap details
			List<CarePartnerMap> carePartnerList = carePartnerMapRepo.findByPatientId(psw.getPatientId());
			carePartnerList.stream().forEach(cp -> {
				setCarePartnerDetails(lambdaBean, cp);
			});

			pdfLambdaBeanList.add(lambdaBean);
		}
		return pdfLambdaBeanList;
	}

	private void setCarePartnerDetails(PdfLambdaBean lambdaBean, CarePartnerMap cp) {
		lambdaBean.setCpFirstName(cp.getUserAccount().getFirstName());
		lambdaBean.setCpLastName(cp.getUserAccount().getLastName());
		lambdaBean.setCpEmail(cp.getUserAccount().getEmail());
		lambdaBean.setCpPhone(cp.getUserAccount().getPhone());
		lambdaBean.setCpRelationship(cp.getRelationShip());
		lambdaBean.setCpTeleCode(cp.getUserAccount().getTeleCode());
	}

	private void setHospitalDetails(PdfLambdaBean lambdaBean, Hospital hospital) {
		lambdaBean.setHospitalId(hospital.getHospitalId());
		lambdaBean.setHospitalName(hospital.getName());
		lambdaBean.setHspCode(hospital.getCode());
		lambdaBean.setCommercialType(hospital.getCommercialType());
		lambdaBean.setCountryCodeId(hospital.getCountryCode().getCountryCodeId());
		lambdaBean.setHspLogo(hospital.getLogo());
		lambdaBean.setHspZoneCode(hospital.getTimeZone().getZoneCode());
		lambdaBean.setPhoneFormat(hospital.getCountryCode().getPhoneFormat());
		lambdaBean.setCountryCode(hospital.getCountryCode().getCountryCode());
		lambdaBean.setCountryCodeDateFormat(hospital.getCountryCode().getDateFormat());
	}

	private void setSurgeonDetails(PatientStageWorkflow psw, PdfLambdaBean lambdaBean, UserAccount sugUseraccout) {
		lambdaBean.setSugUaId(psw.getHspSurgId());
		lambdaBean.setSugFirstName(sugUseraccout.getFirstName());
		lambdaBean.setSugLastName(sugUseraccout.getLastName());
		lambdaBean.setSugTitle(sugUseraccout.getTitle());
	}

	private void setCarecoordinatorDetails(PdfLambdaBean lambdaBean, UserAccount userAccount) {
		lambdaBean.setCcFirstName(userAccount.getFirstName());
		lambdaBean.setCcLastName(userAccount.getLastName());
		lambdaBean.setCcUserAccountId(userAccount.getUserAccountId());
		lambdaBean.setCcUsergroupId(userAccount.getUserGroupId());
	}

	private void setPatientDetails(PdfLambdaBean lambdaBean, Patient patient, List<UserAccount> patUserList) {
		patUserList.stream().forEach(patua -> {
			lambdaBean.setPatFirstName(patient.getFirstName());
			lambdaBean.setPatLastName(patient.getLastName());
			lambdaBean.setPatDob(patient.getDob());
			lambdaBean.setPatGender(patient.getGender());
			lambdaBean.setPatEmail(patient.getEmail());
			lambdaBean.setPatBmi(patient.getBmi());
			lambdaBean.setPatMrn(patient.getMrn());
			lambdaBean.setPatTelecode(patient.getTeleCode());
			lambdaBean.setPatImagePath(patient.getImagePath());
			lambdaBean.setPatPhoneFormat(patient.getTeleCountryCode());
			lambdaBean.setPatPhone(patient.getPhone());
			lambdaBean.setPatImagePath(patient.getImagePath());
			if (patua.getOtherPhoneType() != null) {
				lambdaBean.setOtherPhoneTypeId(patua.getOtherPhoneType().getPhoneTypeId());
				lambdaBean.setPhoneTypeDesc(patua.getOtherPhoneType().getPhoneTypeDesc());
			}
			lambdaBean.setOtherPhone(patua.getOtherPhone());
			lambdaBean.setOtherTeleCode(patua.getOtherTeleCode());
			lambdaBean.setPatHeight(patient.getHeight());
			lambdaBean.setPatWeight(patient.getWeight());
			lambdaBean.setPatInch(patient.getInch());
		});
	}

	public List<PatientStageWorkflow> getDownloadFullVersionUserCondition(DownloadCareplanBean downloadCareplanBean) {
		try {
			List<Long> hospitalPracticeIdlist = null;
			List<Long> surgeonIdList = null;
			List<String> procedureTypeList = null;
			List<PatientStageWorkflow> pswfList = null;

			if (!downloadCareplanBean.getCompleted()) {
				hospitalPracticeIdlist = getHospitalPracticeIdlist(downloadCareplanBean.getHospitalPracticeId(),
						hospitalPracticeIdlist);

				surgeonIdList = getSurgeonIdList(downloadCareplanBean.getHspSugId(), surgeonIdList);

				String bpcia = downloadCareplanBean.getBpcia() == null ? "" : downloadCareplanBean.getBpcia();

				procedureTypeList = getProcedureTypeList(downloadCareplanBean.getProcedureType(), procedureTypeList);

				Date dosFromDate = getDosFromDate(downloadCareplanBean.getDosFrom());

				Date dosToDate = getDosToDate(downloadCareplanBean.getDosTo());

				pswfList = getPatientSwfIdListByDownload(downloadCareplanBean, hospitalPracticeIdlist, surgeonIdList,
						procedureTypeList, bpcia, dosFromDate, dosToDate);

				return pswfList;
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return new ArrayList<>();
	}

	private List<PatientStageWorkflow> getPatientSwfIdListByDownload(DownloadCareplanBean downloadCareplanBean,
			List<Long> hospitalPracticeIdlist, List<Long> surgeonIdList, List<String> procedureTypeList, String bpcia,
			Date dosFromDate, Date dosToDate) {
		List<PatientStageWorkflow> pswfList;
		if (hospitalPracticeIdlist != null && surgeonIdList != null) {
			pswfList = patientStageWorkflowRepo
					.findByHospitalPractice_Hospital_HospitalIdAndHospitalPractice_HospitalPracticeIdInAndHspSurgIdInAndBpciAndProcedureTypeInAndDosBetween(
							downloadCareplanBean.getClientId(), hospitalPracticeIdlist, surgeonIdList, bpcia,
							procedureTypeList, dosFromDate, dosToDate);
		} else if (surgeonIdList != null) {
			pswfList = patientStageWorkflowRepo
					.findByHospitalPractice_Hospital_HospitalIdAndHspSurgIdInAndBpciAndProcedureTypeInAndDosBetween(
							downloadCareplanBean.getClientId(), surgeonIdList, bpcia, procedureTypeList, dosFromDate,
							dosToDate);
		} else {
			pswfList = patientStageWorkflowRepo.findByHospitalPractice_Hospital_HospitalIdAndBpciAndDosBetween(
					downloadCareplanBean.getClientId(), bpcia, dosFromDate, dosToDate);
		}
		return pswfList;
	}

	private Date getDosToDate(Date dosTo) {
		try {
			dosTo = dosTo == null ? new Date() : dosTo;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String toDate = sdf.format(dosTo);
			dosTo = sdf.parse(toDate);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return dosTo;
	}

	private Date getDosFromDate(Date dosFrom) {
		try {
			dosFrom = dosFrom == null ? new Date() : dosFrom;
			String fromDate = sdf.format(dosFrom);
			dosFrom = sdf.parse(fromDate);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return dosFrom;
	}

	private List<String> getProcedureTypeList(String procedureType, List<String> procedureTypeList) {
		if (procedureType != null && !procedureType.trim().isEmpty()) {
			procedureType = procedureType.toLowerCase().contains("other") ? procedureType + ",Other."
					: String.join(",",
							Arrays.stream(procedureType.split(",")).map(s -> "'" + s + "'").toArray(String[]::new));
		}
		return procedureTypeList = Arrays.stream(procedureType.split(",")).map(s -> s.replaceAll("'", ""))
				.collect(Collectors.toList());
	}

	private List<Long> getSurgeonIdList(String hspSugId, List<Long> surgeonIdList) {
		if (hspSugId != null && !hspSugId.isEmpty()) {
			String surgeonId = hspSugId == null ? "" : hspSugId.trim();
			return surgeonIdList = Arrays.stream(surgeonId.split(",")).map(s -> Long.valueOf(s.replaceAll("'", "")))
					.collect(Collectors.toList());
		}
		return surgeonIdList;
	}

	private List<Long> getHospitalPracticeIdlist(String hospitalPracticeId, List<Long> hospitalPracticeIdlist) {
		String hospitalpracticeId = hospitalPracticeId == "" ? "" : hospitalPracticeId.trim();
		if (!hospitalpracticeId.contains("")) {
			hospitalPracticeIdlist = Arrays.stream(hospitalpracticeId.split(","))
					.map(s -> Long.valueOf(s.replaceAll("'", ""))).collect(Collectors.toList());
		}
		return hospitalPracticeIdlist;
	}

	public List<NotifyAllPatsGoodByeMsgBean> executeGoodByeMessageNotification(Long zoneId) {
		List<NotifyAllPatsGoodByeMsgBean> notifyAllPatsGoodByeMsgBeanList = new ArrayList<>();
		try {
			List<NotifyAllPatsGoodByeMsg> notifyAllPatsGoodByeMsgList = notifyAllPatsGoodByeMsgRepo.findByZoneId(null);
			if (notifyAllPatsGoodByeMsgList != null && !notifyAllPatsGoodByeMsgList.isEmpty()) {
				notifyAllPatsGoodByeMsgBeanList = notifyAllPatsGoodByeMsgList.stream()
						.map(NotifyAllPatsGoodByeMsg -> modelMapper.map(notifyAllPatsGoodByeMsgList,
								NotifyAllPatsGoodByeMsgBean.class))
						.toList();
				List<Long> patSWFIds = notifyAllPatsGoodByeMsgList.stream().map(ha -> ha.getPatientSWFId()).toList();

				List<Long> patIds = notifyAllPatsGoodByeMsgList.stream().map(ha -> ha.getPatientId()).toList();

				notifyAllPatsGoodByeMsgBeanList.stream().peek(NotifyAllPatsGoodByeMsgBean -> {
					NotifyAllPatsGoodByeMsgBean.setPatIds(patIds);
					NotifyAllPatsGoodByeMsgBean.setPatSWFIds(patSWFIds);
				}).collect(Collectors.toList());
			}
			return notifyAllPatsGoodByeMsgBeanList;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return notifyAllPatsGoodByeMsgBeanList;
	}

	@Override
	public void updateGoodByeFlagForDeActivatedPatients(List<Long> deactivatedPatientSWFIdList) {
		try {
			List<PatientStageWorkflow> patientStageWorkflowList = patientStageWorkflowRepo
					.findByPatientSWFIdIn(deactivatedPatientSWFIdList);
			if (patientStageWorkflowList != null && !patientStageWorkflowList.isEmpty()) {
				patientStageWorkflowList.stream().forEach(patientStageWorkflow -> {
					patientStageWorkflow.setWelcomeBackFlag(true);
					patientStageWorkflowRepo.save(patientStageWorkflow);
				});
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	@Override
	public List<PatDataforActivityNotifyBean> getactivityDataNotification(Long countryCodeId, Long timeZone) {
		List<PatDataforActivityNotifyBean> patDataforActivityNotifyBeanList = new ArrayList<>();
		List<SettingsData> settingsDataList = new ArrayList<>();
		try {
			List<PatDataforActivityNotify> PatDataforActivityNotifyList = patDataforActivityNotifyRepo
					.findByCountryCodeIdAndZoneId(countryCodeId, timeZone);
			if (PatDataforActivityNotifyList != null && !PatDataforActivityNotifyList.isEmpty()) {
				patDataforActivityNotifyBeanList = PatDataforActivityNotifyList.stream()
						.map(PatDataforActivityNotify -> modelMapper.map(PatDataforActivityNotify,
								PatDataforActivityNotifyBean.class))
						.toList();
			}
			List<Settings> settingsList = settingsRepo.findByCategory("FbNotificationAllEmail");
			settingsDataList = settingsList.stream().map(Settings -> modelMapper.map(Settings, SettingsData.class))
					.toList();
			/** PushNotification **/
			List<Long> userAccIds = PatDataforActivityNotifyList.stream()
					.map(PatDataforActivityNotify::getUserAccountId).toList();
			Map<String, PatientDevice> patDeviceMap = getTokenListbyPatientorCpId(userAccIds);
			PatDataforActivityNotifyBean PatDataforActivityNotifyBean = new PatDataforActivityNotifyBean();
			PatDataforActivityNotifyBean.setPatDeviceMap(patDeviceMap);
			/** FOR WORKFLOW **/
			List<Long> patientSWFIds = PatDataforActivityNotifyList.stream()
					.map(PatDataforActivityNotify::getUserAccountkey).collect(Collectors.toList());
			PatDataforActivityNotifyBean.setPatientSWFIds(patientSWFIds);
			return patDataforActivityNotifyBeanList;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return patDataforActivityNotifyBeanList;
	}

	/** PushNotification **/
	public Map<String, PatientDevice> getTokenListbyPatientorCpId(List<Long> userAccId) {
		try {
			Map<String, PatientDevice> patientDeviceMap = new HashMap<>();
			List<UserAccount> userAccountList = userAccountRepo.findByUserAccountIdInAndActiveTrue(userAccId);
			List<Long> patUserAccKeys = userAccountList.stream().map(UserAccKey -> UserAccKey.getUserAccountKey())
					.toList();
			List<Long> userAccIds = userAccountList.stream().map(UserAccKey -> UserAccKey.getUserAccountId()).toList();

			List<PatientDevice> patDeviceList = patientDeviceRepository
					.findByPatient_PatientIdInOrderByCreatedDate(patUserAccKeys);
			patDeviceList.stream().forEach(patientDevice -> patientDeviceMap
					.put("pat_device" + patientDevice.getPatient().getPatientId(), patientDevice));

			List<PatientDevice> cpPatDeviceList = patientDeviceRepository
					.findByCarePartnerIdInOrderByCreatedDate(userAccIds);
			cpPatDeviceList.stream().forEach(patientDevice2 -> patientDeviceMap
					.put("cp_device" + patientDevice2.getPatient().getPatientId(), patientDevice2));
			return patientDeviceMap;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}
	
	@Override
	public List<LambdaWelcomeMailData> welcomeMailGenerator(Long timeZoneId, String createddaysdifference) {
		List<LambdaWelcomeMailData> lambdaWelcomeMailDataList = new ArrayList<>();
		try {
			List<LambdaWelcomeMail> lambdaWelcomeMailList = lambdaWelcomeMailRepo.findByZoneIdAndCreatedDate(timeZoneId,
					Integer.valueOf(createddaysdifference));

			lambdaWelcomeMailDataList = lambdaWelcomeMailList.stream()
					.map(LambdaWelcomeMail -> modelMapper.map(LambdaWelcomeMail, LambdaWelcomeMailData.class)).toList();
			Optional<Settings> settings = settingsRepo.findByCategoryAndName("LAMBDA", "LAMBDA_EMAIL_BCC_LIST");
			LambdaWelcomeMailData lambdaWelcomeMailData = new LambdaWelcomeMailData();
			lambdaWelcomeMailData.setSetting_Email(settings.get().getValue());
			lambdaWelcomeMailDataList.add(lambdaWelcomeMailData);
			return lambdaWelcomeMailDataList;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return lambdaWelcomeMailDataList;
	}
	
	@Override
	public List<RemainderNotificaitonData> remainderNotificaiton(Long zoneId) {
		List<RemainderNotificaitonData> remainderNotificaitonData = new ArrayList<>();
		try {
			int batchCount = 30;
			List<UserAccount> userAccountList = userAccountRepo
					.findByActiveTrueAndUserPwdCreatedOnNotNullAndIsdeleteFalseAndWelcomeFlagFalseAndUserNameIsNotLikeAndComTypeAndHospital_AllowPatNotificationTrueAndHospital_TimeZoneZoneId(
							"%$$%", "NONE", 2l);
			if (userAccountList != null && !userAccountList.isEmpty()) {
				draftRemainderNotificaitonData(userAccountList, remainderNotificaitonData);
				/** UPDATE USERACCOUNT **/
				updateUserAccount(batchCount, userAccountList);
				/** INSERT UserSecTransAudit AND UserRequestAudit **/
				insertUsersecTransAudit(remainderNotificaitonData, batchCount);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return remainderNotificaitonData;
	}

	private void draftRemainderNotificaitonData(List<UserAccount> userAccountList,
			List<RemainderNotificaitonData> remainderNotificaitonData) {
		remainderNotificaitonData = userAccountList.stream().map(userAccount -> {
			RemainderNotificaitonData remainderNotifyData = new RemainderNotificaitonData();
			remainderNotifyData.setUserPwdCreatedOn(userAccount.getUserPwdCreatedOn());
			remainderNotifyData.setFirstName(userAccount.getFirstName());
			remainderNotifyData.setLastName(userAccount.getLastName());
			remainderNotifyData.setEmail(userAccount.getEmail());
			remainderNotifyData.setTeleCode(userAccount.getTeleCode());
			remainderNotifyData.setPhone(userAccount.getPhone());
			remainderNotifyData.setComType(userAccount.getComType());
			remainderNotifyData.setCountryCodeId(userAccount.getTeleCountryCode());
			remainderNotifyData.setName(userAccount.getHospital().getName());
			remainderNotifyData.setRcOnBoardId(userAccount.getRcOnBoardId());
			remainderNotifyData.setUserAccountId(userAccount.getUserAccountId());
			int daysDiff = DateUtil.daysDiff(userAccount.getUserPwdCreatedOn(), new Date());
			remainderNotifyData.setDaysdiffer(daysDiff);
			return remainderNotifyData;
		}).collect(Collectors.toList());
	}

	private void updateUserAccount(int batchCount, List<UserAccount> userAccountList) {
		userAccountList.forEach(userAccount -> userAccount.setPasswordResetSentOn(new Date()));

		if (userAccountList.size() % batchCount == 0) {
			userAccountRepo.saveAll(userAccountList);
		}
		if (userAccountList != null) {
			userAccountRepo.saveAll(userAccountList);
		}
	}

	@SuppressWarnings("unlikely-arg-type")
	private void insertUsersecTransAudit(List<RemainderNotificaitonData> remainderNotificaitonData, int batchCount) {
		List<UserSecTransAudit> userSecTransAuditList = new ArrayList<>();
		List<UserRequestAudit> userRequestAuditList = new ArrayList<>();
		Map<String, String> dayMap = new HashMap<>();
		dayMap.put("80", "day1");
		dayMap.put("85", "day2");
		dayMap.put("89", "day3");
		dayMap.put("90", "day4");
		dayMap.put("91", "day5");

		remainderNotificaitonData.stream().forEach(remainderNotifyData -> {
			String daydiff = dayMap.get(remainderNotifyData.getDaysdiffer());
			UserSecTransAudit userSecTransAudit = draftUserSecTransAudit(remainderNotifyData, daydiff);
			userSecTransAuditList.add(userSecTransAudit);
			UserRequestAudit userRequestAudit = draftUserRequestAudit(remainderNotifyData);
			userRequestAuditList.add(userRequestAudit);
		});

		if ((userSecTransAuditList.size() % batchCount) == 0) {
			userSecTransAuditRepo.saveAll(userSecTransAuditList);
		}
		if (!userSecTransAuditList.isEmpty()) {
			userSecTransAuditRepo.saveAll(userSecTransAuditList);
		}
		if ((userRequestAuditList.size() & batchCount) == 0) {
			userRequestAuditRepo.saveAll(userRequestAuditList);
		}
		if (!userRequestAuditList.isEmpty()) {
			userSecTransAuditRepo.saveAll(userSecTransAuditList);
		}
	}
	
	private UserRequestAudit draftUserRequestAudit(RemainderNotificaitonData remainderNotifyData) {
		UserRequestAudit userRequestAudit = new UserRequestAudit(); 
		userRequestAudit.getUserAccount().setUserAccountId(remainderNotifyData.getUserAccountId());
		userRequestAudit.setMode("90 Days Acccount Lock");
		userRequestAudit.setStatus("Pending");
		userRequestAudit.setCreatedOn(new Date());
		userRequestAudit.setActivatedBy(null);
		userRequestAudit.setActivatedOn(null);
		return userRequestAudit;

		}
	
		private UserSecTransAudit draftUserSecTransAudit(RemainderNotificaitonData remainderNotifyData,
				String daydiff) {
			UserSecTransAudit UserSecTransAudit = new UserSecTransAudit();
			UserSecTransAudit.setIpAddress(null);
			UserSecTransAudit.setIsSameIPInFuture(null);
			UserSecTransAudit.getUserAccount().setUserAccountId(remainderNotifyData.getUserAccountId());
			UserSecTransAudit.setRandomId(null);
			UserSecTransAudit.setOtp(null);
			UserSecTransAudit.setMode("PWD Remainder " + daydiff);
			UserSecTransAudit.setIsActive(false);
			UserSecTransAudit.setCreatedOn(new Date());
			return UserSecTransAudit;
		}
		
		@Override
		public LambdaCcTodoCountBean fetchLambdaCCList(Long zoneId) {
			LambdaCcTodoCountBean lambdaCcTodoCountBean = new LambdaCcTodoCountBean();
			try {
				List<ClientEmailCC> clientEmailCCList = clientEmailCCRepo
						.findByHospital_TimeZone_ZoneIdAndHospital_CreatedByComTypeNotNullAndHospital_CreatedByComTypeAndHospital_AllowPatNotificationTrueAndActiveTrue(
								zoneId, "NONE");
				List<LambdaCcListBean> LambdaCcListBeanList = new ArrayList<>();
				Map<String, List<Long>> cnTodoCountMap = new HashMap<>();

				if (clientEmailCCList != null && !clientEmailCCList.isEmpty()) {
					for (ClientEmailCC clientEmailCC : clientEmailCCList) {
						LambdaCcListBean LambdaCcListBean = new LambdaCcListBean();
						if (clientEmailCC.getHospital().getCreatedBy().getNotificationFrequency() != null
								&& clientEmailCC.getHospital().getCreatedBy().getNotificationFrequency() != "NONE") {
							LambdaCcListBean.setFirstName(clientEmailCC.getHospital().getCreatedBy().getFirstName());
							LambdaCcListBean.setLastName(clientEmailCC.getHospital().getCreatedBy().getLastName());
							LambdaCcListBean.setEmail(clientEmailCC.getHospital().getCreatedBy().getEmail());
							LambdaCcListBean.setPhone(clientEmailCC.getHospital().getCreatedBy().getPhone());
							LambdaCcListBean.setTelecode(clientEmailCC.getHospital().getCreatedBy().getTeleCode());
							LambdaCcListBean.setGroupName(
									clientEmailCC.getHospital().getCreatedBy().getUserGroup().getGroupName());
							LambdaCcListBean.setMode(clientEmailCC.getHospital().getMode());
							LambdaCcListBean.setTriggerComType(clientEmailCC.getHospital().getTriggerComType());
							LambdaCcListBean.setHospitalId(clientEmailCC.getHospital().getHospitalId());
							LambdaCcListBean.setCode(clientEmailCC.getHospital().getCode());
							LambdaCcListBean.setClientName(clientEmailCC.getHospital().getName());
							LambdaCcListBean.setEmailCc(clientEmailCC.getEmailCc());
							LambdaCcListBean
									.setUseraccountId(clientEmailCC.getHospital().getCreatedBy().getUserAccountId());
							LambdaCcListBean
									.setUserAccountkey(clientEmailCC.getHospital().getCreatedBy().getUserAccountKey());
							LambdaCcListBean.setCcNotification(
									clientEmailCC.getHospital().getCreatedBy().getNotificationFrequency());
							LambdaCcListBeanList.add(LambdaCcListBean);
							/** MAP **/
							List<PatientStageWorkflow> patientSWFList = patientStageWorkflowRepo
									.findByHspCCId(clientEmailCC.getHospital().getCreatedBy().getUserAccountId());
							Long CnId = clientEmailCC.getHospital().getCreatedBy().getUserAccountId();
							List<Long> patSWFId = patientSWFList.stream()
									.map(PatientStageWorkflow -> PatientStageWorkflow.getPatientSWFId())
									.collect(Collectors.toList());

							cnTodoCountMap.put(CnId.toString(), patSWFId);
						}
					}
				}
				lambdaCcTodoCountBean.setCnTodoCountMap(cnTodoCountMap);
				lambdaCcTodoCountBean.setLambdaCcListBeanList(LambdaCcListBeanList);

				return lambdaCcTodoCountBean;
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return lambdaCcTodoCountBean;
		}
		
		@Override
		public List<LambdaProSurveyBean> fetchAllPatientsTodoPROSurveyReminder(Long timeZoneId) {
			List<LambdaProSurveyBean> lambdaProSurveyList = new ArrayList<>();
			try {
				List<LambdaProSurvey> lambdaProSurvey = lambdaProSurveyRepo.
						findByZoneIdOrderByPatientSWFId(timeZoneId);
				if (lambdaProSurvey != null && !lambdaProSurvey.isEmpty()) {
					lambdaProSurveyList = lambdaProSurvey.stream()
							.map(LambdaProSurvey -> modelMapper.map(LambdaProSurvey, LambdaProSurveyBean.class))
							.toList();
				}
				return lambdaProSurveyList;
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return lambdaProSurveyList;
		}
}
