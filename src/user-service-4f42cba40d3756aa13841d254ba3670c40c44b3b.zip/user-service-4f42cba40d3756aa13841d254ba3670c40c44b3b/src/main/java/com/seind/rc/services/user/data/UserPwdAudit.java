package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class UserPwdAudit {

	private Long userPwdAuditId;
	private Long userAccountId;
	private String userPwd;
	private Date createdDate;
	private Long createdBy;
}
