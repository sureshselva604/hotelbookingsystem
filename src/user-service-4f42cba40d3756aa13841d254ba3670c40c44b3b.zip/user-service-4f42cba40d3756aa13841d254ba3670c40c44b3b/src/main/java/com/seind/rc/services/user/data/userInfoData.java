package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class userInfoData {
	private Date activatedDate;
	private Date modifiedDate;
	private Date userPwdCreatedOn;
	private String status;
}
