package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class TodoRACareUserBean {

	private Long careUserUaId;
	private String careUserName;
	private String careUserUgName;
	private Long careUserUgId;
	private String clientName;
}