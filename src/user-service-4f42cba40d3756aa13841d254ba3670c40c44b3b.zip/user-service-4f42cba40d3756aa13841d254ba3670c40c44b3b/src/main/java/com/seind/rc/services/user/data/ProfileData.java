package com.seind.rc.services.user.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)

public class ProfileData {

	@NotBlank(message = "firstName Should not be Blank")
	@NotNull(message = "firstName Should not be null")
	private String firstName;
	@NotBlank(message = "lastName Should not be Blank")
	@NotNull(message = "lastName Should not be null")
	private String lastName;
	@NotBlank(message = "dob Should not be Blank")
	@NotNull(message = "dob Should not be null")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date dob;
	private String email;
	private String code;
	private String phone;
	private String otherPhoneType;
	private String codeOther;
	private String bpci;
	@Default
	private List<ImageData> uploadImage = new ArrayList<>();
	private String teleCode;
	private String teleCountryCode;
	private String teleCodeOther;
	private String teleCountryCodeOther;
	private Long patientSWFId;
	private String gender;

	private Long weight;
	private Long height;
	private Long inch;
	private String bmi;
	private String ssn;
	private String mrnNo;
	private String phoneOther;
	private String hic;
	private Long patientId;

	private String otherPhone;
	private String comType;
	@Default
	private String userTitle = "";
	private String notificationFrequency;
	@Default
	private Boolean realTimeAlert = false;
	@Default
	private Boolean realTimeMessage = false;
	@Default
	private Boolean emailExists = true;
	@Default
	private Boolean phoneExists = true;

	@Default
	private Boolean pushNotification = false;

	public String getPhoneWithTeleCode() {
		if (this.teleCode != null && (this.phone != null && !this.phone.isBlank())) {
			return this.teleCode + "-" + this.phone;
		}
		return null;
	}
}