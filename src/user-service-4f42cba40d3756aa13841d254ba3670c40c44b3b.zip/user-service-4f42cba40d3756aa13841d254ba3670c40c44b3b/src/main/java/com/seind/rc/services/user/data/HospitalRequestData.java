package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HospitalRequestData {
	
	private Long hospitalId;
	private String mode;
	private int superClientId;

}
