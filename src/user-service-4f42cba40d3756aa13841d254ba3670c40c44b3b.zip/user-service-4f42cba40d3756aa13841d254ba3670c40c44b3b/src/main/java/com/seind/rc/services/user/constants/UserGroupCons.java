package com.seind.rc.services.user.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UserGroupCons {

	public static final Long PATIENT = 19l;
	public static final Long CARE_PARTNER = 20l;
	public static final Long CARE_COORDINATOR = 9l;
	public static final Long SURGEON = 18l;
	public static final String STR_CAREPARTNER = "Care Partner";
	public static final String STR_PATIENT = "patient";

	public static final List<Long> addUserCheck = new ArrayList<>(
			Arrays.asList(17l, 9l, 7l, 13l, 18l, 30l, 31l, 32l, 33l, 34l, 27l, 28l));
	public static final List<Long> userAdminShow = new ArrayList<>(Arrays.asList(1l, 19l, 20l, 25l, 18l));
	public static final List<Long> UserCheck = new ArrayList<>(
			Arrays.asList(9l, 17l, 25l, 27l, 28l, 40l, 41l, 30l, 31l, 32l, 33l));	
	public static final List<Long>patientOrCP= new ArrayList<>(Arrays.asList(19L,20L));

	public static final List<Long>messageCheck=new ArrayList<>(Arrays.asList(17L,9L,32L,33L));

}
