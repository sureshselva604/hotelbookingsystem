package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@JsonInclude(Include.NON_NULL)
public class UserSecQuestionAnsData {

	private Long userAccountId;
	private Long  questionId;
	private String question;
	private String ans;
	
	public UserSecQuestionAnsData(Long questionId, String question, String ans) {
		this.questionId = questionId;
		this.question = question;
		this.ans = ans;
	}
	
	
}
