package com.seind.rc.services.user.data;


import lombok.Data;

@Data
public class ResponseMessageSSO {
	
	private Boolean status;
	private Long userId;
}
