package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class UserUploadImgData {
	private Long userAccountId;
	private List<ImageData> uploadImage;
}
