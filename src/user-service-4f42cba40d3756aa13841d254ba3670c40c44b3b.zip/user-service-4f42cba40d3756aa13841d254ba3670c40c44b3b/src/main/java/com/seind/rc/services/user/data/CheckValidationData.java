package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CheckValidationData {

	private int statusCode;
	private boolean status;
	private String error;
	private String message;
	private String randId;
	private Long userGroupId;

}
