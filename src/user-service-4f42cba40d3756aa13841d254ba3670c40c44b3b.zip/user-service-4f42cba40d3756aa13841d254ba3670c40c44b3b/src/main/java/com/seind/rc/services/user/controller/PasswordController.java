package com.seind.rc.services.user.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.ChangePasswordData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.service.PasswordService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * C06
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/password")
@RequiredArgsConstructor
public class PasswordController {

	private static final Logger LOGGER = LogManager.getLogger(PasswordController.class);

	
	private final  PasswordService passwordService;


	/**
	 * This API Fetch the ForgotsecurityAnswer Based on country languageCode.
	 * 
	 * @param randId
	 */
	@Operation(summary = "GetForgotSecurityAnswerByUser")
	@PostMapping(value = "/getForgotSecurityAnswerByUser")
	public ResponseMessage getForgotSecurityAnswerByUser(@RequestBody UpdatePwdData payload) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.getForgotSecurityAnswerByUser(payload.getRandId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}



	/**
	 * Change the existing password into new password.
	 * 
	 * @param request
	 * @param A list of {@link changePasswordData} objects representing the
	 *                details of request.
	 */
	@Operation(summary = "Logged in user password change")
	@PostMapping(value = "/changePassword")
	public ResponseMessage changePassword(HttpServletRequest request,
			@RequestBody ChangePasswordData changePasswordData) {
		String xUser = request.getHeader("x-user");
		Long userId = Long.valueOf(xUser);
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.changePassword(changePasswordData, userId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

}
