package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "UserSecResultDetails")
public class UserSecResultDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userSecResultDetailsId;
	private Long userAccountId;
	private Long question1;
	private Long question2;
	private Long question3;
	private String answer1;
	private String answer2;
	private String answer3;
	private Date createdOn;
	@Column(name = "Irrelevant_Ans")
	private String irrelevantAns;
	private Integer wrongAnswerAttempts;
	private String mode;

}
