package com.seind.rc.services.user.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class CasCommonConstant {
	private CasCommonConstant() {

	}

	public static final String SSOSECKEY = "SSO_SECKEY";
	public static final String SSOSYNC = "SSOSYNC";
	public static final String ONBOARD = "onboard";
	public static final String HRO_LBL = "hro";
	public static final String SSO_ENABLED_STATUS = "SSO_ENABLED_STATUS";
	public static final String STATUS = "status";
	public static final String SSO_HRO_SYNCURL = "SSO_HRO_SYNCURL";
	public static final String SSO_RCOB_SYNCURL = "SSO_RCOB_SYNCURL";
	public static final String INVALIDTOKEN = "Invalid Token or User does not exist";
	public static final String VALIDSTATUS = "User Profile updated successfully";
	public static final String USER_DOES_NOT_EXIST = "User does not exist";
	public static final String SSO_TURNED_OFF = "Invalid security Key or sso feature off";
	public static final String COMPLETED = "Completed";
	public static final String SUCCESS="Success";
	public static final String FAILURE="failure";
	
	public static final List<String> modeListForUserSecTrans= new ArrayList<>(Arrays.asList("login-otp","password-otp","activation-otp","activationotp"));



}
