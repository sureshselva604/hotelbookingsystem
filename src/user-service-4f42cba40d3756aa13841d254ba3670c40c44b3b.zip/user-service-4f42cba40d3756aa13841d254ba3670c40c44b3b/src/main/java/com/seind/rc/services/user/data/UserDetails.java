package com.seind.rc.services.user.data;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.StringEncrypter;
import com.seind.rc.services.user.util.StringEncrypter.EncryptionException;

import lombok.Data;

@Data
public class UserDetails {

	private Long userAccountId;
	private String userName;
	private String firstName;
	private String lastName;
	private String city;
	private String state;
	private String phone;
	private String imagePath;
	private Boolean active;
	private Boolean welcomeFlag;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy HH:mm:ss.SSS")
	private Date dob;
	private String userPwd;
	private Integer wrongPwdAttempt;
	private String address1;
	private String address2;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy HH:mm:ss.SSS")
	private Date createdDate;
	private String clientName;
	private String clientImagePath;

	public String getUserPwd() {
		StringEncrypter se;
		try {
			se = new StringEncrypter("DES");
			return userPwd != null ? se.decrypt(userPwd) : "";
		} catch (EncryptionException e) {
			e.printStackTrace();
		}
		return "";
	}

	public String getPhone() {
		return RCUserUtil.getStringValue(phone);
	}

	public String getAddress1() {
		return RCUserUtil.getStringValue(address1);
	}

	public String getAddress2() {
		return RCUserUtil.getStringValue(address2);
	}

	public String getImagePath() {
		return RCUserUtil.getStringValue(imagePath);
	}

	public String getState() {
		return RCUserUtil.getStringValue(state);
	}

	public String getCity() {
		return RCUserUtil.getStringValue(city);
	}

}
