package com.seind.rc.services.user.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "CountryCode")
public class CountryCode {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CountryCodeId", unique = true, nullable = false)
	private Long countryCodeId;
	private String countryName;
	private String countryCode;
	private String teleCode;
	private Long length;
	private String phoneFormat;
	private String salutation;
	private String dateFormat;
	private String currencyFormat;
	private String language;
	private String helpDeskNo;
	
}
	
