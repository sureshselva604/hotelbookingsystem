package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.ExerciseVideoNotification;
import java.util.List;


public interface ExerciseVideoNotificationRepository  extends JpaRepository<ExerciseVideoNotification, Long>{

	List<ExerciseVideoNotification> findByPatientSwfIdIn(List<Long> patientswfIdList);
}
