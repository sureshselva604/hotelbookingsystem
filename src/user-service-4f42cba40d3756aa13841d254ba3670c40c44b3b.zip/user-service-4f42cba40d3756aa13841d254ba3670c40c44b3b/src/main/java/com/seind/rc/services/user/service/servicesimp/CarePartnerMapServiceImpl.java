package com.seind.rc.services.user.service.servicesimp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.NotificationConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.AddCarePartner;
import com.seind.rc.services.user.data.CarePartnerInfo;
import com.seind.rc.services.user.data.CareServiceData;
import com.seind.rc.services.user.data.ContactData;
import com.seind.rc.services.user.data.ImageData;
import com.seind.rc.services.user.data.NotificationData;
import com.seind.rc.services.user.data.NotifyReqData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.UserExistsReqData;
import com.seind.rc.services.user.data.UserExistsResponse;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.PhoneType;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.CarePartnerMapService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.util.GenerateOTP;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.StringEncrypter;
import com.seind.rc.services.user.util.UploadImageUtil;
import com.seind.rc.services.user.util.UserValidationUtil;

@Service
public class CarePartnerMapServiceImpl implements CarePartnerMapService {

	private static final Logger LOGGER = LogManager.getLogger(CarePartnerMapServiceImpl.class);

	private static final String LOG_MSG_TEXT = "No Carepartner eligiable for email onbehalf of patient";
	private static final String USERMSG = "new user is not conflict with current profile";
	private static final String USEREXIST = "userExistInSystem";
	private static final String INVALID_DATA = "Invalid Data!";
	private static final String CARE_PARTNER = "Care Partner";
	private static final String MESSAGE_STATUS = "Care partner was added successfully!";

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;

	@Autowired
	private UserAccountRepository userRepo;

	@Autowired
	private HospitalRepository hospitalRepo;

	@Autowired
	private PatientStageWorkflowRepository patientSWFRepo;

	@Autowired
	private ModelMapper modelMap;

	@Autowired
	private UserAccountService userService;


	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepo;

	@Autowired
	private PatientRepository patientRepo;

	/**
	 * M01
	 * 
	 * Get CarePartnerMap Record by CarePartnerMapId
	 */
	@Override
	public CarePartnerMap getCarePartnerMapById(Long carePartnerMapId) {
		Optional<CarePartnerMap> cpMap = null;
		try {
			cpMap = carePartnerMapRepo.findById(carePartnerMapId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return cpMap.isPresent() ? cpMap.get() : null;
	}

	/**
	 * M02
	 * 
	 * Get CarePartnerMap Record by PatientId and CarePartner UserAccountId
	 */
	@Override
	public CarePartnerMap getCarePartnerMap(Long userAccountId, Long patientId) {
		List<CarePartnerMap> cpMap = null;
		try {
			cpMap = carePartnerMapRepo.findByUserAccount_UserAccountIdAndPatientId(userAccountId, patientId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return !cpMap.isEmpty() ? cpMap.get(0) : null;
	}

	/**
	 * M03
	 * 
	 * Get Patients Map to CarePartner
	 */
	@Override
	public List<CarePartnerMap> getCarePartnerPatientList(Long userAccountId) {
		List<CarePartnerMap> cpMap = null;
		try {
			cpMap = carePartnerMapRepo.findByActiveTrueAndUserAccount_UserAccountId(userAccountId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return !cpMap.isEmpty() ? cpMap : null;
	}

	/**
	 * M04
	 * 
	 * Get PatientIds Map to CarePartner by CarePartner UserAccountId
	 */
	@Override
	public CareServiceData getPatientIdUsingCarePartner(Long cPUserAccId) {
		CareServiceData response = new CareServiceData();
		try {
			List<Long> patientIds = carePartnerMapRepo
					.findByUserAccount_UserAccountIdAndUserAccount_UserGroup_UserGroupIdAndUserAccount_ActiveAndActive(
							cPUserAccId, 20l, true, true)
					.stream().map(a -> a.getPatientId()).collect(Collectors.toList());
			Optional<UserAccount> cpData = userRepo.findById(cPUserAccId);
			UserAccount cpAcc = null;
			if (cpData.isPresent()) {
				String email = cpData.get().getEmail();
				String phone = cpData.get().getPhone();
				if (email != null) {
					cpAcc = userRepo.findByUserGroup_UserGroupIdAndEmailLike(19L, email);
				} else if (phone != null) {
					cpAcc = userRepo.findByUserGroup_UserGroupIdAndPhoneLike(19L, phone);
				}
			}
			Long cpPatientId = cpAcc != null ? cpAcc.getUserAccountKey() : null;
			response.setPatientIds(patientIds);
			response.setCpPatientId(cpPatientId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M05
	 */
	@Override
	public String getCarePartnerInfoByPatientId(Long patientId) {
		List<UserAccount> cpUserAccount = userRepo.findByWhoseCarePartner(patientId);
		List<CarePartnerInfo> carePartnerUserAcct = cpUserAccount.stream().map(carePartner -> {
			CarePartnerInfo carePartnerData = modelMap.map(carePartner, CarePartnerInfo.class);
			carePartnerData.setSequenceNo(carePartner.getUserGroup().getSeqno());
			return carePartnerData;
		}).toList();
		return carePartnerUserAcct.toString();
	}

	/**
	 * M06
	 */
	@Override
	public ResponseMessage carePartnerInfoDetails(AddCarePartner data) {
		ResponseMessage response = new ResponseMessage();
		String saveStatus = "true";
		String firstName = data.getFirstName();
		String lastName = data.getLastName();
		String gender = data.getGender();
		String email = data.getEmail();
		String phone = data.getPhone();
		String teleCode = data.getTeleCode();
		String teleCountryCode = data.getTeleCountryCode();
		String phoneOther = data.getPhoneOther();
		String teleCodeOther = data.getTeleCodeOther();
		String teleCountryCodeOther = data.getTeleCountryCodeOther();
		String relationship = data.getRelationship();
		String otherPhoneTypeId = data.getOtherPhoneType();
		Boolean onBehalf = data.isOnBehalf();
		List<ImageData> imageData = data.getUploadImage();
		Long patientId = data.getPatientId();
		Long hospitalId = null;
		UserAccount userAccp = null;
		String emailOrPhoneUpdateCheck = "";
		String willSendOnBoardWelcomeLink = "";
		String initialMode = data.getMode();
		try {
			UserAccount loginUser = userRepo.findById(data.getXuser()).get();
			if (loginUser.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)) {
				hospitalId = loginUser.getCreatedByUa().getUserAccountKey();
			} else {
				Optional<Patient> patientOpt = patientRepo.findById(patientId);
				patientId = patientOpt.get().getPatientId();
				hospitalId = patientOpt.get().getCreatedByUa().getUserAccountKey();
			}
			List<UserAccount> existingUserAcc = userRepo.findByEmail(email);
			Hospital hsp = hospitalRepo.findById(hospitalId).get();
			String defaultUserName = GenerateOTP.getAlphaNumericForUserName();
			if (existingUserAcc == null) {
				existingUserAcc = userRepo.findByphoneWithTeleCode(teleCode + "-" + phone);
			}
			LOGGER.info(existingUserAcc.size());
			if (data.getUserAccountId() != null) {
				userAccp = userRepo.findById(data.getUserAccountId()).orElse(null);
				boolean addNewCpCheck = userAccp != null ? getNewCarePartner(userAccp.getEmail(), userAccp, email)
						: false;
				if (addNewCpCheck) {
					CarePartnerMap cp = carePartnerMapRepo
							.findByUserAccount_UserAccountIdAndPatientId(userAccp.getUserAccountId(), patientId)
							.stream().findFirst().orElse(null);
					if (cp != null)
						carePartnerMapRepo.delete(cp);
					data.setUserAccountId(null);
					data.setMode("add");
				}

			}

			if (data.getUserAccountId() != null) {
				userAccp = userRepo.findById(data.getUserAccountId()).orElse(null);
				Long uaId = userAccp.getUserAccountId();
				ContactData phoneAndEmail = ContactData.builder().newEmail(email).newPhone(phone)
						    .oldEmail(userAccp.getEmail()).oldPhone(userAccp.getPhone()).build();	
				willSendOnBoardWelcomeLink = userService.willSendOnBoardWelcomeLink(data.getUserAccountId(), email, phone); 
				emailOrPhoneUpdateCheck = RCUserUtil.emailAndPhoneUpdateCheck(phoneAndEmail, willSendOnBoardWelcomeLink);
				if(!RCUserUtil.stringContains(userAccp.getEmail())&&!RCUserUtil.stringContains(userAccp.getPhone()))
					     userAccp.setActive(false);	
				
				List<UserAccount> uaList = userService.getUsersByEmailId(userAccp.getEmail(), userAccp.getTeleCodeWithPhone())
						          .stream().filter(a->!a.getUserAccountId().equals(uaId)).collect(Collectors.toList());
				
				if(existingUserAcc.isEmpty())
				     existingUserAcc.addAll(uaList);
				
			}
			else {
			    userAccp = new UserAccount();
			    userAccp.setCreatedDate(new Date());
				userAccp.setUserGroupId(UserGroupCons.CARE_PARTNER);
				userAccp.setDescription(UserGroupCons.STR_CAREPARTNER);
				userAccp.setWhoseCarePartner(patientId);
				userAccp.setCreatedBy(data.getXuser());
				userAccp.setDeIdFlag(true);
				userAccp.setWelcomeFlag(true);
				userAccp.setUserActivationStatus("Not Yet Started");
				userAccp.setWrongPwdAttempt(0);
				userAccp.setActive(true);
				userAccp.setIsdelete(false);
				userAccp.setCareFamilyShow(true);
				String defaultPwd = GenerateOTP.getAlphaNumericRandomPwd();
				userAccp.setUserPwd(new StringEncrypter("DES").encrypt(defaultPwd));
				userAccp.setUserPwdCreatedOn(new Date());
				willSendOnBoardWelcomeLink = userService.willSendOnBoardWelcomeLink(data.getXuser(), email, phone);

			}

			userAccp.setUserName(email.isEmpty() ? defaultUserName : email);
			userAccp.setFirstName(firstName);
			userAccp.setLastName(lastName);
			userAccp.setEmail(RCUserUtil.getUserContactDetail(email));
			userAccp.setPhone(RCUserUtil.getUserContactDetail(phone));
			userAccp.setTeleCode(RCUserUtil.getUserContactDetail(teleCode));
			userAccp.setTeleCountryCode(RCUserUtil.getUserContactDetail(teleCountryCode));
			userAccp.setTitle(relationship);
			userAccp.setOtherPhone(RCUserUtil.getUserContactDetail(phoneOther));
			userAccp.setOtherTeleCode(RCUserUtil.getUserContactDetail(teleCodeOther));
			userAccp.setOtherTeleCountryCode(RCUserUtil.getUserContactDetail(teleCountryCodeOther));
			userAccp.setComType(RCUserUtil.getComType(email, phone));
			userAccp.setGender(gender);
			PhoneType phoneType = new PhoneType();
			phoneType.setPhoneTypeId(Long.valueOf(otherPhoneTypeId));
			userAccp.setOtherPhoneType(RCUserUtil.getUserContactDetail(phoneOther)!=null?phoneType:null);
			String defaultImgPath = RCUserUtil.getDefaultImgPath(gender);
			userAccp = UserValidationUtil.getUserAccOnboardLinkon(userAccp, willSendOnBoardWelcomeLink);
			boolean emailExists = userRepo.findByEmailAndUserGroup_UserGroupId(email, UserGroupCons.CARE_PARTNER)
					.isEmpty();
			if(emailExists) {				
				emailExists = userRepo.findByphoneWithTeleCodeAndUserGroup_UserGroupId(teleCode+"-"+phone, UserGroupCons.CARE_PARTNER).isEmpty();
			}
			if(!initialMode.equalsIgnoreCase(data.getMode())) {
				emailExists = true;
			}

			if (emailExists||data.getMode().equalsIgnoreCase("edit")) {
				//boolean emailExistsAfterFlag = findEmailExistsAfterFlag(userAccp);
				if (imageData != null && !imageData.isEmpty()) {
					userAccp.setImagePath(UploadImageUtil.uploadUserImage(userAccp, hsp, imageData));
				} else {
					if(userAccp.getImagePath()==null)
					      userAccp.setImagePath(defaultImgPath);
				}
				userRepo.save(userAccp);
				userAccp = getUserActivationMode( existingUserAcc, userAccp, data.getMode());
				initiateContactPreValidation(userAccp);				
				userAccp.setActive(true);
				userRepo.save(userAccp);
				response.setMessage("Care partner was " + data.getMode() + "ed successfully!");
				response.setStatus(saveStatus);
			}

				response.setMessage("Care partner was "+data.getMode()+"ed successfully!");
				PatientStageWorkflow patientSWF = patientSWFRepo.findByPatient_PatientId(patientId).stream().findFirst().orElse(null);			
				if(userAccp.getUserAccountId()==null) {
					userAccp = userRepo.findByEmailAndUserGroup_UserGroupId(email, UserGroupCons.CARE_PARTNER).orElse(null);
					if(userAccp==null) {
						userAccp = userRepo.findByphoneWithTeleCodeAndUserGroup_UserGroupId(teleCode+"-"+phone, UserGroupCons.CARE_PARTNER).orElse(null);
						}
					userAccp.setWhoseCarePartner(patientId);
					userRepo.save(userAccp);
				}
				response.setHospitalId(hospitalId);
				response = addOrEditCarePartnerMap(userAccp, patientId, relationship, response, data.getMode(), onBehalf);
				String randId = UUID.randomUUID().toString();
				NotifyReqData notifyData = new NotifyReqData();
				notifyData.setPatientId(patientId);
				notifyData.setPatientSwfId(patientSWF.getPatientSWFId());	
				notifyData.setSurgeonId(patientSWF.getHspSurgId());		
				notifyData.setRelationShip(relationship);
				notifyData.setRandId(randId);		
				notifyData.setHspId(hospitalId);	
				notifyData.setToUser(userAccp.getUserAccountId());	
				response = notificationToCP(response,willSendOnBoardWelcomeLink,data.getMode(),notifyData,emailOrPhoneUpdateCheck,onBehalf);			
				
		} catch (Exception e) {
			response.setMessage("Invalid Data");
			response.setSaveStatus(CommonConstant.FALSE);
			LOGGER.info(e);
		}
		response.setHospitalId(null);
		return response;
	}


	/**
	 * M07
	 */
	private ResponseMessage notificationToCP(ResponseMessage response,String willSendOnBoardWelcomeLink,String mode,NotifyReqData notifyData,String emailOrPhoneUpdateCheck,boolean onbehalf) {
	
		List<NotifyReqData> notificationDatas = response.getNotifyData()!=null? response.getNotifyData():new ArrayList<NotifyReqData>();
		if(mode.equalsIgnoreCase("add")&&onbehalf) {
		
			if(willSendOnBoardWelcomeLink.equals("Y")||willSendOnBoardWelcomeLink.equals("P")) {
			    saveUserSecTransAudit(notifyData.getToUser(),notifyData.getRandId());
				notifyData.setNotificationType(NotificationConstant.WELCOMEINVITE);
				notificationDatas.add(notifyData);
			}

			UserValidationUtil.deviceLoginAudit(notifyData.getPatientId(), notifyData.getPatientSwfId(),
					"CAREFAMILY", "Add", "PP Adding New Care Partner");
			
		}
		else {
			if(onbehalf) {
			if(willSendOnBoardWelcomeLink.equals("Y")&&(emailOrPhoneUpdateCheck.equalsIgnoreCase("Email")||emailOrPhoneUpdateCheck.equalsIgnoreCase("Both"))){
				   saveUserSecTransAudit(notifyData.getToUser(),notifyData.getRandId());
				   notifyData.setNotificationType(NotificationConstant.WELCOMEINVITE);
				   notificationDatas.add(notifyData);	
				}	
			
			if(willSendOnBoardWelcomeLink.equals("P")&&(emailOrPhoneUpdateCheck.equalsIgnoreCase("Phone")||emailOrPhoneUpdateCheck.equalsIgnoreCase("Both"))){
				notifyData.setNotificationMode(NotificationConstant.PHONENUMBERUPDATE);
				notificationDatas.add(notifyData);

			}
			if (willSendOnBoardWelcomeLink.equals("P") && (emailOrPhoneUpdateCheck.equalsIgnoreCase("Email")
					|| emailOrPhoneUpdateCheck.equalsIgnoreCase("Both"))) {
				notifyData.setNotificationMode(NotificationConstant.EMAILADDRESSUPDATE);
				notificationDatas.add(notifyData);
			}

		}
	       UserValidationUtil.deviceLoginAudit(notifyData.getPatientId(), notifyData.getPatientSwfId(),
					"CAREFAMILY", "Edit", "updating Care Partner");
		}

		response.setNotifyData(notificationDatas);
		return response;
	}


	/**
	 * M08
	 */
	private UserAccount setPwdAndDob(UserAccount userAccp, List<UserAccount> ulist) {
		if (!ulist.isEmpty()) {
			List<UserAccount> userPswCreatedOn = ulist.stream()
					.filter(ua -> (ua.getUserGroupId() != 19L && ua.getUserGroupId() != 20L)).toList();
			if (userPswCreatedOn != null && !userPswCreatedOn.isEmpty()) {
				userAccp.setUserPwdCreatedOn(userPswCreatedOn.get(0).getUserPwdCreatedOn());
				userAccp.setDob(ulist.get(0).getDob());
			}
		}
		return userAccp;
	}

	
	/**
	 * M09
	 */

	private UserAccount getUserActivationMode( List<UserAccount> existingUserAcc,
			UserAccount userAccp, String mode) {
			if (!existingUserAcc.isEmpty()&& existingUserAcc.get(0).getUserPwd() != null && !existingUserAcc.get(0).getUserPwd().trim().isEmpty()) {
				if (mode.equalsIgnoreCase("add")&&userAccp.getEmail()!=null) {
					userAccp.setUserName(userAccp.getEmail()+"$$"+userAccp.getUserAccountId());
					userAccp.setUserPwd(existingUserAcc.get(0).getUserPwd());
					userAccp.setUserPwdCreatedOn(existingUserAcc.get(0).getUserPwdCreatedOn());
					if (existingUserAcc.get(0).getWelcomeFlag() == false) {
						userAccp.setWelcomeFlag(false);
						userAccp.setWrongPwdAttempt(existingUserAcc.get(0).getWrongPwdAttempt());
						userAccp.setActivationMode(existingUserAcc.get(0).getActivationMode());
						userAccp.setActivationDate(existingUserAcc.get(0).getActivationDate());
					}
				}

				existingUserAcc.stream().filter(a -> !a.getUserAccountId().equals(userAccp.getUserAccountId()))
						.map(a -> mergeUpdateCp(userAccp, a)).toList();
			}
		
		
		
		return userAccp;
	}

	private UserAccount mergeUpdateCp(UserAccount userAccp, UserAccount existingUserAcc) {

		if(userAccp.getEmail()!=null) {
		existingUserAcc.setFirstName(userAccp.getFirstName());
		existingUserAcc.setLastName(userAccp.getLastName());
		existingUserAcc.setUserName(userAccp.getEmail() + "$$" + existingUserAcc.getUserAccountId());
		existingUserAcc.setEmail(userAccp.getEmail());
		existingUserAcc.setPhone(userAccp.getPhone());
		existingUserAcc.setTeleCode(userAccp.getTeleCode());
		existingUserAcc.setGender(userAccp.getGender());
		userRepo.save(existingUserAcc);
		if (existingUserAcc.getUserGroupId().equals(UserGroupCons.PATIENT)) {
			Patient patUpdate = patientRepo.findById(existingUserAcc.getUserAccountKey()).orElse(null);
			if (patUpdate != null) {

				patUpdate.setFirstName(userAccp.getFirstName());
				patUpdate.setLastName(userAccp.getLastName());
				patUpdate.setEmail(userAccp.getEmail());
				patUpdate.setPhone(userAccp.getPhone());
				patUpdate.setTeleCode(userAccp.getTeleCode());
				patUpdate.setGender(userAccp.getGender());
				patientRepo.save(patUpdate);

			}
		}
		
	}
		return existingUserAcc;	
	}

	/**
	 * M10
	 */
	private void initiateContactPreValidation(UserAccount userAccount) {
		if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(userAccount))) {
			// userService.contactPreValidation(userAccount);
		}
	}

	/**
	 * M11
	 */
	@Override
	public CarePartnerMap getActiveCarePartnerMapByPatient(Long patientId) {
		CarePartnerMap carePartnerMap = null;
		try {
			List<CarePartnerMap> cpMapList = carePartnerMapRepo.findByPatientIdAndActive(patientId, true);
			if (cpMapList != null && !cpMapList.isEmpty())
				carePartnerMap = cpMapList.get(0);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return carePartnerMap;
	}

	

	/**
	 * M13
	 */
	public void deactivateCP(Long patientId, String surgeonName, Hospital hsp, String fixedEmailConent,
			String fixedSMSContent, Long currentCPId) {
		if ((currentCPId + "").equalsIgnoreCase("0")) {
			List<UserAccount> ulist = carePartnerList(patientId);
			if (ulist != null && !ulist.isEmpty()) {
				for (UserAccount cpAct : ulist) {
					deativateEmailOrSmsForCp(cpAct.getUserAccountId(), hsp, patientId);
				}
			} else {
				LOGGER.debug(LOG_MSG_TEXT);
			}
		} else {
			// UserAccount cpAct = userService.getUserAccountByUserAccountId(currentCPId);
			deativateEmailOrSmsForCp(currentCPId, hsp, patientId);
		}
	}

	/**
	 * M14
	 */
	private void deativateEmailOrSmsForCp(Long currentCPId, Hospital hsp, Long patientId) {
		NotificationData notifyObj = new NotificationData();

		String notifyType = NotificationConstant.ACCOUNTDEACTIVATION;
		notifyObj.setPatientId(patientId);
		notifyObj.setCpUserId(currentCPId);
		notifyObj.setHspId(hsp.getHospitalId());
		notifyObj.setToUser(currentCPId);
		notifyObj.setNotificationType(notifyType);
		// notificationUtil.sendNotification(notifyObj);
	}

	/**
	 * M15
	 */
	@Override
	public List<UserAccount> carePartnerList(Long patientId) {
		List<UserAccount> uaList = new ArrayList<>();
		try {
			uaList = carePartnerMapRepo.findByPatientIdAndActiveTrueAndUserAccount_UserGroup_UserGroupId(patientId, 20L)
					.stream().filter(a -> a.getUserAccount().getIsdelete() != null || !a.getUserAccount().getIsdelete())
					.map(a -> a.getUserAccount()).toList();
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return uaList;
	}

	/**
	 * M16
	 */
	private ResponseMessage addOrEditCarePartnerMap(UserAccount useracc, Long patientId, String relationShip,
			ResponseMessage response, String mode, boolean onbehalf) {

		CarePartnerMap cp = carePartnerMapRepo
				.findByUserAccount_UserAccountIdAndPatientId(useracc.getUserAccountId(), patientId).stream().findFirst()
				.orElse(null);
		if (mode.equals("add")) {
			if (cp == null) {
				saveCarePartnerMap(useracc, patientId, relationShip, onbehalf, response);
			} else {
				response.setMessage("CarePartner was already mapped");
				response.setSaveStatus(CommonConstant.FALSE);
			}
		} else {

			if (cp == null) {
				saveCarePartnerMap(useracc, patientId, relationShip, onbehalf, response);
			} else {
				if (onbehalf) {
					Optional<CarePartnerMap> patActiveCp = carePartnerMapRepo.findByPatientIdAndActiveTrue(patientId);
					response = deActiveOtherCpNotification(patActiveCp, patientId, response);
					carePartnerMapRepo.updateCarePartnerActive(patientId,
							new ArrayList<>(Arrays.asList(useracc.getUserAccountId())));
					cp.setActive(onbehalf);
				}
				cp.setActive(onbehalf);
				carePartnerMapRepo.save(cp);
			}	
			
		}
		if(!RCUserUtil.stringContains(useracc.getEmail())&&!RCUserUtil.stringContains(useracc.getPhone())) {
			
			List<CarePartnerMap> cpMapList = carePartnerMapRepo.findByActiveTrueAndUserAccount_UserAccountId(useracc.getUserAccountId()).stream()
					                         .map(a->{
					                        	 a.setActive(false);
					                        	 return a;
					                         }).collect(Collectors.toList());
			
			
			carePartnerMapRepo.saveAll(cpMapList);
		}
		
	
		return response;
		
	}	
		

	/**
	 * M17
	 */
	private ResponseMessage saveCarePartnerMap(UserAccount useracc, Long patientId, String relationShip,
			boolean onbehalf, ResponseMessage response) {

		CarePartnerMap careMap = new CarePartnerMap();
		careMap.setPatientId(patientId);
		careMap.setUserAccount(useracc);
		careMap.setCreatedBy(useracc.getUserAccountId());
		careMap.setCreatedDate(new Date());
		careMap.setVerified(false);
		careMap.setRelationShip(relationShip);
		careMap.setActive(false);
		if (onbehalf) {
			Optional<CarePartnerMap> patActiveCp = carePartnerMapRepo.findByPatientIdAndActiveTrue(patientId);
			response = deActiveOtherCpNotification(patActiveCp, patientId, response);
			carePartnerMapRepo.updateCarePartnerActive(patientId,
					new ArrayList<>(Arrays.asList(useracc.getUserAccountId())));
			careMap.setActive(onbehalf);
		}

		carePartnerMapRepo.save(careMap);

		return response;

	}

	/**
	 * M18
	 */
	private ResponseMessage deActiveOtherCpNotification(Optional<CarePartnerMap> patActiveCp, Long patientId,
			ResponseMessage response) {
		if (patActiveCp.isPresent() && patActiveCp.get().getUserAccount().getIsdelete() != null
				&& !patActiveCp.get().getUserAccount().getIsdelete()) {
			NotifyReqData notifyData = new NotifyReqData();
			notifyData.setPatientId(patientId);
			notifyData.setCpUserId(patActiveCp.get().getUserAccount().getUserAccountId());
			notifyData.setHspId(response.getHospitalId());
			notifyData.setToUser(patActiveCp.get().getUserAccount().getUserAccountId());
			notifyData.setNotificationType(NotificationConstant.ACCOUNTDEACTIVATION);
			response.setNotifyData(new ArrayList<NotifyReqData>(Arrays.asList(notifyData)));
		}
		return response;
	}

	/**
	 * M19
	 */
	private Boolean getNewCarePartner(String oldEmailId, UserAccount existingUserAcc, String email) {
		Boolean addNewCarePartner = false;
		if (email != null && !email.isEmpty() && oldEmailId != null && !oldEmailId.equalsIgnoreCase(email)) {
			addNewCarePartner = (existingUserAcc != null && existingUserAcc.getWelcomeFlag());
		}
		return addNewCarePartner;
	}

	

	/**
	 * M20
	 */
	private void saveUserSecTransAudit(Long userAccountId, String randId) {
		try {
		
			UserSecTransAudit userSecTransAudit = userSecTransAuditRepo.findByUserAccount_UserAccountIdOrderByCreatedOnDesc(userAccountId)
				                      .stream().findFirst().orElse(null);
			if(userSecTransAudit!=null) {
				userSecTransAudit.setIsActive(false);	
			}
			userSecTransAudit = new UserSecTransAudit();
			userSecTransAudit.setUserAccount(userRepo.findById(userAccountId).orElse(null));
			userSecTransAudit.setIsActive(true);
			userSecTransAudit.setCreatedOn(new Date());
			userSecTransAudit.setRandomId(randId);
			userSecTransAudit.setMode("AddUser");
			userSecTransAuditRepo.save(userSecTransAudit);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M21
	 */
	@Override
	public boolean successCheckEmailOrPhoneExists(String groupId, String oldEmailId, String oldPhone,
			String oldTeleCode, String email, String phone, String teleCode, String mode) {
		boolean saveStatus = true;
		try {
			if (email != null && !email.isEmpty() && oldEmailId != null
					&& (oldEmailId.isEmpty() || !oldEmailId.equals(email))) {
				LOGGER.info("if email");
				Map<String, String> mailCheckMap = checkUserEmailExist(oldEmailId, email, groupId, mode);
				String statusValue = mailCheckMap.get(CommonConstant.CONFLICTSTATUS);
				String stausValueMsg = mailCheckMap.get(CommonConstant.MESSAGE2);
				saveStatus = getSaveStatusValue(saveStatus, statusValue, stausValueMsg);
				LOGGER.debug("Email address already exist");

			}
			if (phone != null && !phone.isEmpty() && oldPhone != null
					&& (oldPhone.isEmpty() || !oldPhone.equals(phone))) {
				LOGGER.info("if phone");
				Map<String, String> phoneCheckMap = checkUserPhoneExist(
						!oldPhone.isEmpty() ? getUserPhone(oldPhone, oldTeleCode) : "", getUserPhone(phone, teleCode),
						groupId, mode);
				String statusValue = phoneCheckMap.get(CommonConstant.CONFLICTSTATUS);
				String stausValueMsg = phoneCheckMap.get(CommonConstant.MESSAGE2);
				saveStatus = getSaveStatusValue(saveStatus, statusValue, stausValueMsg);
				LOGGER.debug("Mobile Number already exist");
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			saveStatus = false;
		}
		return saveStatus;
	}

	/**
	 * M22
	 */
	private boolean getSaveStatusValue(boolean saveStatus, String statusValue, String stausValueMsg) {
		if (statusValue != null && !(statusValue.equalsIgnoreCase(CommonConstant.FALSE)
				|| statusValue.equalsIgnoreCase(CommonConstant.SUCCESS) || stausValueMsg.equalsIgnoreCase(USERMSG))) {
			saveStatus = false;
		}
		return saveStatus;
	}

	/**
	 * M23
	 */
	private String getUserPhone(String phone, String teleCode) {
		String patUserPhone = "";
		if (teleCode != null && !teleCode.isEmpty()) {
			patUserPhone = (phone != null && !phone.isEmpty()) ? teleCode + "-" + phone.trim() : "";
		}
		return patUserPhone;
	}

	/**
	 * M24
	 */
	public Map<String, String> checkUserEmailExist(String oldEmail, String newEmail, String profileUpdatingRole,
			String addOrEdit) {
		Map<String, String> statusMap = new HashMap<>();
		boolean conflictwithothergroup = false;
		boolean profileRoleConflictStatus = false;
		try {
			if (!newEmail.isEmpty()) {
				List<UserAccount> newUserAccountList = userRepo.findByEmail(newEmail);
				// check new email exist
				if (newUserAccountList != null && !newUserAccountList.isEmpty() && !oldEmail.isEmpty()) {
					// if new email exist check with old email role
					LOGGER.info(newUserAccountList + "newUserAccountList");
					List<UserAccount> olduserAccountList = userRepo.findByEmail(oldEmail);
					checkUserGroupConflict(statusMap, conflictwithothergroup, newUserAccountList, olduserAccountList);
				} else {
					LOGGER.info("newUserAccountListNot");

					checkUserConflictIfOldUserIsEmpty(profileUpdatingRole, statusMap, profileRoleConflictStatus,
							newUserAccountList, addOrEdit);
				}
			}
		} catch (Exception e) {
			statusMap.put(CommonConstant.CONFLICTSTATUS, CommonConstant.FAILURE);
			statusMap.put(CommonConstant.MESSAGE2, "Not able to validate");
			LOGGER.error("Exception in - UserAccountDaoImpl , Method Name - checkUserEmailExist: ", e);
		}
		return statusMap;
	}

	/**
	 * M25
	 */
	public Map<String, String> checkUserPhoneExist(String oldPhone, String newPhone, String profileUpdatingRole,
			String addOrEdit) {
		Map<String, String> statusMap = new HashMap<>();
		boolean conflictwithothergroup = false;
		String oldPhonenum = "";
		String oldTelecode = "";
		String newPhoneNum = "";
		String newTelecode = "";
		boolean profileRoleConflictStatus = false;
		try {
			String[] oldPhoneWithTelecodeList = RCUserUtil.returnPhoneValues(oldPhone);
			oldPhonenum = oldPhoneWithTelecodeList[0];
			oldTelecode = oldPhoneWithTelecodeList[1];
			String[] newPhoneWithTelecodeList = RCUserUtil.returnPhoneValues(newPhone);
			newPhoneNum = newPhoneWithTelecodeList[0];
			newTelecode = newPhoneWithTelecodeList[1];
			if (!newPhoneNum.isEmpty()) {
				List<UserAccount> newUserAccountList = userRepo.findByPhoneAndTeleCode(newPhoneNum, newTelecode);
				if (newUserAccountList != null && !newUserAccountList.isEmpty() && !oldPhonenum.isEmpty()) {
					List<UserAccount> oldUserAccountList = userRepo.findByPhoneAndTeleCode(oldPhonenum, oldTelecode);
					LOGGER.info(oldUserAccountList + "oldUserAccountList");
					checkUserGroupConflict(statusMap, conflictwithothergroup, newUserAccountList, oldUserAccountList);
				} else {
					LOGGER.info("oldUserAccountListNot");

					checkUserConflictIfOldUserIsEmpty(profileUpdatingRole, statusMap, profileRoleConflictStatus,
							newUserAccountList, addOrEdit);
				}
			}
		} catch (Exception e) {
			statusMap.put(CommonConstant.CONFLICTSTATUS, CommonConstant.FAILURE);
			statusMap.put(CommonConstant.MESSAGE2, "Not able to validate");
			LOGGER.error("Exception in - UserAccountDaoImpl , Method Name - checkUserPhoneExist: ", e);
		}
		return statusMap;
	}

	/**
	 * M26
	 */
	private void checkUserConflictIfOldUserIsEmpty(String profileUpdatingRole, Map<String, String> statusMap,
			boolean profileRoleConflictStatus, List<UserAccount> newUserAccountList, String addOrEdit) {
		if (newUserAccountList != null && !newUserAccountList.isEmpty()) {
			profileRoleConflictStatus = findUserHaveConflictwithProfileRole(profileUpdatingRole,
					profileRoleConflictStatus, newUserAccountList, addOrEdit);
			setConflictStatusIfUserExistInSystem(statusMap, profileRoleConflictStatus);
		} else {
			statusMap.put(USEREXIST, CommonConstant.FALSE);
			statusMap.put(CommonConstant.CONFLICTSTATUS, CommonConstant.FALSE);
			statusMap.put(CommonConstant.MESSAGE2, "email doesnt exist");
		}
	}

	/**
	 * M27
	 */
	private boolean findUserHaveConflictwithProfileRole(String profileUpdatingRole, boolean profileRoleConflictStatus,
			List<UserAccount> newUserAccountList, String addOrEdit) {
		boolean isOfficeStaff = false;
		isOfficeStaff = checkUserIsOfficeStaff(isOfficeStaff, profileUpdatingRole);
		if (profileUpdatingRole.equals("20") && addOrEdit.equalsIgnoreCase("add")) {
			profileRoleConflictStatus = false;
		} else {
			for (UserAccount ua : newUserAccountList) {
				String newUsergroup = ua.getUserGroup().getUserGroupId().toString();
				profileRoleConflictStatus = newUsergroup.equals(profileUpdatingRole);
				if (isOfficeStaff && (newUsergroup.equals("17") || newUsergroup.equals("9"))) {
					profileRoleConflictStatus = true;
					break;
				}
			}
		}
		return profileRoleConflictStatus;
	}

	/**
	 * M28
	 */
	private void setConflictStatusIfUserExistInSystem(Map<String, String> statusMap,
			boolean profileRoleConflictStatus) {
		if (profileRoleConflictStatus) {
			statusMap.put(USEREXIST, "true");
			statusMap.put(CommonConstant.CONFLICTSTATUS, "true");
			statusMap.put(CommonConstant.MESSAGE2, "old usergroup is conflict with new user's usergroup");
		} else {
			statusMap.put(USEREXIST, "true");
			statusMap.put(CommonConstant.CONFLICTSTATUS, CommonConstant.FALSE);
			statusMap.put(CommonConstant.MESSAGE2, USERMSG);
		}
	}

	/**
	 * M29
	 */
	private void checkUserGroupConflict(Map<String, String> statusMap, boolean isConflictWithOtherGroup,
			List<UserAccount> newUaList, List<UserAccount> oldUaList) {
		if (oldUaList != null && !oldUaList.isEmpty()) {
			isConflictWithOtherGroup = checknewUserConflictWithOldUserMultiRole(newUaList, isConflictWithOtherGroup,
					oldUaList);
			setConflictStatusIfUserExistInSystem(statusMap, isConflictWithOtherGroup);
		} else {
			statusMap.put(CommonConstant.CONFLICTSTATUS, CommonConstant.FAILURE);
			statusMap.put(CommonConstant.MESSAGE2, "old user detail not available");
		}
	}

	/**
	 * M30
	 */
	private boolean checknewUserConflictWithOldUserMultiRole(List<UserAccount> newUaList,
			boolean isConflictWithOtherGroup, List<UserAccount> oldUaList) {
		boolean isOldUserOfficeStaff = false;
		for (UserAccount newUserAcct : newUaList) {
			String newgroup = newUserAcct.getUserGroup().getUserGroupId().toString();
			boolean isNewOfficeStaff = checkUserIsOfficeStaff(isOldUserOfficeStaff, newgroup);

			isConflictWithOtherGroup = CheckNewUserConflictWithOtherGroup(oldUaList, isOldUserOfficeStaff,
					isConflictWithOtherGroup, newgroup, newUserAcct, isNewOfficeStaff);
			if (isConflictWithOtherGroup)
				break;
		}
		return isConflictWithOtherGroup;
	}

	/**
	 * M31
	 */
	private boolean checkUserIsOfficeStaff(boolean isOfficeStaff, String oldGroup) {
		if (oldGroup.equals("9") || oldGroup.equals("17"))
			isOfficeStaff = true;
		return isOfficeStaff;
	}

	/**
	 * M32
	 */
	private boolean CheckNewUserConflictWithOtherGroup(List<UserAccount> oldUaList, boolean isOldOfficeStaff,
			boolean isConflictWithOtherGroup, String newGroup, UserAccount newUserAcct, boolean isNewOfficeStaff) {
		try {
			boolean isCpAddFlag = false;
			for (UserAccount oldUserAcct : oldUaList) {
				String oldgroup = oldUserAcct.getUserGroup().getUserGroupId().toString();
				isOldOfficeStaff = checkUserIsOfficeStaff(isOldOfficeStaff, oldgroup);
				boolean isMultiRoleCondition = findIfChecknewUserConflictWithOldUserMultiRole(isOldOfficeStaff,
						isNewOfficeStaff, newGroup, oldgroup);
				if (isMultiRoleCondition) {
					isConflictWithOtherGroup = true;
				}
				if (oldgroup.equals("20")) {
					isCpAddFlag = isCPExistForSamePatient(newUserAcct, oldUserAcct, isCpAddFlag);
					if (isCpAddFlag) {
						isConflictWithOtherGroup = true;
					}
				}
				if (isConflictWithOtherGroup)
					break;
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return isConflictWithOtherGroup;
	}

	/**
	 * M33
	 */
	private boolean findIfChecknewUserConflictWithOldUserMultiRole(boolean isOldOfficeStaff, boolean isNewOfficeStaff,
			String newGroup, String oldGroup) {
		return ((isOldOfficeStaff && isNewOfficeStaff) || (newGroup.equals(oldGroup)));
	}

	/**
	 * M34
	 */
	private boolean isCPExistForSamePatient(UserAccount newUserAcct, UserAccount oldUserAcct, boolean cpAddFlag) {
		try {
			List<CarePartnerMap> cpmList = carePartnerMapRepo
					.findByActiveTrueAndUserAccount_UserAccountId(oldUserAcct.getUserAccountId());
			cpAddFlag = cpmList.stream()
					.anyMatch(a -> a.getPatient().getPatientId().equals(newUserAcct.getUserAccountKey()));
		} catch (Exception e) {
			LOGGER.error("Error in isCPExistForSamePatient : ", e);
			cpAddFlag = false;
		}
		return cpAddFlag;
	}

	



	/**
	 * M66
	 */
	@Override
	public ResponseMessage checkPatient(Date dob, Long patientId, Long mappingId) {
		ResponseMessage response = new ResponseMessage();
		boolean result = false;
		try {
			result = checkPatient(dob, patientId);
			if (result) {
				carePartnerMapRepo.updateCarePartnerVerified(mappingId);
				response.setStatus(CommonConstant.SUCCESS);

			} else {
				response.setStatus(CommonConstant.FAILURE);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			response.setStatus(CommonConstant.FAILURE);
		}
		return response;
	}

	/**
	 * M67
	 */
	private boolean checkPatient(Date dob, Long patientId) {
		try {
			List<Patient> patientList = patientRepo.findByPatientIdAndDob(patientId, dob);
			return patientList != null && !patientList.isEmpty();
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return false;
	}

	/**
	 * M68
	 */
	@Override
	public List<CarePartnerMap> getActiveCarePartnerMapbyCpUseraccount(Long userAccountId) {
		List<CarePartnerMap> cpmm = new ArrayList<CarePartnerMap>();
		try {

			UserAccount user = userRepo.findByUserAccountIdAndUserGroupUserGroupId(userAccountId, 20l);
			List<PatientStageWorkflow> patSWF = patientSWFRepo.findAll();
			List<Long> patientIds = patSWF.stream().filter(pat -> pat.getPatient() != null)
					.map(pat -> pat.getPatient().getPatientId()).collect(Collectors.toList());
			cpmm = carePartnerMapRepo.findByActiveAndUserAccount_UserAccountIdAndPatientIdIn(true,
					user.getUserAccountId(), patientIds);

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return cpmm;
	}

	@Override
	public UserExistsResponse getUserExists(UserExistsReqData request, UserExistsResponse response) {
		try {
			Map<String, String> statusMap = new HashMap<>();
			boolean isOldEmailEqualNewEmail = request.getNewEmail().equals(request.getOldEmail());
			
			boolean isOldPhoneEqualsNewPhone = request.getOldPhone() != null &&  request.getNewPhone().equals(request.getOldPhone());
			List<UserAccount> newList = new ArrayList<>();
			List<UserAccount> oldList = new ArrayList<>();
			String emailConflictStatus = "";
			String phoneConflictStatus = "";

			if (userNameCheck(request.getNewEmail(), request.getNewPhone(), isOldEmailEqualNewEmail,
					isOldPhoneEqualsNewPhone)) {
				response.setStatus(CommonConstant.SUCCESS);
				response.setPopUpStatus(CommonConstant.FALSE);
				response.setMessage("Both users are same or userName is empty");
			} else {

				if (!request.getNewEmail().isEmpty() && !isOldEmailEqualNewEmail) {

					newList = userRepo.findByEmail(request.getNewEmail());

					oldList = !request.getOldEmail().isBlank() ? userRepo.findByEmail(request.getOldEmail())
							: Collections.emptyList();

					statusMap = checkUserExist(request.getOldEmail(), request.getNewEmail(),
							request.getUpdatingProfileRole(), request.getAddOrEdit(), oldList, newList);

					emailConflictStatus = ConflictStatus(response, statusMap, emailConflictStatus,
							request.getNewEmail());
				}

				if (!request.getNewPhone().isEmpty() && !isOldPhoneEqualsNewPhone) {

					newList = userRepo.findByphoneWithTeleCode(request.getNewPhone());

					oldList = !request.getOldPhone().isBlank() ? userRepo.findByphoneWithTeleCode(request.getOldPhone())
							: Collections.emptyList();

					statusMap = checkUserExist(request.getOldPhone(), request.getNewPhone(),
							request.getUpdatingProfileRole(), request.getAddOrEdit(), oldList, newList);

					phoneConflictStatus = ConflictStatus(response, statusMap, phoneConflictStatus,
							request.getNewPhone());
				}

//				response = phoneConflictStatus.equalsIgnoreCase(CommonConstant.True)||emailConflictStatus.equalsIgnoreCase(CommonConstant.True)
//			                ? response

			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	private String ConflictStatus(UserExistsResponse response, Map<String, String> userExistsMap,
			String userConflictStatus, String newEmailOrPhone) {
		if (userExistsMap != null && !userExistsMap.isEmpty()) {
			userConflictStatus = userExistsMap.get("conflictStatus");
			checkUserIsExist(response, userExistsMap, userConflictStatus, newEmailOrPhone);
		}
		return userConflictStatus;

	}

	private void checkUserIsExist(UserExistsResponse response, Map<String, String> userExistsMap,
			String userConflictStatus, String newEmailOrPhone) {
		if (userConflictStatus.equalsIgnoreCase(CommonConstant.True)) {
			response.setStatus(CommonConstant.FAILURE);
			response.setPopUpStatus(CommonConstant.FALSE);
			response.setMessage("User Already Exist");
		} else if (userConflictStatus.equalsIgnoreCase(CommonConstant.FALSE)) {
			String userExistWithoutConflict = userExistsMap.get("userExistInSystem");
			OtherRoleUserData(response, userConflictStatus, newEmailOrPhone, userExistWithoutConflict);
		} else {
			response.setStatus(CommonConstant.FAILURE);
			response.setPopUpStatus(CommonConstant.FALSE);
			response.setMessage("User not able to validate. Error occured.");

		}

	}

	private void OtherRoleUserData(UserExistsResponse response, String userConflictStatus, String newEmailOrPhone,
			String userExistWithoutConflict) {
		if (userExistWithoutConflict.equals("true")) {
			UserAccount ua = userConflictStatus.equals(CommonConstant.FALSE)
					? userService.validateUserNew(newEmailOrPhone).stream().findFirst().orElse(null)
					: null;
			if (ua != null) {
				response.setPopUpStatus(CommonConstant.True);
				modelMap.map(ua, response);
				response.setGroupName(ua.getUserGroup().getGroupName());
				response.setOtherPhoneType(
						ua.getOtherPhoneType() != null ? ua.getOtherPhoneType().getPhoneTypeDesc() : "");
				response.setMessage("User Exist without Conflict");
				response.setStatus(CommonConstant.SUCCESS);

			} else {
				response.setStatus(CommonConstant.SUCCESS);
				response.setPopUpStatus(CommonConstant.FALSE);
				response.setMessage("Not able to fetch the Details of User");
			}
		} else {
			response.setStatus(CommonConstant.SUCCESS);
			response.setPopUpStatus(CommonConstant.FALSE);
			response.setMessage("New User");
		}

	}

	public boolean userNameCheck(String newEmail, String newPhone, boolean isOldEmailEqualNewEmail,
			boolean isOldPhoneEqualsNewPhone) {
		return (newEmail.isBlank() && newPhone.isBlank()) || (isOldEmailEqualNewEmail && isOldPhoneEqualsNewPhone);
	}

	public Map<String, String> checkUserExist(String oldEmail, String newEmail, Long profileUpdatingRole,
			String addOrEdit, List<UserAccount> oldEmailList, List<UserAccount> newEmailList) {
		Map<String, String> statusMap = new HashMap<>();
		Boolean profileRoleConflictStatus = false;
		if (!newEmail.isEmpty()) {

			if (newEmailList != null && !newEmailList.isEmpty() && !oldEmail.isBlank()) {

				profileRoleConflictStatus = newEmailList.stream().map(new1 -> {
					return checkOldEmail(new1, oldEmailList);
				}).anyMatch(a -> a);

				setConflictStatusIfUserExistInSystem(statusMap, profileRoleConflictStatus);

			} else {

				if (newEmailList != null && !newEmailList.isEmpty()) {
					boolean isStaffUser = profileUpdatingRole.equals(17L) || profileUpdatingRole.equals(9L) ? true
							: false;

					if (profileUpdatingRole.equals(20L) && addOrEdit.equalsIgnoreCase("add")) {
						profileRoleConflictStatus = false;
					} else {
						profileRoleConflictStatus = !newEmailList.stream().filter(ua -> {

							boolean profileRoleConflict = ua.getUserGroupId().compareTo(profileUpdatingRole) == 0;

							if (isStaffUser && (ua.getUserGroupId().compareTo(17L) == 0
									|| ua.getUserGroupId().compareTo(9L) == 0)) {
								return true;
							}

							return profileRoleConflict;
						}).collect(Collectors.toList()).isEmpty();

					}

					setConflictStatusIfUserExistInSystem(statusMap, profileRoleConflictStatus);

				} else {
					statusMap.put(USEREXIST, CommonConstant.FALSE);
					statusMap.put(CommonConstant.CONFLICTSTATUS, CommonConstant.FALSE);
					statusMap.put(CommonConstant.MESSAGE2, "email doesnt exist");
				}

			}

		}

		return statusMap;

	}

	private Boolean checkOldEmail(UserAccount newUa, List<UserAccount> oldEmailList) {

		Long newGroup = newUa.getUserGroupId();
		boolean isStaffUser = newGroup.equals(17L) || newGroup.equals(9L) ? true : false;
		Boolean data = oldEmailList.stream().map(old -> {
			return IterateOldEmail(old, newGroup, isStaffUser, newUa);
		}).anyMatch(a -> a);

		return data;
	}

	private Boolean IterateOldEmail(UserAccount oldUa, Long newGroup, boolean isStaffUser, UserAccount newUa) {

		Long oldGroup = oldUa.getUserGroupId();
		boolean isStaffUserOld = oldGroup.equals(17L) || oldGroup.equals(9L) ? true : false;

		boolean conflictCheck = (isStaffUserOld && isStaffUser) || newGroup.equals(oldGroup) ? true : false;

//		if (oldGroup.equals(20L)) {
//			conflictCheck = isCPExistForSamePatient(newUa, oldUa, false);
//		}

		return conflictCheck;
	}



}