package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class DeviceInformationData {
	
	private String handshakeKey;
	private String deviceType;

}
