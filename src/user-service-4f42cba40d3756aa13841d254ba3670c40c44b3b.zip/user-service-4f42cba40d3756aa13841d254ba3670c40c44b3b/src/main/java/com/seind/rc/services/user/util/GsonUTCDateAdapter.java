package com.seind.rc.services.user.util;

import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

public class GsonUTCDateAdapter implements JsonDeserializer<Date> {

	private static final Logger logger=LogManager.getLogger(GsonUTCDateAdapter.class);

	@Override
	public Date deserialize(JsonElement element, Type arg1, JsonDeserializationContext arg2) throws JsonParseException {
		String date = element.getAsString();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		try {
			return formatter.parse(date);
		} catch (ParseException e) {
			logger.error("Error Occurred in Deserialize : ",e);
			return null;
		}
	}
}
