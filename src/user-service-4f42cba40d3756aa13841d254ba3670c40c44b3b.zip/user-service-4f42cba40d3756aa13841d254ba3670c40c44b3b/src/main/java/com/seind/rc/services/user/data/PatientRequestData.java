package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PatientRequestData {
	
	private Long patientId;
	private Long carePartnerId;

}
