package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PracticeOverlapViewData {

	
	private Long careUserUaId;
	
	private String careUserName;
	
	private String careUserUgName;
	
	private Long careUserUgId;
	
	private String clientName;
	
	private String userGroupName;
	
	private Long loginUaId; 
	
	private boolean isSelectedPracticeOverlap;
	
	private Long overlapSelectedPracticeId;
	
	private Long nonOverlapSelectedSosId;
	
	private Long userAccountId;
	
	private String firstName;
	
	private String lastName;
	
	private Long userGroupId;
	
	private String groupName;
	
	private Integer isCareNavigator;
	
	private String name;
	
	private Long userAccountKey;
	
	private Long hospitalId;
}
