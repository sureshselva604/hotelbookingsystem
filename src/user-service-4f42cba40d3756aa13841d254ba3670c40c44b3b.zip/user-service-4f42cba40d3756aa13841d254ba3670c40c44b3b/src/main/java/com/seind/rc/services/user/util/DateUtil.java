package com.seind.rc.services.user.util;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.CommonConstant.DateFormatRC;

public class DateUtil {
	
	private DateUtil() {
	}

	private static final Logger logger_Du = LogManager.getLogger(DateUtil.class);
	public static final long SECOND_MILLIS_DU = 1000;
	public static final long MINUTE_MILLIS_DU = SECOND_MILLIS_DU * 60;
	public static final long HOUR_MILLIS_DU = MINUTE_MILLIS_DU * 60;
	public static final long DAY_MILLIS_DU = HOUR_MILLIS_DU * 24;
	public static final long YEAR_MILLIS_DU = DAY_MILLIS_DU * 365;

	
	
	protected static final String[] month = { "January", "February", "March", "April", "May", "June", "July", "August",
			"September", "October", "November", "December" };

	
	public static java.sql.Timestamp newTimestamp() {
		return new java.sql.Timestamp(System.currentTimeMillis());
	}

	
	public static int secondsDiff(Date earlyDate, Date ltrDate) {
		if (earlyDate == null || ltrDate == null)
			return 0;

		return (int) ((ltrDate.getTime() / SECOND_MILLIS_DU) - (earlyDate.getTime() / SECOND_MILLIS_DU));
	}

	
	public static int minutesDiff(Date earlyDate, Date ltrDate) {
		if (earlyDate == null || ltrDate == null)
			return 0;

		return (int) ((ltrDate.getTime() / MINUTE_MILLIS_DU) - (earlyDate.getTime() / MINUTE_MILLIS_DU));
	}

	
	public static int hoursDiff(Date earlyDate, Date ltrDate) {
		if (earlyDate == null || ltrDate == null)
			return 0;

		return (int) ((ltrDate.getTime() / HOUR_MILLIS_DU) - (earlyDate.getTime() / HOUR_MILLIS_DU));
	}

	
	public static int daysDiff(Date earlyDate, Date ltrDate) {
		SimpleDateFormat sdf = new SimpleDateFormat(DateFormatRC.MM_DD_YYYY);
		try {
			earlyDate = sdf.parse(sdf.format(earlyDate));
		} catch (ParseException e) {

			logger_Du.error(CommonConstant.EXCEPTION, e);
		}
		try {
			ltrDate = sdf.parse(sdf.format(ltrDate));
		} catch (ParseException e) {

			logger_Du.error(CommonConstant.EXCEPTION, e);
		}
		if (earlyDate == null || ltrDate == null)
			return 0;

		return (int) ((ltrDate.getTime() / DAY_MILLIS_DU) - (earlyDate.getTime() / DAY_MILLIS_DU));
	}


}

