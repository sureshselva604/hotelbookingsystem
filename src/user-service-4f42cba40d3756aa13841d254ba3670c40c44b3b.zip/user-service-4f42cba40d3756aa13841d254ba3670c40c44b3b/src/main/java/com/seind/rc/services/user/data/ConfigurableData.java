package com.seind.rc.services.user.data;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ConfigurableData {

	private Long loginUaHspOrPracId;
	private Long serviceLineId;
	private Integer admissionId;
}
