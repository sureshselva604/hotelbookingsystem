package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class MenuConfigData {
	private Integer menuId;
	private String name;
	private String refName;
	private Boolean status;
}
