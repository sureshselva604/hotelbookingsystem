package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class PatientStageWorkflowDownloadData {

	private Long patientSWFId;
	private Long patientId;
	private Long hspCCId;
	private Date dos;
}
