package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "RK_UserAccount")
public class RKUserAccount {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userAccountId;
	private String userName;
	private String userPwd;
	private String firstName;
	private String lastName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zipcode;
	private String country;
	private String email;
	private String title;
	private String phone;
	private String imagePath;
	private boolean active;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserGroupId")
	private UserGroup userGroup;

	private Long userAccountKey;
	private Boolean deIdFlag;
	private Date createdDate;
	private Long createdBy;
	private Date lastModifiedDate;
	private Long lastModifiedBy;
	private Boolean isdelete;
	private Long notificationId;
	private String description;
	private String comType;
	private Date dob;
	//private String confirmPwd;
//	private String newpwd;
//	private String subaccoundId;
	private String gender;
	private String bloodGroup;
	private Long whoseCarePartner;
	private String randomId;
	private int welcomeFlag;
	private String randId;
	private Long profileResultDetailId;
	private Integer wrongPwdAttempt;
	private Date userPwdCreatedOn;
	private String teleCode;
	private String teleCountryCode;
	private boolean isOnBoardLinkSent;
	private Date onBoardLinkSentOn;
		
	private String cCNotification;
	private Boolean primaryUser;
	private Integer reenroll;
	private Integer menuconfig;
	private Boolean latest;
	@Temporal(TemporalType.TIMESTAMP)
	private Date archiveDate;
	private Boolean todoPrivilege;
	private Long rcOnBoardId;
	private Long patientId;
	private Boolean careFamilyShow;
	private Boolean realTimeMessage;
	private Boolean realTimeAlert;
	private Boolean demoSite;
	private Boolean strykerAct;
	private Boolean allowOnboard;
	private String userTitle;
	@Temporal(TemporalType.TIMESTAMP)
	private Date pHIAckDate;
	private String otherPhone;
	private String otherTeleCode;
	private String OtherTeleCountryCode;
	private Long OtherPhoneType;
	private Boolean tempPasswordActive;
	@Temporal(TemporalType.TIMESTAMP)
	private Date passwordResetSentOn;
	private String activationMode;
	@Temporal(TemporalType.TIMESTAMP)
	private Date activationDate;
	private String userActivationStatus;
	private Boolean hopcoAct;
	private Integer pushNotification;
	private Boolean credResetRequired;
	@Temporal(TemporalType.TIMESTAMP)
	private Date lockedDate;
}
