package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HospitalContactData {
	
	private Long hospitalContactid;
	private Long hospitalId;
	private String contacttext;
	private String deviceContacttext;

}
