package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.DeviceVersion;

public interface DeviceVersionRepository extends JpaRepository<DeviceVersion, Long>{

	DeviceVersion findFirstByAppmodeOrderByVersionIdDesc(String mode);
	List<DeviceVersion> findByAppmodeOrderByVersionIdDesc(String mode);
}
