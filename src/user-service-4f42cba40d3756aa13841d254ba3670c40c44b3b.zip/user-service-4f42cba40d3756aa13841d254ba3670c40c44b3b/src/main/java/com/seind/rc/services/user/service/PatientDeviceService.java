package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.LoginRoles;
import com.seind.rc.services.user.data.PatientDeviceRequest;
import com.seind.rc.services.user.data.PatientDeviceResponse;
import com.seind.rc.services.user.data.PatientFlagResponseData;
import com.seind.rc.services.user.data.PatientStatusData;
import com.seind.rc.services.user.data.PatientStatusDeviceData;
import com.seind.rc.services.user.data.StatusResponse;
import com.seind.rc.services.user.entities.PatientDevice;


public interface PatientDeviceService {

	PatientDevice findByHandShakeKey(String handshakeKey);

	PatientStatusData getPatientStatusDetails(Long patientId);

	PatientDeviceResponse patientOrCarepartnerCheckStatus(PatientDeviceRequest reqData);

	List<LoginRoles> activeBodyPartListforCarePartner(PatientDeviceRequest reqData);

	StatusResponse validateOtpDev(PatientDeviceRequest reqData);

	PatientFlagResponseData getEmailorPhExistsFlagByPatient(PatientStatusDeviceData patientData);


}
