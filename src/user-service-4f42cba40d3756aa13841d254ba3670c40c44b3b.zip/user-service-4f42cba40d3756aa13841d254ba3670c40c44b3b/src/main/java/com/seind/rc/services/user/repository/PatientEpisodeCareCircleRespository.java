package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.seind.rc.services.user.entities.PatientEpisodeCareCircle;

@Repository
public interface PatientEpisodeCareCircleRespository extends JpaRepository<PatientEpisodeCareCircle, Long> {

	List<PatientEpisodeCareCircle> findByPatient_PatientId(Long patientId);

	List<PatientEpisodeCareCircle> findByPatientStageWorkflow_PatientSWFIdAndUserAccount_UserGroup_GroupNameIn(
			Long patientSWFId, List<String> groupNmae);

	List<PatientEpisodeCareCircle> findByPatientStageWorkflow_PatientSWFIdAndEpisodeIdAndUserAccount_CareFamilyShowTrueAndUserAccount_UserGroup_UserGroupIdNotIn(
			Long patientSWFId, Long episodeId, List<Long> userGroupIds);

}
