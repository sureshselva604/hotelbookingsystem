package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PasswordHistory;

import jakarta.transaction.Transactional;

@Transactional
public interface PasswordHistoryRepository extends JpaRepository<PasswordHistory, Long> {

	List<PasswordHistory> findTop5ByUserAccount_UserAccountIdOrderByPwdIdDesc(Long userAccountId);

	void deleteByUserAccount_UserAccountIdAndPwdIdNotIn(Long userAccountId, List<Long> pwdId);

}
