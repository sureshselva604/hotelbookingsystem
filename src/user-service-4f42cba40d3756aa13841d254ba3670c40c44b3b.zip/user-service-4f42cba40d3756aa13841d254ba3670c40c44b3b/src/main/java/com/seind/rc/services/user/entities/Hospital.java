package com.seind.rc.services.user.entities;

import java.util.Date;

import org.hibernate.annotations.Formula;

import com.seind.rc.services.user.util.RCUserUtil;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "Hospital")
public class Hospital {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HospitalId", unique = true, nullable = false)
	private Long hospitalId;
	private Long hospitalGroupId;
	private String code;
	private String name;
	private String description;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String country;
	private String zipcode;
	private String phone;
	private String email;
	private Boolean active;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CreatedBy")
	private UserAccount createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date lastModifiedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LastModifiedBy")
	private UserAccount lastModifiedBy;

	private Date deactivatedDate;
	private Long deactivatedBy;
	private Boolean deIdFlag;
	private Boolean isDelete;
	private String backdropImage;// BackDropImage
	private String logo;
	private String mode;
	private String procedureType;
	private Boolean directClient;
	private Boolean availSecurity;
	private String triggerComType;
	private Integer contacttype;
	private Boolean commercialType;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CountryCodeId")
	private CountryCode CountryCode;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ZoneId")
	private TimeZone timeZone;

	private Boolean allowPatNotification;
	private Boolean badgeEnabled;
	private Integer pRO_ClientId;
	private Integer admissionId;
	private Boolean isAppmntOpted;
	private String clientManager;
	private String clientExcecutive;
	private Boolean emailAlias;
	private String clientCategory;
	private Boolean customWorkflow;
	private Boolean bulletinRequired;
	private String clientTypeLabel;
	private Boolean coachEnabled;
	private Boolean cnDropDown;
	private Long clientTypeMasterId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "clientTypeMasterId", updatable = false, insertable = false)
	private ClientTypeMaster clientTypeMaster;
	private Boolean hopcoClient;
	private String shortState;
	private String hospitalCCN;
	private String hRO_id;
	private Long oBClientPKId;
	private Long oBSOSPKId;
	private Integer superClientIdPk;

	@Formula("(select ctm.ClientType from ClientTypeMaster ctm where ctm.ClientTypeMasterId = ClientTypeMasterId)")
	private String clientType;

	public void getCity(String hspCity) {
		RCUserUtil.getStringNullOrEmpty(hspCity);
	}

	public void getState(String hspState) {
		RCUserUtil.getStringNullOrEmpty(hspState);
	}

	public void getZipcode(String hspZipcode) {
		RCUserUtil.getStringNullOrEmpty(hspZipcode);
	}

	public void getCountry(String hspCountry) {
		RCUserUtil.getStringNullOrEmpty(hspCountry);
	}

}
