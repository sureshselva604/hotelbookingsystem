package com.seind.rc.services.user.service.servicesimp;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.ClientDashboardData;
import com.seind.rc.services.user.data.GraphData;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {
	
	private static final Logger LOGGER = LogManager.getLogger(AdminServiceImpl.class);

	@Autowired
	private UserAccountRepository userRepo;
	
	@Autowired
	private PatientRepository patientRepo;
	
	@Autowired
	private HospitalSurgeonRepository hspSugRepo;
	
	
	@Override
	public ClientDashboardData clientDashboardData(Long hospitalId) {
		try {
	        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM");
			List<Long> cnList = userRepo.findByUserAccountKey(hospitalId).stream()
					            .map(UserAccount::getUserAccountId).toList();
			List<Patient> paList = patientRepo.findByCreatedByIn(cnList);
			List<GraphData> graphData =paList.stream()
					.collect(Collectors.groupingBy(record -> monthFormat.format(record.getCreatedDate()),
							Collectors.counting()))
					.entrySet().stream().map(entry -> new GraphData(entry.getKey(), entry.getValue()))
					.toList();
			List<Long> surgeonIds = hspSugRepo.findByHospitalId(hospitalId).stream()
					               .map(HospitalSurgeon::getSurgeon).map(Surgeon::getSurgeonId).toList();
			int sugList =  userRepo.countByUserAccountKeyIn(surgeonIds);
			return ClientDashboardData.builder().patientCount(paList.size()).userCount(sugList+cnList.size())
					                        .graphData(graphData).hospitalId(hospitalId).build();		                            
		}
		catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
			return ClientDashboardData.builder().build();
		}
	}

	@Override
	public ClientDashboardData getDashBoardCount() {
		try {
			int userCount= userRepo.countByActiveTrue();
			int patientCount=(int)patientRepo.count();
			return ClientDashboardData.builder().userCount(userCount).patientCount(patientCount).build();
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
			return ClientDashboardData.builder().build();
		}
	}
}
