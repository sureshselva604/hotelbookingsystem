package com.seind.rc.services.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "OverlapViewOnDemand")
@Data
public class OverlapViewOnDemand {
	@Id
	private Long Id;
	private Long patientSwfId;
	private Long uaCcHspOrPracId;
	private Long uaSecCcHspOrPracId;
	private Long hospitalPracticeId;
	private Long hspSugId;
	private Long servicelineId;
	private Long payorType;
	private String procedureType;

}
