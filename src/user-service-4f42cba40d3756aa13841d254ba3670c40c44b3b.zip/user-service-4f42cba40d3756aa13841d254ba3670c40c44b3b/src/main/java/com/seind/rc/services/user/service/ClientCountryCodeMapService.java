package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.CountryCodeMapData;
import com.seind.rc.services.user.entities.ClientCountryCodeMap;

public interface ClientCountryCodeMapService {
	
	ClientCountryCodeMap getClientCountryCodeMapById(Long clientCountryCodeMapId);
	
	List<CountryCodeMapData> fetchCountryCodeByHspOrPracId(Long hospitalId);

}
