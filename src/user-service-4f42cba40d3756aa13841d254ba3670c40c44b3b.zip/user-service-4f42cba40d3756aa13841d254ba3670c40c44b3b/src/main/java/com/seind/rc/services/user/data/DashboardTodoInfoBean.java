package com.seind.rc.services.user.data;

import java.util.Map;

import lombok.Data;

@Data
public class DashboardTodoInfoBean {

	private String bpci;
	private Boolean pswExcludeMyTodo;
	private String payorType;
	private String clientType;
	private Boolean pswExcludeCareCards;
	private Boolean isRevision;
	private Long hospitalId;
	private Long zoneId;
	private Long countryCodeId;
	private String countryCodeIdStr;
	private Integer admissionId;
	private Long patientSwfId;
	private String startDateRange;
	private String endDateRange;
	private Long loginUaId;
	private Long selectedCnUaId;
	private Long loginHspOrPracId;
	private String pracOrHsp;
	private String todoViewMode;
	private Long stageWorkFlowId;
	private Map<String, Long> hhaSurveyMap;
	private Map<String, Integer> surveyRelateMap;

}