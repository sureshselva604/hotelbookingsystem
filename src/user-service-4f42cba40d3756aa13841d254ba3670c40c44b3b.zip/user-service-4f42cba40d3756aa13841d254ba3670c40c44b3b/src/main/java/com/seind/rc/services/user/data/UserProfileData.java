package com.seind.rc.services.user.data;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserProfileData {

	private String firstName;
	private String lastName;
	private String userName;
	private String imagePath;
	private String phone;
	private String teleCode;
	private String teleCountryCode;	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date dob;
	private String comType;
	private String email;
	private String notificationFrequency;
	private boolean realTimeMessage;
	private boolean realTimeAlert;
	@Default
	private String title = "";
	@Default
	private String otherPhone = "";
	@Default
	private String otherTeleCode = "";
	@Default
	private String otherTeleCountryCode = "";
	@Default
	private String otherPhoneType = "";
	private boolean pushNotification;	
	@Default
	private String relationship = "";
	@Default
	private String groupName = "";
	private Long userAccountId;
	private Boolean onBehalf;
	@Default
	private String gender = "";
	@JsonAlias("isEmailValid")
	private boolean isEmailValid;
	@JsonAlias("isPhoneValid")
	private boolean isPhoneValid;

}