package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PatientDetails {
	
	private String cpFirstName;
	private String cpLastName;
	private String cpImagePath;
	private String cpRelationship;
	private String cpGroupName;
	private Long cpUserAccountId;
	private boolean cpActive;
	private String cpTelecode;
	private String cpTeleCountryCode;
	private String cpPhone;
	private String cpEmail;
	private boolean pswIsActive;
	private Long patientId;

}
