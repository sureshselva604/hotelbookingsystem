package com.seind.rc.services.user.service;

public interface UserSecCodeAuditService {

	void resetUserSecCodeAudit(Long userAccountId);

}
