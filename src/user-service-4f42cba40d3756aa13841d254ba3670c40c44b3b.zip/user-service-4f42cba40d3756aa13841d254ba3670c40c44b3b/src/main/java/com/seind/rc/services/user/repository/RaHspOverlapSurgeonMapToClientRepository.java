package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.RaHspOverlapSurgeonMapToClient;

public interface RaHspOverlapSurgeonMapToClientRepository extends  JpaRepository<RaHspOverlapSurgeonMapToClient, Long> {

	List<RaHspOverlapSurgeonMapToClient> findByHpHospitalId(Long hpHospitalId);
}
