package com.seind.rc.services.user.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;



public class ZipFileUtil {
	
	public static boolean extratZipfile(File source, String destination, String pwd) {
		boolean extractStatus = false;

		try {
			ZipFile zipFile = new ZipFile(source);
			if (!pwd.isEmpty() || zipFile.isEncrypted()) {
				zipFile.setPassword(pwd);
			}
			zipFile.extractAll(destination + "");
			extractStatus = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return extractStatus;
	}
	

	public static File createZipFile(File folderPath, String password) throws IOException , net.lingala.zip4j.exception.ZipException{
		String zipFilePath = folderPath + "/" + folderPath.getName() + ".zip";
		File file = new File(zipFilePath);
		if (file.exists()) {
			Files.deleteIfExists(Paths.get(zipFilePath));
		}
		try {
			zipFilePath = folderPath + "/" + folderPath.getName() + ".zip";
			ZipFile zipFile = new ZipFile(zipFilePath);
			ZipParameters parameters = new ZipParameters();
			parameters.setIncludeRootFolder(true);
			parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); 
			parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
			parameters.setEncryptFiles(true);
			parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD);
			parameters.setAesKeyStrength(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
			parameters.setPassword(password);
			zipFile.createZipFileFromFolder(folderPath,parameters,true,4294967296L);
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return new File(zipFilePath);
	}

}
