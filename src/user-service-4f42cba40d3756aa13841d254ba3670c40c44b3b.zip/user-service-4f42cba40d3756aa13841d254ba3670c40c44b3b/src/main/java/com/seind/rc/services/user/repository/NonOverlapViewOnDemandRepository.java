package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.NonOverlapViewOnDemand;

public interface NonOverlapViewOnDemandRepository  extends JpaRepository< NonOverlapViewOnDemand, Long> {

	NonOverlapViewOnDemand findByPatientSwfId(Long patientSWFId);

}
