package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.seind.rc.services.user.data.HospitalOverlapSurgeonsData;
import com.seind.rc.services.user.entities.Surgeon;


public interface SurgeonRepository extends JpaRepository<Surgeon, Long> {

	List<Surgeon> findBySurgeonIdIn(List<Long> userAccountKey);

	Surgeon findBySurgeonIdAndActive(Long surgeonId, boolean active);
	

	@Query(value = " select NEW com.seind.rc.services.user.data.HospitalOverlapSurgeonsData(hs.surgeon.surgeonId,ua.userAccountId,s.firstName,s.lastName,s.salutation,h.name as oLPracName,h.name as oLHspName, "
			+ " 0 as isOverLap,0 as practiceId,h.hospitalId) from  HospitalSurgeon hs "
			+ " join Surgeon s  on s.surgeonId = hs.surgeon.surgeonId "
			+ " join  UserAccount ua on ua.userAccountKey = hs.surgeon.surgeonId "
			+ " join HospitalNavigatorSugMapping hsnm on hsnm.surgeonId = hs.surgeon.surgeonId "
			+ " join HNSurgMapToClient hnsc on hnsc.hNSurgMapId = hsnm.hnsugMappingid "
			+ " join Hospital h on h.hospitalId = hnsc.hospitalId where hs.hospitalId = :hsHospitalId "
			+ " and hs.surgeon.surgeonId not in (" + " select distinct hs2.surgeon.surgeonId from HospitalSurgeon hs2 "
			+ " join HospitalPractice hp on hp.practiceId= hs2.hospitalId and hp.isOverLap=true "
			+ " where hp.hospitalId = :hpHospitalId )")
	List<HospitalOverlapSurgeonsData> getRaHospitalOverlapSurgeonsFour(@Param("hsHospitalId") Long hsHospitalId,
			@Param("hpHospitalId") Long hpHospitalId);



}
