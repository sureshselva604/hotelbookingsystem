package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class BiographyQuestions {
	
	private Long profileResultDetailId;
	private Long userAccountId;
	private String questionId;
	private String answers;
	private String randomId;

}
