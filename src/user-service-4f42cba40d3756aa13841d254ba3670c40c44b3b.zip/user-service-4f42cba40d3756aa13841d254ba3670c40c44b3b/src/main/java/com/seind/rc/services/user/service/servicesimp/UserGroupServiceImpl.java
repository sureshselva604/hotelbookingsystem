package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.UserDetails;
import com.seind.rc.services.user.data.UserGroupPrivilegeData;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.MenuConfiguration;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.entities.UserGroupPrivilege;
import com.seind.rc.services.user.entities.UserPrivilege;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.MenuConfigurationRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserGroupPrivilegeRepository;
import com.seind.rc.services.user.repository.UserGroupRepository;
import com.seind.rc.services.user.repository.UserPrivilegeRepository;
import com.seind.rc.services.user.service.UserGroupService;

@Service
public class UserGroupServiceImpl implements UserGroupService {

	private static final Logger LOGGER = LogManager.getLogger(UserGroupServiceImpl.class);

	@Autowired
	private UserGroupRepository userGroupRepo;

	@Autowired
	private MenuConfigurationRepository menuConfigRepo;

	@Autowired
	private UserPrivilegeRepository userPrivilegeRepo;

	@Autowired
	private UserGroupPrivilegeRepository userGroupPrivilegeRepo;

	@Autowired
	private UserAccountRepository userAccRepo;

	@Autowired
	private HospitalRepository hspRepo;

	/**
	 * M01
	 * 
	 * Find List of UserGroup Expect 30 and 31 based on Client MenuConfiguration
	 * 30->Hospital Patient Enroller 31->Practice Patient Enroller
	 */
	@Override
	public List<UserGroup> findAllUserGroup(Long clientId) {
		List<UserGroup> userGroup = null;
		try {
			MenuConfiguration mg = menuConfigRepo.findByMenuMenuIdAndHospitalHospitalId(18L, clientId)
					                .stream().findFirst().orElse(null);
			userGroup = userGroupRepo.findAll();
			for (UserGroup usGrp : userGroup) {
				if (usGrp.getUserGroupId() == 30 || usGrp.getUserGroupId() == 31) {
					if (Boolean.FALSE.equals(mg.getStatus())) {
						userGroup.remove(usGrp);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userGroup;
	}

	/**
	 * M02
	 * 
	 * Fetch UserPrivilegeData By UserAccountId
	 */
	@Override
	public List<UserGroupPrivilegeData> getUserPrivilegeByUserId(Long userId) {
		List<UserGroupPrivilegeData> privilegeList = new ArrayList<UserGroupPrivilegeData>();
		List<UserPrivilege> privilegeGroup = userPrivilegeRepo.findByUserId(userId);
		for (UserPrivilege a : privilegeGroup) {
			UserGroupPrivilegeData u = new UserGroupPrivilegeData();
			u.setMenuId(a.getMenu().getMenuId());
			u.setSequenceNo(a.getMenu().getSequenceNo());
			u.setName(a.getMenu().getName());
			u.setRefName(a.getMenu().getRefName());
			u.setStatus(a.getStatus());
			u.setIsView(a.getIsView());
			u.setIsEdit(a.getIsEdit());
			privilegeList.add(u);
		}
		privilegeList = privilegeList.stream().sorted(Comparator.comparingLong(UserGroupPrivilegeData::getSequenceNo))
				.collect(Collectors.toList());
		return privilegeList;
	}

	/**
	 * M03
	 * 
	 * Fetch UserGroupPrivilegeData By UserGroupId
	 */
	@Override
	public List<UserGroupPrivilegeData> getUserGroupPrivelegeByGroupId(Long userGroupId) {
		List<UserGroupPrivilegeData> privilegeList = new ArrayList<UserGroupPrivilegeData>();
		List<UserGroupPrivilege> privilegeGroup = userGroupPrivilegeRepo.findByUserGroup_UserGroupId(userGroupId);
		for (UserGroupPrivilege a : privilegeGroup) {
			UserGroupPrivilegeData u = new UserGroupPrivilegeData();
			u.setMenuId(a.getMenu().getMenuId());
			u.setSequenceNo(a.getMenu().getSequenceNo());
			u.setName(a.getMenu().getName());
			u.setRefName(a.getMenu().getRefName());
			u.setStatus(a.getStatus());
			u.setIsView(a.getIsView());
			u.setIsEdit(a.getIsEdit());
			privilegeList.add(u);
		}
		privilegeList = privilegeList.stream().sorted(Comparator.comparingLong(UserGroupPrivilegeData::getSequenceNo))
				.collect(Collectors.toList());
		return privilegeList;
	}

	/**
	 * M04
	 * 
	 * Get UserDetails By UserGroupId
	 */
	@Override
	public List<UserDetails> getUsersByUserGroupId(Long userGroupId) {
		List<UserDetails> response = new ArrayList<>();
		try {
			List<UserAccount> userList = userAccRepo.findByUserGroup_UserGroupId(userGroupId);
			for (UserAccount userAcc : userList) {
				UserDetails data = new UserDetails();
				data.setFirstName(userAcc.getFirstName());
				data.setLastName(userAcc.getLastName());
				data.setActive(userAcc.getActive());
				data.setUserName(userAcc.getUserName());
				data.setPhone(userAcc.getPhone());
				data.setCity(userAcc.getCity());
				data.setAddress1(userAcc.getAddress1());
				data.setAddress2(userAcc.getAddress2());
				data.setState(userAcc.getState());
				data.setCreatedDate(userAcc.getCreatedDate());
				data.setUserAccountId(userAcc.getUserAccountId());
				data.setImagePath(userAcc.getImagePath());
				data.setWrongPwdAttempt(userAcc.getWrongPwdAttempt());
				data.setWelcomeFlag(userAcc.getWelcomeFlag());
				data.setDob(userAcc.getDob());
				data.setUserPwd(userAcc.getUserPwd());
				data.setClientName(userAcc.getUserGroup().getGroupName());
				if (!UserGroupCons.userAdminShow.contains(userGroupId)) {
					Hospital client = hspRepo.findById(userAcc.getUserAccountKey()).get();
					data.setClientName(client.getName());
					data.setClientImagePath(client.getLogo());
				}
				response.add(data);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

}
