package com.seind.rc.services.user.controller;

import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.data.HospitalPracticeData;
import com.seind.rc.services.user.data.HospitalRequestData;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.service.HospitalService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

/**
 * C02
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/hospital")
@RequiredArgsConstructor
public class HospitalController {

	private static final Logger LOGGER = LogManager.getLogger(HospitalController.class);

	@Autowired
	private HospitalService hospitalService;

//	@Autowired
//	private UserAccountService userAccountService;

	/**
	 * Get HospitalId for any UserAccountId Based on FirstTime Sync in Device
	 */
//	@PostMapping(value = "/getHospitalForAnyUserAccountId")
//	public Long getHospitalForAnyUserAccountId(@RequestBody CommonObjectData objData) {
//		UserAccount userAccount = null;
//		Long hospitalId = null;
//		try {
//			userAccount = userAccountService.getUserAccountByUserAccountKey(objData.getUserAccountId());
//			hospitalId = hospitalService.getHospitalIdForAnyUserAccount(userAccount).getHospitalId();
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return hospitalId;
//	}

	/**
	 * Get Hospital Data for Patient FirstTime Sync in Device
	 */
//	@PostMapping(value = "/getHopsitalInfoByCNId")
//	public HospitalDeviceData getHopsitalInfoByCNId(@RequestBody UserRequestData objData) {
//		HospitalDeviceData hsp = null;
//		try {
//			hsp = hospitalService.getHopsitalInfoByCNId(objData.getUserAccountKey());
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return hsp;
//	}

	/**
	 * Get Hospital List By Mode
	 */
	@Operation(summary = "Get Hospital List By Mode")
	@PostMapping(value = "/hospitalListSub")
	public List<Hospital> getHospitalByMode(@RequestBody HospitalRequestData data) {
		List<Hospital> response = null;
		try {
			response = hospitalService.getHospitalByMode(data.getMode(), data.getSuperClientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Retrieves a list of hospital IDs based on the hospital type and a given
	 * hospital ID.
	 *
	 * @param hospitalId The unique identifier for the hospital.
	 * @return ResponseEntity with a list of hospital IDs.
	 */
	@Operation(summary = "Get Hospital List By Type")
	@GetMapping(value = "/getHospitalByType/{hospitalId}")
	public List<Long> getHospitalByType(@PathVariable Long hospitalId) {
		try {
			return hospitalService.getHospitalByType(hospitalId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return Collections.emptyList();
		}
	}

	@Operation(summary = "Get Hospital Practice List By Type")
	@GetMapping(value = "/getHospitalPracticeByType/{hospitalId}")
	public List<HospitalPracticeData> getHospitalPracticeByType(@PathVariable Long hospitalId) {
		try {
			return hospitalService.getHospitalPracticeByType(hospitalId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return Collections.emptyList();
		}
	}

}
