package com.seind.rc.services.user.service;

import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.ResponseMessageSSO;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.entities.UserAccount;

public interface SSOService {

	ResponseMessageSSO checkUserExists(SsoSyncData ssoSyncData);

	ResponseMessageSSO resetFailureAttemptStatus(SsoSyncData ssoSyncData);

	ResponseMessageSSO updateRCFailureAttemptStatus(SsoSyncData ssoSyncData);

	ResponseMessage updateSecurityQues(SsoSyncData ssoSyncData);

	SsoSyncData getUserInfo(SsoSyncData ssoSyncData, Long userId);

	ResponseMessage updateProfile(SsoSyncData ssoSyncData);

	ResponseMessage updateSecurityQuesAttempts(SsoSyncData ssoSyncData);

	ResponseMessage accountLock(SsoSyncData ssoSyncData);

	ResponseMessage updatePassword(SsoSyncData ssoSyncData);

	ResponseMessage updateCSRPwd(SsoSyncData ssoSyncData);

	ResponseMessage updateActivationFromSSO(SsoSyncData ssoSyncData);

	ResponseMessage updateInvalidSecCodeAudit(SsoSyncData ssoSyncData);

	ResponseMessage secCodeReset(SsoSyncData ssoSyncData);

	ResponseMessage unlockAccount(SsoSyncData ssoSyncData);

	ResponseMessage captchaAudit(SsoSyncData ssoSyncData);

	void resetFailureAttemptStatus(String userName);

	void updateFailureAttemptStatus(Long rcAccountId, int wrongAttempt);

	void updateSecQues(Long rcUserId, Long quesId1, Long quesId2, Long quesId3, String ans1, String ans2, String ans3);

	void updateProfile(UserAccount userAcct, String firstName, String lastName, String phone, String teleCode,
			String countryCode);

	void disableAuditActive(UserAccount userAcct, String mode);

	void insertUserSecCodeAudit(UserAccount userAccount, String teleCode, String title);

	void resetUserSecCodeAudit(UserAccount user);

	boolean checkRCUserExists(String userName);

	UserAccount getSSOUserAccountByUserName(String userName);

}