package com.seind.rc.services.user.service.servicesimp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.PatientService;

@Service
public class PatientServiceImpl implements PatientService {

	private static final Logger LOGGER = LogManager.getLogger(PatientServiceImpl.class);

	@Autowired
	private PatientRepository patientRepo;


	@Autowired
	private PatientStageWorkflowRepository pswfRepo;

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;

	@Autowired
	private UserAccountRepository userRepo;


	@Override
	public int activeBodypart(Long patientId) {
		int ct = 0;
		try {
			long count = pswfRepo.countByPswIsActiveAndPatient_PatientId(true, patientId);
			if (count != 0) {
				ct = (int) count;
			}
		} catch (Exception e) {
			ct = 0;
		}
		return ct;
	}

	@Override
	public int activePatientBodypartforCP(Long userAccountId) {
		try {
			Long count = carePartnerMapRepo.findByActiveTrueAndUserAccount_UserAccountId(userAccountId).stream().filter(
					a -> pswfRepo.findByPatient_PatientId(a.getPatientId()).stream().anyMatch(b -> b.getPswIsActive()))
					.count();
			return count.intValue();
		} catch (Exception e) {
			return 0;
		}
	}

//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	@Override
//	public UserAccount getPatientUserAccountByPatientswfId(Long patientswfId) { 
//		String sql = new StringBuilder(
//				"select ua.* from UserAccount ua,PatientStageWorkflow pswf where ua.UserAccountKey=pswf.patientid ")
//						.append(" and ua.Usergroupid=19 and pswf.patientswfid= ").append(patientswfId).toString();
//		NativeQuery query = getSession().createSQLQuery(sql);
//		query.addEntity(UserAccount.class);
//		List<UserAccount> uaList = query.list();
//		if (!uaList.isEmpty()) {
//			return uaList.get(0);
//		} else {
//			return null;
//		}
//	}

	@Override
	public UserAccount getPatientUserAccountByPatientSWFId(Long patientswfId) {
		UserAccount userAccount = null;
		try {
			PatientStageWorkflow pwsId = pswfRepo.findById(patientswfId).orElse(null);
			if (pwsId != null) {
				userAccount = userRepo
						.findByUserAccountKeyAndUserGroup_UserGroupId(pwsId.getPatient().getPatientId(), 19L)
						.orElse(null);
			} else {
				return null;
			}
		} catch (Exception e) {
			LOGGER.info(e.getMessage());
		}
		return userAccount;
	}

	@Override
	public UserAccount getUserAccountDetailsByPatientIdAndUserGroupId(Long patientId) {
		UserAccount userAccount = null;
		try {
			Patient patient = patientRepo.findById(patientId).orElse(null);
			if (patient != null) {
				userAccount = userRepo.findByUserAccountKeyAndUserGroup_UserGroupId(patient.getPatientId(), 19L)
						.orElse(null);
			} else {
				return null;
			}
		} catch (Exception e) {
			LOGGER.info(e.getMessage());
		}
		return userAccount;
	}

}
