package com.seind.rc.services.user.util;

import java.io.File;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.seind.rc.services.user.constants.CommonConstant;

public class RestCloudService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RestCloudService.class);
	private ResourceBundle rs = ResourceBundle.getBundle("application");
	private static final String BUCKET_NAME="bucketname";
	private String bucketname = rs.getString(BUCKET_NAME);

	
	AmazonS3Client s3Client = null;

	public void cloudConnection() {		
		s3Client = RCUserUtil.getS3Client();
	}		

	
	public void filePathbyFolder(String resultDataFilePath, String imagPath) {
		String imgName = imagPath.substring(imagPath.lastIndexOf('/'), imagPath.length());
		String damPath = imagPath.replace(imgName, "");
		LOGGER.debug("resultDataFilePath+imagPath:: {}", resultDataFilePath);
		LOGGER.debug("Name:: {}", imgName);
		LOGGER.debug("DamPath: {}", damPath);
		
		File surveyDataPathPathFile = new File(resultDataFilePath);
		if (!surveyDataPathPathFile.isDirectory()) {
			surveyDataPathPathFile.mkdirs();
		}
		cloudConnection();
		fileUpload(surveyDataPathPathFile.getAbsolutePath() + imgName, damPath, imgName);
	}
	
	
	public void fileUpload(String filePath, String imagePath, String fileObjKeyName) {
		try {
			String keyName = imagePath;
			if (imagePath.startsWith("/"))
				keyName = imagePath.replaceFirst("/", "");

			String objectKeyName = keyName + fileObjKeyName;

			PutObjectRequest s3Put = new PutObjectRequest(bucketname, objectKeyName, new File(filePath))
					.withCannedAcl(CannedAccessControlList.PublicReadWrite);
			ObjectMetadata objectMetaData = new ObjectMetadata();
			objectMetaData.setContentType("plain/text");
			objectMetaData.addUserMetadata("x-amz-meta-title", "someTitle");
			s3Put.setMetadata(objectMetaData);
			s3Client.putObject(s3Put);
			LOGGER.debug(" File upload  Completed");
			
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

}
