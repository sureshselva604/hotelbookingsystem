package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class HospitalOverlapSurgeonsData {

	private Long surgeonId;
	
	private Long userAccountId;
	
	private String firstName;
	
	private String  lastName;
	
	private String salutation;
	
	private String oLPracName;
		
	private String oLHspName;
	
	private Boolean isOverLap;
	
	private Boolean practiceId;
	
	private Long hospitalId	;
	
}
