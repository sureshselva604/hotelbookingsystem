package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WelcomeInfoData {
	private String patientName;
	private String patientFirstName;
	private String patientLastName;
	private String clientLogoPath;
	private Long userAccountId;
	private Long userGroupId;
	private String email;
	private String teleCode;
	private String phone;
	private String dateFormat;
	private String onbehalfName;
	private String status;
	private String message;
}
