package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.HospitalListDeviceData;
import com.seind.rc.services.user.data.HospitalPracticeApptInfo;
import com.seind.rc.services.user.data.HospitalPracticeData;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.HospitalPractice;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.PracticeCoordinatorHSPMapping;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.entities.UserGroupHspPracMap;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.HospitalPracticeRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.PracticeCoordinatorHSPMappingRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserGroupHspPracMapRepository;
import com.seind.rc.services.user.repository.UserGroupRepository;
import com.seind.rc.services.user.service.HospitalService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class HospitalServiceImpl implements HospitalService {

	private static final Logger LOGGER = LogManager.getLogger(HospitalServiceImpl.class);

	@Autowired
	private HospitalRepository hospitalRepo;

	@Autowired
	private UserAccountRepository userAccountRepo;

	@Autowired
	private HospitalSurgeonRepository hspSugRepo;

	@Autowired
	private HospitalPracticeRepository hospitalPracticeRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private UserGroupRepository userGroupRepository;

	@Autowired
	private PracticeCoordinatorHSPMappingRepository PCHSPMappingRepo;

	@Autowired
	private PatientRepository patientRepository;

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;

	@Autowired
	private PatientStageWorkflowRepository pswfRepository;

	@Autowired
	private UserGroupHspPracMapRepository userGrpHspPracMap;

	/**
	 * M01
	 * 
	 * Fetch Hospilal Data using hospitalId
	 */
	@Override
	public Hospital getHospitalById(Long hospitalId) {
		Optional<Hospital> hsp = null;
		try {
			hsp = hospitalRepo.findById(hospitalId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hsp.isPresent() ? hsp.get() : null;
	}

	/**
	 * M02
	 * 
	 * Find DateFormat for a Hospital in CountryCode Table
	 */
	@Override
	public String getDateFormatForHospital(Long hospitalId) {
		Hospital hosp = new Hospital();
		try {
			hosp = hospitalRepo.findById(hospitalId).orElse(null);
			return hosp.getCountryCode().getDateFormat();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return "MMDDYYYY";
		}

	}

	/**
	 * M03
	 * 
	 * Find Hospidal Data By Surgeon UserAccountId
	 */
	@Override
	public Hospital getHospitalBySurgeonUserAccountId(Long userAccountId) {
		Optional<Hospital> hsp = null;
		try {
			Long UserAccountKey = userAccountRepo.findById(userAccountId).get().getUserAccountKey();
			LOGGER.info("Key.." + UserAccountKey);
			Long hospitalId = hspSugRepo.findDistinctBySurgeon_SurgeonIdOrderByHospitalSurgeonIdDesc(UserAccountKey)
					.get(0).getHospitalId();
			hsp = hospitalRepo.findById(hospitalId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return hsp.isPresent() ? hsp.get() : null;
	}

	/**
	 * M04
	 * 
	 * Find HospitalId Based on User Condition (19,20,18) 19->PatientGroupId
	 * 20->CarePartnerGroupId 18->SurgeonGroupId
	 */
	@Override
	public Hospital getHospitalIdForAnyUserAccount(UserAccount userAccount) {
		Long hospitalId = null;
		if (userAccount.getUserGroup().getUserGroupId() == 19L) {
			hospitalId = getHospitalIdByPatientUseraccountId(userAccount.getUserAccountKey());
		} else if (userAccount.getUserGroup().getUserGroupId() == 20L) {
			hospitalId = getHospitalIdByPatientCarePartnerUseraccountId(userAccount);
		} else if (userAccount.getUserGroup().getUserGroupId() == 18L) {
			hospitalId = getHospitalBySurgeonUserAccountId(userAccount.getUserAccountId()).getHospitalId();
		} else {
			hospitalId = userAccount.getUserAccountKey();
		}
		Hospital hospital = hospitalRepo.findById(hospitalId).orElse(null);
		return hospital;
	}

	/**
	 * M05
	 * 
	 * Find HospitalId Using Patient UseraccountId
	 */
	public Long getHospitalIdByPatientUseraccountId(Long patientId) {
		PatientStageWorkflow patSwf = null;
		Long hospitalId = 0L;
		try {
			patSwf = pswfRepository.findByPatient_PatientIdOrderByPatientSWFIdDesc(patientId).stream().findFirst()
					.orElse(null);
			hospitalId = patSwf.getCCUserAccount().getUserAccountKey();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return hospitalId;
	}

	/**
	 * M06
	 * 
	 * Find HospitalId Using Patient/Carepartner UseraccountId
	 */
	public Long getHospitalIdByPatientCarePartnerUseraccountId(UserAccount useracc) {
		PatientStageWorkflow patSwf = null;
		Long hospitalId = 0L;
		try {
			if (useracc.getUserGroup().getUserGroupId().equals(UserGroupCons.CARE_PARTNER)) {
				List<CarePartnerMap> cpmList = carePartnerMapRepo
						.findByActiveIsTrueAndUserAccount_userAccountIdAndUserAccount_UserGroup_UserGroupId(
								useracc.getUserAccountId(), UserGroupCons.CARE_PARTNER);
				if (!cpmList.isEmpty()) {
					CarePartnerMap cpm = cpmList.get(0);
					patSwf = pswfRepository.findByPatient_PatientIdOrderByPatientSWFIdDesc(cpm.getPatientId()).stream()
							.findFirst().orElse(null);
					hospitalId = patSwf.getCCUserAccount().getUserAccountKey();
				} else {

					patSwf = pswfRepository
							.findByPatient_PatientIdOrderByPatientSWFIdDesc(useracc.getWhoseCarePartner()).stream()
							.findFirst().orElse(null);
					hospitalId = patSwf.getCCUserAccount().getUserAccountKey();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return hospitalId;
	}

	/**
	 * M07
	 * 
	 * Get Hospital list by mode H/P H-Hospital P-Practice
	 */
	@Override
	public List<Hospital> getHospitalByMode(String mode, int superClientId) {
		List<Hospital> response = null;
		try {
			if (mode.equalsIgnoreCase("all"))
				response = hospitalRepo.findByDirectClient(true);
			else
				response = hospitalRepo.findByModeAndDirectClientAndSuperClientIdPk(mode, true, superClientId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M08
	 */
//	@Override
//	public HospitalDeviceData getHopsitalInfoByCNId(Long cnAccountId) {
//		UserAccount userAccount = null;
//		HospitalDeviceData hospitalData = null;
//		try {
//			userAccount = userAccountService.getUserAccountByUserAccountId(cnAccountId);
//			Long userAccountkey = userAccount.getUserAccountKey();
//			Hospital hospital = getHospitalById(userAccountkey);
//			modelMapper.getConfiguration().setAmbiguityIgnored(true);
//			hospitalData = modelMapper.map(hospital, HospitalDeviceData.class);
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return hospitalData;
//	}

	/**
	 * M09
	 * 
	 * Retrieves a list of hospital IDs based on the hospital type and a given
	 * hospital ID.
	 *
	 * @param hospitalId The unique identifier for the hospital.
	 * @return ResponseEntity with a list of hospital IDs.
	 */
	@Override
	public List<Long> getHospitalByType(Long hospitalId) {
		try {
			List<Long> hspList = new ArrayList<>();
			Optional<Hospital> hospitalOpt = hospitalRepo.findById(hospitalId);
			if (hospitalOpt.isPresent()) {
				Hospital hospital = hospitalOpt.get();
				if (hospital.getMode().equalsIgnoreCase("H")) {
					List<HospitalPractice> hospitalSosList = hospitalPracticeRepo.findByHospitalId(hospitalId);
					hspList = hospitalSosList.stream().map(HospitalPractice::getSecHospitalId)
							.collect(Collectors.toList());
				} else {
					List<HospitalPractice> practiceSosList = hospitalPracticeRepo.findByPracticeId(hospitalId);
					hspList.add(hospitalId);
					hspList.addAll(
							practiceSosList.stream().map(HospitalPractice::getHospitalId).collect(Collectors.toList()));
				}
			}
			return hspList;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	/**
	 * M10
	 */
	@Override
	public List<HospitalPracticeData> getHospitalPracticeByType(Long hospitalId) {
		try {
			Optional<Hospital> hospitalOpt = hospitalRepo.findById(hospitalId);
			List<HospitalPracticeData> hospitalPracticeDataList = new ArrayList<>();
			if (hospitalOpt.isPresent()) {
				Hospital hospital = hospitalOpt.get();
				if (hospital.getMode().equalsIgnoreCase("H")) {
					List<HospitalPractice> hospitalSosList = hospitalPracticeRepo.findByHospitalId(hospitalId);
					hospitalPracticeDataList = hospitalSosList.stream().filter(a -> !a.getIsOverLap()).map(a -> {
						HospitalPracticeData data = modelMapper.map(a, HospitalPracticeData.class);
						data.setHospitalId(a.getSecHospitalId());
						return data;
					}).map(a -> {
						Hospital sos = hospitalRepo.findById(a.getHospitalId()).orElse(null);
						a.setName(sos.getName());
						a.setAdmissionId(sos.getAdmissionId());
						a.setDirectClient(sos.getDirectClient());
						return a;
					}).collect(Collectors.toList());
				} else {
					List<HospitalPractice> practiceSosList = hospitalPracticeRepo.findByPracticeId(hospitalId);
					hospitalPracticeDataList = practiceSosList.stream().map(a -> {
						HospitalPracticeData data = modelMapper.map(a, HospitalPracticeData.class);
						data.setHospitalId(a.getIsOverLap() ? a.getSecHospitalId() : a.getHospitalId());
						return data;
					}).map(a -> {
						Hospital sos = hospitalRepo.findById(a.getHospitalId()).orElse(null);
						a.setName(sos.getName());
						a.setAdmissionId(sos.getAdmissionId());
						a.setDirectClient(sos.getDirectClient());
						return a;
					}).collect(Collectors.toList());
					Hospital practice = hospitalRepo.findById(hospitalId).orElse(null);
					HospitalPracticeData practiceData = modelMapper.map(practice, HospitalPracticeData.class);
					hospitalPracticeDataList.add(practiceData);
				}
			}
			return hospitalPracticeDataList;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	@Override
	public List<HospitalListDeviceData> getHospitalListInfoByPatientId(Long patientId) {
		List<HospitalListDeviceData> hospitalListDeviceDataList = new ArrayList<>();
		try {
			Patient patient = patientRepository.findById(patientId).orElse(null);

			UserGroup userGroup = userGroupRepository.findById(patient.getCreatedByUa().getUserGroup().getUserGroupId())
					.orElse(null);

			if (userGroup.getGroupType().equalsIgnoreCase("HOSPITAL")) {
				Hospital hospital = hospitalRepo.findById(patient.getCreatedByUa().getUserAccountKey()).orElse(null);
				HospitalListDeviceData hospitalListDeviceData = modelMapper.map(hospital, HospitalListDeviceData.class);
				hospitalListDeviceData.setPatientId(patientId);
				hospitalListDeviceDataList.add(hospitalListDeviceData);

			} else {

				List<Long> hospitalIds = getHositaIdsByLoginUser(patient.getCreatedByUa());
				hospitalListDeviceDataList = hospitalRepo.findByHospitalIdIn(hospitalIds).stream().map(a -> {

					HospitalListDeviceData data = modelMapper.map(a, HospitalListDeviceData.class);
					data.setPatientId(patientId);
					return data;

				}).toList();
			}

		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}

		return hospitalListDeviceDataList;
	}

	private List<Long> getHositaIdsByLoginUser(UserAccount loginUser) {
		try {
			Long userAccountKey = loginUser.getUserAccountKey();
			Hospital hospital = hospitalRepo.findById(userAccountKey).orElse(null);
			if (loginUser.getUserGroup().getUserGroupId().compareTo(32L) == 0) {
				return PCHSPMappingRepo.findByPcUserid(loginUser.getUserAccountId()).stream()
						.map(a -> a.getHospitalId()).collect(Collectors.toList());
			} else if (hospital.getMode().equalsIgnoreCase("H")) {
				List<HospitalPractice> hospitalList = hospitalPracticeRepo
						.findByHospitalIdAndActiveTrue(hospital.getHospitalId());
				return hospitalList.stream().filter(a -> !a.getIsOverLap()).map(a -> a.getSecHospitalId())
						.collect(Collectors.toList());

			} else {
				List<HospitalPractice> practiceList = hospitalPracticeRepo
						.findByPracticeIdAndActiveTrue(hospital.getHospitalId());
				return practiceList.stream().map(a -> a.getIsOverLap() ? a.getSecHospitalId() : a.getHospitalId())
						.collect(Collectors.toList());
			}

		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	@Override
	public Hospital fetchHospitalByHospitalIdAndClientType(Long hospitalId, String client) {
		try {
			Hospital Hospital = hospitalRepo.findByHospitalIdAndClientTypeMaster_ClientTypeLike(hospitalId, client);
			return Hospital;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	@Override
	public List<HospitalPracticeApptInfo> findHospitalByPractice(UserAccountData user) {
		List<HospitalPracticeApptInfo> hpApptInfos = new ArrayList<HospitalPracticeApptInfo>();
		try {
			Long userAccountKey = user.getUserAccountKey();
			Hospital hospital = hospitalRepo.findById(userAccountKey).orElse(null);
			if (user.getUserGroupId().compareTo(32L) == 0) {
				List<PracticeCoordinatorHSPMapping> pcHspMap = PCHSPMappingRepo.findByPcUserid(user.getUserAccountId())
						.stream().filter(a -> a.getHospitalId().equals(userAccountKey)).collect(Collectors.toList());
				for (PracticeCoordinatorHSPMapping pcmap : pcHspMap) {
					HospitalPractice hspp = pcmap.getHspPractice();
					HospitalPracticeApptInfo apptInfoList = getHspPracticeDataBuilder(hspp, user.getUserGroupId());
					hpApptInfos.add(apptInfoList);

				}
			} else if (user.getUserGroupId().compareTo(29L) == 0) {
				List<HospitalPractice> hospitalList = hospitalPracticeRepo
						.findByHospitalIdAndActiveTrue(hospital.getHospitalId());
				List<Long> hsppIds = hospitalList.stream().map(a -> a.getHospitalPracticeId())
						.collect(Collectors.toList());
				List<UserGroupHspPracMap> usergrp = userGrpHspPracMap.findByHospitalPracticeIdIn(hsppIds);// fin
				for (UserGroupHspPracMap ugMap : usergrp) {
					HospitalPractice hspp = ugMap.getHspPractice();
					HospitalPracticeApptInfo apptInfoList = getHspPracticeDataBuilder(hspp, user.getUserGroupId());
					hpApptInfos.add(apptInfoList);
				}
			} else {
				List<HospitalPractice> practiceList = hospitalPracticeRepo
						.findByPracticeIdAndActiveTrue(hospital.getHospitalId());
				practiceList.stream().filter(a -> (a.getIsOverLap() && a.getSecHospital() != null)
						|| (!a.getIsOverLap() && a.getHospital() != null)).collect(Collectors.toList());
				for (HospitalPractice hspp : practiceList) {
					HospitalPracticeApptInfo apptInfoList = getHspPracticeDataBuilder(hspp, user.getUserGroupId());
					hpApptInfos.add(apptInfoList);
				}
			}

		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return hpApptInfos;
	}

	private HospitalPracticeApptInfo getHspPracticeDataBuilder(HospitalPractice hspp, Long userGroupId) {
		List<Long> groupIds = Arrays.asList(29L, 32L);
		if (hspp != null && hspp.getHospital() != null) {
			return HospitalPracticeApptInfo.builder()
					.hospitalId(!hspp.getIsOverLap() && hspp.getHospital() != null && groupIds.contains(userGroupId)
							? hspp.getHospitalId()
							: hspp.getSecHospitalId())
					.admissionId(hspp.getHospital().getAdmissionId())
					.availSecurity(hspp.getHospital().getAvailSecurity()).clienttype(hspp.getHospital().getClientType())
					.code(hspp.getHospital().getCode()).directClient(hspp.getHospital().getDirectClient())
					.hospitalPracticeid(hspp.getHospitalPracticeId()).mode(hspp.getHospital().getMode())
					.name(hspp.getHospital().getName()).build();
		}
		return null;
	}

	private HospitalPracticeApptInfo getHspPracticeDataBuilder(HospitalPractice hspp) {
		if (hspp != null && hspp.getHospital() != null) {
			return HospitalPracticeApptInfo.builder().hospitalId(hspp.getSecHospitalId())
					.admissionId(hspp.getSecHospital().getAdmissionId())
					.availSecurity(hspp.getHospital().getAvailSecurity()).clienttype(hspp.getHospital().getClientType())
					.code(hspp.getSecHospital().getCode()).directClient(hspp.getSecHospital().getDirectClient())
					.hospitalPracticeid(hspp.getHospitalPracticeId()).mode(hspp.getSecHospital().getMode())
					.name(hspp.getHospital().getName()).build();
		}
		return null;
	}

	@Override
	public List<HospitalPracticeApptInfo> fetchMultiHosptialPracticeByHspId(Long userAccountKey) {
		List<HospitalPracticeApptInfo> hpApptInfos = new ArrayList<HospitalPracticeApptInfo>();
		try {
			Long practiceId = 100001l;
			List<HospitalPractice> hsppList = hospitalPracticeRepo.findByHospitalIdAndPracticeId(userAccountKey,
					practiceId);
			hsppList = hsppList.stream().filter(hp -> hp.getSecHospital() != null && hp.getHospital() != null
					&& hp.getHospital().getMode().equalsIgnoreCase("H")).collect(Collectors.toList());
			for (HospitalPractice hspp : hsppList) {
				HospitalPracticeApptInfo apptInfoList = getHspPracticeDataBuilder(hspp);
				hpApptInfos.add(apptInfoList);
			}

		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION ,e);
		}
		return hpApptInfos;
	}
}
