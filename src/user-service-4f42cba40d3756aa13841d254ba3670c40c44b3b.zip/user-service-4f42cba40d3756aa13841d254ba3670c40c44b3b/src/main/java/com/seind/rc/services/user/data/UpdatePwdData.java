package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class UpdatePwdData {

	private String randId;
	private String newPassword;
	private String encodedSecurityDict;
	private List<Long> WrongUserSecQuestionId;
	
}
