package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class HospitalNotifyData {

	private Long hospitalId;
	private String code;
	private String name;
	private String logo;
	private Boolean allowPatNotification = true;
	private String helpDeskNo;
	private String dateFormat;
	private String language;
	private Boolean emailAlias;
}
