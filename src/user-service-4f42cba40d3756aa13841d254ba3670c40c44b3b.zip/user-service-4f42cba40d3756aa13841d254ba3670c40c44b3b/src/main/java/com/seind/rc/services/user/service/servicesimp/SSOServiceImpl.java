package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CasCommonConstant;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.ResponseMessageSSO;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.entities.CaptchaAudit;
import com.seind.rc.services.user.entities.CountryCode;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.PasswordHistory;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecCodeAudit;
import com.seind.rc.services.user.entities.UserSecResultDetails;
import com.seind.rc.services.user.repository.CaptchaAuditRepository;
import com.seind.rc.services.user.repository.CountryCodeRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserSecCodeAuditRepository;
import com.seind.rc.services.user.repository.UserSecResDetRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.SSOService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecResDetService;
import com.seind.rc.services.user.service.UserSecTransAuditService;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.SSOSyncUtil;

@Service
public class SSOServiceImpl implements SSOService {

	private static final Logger LOGGER = LogManager.getLogger(SSOServiceImpl.class);

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private UserAccountRepository userAccountRepo;

	@Autowired
	private UserSecResDetService userSecResService;

	@Autowired
	private HospitalService hospitalService;

	@Autowired
	private HospitalRepository hspRepo;

	@Autowired
	private CountryCodeRepository countryCodeRepo;

	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepo;

	@Autowired
	private UserSecCodeAuditRepository userSecCodeAuditRepo;

	@Autowired
	private CaptchaAuditRepository captchaAuditRepo;

	@Autowired
	private UserSecTransAuditService userSecTransAuditService;
	
	@Autowired
	private UserSecResDetRepository userSecResDetRepo;

	/**
	 * M01
	 * 
	 * check if the user exists in userAccount by userName or email
	 */
	@Override
	public boolean checkRCUserExists(String userName) {
		boolean userExists = false;
		try {
			Optional<UserAccount> userAcct = userAccountRepo.findUserAccountIdByUserNameOrEmail(userName, userName);
			userExists = userAcct.isPresent() ? true : false;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userExists;
	}

	/**
	 * M02
	 * 
	 * Fetch ssoUserAccount by userName or email and userGroupId not in (19,20)
	 */
	@Override
	public UserAccount getSSOUserAccountByUserName(String userName) {
		try {
			Long grpId[] = { 19l, 20l };
			List<UserAccount> uaList = userAccountRepo.findByUserNameOrEmailAndUserGroup_UserGroupIdNotIn(userName,
					userName, grpId);
			if (uaList != null && !uaList.isEmpty()) {
				return uaList.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	/**
	 * M03
	 * 
	 * Fetch userAccountId by userName and email if exists
	 */
	@Override
	public ResponseMessageSSO checkUserExists(SsoSyncData ssoSyncData) {
		ResponseMessageSSO response = new ResponseMessageSSO();
		boolean status = false;
		Long userId = 0l;
		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled) && getAuthStatusByKey(ssoSyncData)) {
				String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
				UserAccount userAccount = userAccountService.getUserAccountByUserNameAndEmail(userName);
				if (userAccount != null) {
					status = true;
					userId = userAccount.getUserAccountId();
				}

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		response.setUserId(userId);
		response.setStatus(status);
		return response;
	}

	/**
	 * M04
	 * 
	 * Reset password failure attempts status in userAccoount
	 */
	@Override
	public ResponseMessageSSO resetFailureAttemptStatus(SsoSyncData ssoSyncData) {
		ResponseMessageSSO response = new ResponseMessageSSO();
		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				String userName = RCUserUtil.getNonEmptyString(ssoSyncData.getUserName());
				if (getAuthStatusByKey(ssoSyncData) && userName != null
						&& userAccountRepo.findUserAccountIdByUserNameOrEmail(userName, userName) != null ? true
								: false) {
					resetFailureAttemptStatus(userName);
					response.setStatus(true);
				}

			}
		} catch (Exception e) {
			response.setStatus(false);
			LOGGER.error(e.getMessage());
		}

		return response;
	}

	/**
	 * M05
	 * 
	 * Reset userAccount after password failure attempts
	 */
	@Override
	public void resetFailureAttemptStatus(String rcUserName) {
		try {
			List<UserAccount> userAccountList = userAccountRepo.findByEmail(rcUserName);
			userAccountList.stream().map(userAccount -> {
				userAccount.setWrongPwdAttempt(0);
				userAccountRepo.save(userAccount);
				return userAccount;
			});

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	/**
	 * M06
	 * 
	 * Update wrong password attempts in userAccount
	 */
	@Override
	public ResponseMessageSSO updateRCFailureAttemptStatus(SsoSyncData ssoSyncData) {
		ResponseMessageSSO response = new ResponseMessageSSO();
		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
				UserAccount userAccount = userAccountService.getUserAccountByUserNameAndEmail(userName);
				if (userAccount != null && getAuthStatusByKey(ssoSyncData)) {
					updateFailureAttemptStatus(userAccount.getUserAccountId(), ssoSyncData.getCount());
					response.setStatus(true);
				}
			}
		} catch (Exception e) {
			response.setStatus(false);
			LOGGER.error(e.getMessage());
		}
		return response;

	}

	/**
	 * M07
	 */
	@Override
	public void updateFailureAttemptStatus(Long rcAccountId, int wrongAttempt) {
		try {
			UserAccount userAccount = userAccountRepo.findById(rcAccountId).orElse(null);
			if(userAccount!=null) {
			userAccount.setWrongPwdAttempt(wrongAttempt);
			userAccountRepo.save(userAccount);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	/**
	 * M08
	 * 
	 * Update Sceurity Questions
	 */
	@Override
	public ResponseMessage updateSecurityQues(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
				UserAccount userAccount = userAccountRepo.findByUserName(userName).stream().findFirst().orElse(null);
				if (!userName.isEmpty() && userAccount != null && getAuthStatusByKey(ssoSyncData)) {
					updateSecQues(userAccount.getUserAccountId(), ssoSyncData.getQuesId1(), ssoSyncData.getQuesId2(),
							ssoSyncData.getQuesId3(), ssoSyncData.getAns1(), ssoSyncData.getAns2(),
							ssoSyncData.getAns3());
					response.setStatus(CommonConstant.SUCCESS);
				}
			} else {
				response.setStatus(CasCommonConstant.SSO_TURNED_OFF);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M09
	 * 
	 * SecretKey Check in Setting Value based on Category and Name
	 */
	private boolean getAuthStatusByKey(SsoSyncData ssoSyncData) {
		Boolean status = false;
		String actualKey = rcUserUtil.getSettingsValue(CommonConstant.SSOSYNC, CommonConstant.SSOSECKEY);
		String secretKey = ssoSyncData.getSecretKey();
		if (actualKey.equals(secretKey)) {
			status = true;
		}
		return status;
	}

	/**
	 * M10
	 * 
	 * Save Updated UserSecurity Questions
	 */
	@Override
	public void updateSecQues(Long rcUserId, Long quesId1, Long quesId2, Long quesId3, String ans1, String ans2,
			String ans3) {
		try {
			UserSecResultDetails userId = new UserSecResultDetails();
			userId.setUserAccountId(rcUserId);
			userId.setQuestion1(quesId1);
			userId.setQuestion2(quesId2);
			userId.setQuestion3(quesId3);
			userId.setAnswer1(ans1);
			userId.setAnswer2(ans2);
			userId.setAnswer3(ans3);
			userId.setAnswer3(ans3);
			userId.setCreatedOn(new Date());
			userId.setIrrelevantAns("No");
			userId.setWrongAnswerAttempts(0);
			userId.setMode("Web");
			Long user = userAccountService.getUserSecResultDetailsAlreadyExist(rcUserId);
			if (user > 0) {
				userAccountService.insertOrUpdateUserSecResultDetails(user, userId);
			} else {
				userAccountService.insertOrUpdateUserSecResultDetails(-1l, userId);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	/**
	 * M11
	 * 
	 * Get UserActivate,Password Created,Modified Date
	 */
	@Override
	public SsoSyncData getUserInfo(SsoSyncData ssoSyncData, Long userId) {
		Hospital hsp = null;
		SsoSyncData resultdata = new SsoSyncData();
		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				String userName = RCUserUtil.getNonEmptyString(ssoSyncData.getUserName());
				userName = RCUserUtil.rcDecrypt(userName);
				UserAccount userAccount = userAccountService.validateUserNew(userName).stream().findFirst()
						.orElse(null);
				if (userAccount != null && getAuthStatusByKey(ssoSyncData) && userName != null
						&& checkRCUserExists(userName)) {
					UserSecResultDetails usersecResultDetalils = userSecResService
							.getUserSecResultDetails(userAccount.getUserAccountId());
					if (usersecResultDetalils != null) {
						resultdata.setQuesId1(usersecResultDetalils.getQuestion1());
						resultdata.setQuesId2(usersecResultDetalils.getQuestion2());
						resultdata.setQuesId3(usersecResultDetalils.getQuestion3());
						resultdata.setAns1(usersecResultDetalils.getAnswer1());
						resultdata.setAns2(usersecResultDetalils.getAnswer2());
						resultdata.setAns3(usersecResultDetalils.getAnswer3());
					}
					if (userAccount.getUserGroup().getUserGroupId() != 18l) {
						hsp = hspRepo.findById(userAccount.getUserAccountKey()).orElse(null);
					}
					else {
						hsp = hospitalService.getHospitalBySurgeonUserAccountId(userAccount.getUserAccountId());
					resultdata.setRcHspName(hsp.getName());
					resultdata.setRcAccountId(userAccount.getUserAccountId());
					resultdata.setRcAccType(userAccount.getUserGroup().getGroupName());
					resultdata.setUserName(RCUserUtil.rcEncrypt(userName));
					resultdata.setUserPwd(userAccount.getUserPwd());
					resultdata.setUserPwdCreatedOn(userAccount.getUserPwdCreatedOn());
					resultdata.setActivatedDate(userAccount.getActivationDate());
					resultdata.setModifiedDate(userAccount.getLastModifiedDate());
					resultdata.setWelcomeFlag(userAccount.getWelcomeFlag() == true);
					}

				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
//		response.setActivatedDate(resultdata.getActivatedDate());
//		response.setModifiedDate(resultdata.getModifiedDate());
//		response.setUserPwdCreatedOn(resultdata.getUserPwdCreatedOn());
		return resultdata;
	}

	/**
	 * M12
	 * 
	 * Update Profile Based on UserName
	 */
	@Override
	public ResponseMessage updateProfile(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			String firstName = ssoSyncData.getFirstName();
			String lastName = ssoSyncData.getLastName();
			String phone = RCUserUtil.getNonEmptyString(ssoSyncData.getPhNum());
			String teleCode = RCUserUtil.getNonEmptyString(ssoSyncData.getTeleCode());
			UserAccount user = getSSOUserAccountByUserName(userName);
			List<CountryCode> cc = countryCodeRepo.findByTeleCode(ssoSyncData.getTeleCode());
			String countryCode = cc != null ? cc.get(0).getCountryCode() : "";
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				if (getAuthStatusByKey(ssoSyncData) && user != null) {
					updateProfile(user, firstName, lastName, phone, teleCode, countryCode);
					response.setStatus(CasCommonConstant.VALIDSTATUS);
					if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(user))) {
						userAccountService.contactPreValidation(user);
					}
				} else {
					response.setStatus(CasCommonConstant.INVALIDTOKEN);
				}
			} else {
				response.setStatus("SSO feature turned off");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M13
	 * 
	 * Save Updated Profile
	 */
	@Override
	public void updateProfile(UserAccount userAcct, String firstName, String lastName, String phone, String teleCode,
			String countryCode) {
		UserAccount userAccount = userAccountRepo.findById(userAcct.getUserAccountId()).orElse(null);
		if(userAccount!=null) {
		userAccount.setFirstName(firstName);
		userAccount.setLastName(lastName);
		userAccount.setPhone(phone);
		userAccount.setTeleCode(teleCode);
		userAccountRepo.save(userAccount);
		}
	}

	/**
	 * M14
	 * 
	 * Update Security Question Attempts on WrongPassword count
	 */
	@Override
	public ResponseMessage updateSecurityQuesAttempts(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			UserAccount user = getSSOUserAccountByUserName(userName);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				if (getAuthStatusByKey(ssoSyncData) && user != null) {
					userSecResDetRepo.updateSecurityQuesAttempts(user.getUserAccountId(),ssoSyncData.getCount());
					response.setStatus("failureSecQuesCount");
				} else {
					response.setStatus(CasCommonConstant.INVALIDTOKEN);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M16
	 * 
	 * Lock UserAccount Based on WrongPassword count
	 */
	@Override
	public ResponseMessage accountLock(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();

		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			UserAccount user = getSSOUserAccountByUserName(userName);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				if (getAuthStatusByKey(ssoSyncData) && user != null) {
					updateAccountLock(user);
					response.setStatus("Account was Locked");
				} else {
					response.setStatus(CasCommonConstant.INVALIDTOKEN);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M17
	 * 
	 * Change Active Status to False For Account Lock
	 */
	private void updateAccountLock(UserAccount userAcct) {
		UserAccount userAccount = userAccountRepo.findById(userAcct.getUserAccountId()).orElse(null);
		if(userAccount!=null) {
		userAccount.setActive(false);
		userAccount.setLastModifiedDate(new Date());
		userAccount.setLockedDate(new Date());
		userAccountRepo.save(userAccount);
		}
	}

	/**
	 * M18
	 * 
	 * Update Password
	 */
	@Override
	public ResponseMessage updatePassword(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();

		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			UserAccount user = getSSOUserAccountByUserName(userName);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				if (getAuthStatusByKey(ssoSyncData) && user != null) {
					updatePassword(user, ssoSyncData.getUserPwd());
					response.setStatus("Password updated successfully");

					PasswordHistory pwdHistory = new PasswordHistory();
					pwdHistory.setUserAccount(user);
					pwdHistory.setUserPwd(ssoSyncData.getUserPwd());
					pwdHistory.setCreatedDate(new Date());
					userSecTransAuditService.savePasswordHistory(pwdHistory);
					userSecResDetRepo.updateSecurityQuesAttempts(user.getUserAccountId(),0);
					updateFailureAttemptStatus(user.getUserAccountId(), 0);
				} else {
					response.setStatus(CasCommonConstant.INVALIDTOKEN);
				}
			} else {
				response.setStatus("SSO feature off");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M19
	 * 
	 * Save Updated Password
	 */
	private void updatePassword(UserAccount userAcct, String encPassword) {
		UserAccount userAccount = userAccountRepo.findById(userAcct.getUserAccountId()).orElse(null);
		if(userAccount!=null) {
		userAccount.setUserPwd(encPassword);
		userAccount.setActive(true);
		userAccount.setUserPwdCreatedOn(new Date());
		userAccount.setTempPasswordActive(false);
		userAccountRepo.save(userAccount);
		}
	}

	/**
	 * M20
	 * 
	 * Update CSR Password
	 */
	@Override
	public ResponseMessage updateCSRPwd(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();

		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			UserAccount user = getSSOUserAccountByUserName(userName);
			if (SSOSyncUtil.ssoStatus(ssoEnabled) && getAuthStatusByKey(ssoSyncData)) {
				if (user != null) {
					user.setActive(true);
					user.setUserPwd(ssoSyncData.getUserPwd());
					user.setWrongPwdAttempt(0);
					user.setUserPwdCreatedOn(new Date());
					user.setTempPasswordActive(true);
					userAccountRepo.save(user);
					response.setStatus(CommonConstant.SUCCESS);
				} else {
					response.setStatus(CasCommonConstant.USER_DOES_NOT_EXIST);
				}
			} else {
				response.setStatus(CasCommonConstant.SSO_TURNED_OFF);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M21
	 * 
	 * Update UserActivate From Other Portal
	 */
	@Override
	public ResponseMessage updateActivationFromSSO(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();

		try {
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			boolean welcomeFlag = ssoSyncData.isWelcomeFlag() ? true : false;
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
				UserAccount userAccount = userAccountService.validateUserNew(userName).stream().findFirst()
						.orElse(null);
				if (userAccount != null && getAuthStatusByKey(ssoSyncData) && userName != null
						&& checkRCUserExists(userName) && userAccount.getActive()) {
					updateSecQues(userAccount.getUserAccountId(), ssoSyncData.getQuesId1(), ssoSyncData.getQuesId2(),
							ssoSyncData.getQuesId3(), ssoSyncData.getAns1(), ssoSyncData.getAns2(),
							ssoSyncData.getAns3());
					userAccount.setWelcomeFlag(welcomeFlag);
					userAccount.setUserPwd(ssoSyncData.getUserPwd());
					userAccount.setUserPwdCreatedOn(new Date());
					userAccount.setActivationDate(new Date());
					userAccount.setActive(true);
					userAccount.setActivationMode(
							(ssoSyncData.getFromPortal() != null && !ssoSyncData.getFromPortal().isEmpty())
									? ssoSyncData.getFromPortal().substring(0, 2)
									: "");
					userAccount.setUserActivationStatus(welcomeFlag == false ? CasCommonConstant.COMPLETED : null);
					userAccountRepo.save(userAccount);
					disableAuditActive(userAccount, "AddUser");
					response.setStatus("Details updated Successfully");
				}
			} else {
				response.setStatus(CasCommonConstant.SSO_TURNED_OFF);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M22
	 * 
	 * Save UserTransAudit for AddUser
	 */
	@Override
	public void disableAuditActive(UserAccount userAcct, String mode) {
		int updatedRecord = userSecTransAuditRepo.userSecTransAuditActiveUpdate(userAcct.getUserAccountId(),
				new ArrayList<>(Arrays.asList(mode)));
		LOGGER.debug("Update Record..." + updatedRecord);
	}

	/**
	 * M23
	 * 
	 * Update UserSecTransAduit,Captcha Audit for invalid Otp Attempt
	 */
	@Override
	public ResponseMessage updateInvalidSecCodeAudit(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled)) {
				UserAccount user = getSSOUserAccountByUserName(userName);
				if (user != null) {
					insertUserSecCodeAudit(user, ssoSyncData.getTeleCode(), ssoSyncData.getTitle());
					int count = 0;
					count = Integer.parseInt(rcUserUtil.getSettingsValue("OTPValidation", "OTPAttempts"));
					otpAttemptCheck(response, ssoSyncData, user, count);
				} else {
					response.setStatus(CasCommonConstant.USER_DOES_NOT_EXIST);
				}
			} else {
				response.setStatus(CasCommonConstant.SSO_TURNED_OFF);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M24
	 */
	@Override
	public void insertUserSecCodeAudit(UserAccount userAccount, String teleCode, String title) {
		UserSecCodeAudit userSecCode = new UserSecCodeAudit();
		userSecCode.setUserAccount(userAccount);
		userSecCode.setSecCode(teleCode);
		userSecCode.setMode(title);
		userSecCode.setStatus(true);
		userSecCode.setCreatedDate(new Date());
		userSecCodeAuditRepo.save(userSecCode);
	}

	/**
	 * M25
	 */
	private void otpAttemptCheck(ResponseMessage response, SsoSyncData ssoSyncData, UserAccount user, int count) {
		if (ssoSyncData.getCount() == count) {
			updateAccountLock(user);
			try {
				resetUserSecCodeAudit(user);
				disableAuditActive(user, "AddUser");
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			response.setStatus("User Activation Not successfully");
			captchaLockBySSO(ssoSyncData, user);
		} else {
			response.setStatus("User Activation successfully");
		}
	}

	/**
	 * M26
	 */
	private void captchaLockBySSO(SsoSyncData ssoSyncData, UserAccount user) {
		try {
			if (ssoSyncData.getTitle().toUpperCase().contains("Captcha".toUpperCase())) {
				CaptchaAudit captchaAudit = new CaptchaAudit();
				captchaAudit.setUserId(user);
				captchaAudit.setLockedDate(new Date());
				captchaAudit.setLockStatus(true);
				captchaAuditRepo.save(captchaAudit);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	/**
	 * M27
	 */
	@Override
	public void resetUserSecCodeAudit(UserAccount user) {
		int updatedRecord = userSecCodeAuditRepo.userSecCodeAuditUpdate(false, user.getUserAccountId());
		LOGGER.debug("Update Record..." + updatedRecord);
	}

	/**
	 * M28
	 */
	@Override
	public ResponseMessage secCodeReset(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled) && getAuthStatusByKey(ssoSyncData)) {
				UserAccount user = getSSOUserAccountByUserName(userName);
				if (user != null) {
					try {
						resetUserSecCodeAudit(user);
					} catch (Exception e) {
						LOGGER.error(e.getMessage());
					}
					response.setStatus(CommonConstant.SUCCESS);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M29
	 * 
	 * Unlock UserAccount
	 */
	@Override
	public ResponseMessage unlockAccount(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			String userName = RCUserUtil.rcDecrypt(ssoSyncData.getUserName());
			String ssoEnabled = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC,
					CasCommonConstant.SSO_ENABLED_STATUS);
			if (SSOSyncUtil.ssoStatus(ssoEnabled) && getAuthStatusByKey(ssoSyncData)) {
				UserAccount user = getSSOUserAccountByUserName(userName);
				if (user != null) {
					updateAccountUnlock(user);
					try {
						resetUserSecCodeAudit(user);
					} catch (Exception e) {
						LOGGER.error(e.getMessage());
					}
					response.setStatus(CommonConstant.SUCCESS);

				} else {
					response.setStatus(CasCommonConstant.USER_DOES_NOT_EXIST);
				}
			} else {
				response.setStatus(CasCommonConstant.SSO_TURNED_OFF);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M30
	 */
	private void updateAccountUnlock(UserAccount userAcct) {
		UserAccount userAccount = userAccountRepo.findById(userAcct.getUserAccountId()).orElse(null);
		if(userAccount!=null) {
		userAccount.setActive(true);
		userAccount.setLastModifiedDate(new Date());
		userAccountRepo.save(userAccount);
		}
		int updatedRecord = captchaAuditRepo.captchaAuditUpdate(false, userAcct.getUserAccountId());
		LOGGER.debug("Update Record..." + updatedRecord);
	}

	/**
	 * M31
	 * 
	 * Update UserAccount based on captchaAudit
	 */
	@Override
	public ResponseMessage captchaAudit(SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			String userName = ssoSyncData.getUserName();
			LOGGER.info(userName);
			if (!userName.isEmpty()) {
				UserAccount user = getSSOUserAccountByUserName(userName);
				LOGGER.info(user + "");

				if (user != null && !user.getActive()) {
					try {
						updateAccountUnlock(user);
					} catch (Exception e) {
						LOGGER.error(e.getMessage());
					}
					response.setStatus(CasCommonConstant.SUCCESS);
					response.setMessage("Account reset successfully");
					ssoSyncData.setUserName(RCUserUtil.rcEncrypt(user.getEmail()));
					try {
						new SSOSyncUtil().unlockAccount(ssoSyncData,
								userAccountService.getSSOAPIURL(CasCommonConstant.ONBOARD));
					} catch (Exception e) {
						LOGGER.error(e.getMessage());
					}
					try {
						new SSOSyncUtil().unlockAccount(ssoSyncData,
								userAccountService.getSSOAPIURL(CasCommonConstant.HRO_LBL));
					} catch (Exception e) {
						LOGGER.error(e.getMessage());
					}
				} else {
					response.setStatus(CasCommonConstant.FAILURE);
					response.setMessage("Account reset failed ");
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}
}