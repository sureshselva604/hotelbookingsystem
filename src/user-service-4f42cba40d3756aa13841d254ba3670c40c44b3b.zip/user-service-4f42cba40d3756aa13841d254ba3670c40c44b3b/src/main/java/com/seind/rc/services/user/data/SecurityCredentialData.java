package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class SecurityCredentialData {
	private String handShakeKey;
	private Long userAccountId;
}
