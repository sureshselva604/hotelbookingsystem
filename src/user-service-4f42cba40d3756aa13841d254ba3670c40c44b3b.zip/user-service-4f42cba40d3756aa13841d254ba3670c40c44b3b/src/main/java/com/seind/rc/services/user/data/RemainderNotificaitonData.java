package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class RemainderNotificaitonData {

	private Date userPwdCreatedOn;
	private String firstName;
	private String lastName;
	private String email;
	private String teleCode;
	private String Phone;
	private String comType;
	private String countryCodeId;
	private String name;
	private Long rcOnBoardId;
	private Long userAccountId;
	private Integer daysdiffer;
}