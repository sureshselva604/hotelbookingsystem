package com.seind.rc.services.user.util;

import java.util.UUID;

public class GlobalUtil {
	private GlobalUtil() {
	}

	public static String createDeviceKey() {
		String deviceKey = "";
		String temp = "";
		UUID cc1 = UUID.randomUUID();
		UUID cc2 = UUID.randomUUID();

		if (cc1.compareTo(cc2) != 0)

		{
			cc1.toString();
			cc2.toString();
			temp = cc1.toString().concat(cc2.toString());
			temp = temp.replace("-", "");
			deviceKey = temp.substring(0, 5);
			deviceKey = deviceKey.concat(temp.substring(27, 32));
		}
		return deviceKey;
	}

	public static String createUnlockKey() {
		String unlockkey = "";
		String temp = "";
		UUID cc1 = UUID.randomUUID();
		UUID cc2 = UUID.randomUUID();

		if (cc1.compareTo(cc2) != 0) {
			cc1.toString();
			cc2.toString();
			temp = cc1.toString().concat(cc2.toString());
			temp = temp.replace("-", "");
			unlockkey = temp.substring(5, 10);
		}
		return unlockkey;
	}

}
