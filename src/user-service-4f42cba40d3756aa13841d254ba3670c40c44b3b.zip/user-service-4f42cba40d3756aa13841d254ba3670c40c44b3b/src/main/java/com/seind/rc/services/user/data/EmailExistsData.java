package com.seind.rc.services.user.data;

import com.seind.rc.services.user.entities.UserAccount;

import lombok.Data;

@Data
public class EmailExistsData {

	private String emailExists;
	private Boolean carePartnerExists;
	private UserAccount useraccount;


}
