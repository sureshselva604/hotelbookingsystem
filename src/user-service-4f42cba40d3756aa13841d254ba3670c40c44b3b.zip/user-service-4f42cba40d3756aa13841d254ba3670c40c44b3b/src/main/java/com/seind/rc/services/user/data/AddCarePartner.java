package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class AddCarePartner {
	private String email;
	private String firstName;
	private String lastName;
	private String gender;
	private boolean onBehalf=false;
	private String code;
	private String codeOther;
	private String teleCountryCode;
	private String teleCode;
	private String phone;
	private String otherPhoneType;
	private String teleCountryCodeOther;
	private String teleCodeOther;
	private String phoneOther;
	private String relationship;
	private List<ImageData> uploadImage;
	private Long patientId;
	private Long takenBy;
	private Long userAccountId;
	private Long patientSwfId; 
	private Long xuser;
	private String mode; 
}
