package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.LambdaWelcomeMail;

public interface LambdaWelcomeMailRepo extends JpaRepository<LambdaWelcomeMail, Long>{

	
	List<LambdaWelcomeMail> findByZoneIdAndCreatedDate(Long zoneId,Integer createdDate);
}

