package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.UserSecQuestionsData;

public interface UserSecQuesService {
	
	List<UserSecQuestionsData> getUserSecQuestions();	

}
