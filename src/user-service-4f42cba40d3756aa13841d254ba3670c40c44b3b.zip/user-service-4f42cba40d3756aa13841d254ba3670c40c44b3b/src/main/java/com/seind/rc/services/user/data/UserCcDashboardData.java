package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserCcDashboardData {
	private UserAccountData loginCcUaData;
	private UserAccountData strykerAdminUaData;
	private UserAccountData patUseAccData;
	private UserAccountData patientSwfCcUaData;
	private HospitalData hospitalData;
	private PatientStageWorkflowData patientSwfData;
	private PatientData patientData;
	private boolean willMytodoBeImpacted;
}
