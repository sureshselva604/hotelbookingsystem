package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class SurgeonData {
	
	private Long surgeonId;
	private Long surgeonUserAccId;
	private Long hospitalSurgeonId;
	private String firstName;
	private String lastName;

}
