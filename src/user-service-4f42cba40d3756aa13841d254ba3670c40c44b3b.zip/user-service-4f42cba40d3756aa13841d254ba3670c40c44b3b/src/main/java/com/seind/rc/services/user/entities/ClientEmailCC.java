package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
@Entity
public class ClientEmailCC {

	@Id
	@Column(name = "Id")
	private Long id;

	@Column(name = "ClientId")
	private Long clientId;

	@Column(name = "EmailCc")
	private String emailCc;

	@Column(name = "Active")
	private boolean active;

	@Column(name = "CreatedDate")
	private Date createdDate;

	@Column(name = "CreatedBy")
	private Long createdBy;

	@Column(name = "LastModifiedDate")
	private Date lastModifiedDate;

	@Column(name = "LastModifiedBy")
	private Long lastModifiedBy;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ClientId", referencedColumnName = "HospitalId", insertable = false, updatable = false)
	private Hospital hospital;
}