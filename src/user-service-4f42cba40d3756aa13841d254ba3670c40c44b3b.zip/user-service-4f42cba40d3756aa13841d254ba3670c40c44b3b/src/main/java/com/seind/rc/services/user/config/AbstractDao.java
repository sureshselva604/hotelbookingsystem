package com.seind.rc.services.user.config;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;

import jakarta.persistence.EntityManager;

public abstract class AbstractDao<P extends Serializable, T> {

	private final Class<T> persistentClass;

	@SuppressWarnings("unchecked")
	protected AbstractDao() {
		this.persistentClass = (Class<T>) ((ParameterizedType) this.getClass().getGenericSuperclass())
				.getActualTypeArguments()[1];
	}

	@Autowired
    private EntityManager entityManager;

    public Session getSession() {
        return entityManager.unwrap(Session.class);
    }

	public T getByKey(P key) {
		return getSession().get(persistentClass, key);
	}

	public void persist(T entity) {
		getSession().persist(entity);
	}

	public void delete(T entity) {
		getSession().delete(entity);
	}

//	@SuppressWarnings("deprecation")
//	protected Criteria createEntityCriteria() {
//		return getSession().createCriteria(persistentClass);
//	}

}
