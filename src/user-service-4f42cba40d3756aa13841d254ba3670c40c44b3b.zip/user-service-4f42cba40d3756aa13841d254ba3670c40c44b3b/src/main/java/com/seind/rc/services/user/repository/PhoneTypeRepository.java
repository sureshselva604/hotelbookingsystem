package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PhoneType;

public interface PhoneTypeRepository extends JpaRepository<PhoneType, Long>{
	
	List<PhoneType> findAllByOrderBySeqNoAsc();
	
}
