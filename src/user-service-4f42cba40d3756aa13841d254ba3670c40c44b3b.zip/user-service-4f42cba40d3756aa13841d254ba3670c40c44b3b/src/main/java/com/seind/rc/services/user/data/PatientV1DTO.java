package com.seind.rc.services.user.data;


import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.HospitalPractice;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.UserAccount;

import lombok.Data;

@Data
public class PatientV1DTO {
	
	private Long patientswfid;
	private Long loginUseraccountId;
	private Long loginhsporpracId ;
	private int patientadmissionId;
	private Long newStageWorkFlowId;
	private Long newEpisodeId;
	
	private PatientStageWorkflow psw;
	private HospitalPractice hp;
	private Hospital patHsp;
	private UserAccount surgeonUa;
	private Hospital loginHospital;	
	
	
}
