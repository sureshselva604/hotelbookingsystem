package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.seind.rc.services.user.util.RCUserUtil;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HospitalDeviceData {

	private Long hospitalId;
	private String name;
	private String email;
	private String phone;
	private Long zoneId;
	private int admissionId;
	private Boolean customWorkflow;
	private Long patientId;
	private String address1;
	private String address2;
	private String city;
	private String country;
	private String zipcode;
	private String imagePath;
	private String logo;
	private String hospital;
	private String backDropImage;

	public void setImagePath(String logo) {
		this.logo = logo;
	}

	public void setHospital(String backDropImage) {
		this.backDropImage = backDropImage;
	}

	public void setAddress1(String address1) {
		this.address1 = RCUserUtil.singleStrCondition(address1 != null && !address1.isEmpty(), address1, "");
	}

	public void setAddress2(String address2) {
		this.address2 = RCUserUtil.singleStrCondition(address2 != null && !address2.isEmpty(), address2, "");
	}

	public void setCountry(String country) {
		this.country = RCUserUtil.singleStrCondition(country != null && !country.isEmpty(), country, "");
	}

	public void setZipcode(String zipcode) {
		this.zipcode = RCUserUtil.singleStrCondition(zipcode != null && !zipcode.isEmpty(), zipcode, "");
	}

}
