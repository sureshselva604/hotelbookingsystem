package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.SecurityDict;

public interface SecurityDictRepository extends JpaRepository<SecurityDict,Long>{

	Long countByIsActiveAndSecurityDictData(Boolean active,String data);
}
