package com.seind.rc.services.user.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.ResponseMessageSSO;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.service.SSOService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * C07
 */
@CrossOrigin
//@Headers(value = { "" })
@RestController
@RequestMapping("/api/ssoAdmin")
@RequiredArgsConstructor
public class SSOSyncController {

	private static final Logger LOGGER = LogManager.getLogger(SSOSyncController.class);

	@Autowired
	private SSOService ssoService;

	/**
	 * Check whether the user exists
	 */
	@Operation(summary = "User Verification")
	@PostMapping("/checkUserExists")
	public ResponseMessageSSO checkUserExists(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessageSSO response = new ResponseMessageSSO();
		try {
			response = ssoService.checkUserExists(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Reset password failure attempt
	 */
	@Operation(summary = "Reset Failure Attempt")
	@PostMapping("/resetFailureAttempt")
	public ResponseMessageSSO resetFailureAttemptStatus(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessageSSO response = new ResponseMessageSSO();
		try {
			response = ssoService.resetFailureAttemptStatus(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * update password failure attempt
	 */
	@Operation(summary = "Update Failure Attempt")
	@PostMapping("/failureAttemptCount")
	public ResponseMessageSSO updateRCFailureAttemptStatus(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessageSSO response = new ResponseMessageSSO();
		try {
			response = ssoService.updateRCFailureAttemptStatus(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Update security questions and answers
	 */
	@Operation(summary = "Update Security Questions")
	@PostMapping("/updateSecQues")
	public ResponseMessage updateSecurityQues(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.updateSecurityQues(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Get other app user information details for user creation
	 */
	@Operation(summary = "Get other app user info details for user creation")
	@PostMapping("/getUserInfo")
	public SsoSyncData getUserInfo(@RequestBody SsoSyncData ssoSyncData, HttpServletRequest request) {
		SsoSyncData response = new SsoSyncData();
		String xUser = request.getHeader("x-user");
		Long userId = Long.valueOf(xUser);
		try {
			response = ssoService.getUserInfo(ssoSyncData, userId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Update and save profile data in userAccount
	 */
	@Operation(summary = "Profile update")
	@PostMapping("/updateProfile")
	public ResponseMessage updateProfile(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.updateProfile(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Update count for failure security questions
	 */
	@Operation(summary = "failureSecQuesCount update")
	@PostMapping("/failureSecQuesCount")
	public ResponseMessage updateSecurityQuesAttempts(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.updateSecurityQuesAttempts(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Update userAccountLock
	 */
	@Operation(summary = "accountLock update")
	@PostMapping("/accountLock")
	public ResponseMessage accountLock(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.accountLock(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Update user password
	 */
	@Operation(summary = "Password update")
	@PostMapping("/updatePwd")
	public ResponseMessage updatePwd(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.updatePassword(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * CSR password update
	 */
	@Operation(summary = "CSR Password update")
	@PostMapping("/updateCsrPwd")
	public ResponseMessage updateCSRPwd(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.updateCSRPwd(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Update Details while user creation
	 */
	@Operation(summary = "Update Details while user creation")
	@PostMapping("/updateActivationFromSSO")
	public ResponseMessage updateActivationFromSSO(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.updateActivationFromSSO(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Update Activation status From SSO
	 */
	@Operation(summary = "Update Activation status From SSO")
	@PostMapping("/updateInvalidSecCodeAudit")
	public ResponseMessage updateInvalidSecCodeAudit(@RequestBody SsoSyncData ssoSyncData, HttpServletRequest request) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.updateInvalidSecCodeAudit(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Security code audit reset
	 */
	@Operation(summary = "Security code audit reset")
	@PostMapping("/seccodereset")
	public ResponseMessage secCodeReset(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.secCodeReset(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Unlock userAccount
	 */
	@Operation(summary = "unlockAccount")
	@PostMapping("/unlockAccount")
	public ResponseMessage unlockAccount(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.unlockAccount(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;

	}

	/**
	 * Get userAccount lock by Captcha
	 */
	@Operation(summary = "getAccount lock by Captcha")
	@PostMapping("/captchaAudit")
	public ResponseMessage captchaAudit(@RequestBody SsoSyncData ssoSyncData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = ssoService.captchaAudit(ssoSyncData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

}