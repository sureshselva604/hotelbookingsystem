package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.controller.DeviceController;
import com.seind.rc.services.user.data.ProfileQuestionsDetails;
import com.seind.rc.services.user.data.ProfileQuestionsList;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.StatusResponse;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.ProfileQuestions;
import com.seind.rc.services.user.entities.ProfileResultDetails;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.ProfileQuestionsRepository;
import com.seind.rc.services.user.repository.ProfileResultDetailsRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.ProfileResultDetailsService;

@Service
public class ProfileResultDetailsServiceImpl implements ProfileResultDetailsService {

	private static final Logger LOGGER = LogManager.getLogger(DeviceController.class);

	@Autowired
	private ProfileResultDetailsRepository profileResDetailsRepo;

	@Autowired
	private ProfileQuestionsRepository profileQuesRepo;
	
	@Autowired
	private PatientRepository patientRepository;

	@Autowired
	private UserAccountRepository userRepository;

	/**
	 * M01
	 */
	@Override
	public ResponseMessage updateProfileAboutMe(ProfileQuestionsList profileQues, Long loginUserId) {
		ResponseMessage statusResponse = new ResponseMessage();
		try {
			UserAccount userAccount = userRepository.findById(loginUserId).orElse(null);// getLoggedInUser();
			String quesIds = "";
			String answers = "";
			List<ProfileQuestionsDetails> profileQuesDatas = profileQues.getProfileQuestions();
			ProfileResultDetails profileResult = null;
			quesIds = profileQuesDatas.stream().map(ques -> ques.getQuestionId()).collect(Collectors.joining("##"));
			answers = profileQuesDatas.stream().map(ans -> ans.getAnswer()).collect(Collectors.joining("##"));
			if (userAccount.getProfileResultDetailId() == null) {
				profileResult = new ProfileResultDetails();
				profileResult.setUserAccountId(loginUserId);
				profileResult.setAnswers(answers);
				profileResult.setQuestionIds(quesIds);
				profileResDetailsRepo.save(profileResult);
				userAccount.setProfileResultDetailId(profileResult.getProfileResultDetailId());
				userRepository.save(userAccount);
			} else {
				profileResult = profileResDetailsRepo.findByUserAccount_UserAccountId(userAccount.getUserAccountId());
				profileResult.setAnswers(answers);
				profileResult.setQuestionIds(quesIds);
				profileResDetailsRepo.save(profileResult);
				userAccount.setProfileResultDetailId(profileResult.getProfileResultDetailId());
				userRepository.save(userAccount);
			}
			Patient patient = userAccount.getPatient();
			patient.setIsProfileDone(true);
			patientRepository.save(patient);
//			TODO
//		if(userAccount.getUserGroup().getUserGroupId() == 19l)
//		{
//			PatientStageWorkflow pswf = patientService.getActivePatientSWFByPatientId(userAccount.getUserAccountKey());
//			if(pswf!=null)
//			{
//				deviceService.logDeviceTransactionAudit(pswf.getPatientId(),
//						pswf.getPatientSWFId(), MYPROFILE,"Add", "About me details");
//			}
//		}
			statusResponse.setStatus(CommonConstant.SUCCESS);
		} catch (Exception e) {
			statusResponse.setStatus(CommonConstant.FAILURE);
			e.printStackTrace();
		}
		return statusResponse;
	}

	/**
	 * M02
	 */
	@Override
	public ProfileQuestionsList getUserProfileQuestionsList(Long patUserId) {
		UserAccount userAccount = userRepository.findById(patUserId).orElse(null);
		ProfileQuestionsList profileQuestions = new ProfileQuestionsList();
		List<ProfileQuestionsDetails> profileDatas = new ArrayList<ProfileQuestionsDetails>();
		List<ProfileQuestions> profileQuestionList = profileQuesRepo.findAll();
		String[] answerList = null;
		if (userAccount.getProfileResultDetailId() == null) {
			for (ProfileQuestions profileQues : profileQuestionList) {
				ProfileQuestionsDetails quesData = new ProfileQuestionsDetails();
				quesData.setQuestionId(profileQues.getQuestionId().toString());
				quesData.setQuestion(profileQues.getQuestionName());
				quesData.setAnswer("");
				profileDatas.add(quesData);
			}
		} else {
			ProfileResultDetails profileResultDetails = profileResDetailsRepo
					.findByUserAccount_UserAccountId(userAccount.getUserAccountId());
			if (profileResultDetails!= null && profileResultDetails.getAnswers().length() > 0) {
				answerList = profileResultDetails.getAnswers().split("##");
			}
			for (int i = 0; i < profileQuestionList.size(); i++) {
				ProfileQuestions profileQues = profileQuestionList.get(i);
				ProfileQuestionsDetails quesData = new ProfileQuestionsDetails();
				quesData.setQuestionId(profileQues.getQuestionId().toString());
				quesData.setQuestion(profileQues.getQuestionName());
				quesData.setAnswer(answerList != null && answerList.length > 0 ? answerList[i] : "");
				profileDatas.add(quesData);
			}
		}
		profileQuestions.setProfileQuestions(profileDatas);
		return profileQuestions;
	}

//	/**
//	 * M03
//	 */
//	@Override
//	public String getBiographyQuestionAnswerInfoByPatientId(Long patientId) {
//		List<BiographyQuestions> biographyQuesData = new ArrayList<BiographyQuestions>();
//		try {
//			Optional<ProfileResultDetails> profileResultDetailList = profileResDetailsRepo
//					.findByUserAccount_UserAccountKey(patientId);
//			for (ProfileResultDetails profileResult : profileResultDetailList) {
//				BiographyQuestions data = new BiographyQuestions();
//				data.setProfileResultDetailId(profileResult.getProfileResultDetailId());
//				data.setUserAccountId(profileResult.getUserAccount().getUserAccountId());
//				data.setQuestionId(profileResult.getQuestionIds());
//				if (profileResult.getAnswers() != null)
//					data.setAnswers(profileResult.getAnswers());
//				else
//					data.setAnswers("");
//
//				if (profileResult.getRandomId() != null)
//					data.setRandomId(profileResult.getRandomId());
//				else
//					data.setRandomId("");
//				biographyQuesData.add(data);
//			}
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return biographyQuesData.toString();
//	}

	/**
	 * M04
	 */
	@Override
	public List<ProfileResultDetails> getProfileResultDetailsByPatientId(Long userAccountId) {
		List<ProfileResultDetails> profileResultDetails = new ArrayList<ProfileResultDetails>();
		try {
			profileResultDetails.add(profileResDetailsRepo.findByUserAccount_UserAccountId(userAccountId));
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return profileResultDetails;
	}

}
