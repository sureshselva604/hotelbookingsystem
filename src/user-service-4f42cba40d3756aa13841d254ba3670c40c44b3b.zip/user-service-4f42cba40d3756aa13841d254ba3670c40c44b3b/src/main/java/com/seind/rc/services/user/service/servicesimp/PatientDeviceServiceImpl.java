package com.seind.rc.services.user.service.servicesimp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.CommonConstant.DateFormatRC;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.LoginRoles;
import com.seind.rc.services.user.data.PatientCarePartnerDTO;
import com.seind.rc.services.user.data.PatientDeviceRequest;
import com.seind.rc.services.user.data.PatientDeviceResponse;
import com.seind.rc.services.user.data.PatientFlagResponseData;
import com.seind.rc.services.user.data.PatientStatusData;
import com.seind.rc.services.user.data.PatientStatusDeviceData;
import com.seind.rc.services.user.data.PatientVitalData;
import com.seind.rc.services.user.data.StatusResponse;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientDevice;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.PatientDeviceRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.ApiCacheService;
import com.seind.rc.services.user.service.CarePartnerMapService;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.PatientDeviceService;
import com.seind.rc.services.user.service.PatientService;
import com.seind.rc.services.user.service.PatientStageWorkflowSevice;
import com.seind.rc.services.user.service.SurgeonService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecCodeAuditService;
import com.seind.rc.services.user.service.UserSecTransAuditService;
import com.seind.rc.services.user.util.CasUtil;
import com.seind.rc.services.user.util.GenerateOTP;
import com.seind.rc.services.user.util.GlobalUtil;
import com.seind.rc.services.user.util.I18nUtil;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.StringEncrypter;
import com.seind.rc.services.user.util.StringEncrypter.EncryptionException;

@Service
public class PatientDeviceServiceImpl implements PatientDeviceService {

	private static final Logger LOGGER = LogManager.getLogger(PatientDeviceServiceImpl.class);

	private static final String INVALID_USER = "Invalid user";
	private static final String PSERVERURL = "pserverurl";
	private static final String FORGOTEMAIL = "ForgotPasswordEmail";
	SimpleDateFormat sdf = new SimpleDateFormat(DateFormatRC.STR_YYYY_MM_DD_HH_MM_SS);
	private static final ResourceBundle app = ResourceBundle.getBundle("messages.app");
	private static final ResourceBundle applicationProp = ResourceBundle.getBundle("application");

	@Autowired
	private PatientDeviceRepository patientDeviceRepo;

	@Autowired
	private PatientService patientService;

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private CarePartnerMapService carePatMapService;

	@Autowired
	private HospitalService hospitalService;

	@Autowired
	private HospitalRepository hospitalRepo;

	@Autowired
	private PatientStageWorkflowSevice pswfService;

	@Autowired
	private CarePartnerMapService carePartnerMapService;

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private UserSecCodeAuditService userSecCodeService;

	@Autowired
	private UserAccountRepository userAccRepo;

	@Autowired
	private SurgeonService surgeonService;

	@Autowired
	private UserSecTransAuditService userSecTransAuditService;

	@Autowired
	private ApiCacheService apiCacheService;

	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepo;

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private CasUtil casUtil;

	@Autowired
	private UserAccountRepository userRepository;

	@Autowired
	private PatientStageWorkflowRepository pswfRepo;

	@Override
	public PatientDevice findByHandShakeKey(String handshakeKey) {
		return patientDeviceRepo.findByHandshakeKey(handshakeKey).stream().findFirst().orElse(null);
	}

	public PatientStatusData getPatientStatusDetails(Long patientId) {
		PatientStatusData patientData = new PatientStatusData();
		String format = "";
		String userName = "";
		Boolean isCarePartner = false;
		UserAccount patUa = null;

		try {
			PatientStageWorkflow patientSWF = pswfRepo.findByPatient_PatientId(patientId).stream().findFirst()
					.orElse(null);
			patUa = patientService.getPatientUserAccountByPatientSWFId(patientSWF.getPatientSWFId());

			if (patUa != null) {
				if (patUa.getEmail() != null) {
					format = "EM";
					userName = patUa.getEmail();
				} else if (patUa.getPhone() != null) {
					format = "PN";
					userName = patUa.getPhone();
				}
				UserAccount cpUa = userAccountService.getUserExistByUserNameGroupId(userName, format, 20l);
				if (cpUa != null) {
					isCarePartner = true;
				}
			} else {
				draftPatientDataJobjIfUsersFalse(patientData);
				return patientData;
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			draftPatientDataJobjIfUsersFalse(patientData);
			return patientData;
		}
		patientData.setIsPatient(patUa != null);
		patientData.setIsCarePartner(isCarePartner);
		return patientData;
	}

	private void draftPatientDataJobjIfUsersFalse(PatientStatusData patientData) {
		patientData.setIsPatient(false);
		patientData.setIsCarePartner(false);
	}

	@Override
	public PatientDeviceResponse patientOrCarepartnerCheckStatus(PatientDeviceRequest reqData) {
		PatientDeviceResponse response = new PatientDeviceResponse();
		try {
			String pswd = reqData.getPassword();
			if (StringUtils.isNotBlank(pswd)) {
				validateAndSaveLoginHistory(reqData.getUserName(), pswd);
			}
			if (StringUtils.isNotBlank(pswd) && StringUtils.isNotBlank(reqData.getUserName())
					&& StringUtils.isNotBlank(reqData.getVersion())) {
				response = executePatientCarePartnerCheckStatus(reqData, response);
			} else {
				response = flagErrorMsg(response, "Invalid URL or handshake");

			}
		} catch (Exception e) {
			response = flagErrorMsg(response, "Problem in fetching device or practice");
		}
		return response;
	}

	public PatientDeviceResponse flagErrorMsg(PatientDeviceResponse respData, String errMsg) {
		try {
			respData.setMessage(errMsg);
			respData.setStatus(CommonConstant.FAILURE);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return respData;

	}

	private PatientDeviceResponse executePatientCarePartnerCheckStatus(PatientDeviceRequest reqData,
			PatientDeviceResponse response) {
		try {
			StringEncrypter enc1 = new StringEncrypter("DES");
			List<Long> groupIds = List.of(19l, 20l);
			String format = validateUserName(reqData.getUserName());
			UserAccount user = userAccountService.validateUserNew(reqData.getUserName()).stream().findFirst()
					.orElse(null);
			if (user != null && groupIds.contains(user.getUserGroup().getUserGroupId())) {
				if (user.getActive() && user.getUserPwd().equalsIgnoreCase(enc1.encrypt(reqData.getPassword()))) {
					List<CarePartnerMap> cpMap = carePartnerMapRepo
							.findByActiveTrueAndUserAccount_UserAccountId(user.getUserAccountId());
					if ((!cpMap.isEmpty() && user.getUserGroup().getUserGroupId() == 20l)
							|| user.getUserGroup().getUserGroupId() == 19l) {
//							TokenUser user = new TokenUser(ua2);
//							tokenUtil.getTokenCacheService().clearUserToken(user.getUsername() + serialNo);
//							String tokenString = tokenUtil.createTokenForUser(user, serialNo);

						userSecCodeService.resetUserSecCodeAudit(user.getUserAccountId());
						Boolean isStaff = isStafforNot(user);
						response = bundleAllToExecutePatientCarePartnerCheckStatus(response, isStaff,
								reqData.getDeviceName(), reqData.getSerialNo(), user, format);
//							jsonObject2.addProperty("tokenId", tokenString);

					} else {
						response = flagErrorMsg(response, CommonConstant.ERR_MSG_TEXT);

					}
				} else {
					response = flagErrorMsg(response, CommonConstant.ACCOUNT_DEACTIVATED);

				}
			} else {
				response = flagErrorMsg(response, CommonConstant.ERR_MSG_TEXT);

			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	private PatientDeviceResponse bundleAllToExecutePatientCarePartnerCheckStatus(PatientDeviceResponse response,
			Boolean isStaff, String deviceName, String serialNo, UserAccount user, String format) {
		PatientDevice patientDevice = null;
		String groupName = user.getUserGroup().getGroupName();
		try {
			if (user.getUserGroup().getGroupName().equalsIgnoreCase(CommonConstant.STR_CAREPARTNER)) {
				groupName = user.getUserGroup().getGroupName();
				List<PatientDevice> patientDeviceList = patientDeviceRepo
						.findByCarePartnerIdAndSerialNumber(user.getUserAccountId(), serialNo);
				patientDevice = patientDeviceList.isEmpty() ? null : patientDeviceList.get(0);

				List<CarePartnerMap> cpm = carePatMapService
						.getActiveCarePartnerMapbyCpUseraccount(user.getUserAccountId());
				if (cpm.isEmpty()) {
					if (!user.getWelcomeFlag()) {
						response = flagErrorMsg(response, CommonConstant.ERR_MSG_TEXT2);
					} else {
						response = flagErrorMsg(response, INVALID_USER);
					}
				} else {
					response = allDraft3ToExecutePatientCarePartnerCheckStatus(response, patientDevice, isStaff,
							deviceName, serialNo, user, format, groupName);
				}

			} else if (user.getUserGroup().getGroupName().equalsIgnoreCase(CommonConstant.STR_PATIENT1)) {
				groupName = user.getUserGroup().getGroupName();
				response = draft1And2ToExecutePatientCarePartnerCheckStatus(user, response, deviceName, serialNo,
						isStaff, format, groupName);
			} else {
				response = flagErrorMsg(response, CommonConstant.ERR_NOT_PAT_USER);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	private PatientDeviceResponse draft1And2ToExecutePatientCarePartnerCheckStatus(UserAccount user,
			PatientDeviceResponse response, String deviceName, String serialNo, Boolean isStaff, String format,
			String groupName) {

		List<PatientDevice> patientDeviceList = patientDeviceRepo
				.findByPatient_PatientIdAndSerialNumber(user.getUserAccountKey(), serialNo);
		PatientDevice patientDevice = patientDeviceList.isEmpty() ? null : patientDeviceList.get(0);
		if (patientDevice !=null && patientDevice.getDeviceId() != null) {
			response.setIsTempPasswordActive(user.getTempPasswordActive());
			response = draft3ToExecutePatientCarePartnerCheckStatus(response, patientDevice, isStaff, groupName);
		} else {
			patientDevice = createPatientDevice(deviceName, serialNo);
			Patient patient = patientRepo.findById(user.getUserAccountKey()).orElse(null);
			patientDevice.setMode(format);
			patientDevice.setPatient(patient);
			patientDeviceRepo.save(patientDevice);
			response.setIsTempPasswordActive(user.getTempPasswordActive());
			response = draft3ToExecutePatientCarePartnerCheckStatus(response, patientDevice, isStaff, groupName);
		}
		return response;
	}

	private PatientDeviceResponse allDraft3ToExecutePatientCarePartnerCheckStatus(PatientDeviceResponse response,
			PatientDevice patientDevice, Boolean isStaff, String deviceName, String serialNo, UserAccount user,
			String format, String groupName) {
		try {
			if (patientDevice != null && patientDevice.getDeviceId() != null) {
				response.setIsTempPasswordActive(user.getTempPasswordActive());
				response = draft3ToExecutePatientCarePartnerCheckStatus(response, patientDevice, isStaff, groupName);
			} else {
				patientDevice = createPatientDevice(deviceName, serialNo);
				UserAccount carePartner = userRepository.findById(user.getUserAccountId()).orElse(null);
				patientDevice.setCarePartnerId(carePartner.getUserAccountId());
				List<CarePartnerMap> cpm = carePatMapService
						.getActiveCarePartnerMapbyCpUseraccount(carePartner.getUserAccountId());
				Patient pp = patientRepo.findById(cpm.get(0).getPatientId()).orElse(null);
				patientDevice.setPatient(pp);
				patientDevice.setMode(format);

				/** getting HealthKitLastSyncData from device */
//				HealthKitLastSyncData healthKitLastSyncData = deviceservice.fetchMaxHealthKitSyncDates(pp.getPatientId());
//				patientDevice.setActivityMaxDate(healthKitLastSyncData.getActivityMaxDate());
//				patientDevice.setHeartMaxDate(healthKitLastSyncData.getHeartMaxDate()); 
//				patientDevice.setSleepMaxDate(healthKitLastSyncData.getSleepMaxDate());
//				patientDevice.setWalkingMaxDate(healthKitLastSyncData.getWalkingMaxDate());
				patientDeviceRepo.save(patientDevice);

				response.setIsTempPasswordActive(carePartner.getTempPasswordActive());
				response = draft3ToExecutePatientCarePartnerCheckStatus(response, patientDevice, isStaff, groupName);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	private PatientDeviceResponse draft3ToExecutePatientCarePartnerCheckStatus(PatientDeviceResponse response,
			PatientDevice patientDevice, Boolean isStaff, String groupName) {
		try {
			response.setStatus(CommonConstant.SUCCESS);
			response.setDeviceKey(patientDevice.getDeviceKey());
			response.setPatientId(
					patientDevice.getPatient().getPatientId() != null ? patientDevice.getPatient().getPatientId() : 0l);
			response.setCarePartnerId(patientDevice.getCarePartnerId() != null ? patientDevice.getCarePartnerId() : 0l);
			response.setIsOfficeStaff(isStaff);
			String country = "";
			if (groupName.equalsIgnoreCase(CommonConstant.STR_CAREPARTNER)) {
				if (patientDevice.getCarePartnerId() != null && patientDevice.getCarePartnerId() != 0l) {
					response.setIsCarePartner(true);
					CarePartnerMap actPat = carePatMapService
							.getCarePartnerPatientList(patientDevice.getCarePartnerId()).get(0);
					country = userAccountService
							.getCountryCodebyUseraccountKey(actPat.getPatientId() != null ? actPat.getPatientId() : 0l);
				}
			} else if (groupName.equalsIgnoreCase(CommonConstant.STR_PATIENT1)) {
				response.setIsCarePartner(false);
				if (patientDevice.getPatient().getPatientId() != null) {
					country = userAccountService
							.getCountryCodebyUseraccountKey(patientDevice.getPatient().getPatientId());
				}
			}
			response.setCountryCode(country != "" ? country : "");

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	private PatientDevice createPatientDevice(String deviceName, String serialNo) {
		PatientDevice device = new PatientDevice();
		/** status table bending */
//	Status status1 = new Status(Long.valueOf(1));
		device.setStatusId(/* status1 */1l);
		String deviceKey = GlobalUtil.createDeviceKey();
		device.setCode("device");
		device.setName((deviceName != null && !deviceName.trim().isEmpty()) ? deviceName : "Unknown Device");
		device.setSerialNumber(serialNo);
		device.setHandshakeKey(serialNo + deviceKey);
		device.setDeviceKey(deviceKey);
		device.setUnlockKey(GlobalUtil.createUnlockKey());
		device.setCreatedDate(new Date());
		device.setFormConfig(false);
		device.setSurveyConfig(false);
		device.setVideoConfig(false);
		device.setCarePartnerId(0l);
		return device;
	}

	private String validateUserName(String userName) {
		String format = "";
		try {
			if (isValidEmail(userName)) {
				format = "EM";
			} else if (StringUtils.isNumeric(userName)) {
				format = "PN";
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return format;
	}

	public boolean isValidEmail(String userName) {
		final Pattern validEmailAddressRegex = Pattern.compile(app.getString("VALID_EMAIL_REGEX"),
				Pattern.CASE_INSENSITIVE);
		Matcher matcher = validEmailAddressRegex.matcher(userName);

		return matcher.find();
	}

	private Boolean isStafforNot(UserAccount ua) {
		Boolean isStaff = false;
		try {
			List<UserAccount> userList = userAccountService.getUsersByEmailId(ua.getEmail(),
					(ua.getPhone() != null ? ua.getTeleCode() + "-" + ua.getPhone() : ""));
			for (UserAccount uac : userList) {
				if (uac.getUserGroup().getUserGroupId() != 19L && uac.getUserGroup().getUserGroupId() != 20L) {
					isStaff = true;
					break;
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return isStaff;
	}

	private void validateAndSaveLoginHistory(String userName, String pswd) {
		try {
			String loginUserName = userName;
			loginUserName = loginUserName.replace("+", "").replace("(", "").replace(")", "").replace(" ", "");
			if (loginUserName != null && !loginUserName.trim().isEmpty()) {
				rcUserUtil.saveLoginHistory(loginUserName, new StringEncrypter("DES").encrypt(pswd), "Device", null);
//					String format = validateUserName(loginUserName);

			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	@Override
	public List<LoginRoles> activeBodyPartListforCarePartner(PatientDeviceRequest reqData) {
		List<LoginRoles> rolesList = new ArrayList<LoginRoles>();
		try {
			UserAccount user = userRepository.findById(reqData.getUserAccountId()).orElse(null);
			String email = (user.getEmail() != null && !user.getEmail().isEmpty()) ? user.getEmail() : null;

			String phoneNo = (StringUtils.isNotBlank(user.getTeleCode()) && user.getPhone()!=null ) ? user.getTeleCode() : "";
			if (phoneNo != null && !phoneNo.isEmpty()) {
				phoneNo = (StringUtils.isNotBlank(user.getPhone())) ? phoneNo + "-" + user.getPhone() : "";
			}
			List<UserAccount> userList = userAccountService.getUsersByEmailId(email, phoneNo, user.getUserAccountId());
			for (UserAccount userAcc : userList) {
				rolesList = subActiveBodyPartListforCarePartner(userAcc, rolesList);
			}
			
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		// TODO Auto-generated method stub
		return rolesList;
	}

	private List<LoginRoles> subActiveBodyPartListforCarePartner(UserAccount userAcc, List<LoginRoles> rolesList) {
		try {
			String userGroupName = userAcc.getUserGroup() != null && userAcc.getUserGroup().getUserGroupId() != 0
					? userAcc.getUserGroup().getGroupName()
					: "";
				if (userGroupName.equalsIgnoreCase(UserGroupCons.STR_CAREPARTNER)) {
					List<CarePartnerMap> clist = carePartnerMapService
							.getCarePartnerPatientList(userAcc.getUserAccountId());
					for (CarePartnerMap cp : clist) {
						Patient pat = patientRepo.findById(cp.getPatientId()).orElse(null);
						UserAccount patActId = userAccRepo
								.findByUserAccountKeyAndUserGroup_UserGroupId(cp.getPatientId(), 19l).orElse(null);
						List<PatientStageWorkflow> patientStageWorkFlowList = pswfService
								.getPatientStageWorkflowByPatientId(pat.getPatientId());
						for (PatientStageWorkflow patswf : patientStageWorkFlowList) {
							if (patswf.getPswIsActive()) {
								Boolean bodyPartAvail = true;
								LoginRoles roles = getLoginRoles(userAcc, pat, patActId, patswf, cp, bodyPartAvail);
								rolesList.add(roles);
							}
						}
					}
				} else if (userGroupName.equalsIgnoreCase(UserGroupCons.STR_PATIENT)) {
					Patient pat = patientRepo.findById(userAcc.getUserAccountKey()).orElse(null);
					UserAccount patActId = userAccRepo
							.findByUserAccountKeyAndUserGroup_UserGroupId(pat.getPatientId(), 19l).orElse(null);
					List<PatientStageWorkflow> patientStageWorkFlowList = pswfRepo
							.findByPatient_PatientId(pat.getPatientId());
					for (PatientStageWorkflow patswf : patientStageWorkFlowList) {
						if (patswf.getPswIsActive()) {
							Boolean bodyPartAvail = true;
							LoginRoles roles = getLoginRoles(userAcc, pat, patActId, patswf, null, bodyPartAvail);
							rolesList.add(roles);
						}
					}
				}
				else {
				LoginRoles roles = getLoginRolesForMisc(userAcc);
				rolesList.add(roles);

			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return rolesList;

	}

	private LoginRoles getLoginRolesForMisc(UserAccount userAcc) throws EncryptionException {
		StringEncrypter se = new StringEncrypter("DES");
		LoginRoles role = new LoginRoles();
		try {
			if (userAcc != null) {
				role.setLoginAccountId(userAcc.getUserAccountId());
				role.setUserGroupId(userAcc.getUserGroup() != null ? userAcc.getUserGroup().getUserGroupId() : 0l);
				role.setFirstName(userAcc.getFirstName());
				role.setLastName(userAcc.getLastName());
				role.setPatientAccountId(0l);
				role.setPatientId(0l);
				role.setImagePath(userAcc.getImagePath());
				Hospital hsp = hospitalService.getHospitalIdForAnyUserAccount(userAcc);
				role.setHospitalId(hsp.getHospitalId());
				role.setHospitalName(hsp.getName());
				role.setMappingId(0l);
				role.setVerified(true);
				role.setCname(userAcc.getUserName());
				role.setCid(se.decrypt(userAcc.getUserPwd()));
				role.setDos("");
				role.setSurgeonName("");
				role.setIsBodypartavailable(false);
				role.setMajorGroupId(userAcc.getUserGroup() != null ? userAcc.getUserGroup().getUserGroupId() : 0l);
				role.setUserGroupName(userAcc.getUserGroup() != null ? userAcc.getUserGroup().getGroupName() : "");
				if (userAcc.getUserGroup() != null
						&& CommonConstant.STR_CARE_OUTCOME.equalsIgnoreCase(userAcc.getUserGroup().getGroupName())) {
					role.setMajorGroupName("Care Navigator");
				} else {
					role.setMajorGroupName(userAcc.getUserGroup().getGroupName());
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return role;
	}

	private LoginRoles getLoginRoles(UserAccount userAcc, Patient pat, UserAccount patActId,
			PatientStageWorkflow patswf, CarePartnerMap cp, Boolean bodyPartAvail) {
		LoginRoles role = new LoginRoles();
		try {
			if (userAcc != null) {
				role.setLoginAccountId(patActId.getUserAccountId());
				role.setUserGroupId(
						userAcc.getUserGroup() != null && userAcc.getUserGroup().getUserGroupId() == 20l ? 19l
								: userAcc.getUserGroup().getUserGroupId());
				role.setMajorGroupId(userAcc.getUserGroup() != null ? userAcc.getUserGroup().getUserGroupId() : 0l);
				role.setFirstName(pat.getFirstName());
				role.setLastName(pat.getLastName());
				role.setPatientAccountId(patActId.getUserAccountId());
				role.setPatientId(pat.getPatientId());
				role.setImagePath(patActId.getImagePath());
				role.setPatientStageWorkflowId(patswf.getPatientSWFId());
				role.setIsBodypartavailable(bodyPartAvail);
				role.setProcedure(patswf.getProcedureType());
				Hospital hospital = patswf.getCCUserAccount().getHospital();
				role.setHospitalId(hospital.getHospitalId());
				role.setHospitalName(hospital.getName());
				if (cp != null) {
					role.setMappingId(cp.getCarePartnerMapId());
					role.setVerified(cp.getVerified());
				}
				if (userAcc.getUserGroup() != null && userAcc.getUserGroup().getUserGroupId() == 19l) {
					role.setMappingId(0l);
					role.setVerified(true);
				}
				role.setCname(userAcc.getUserName());
				role = setPatSurgeonInfo(userAcc, patswf, role);
				role.setUserGroupName(userAcc.getUserGroup() != null ? userAcc.getUserGroup().getGroupName() : "");
				role.setMajorGroupName(userAcc.getUserGroup() != null ? userAcc.getUserGroup().getGroupName() : "");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return role;
	}

	private LoginRoles setPatSurgeonInfo(UserAccount userAcc, PatientStageWorkflow patswf, LoginRoles role)
			throws EncryptionException {
		SimpleDateFormat fmt = new SimpleDateFormat(CommonConstant.STR_MM_DD_YYYY);
		StringEncrypter se = new StringEncrypter("DES");
		try {
			role.setCid(se.decrypt(userAcc.getUserPwd()));
			role.setDos((patswf.getDos() != null ? fmt.format(patswf.getDos()) : ""));
			UserAccount surgeonAct = userRepository.findById(patswf.getHspSurgId()).orElse(null);
			if (surgeonAct.getUserAccountKey() != null) {
				Surgeon surgeon = surgeonService.getSurgeonByIdAndActive(surgeonAct.getUserAccountKey());
				if (surgeon != null) {
					role.setSurgeonName(
							surgeon.getSalutation() + surgeonAct.getFirstName() + " " + surgeonAct.getLastName());
				} else {
					role.setSurgeonName("");
				}
			} else {
				role.setSurgeonName("");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			role.setCid("");
			role.setDos("");
			role.setSurgeonName("");
		}
		return role;
	}

	@Override
	public StatusResponse validateOtpDev(PatientDeviceRequest reqData) {
		StatusResponse statusResp = new StatusResponse();
		try {
			byte[] decodedBytes = Base64.getDecoder().decode(reqData.getOtp());
			String decodedBytePwd = new String(decodedBytes);
			decodedBytePwd = reqData.getOtp();
			UserSecTransAudit userTransAudit = userSecTransAuditService
					.fetchIPCaptureActiveUserSecTransAudit(reqData.getUserAccountId(), reqData.getMode());
			UserAccount userAct = userRepository.findById(reqData.getUserAccountId()).orElse(null);
			Integer ct = apiCacheService.getAttemptCount(reqData.getUserAccountId() + "otptrg");
			if (ct >= 5) {
				statusResp.setStatus(CommonConstant.FAILURE);
				statusResp.setMessage(CommonConstant.ERR_ATTEMPTS_MANY);
				return statusResp;

			}
			apiCacheService.setAttemptCount(reqData.getUserAccountId() + "otptrg", ct + 1);
			List<PatientStageWorkflow> pswf = null;
			if (userAct != null && userAct.getUserGroup().getUserGroupId().compareTo(19L) == 0) {
				pswf = pswfRepo.findByPatient_PatientId(userAct.getUserAccountKey());
			} else if (userAct != null && userAct.getUserGroup().getUserGroupId().compareTo(20L) == 0) {
				pswf = pswfRepo.findByPatient_PatientId(userAct.getWhoseCarePartner());
			}

			if (pswf != null && !pswf.isEmpty()) {
				UserAccount sugUserAct = userRepository.findById(pswf.get(0).getHspSurgId()).orElse(null);
				statusResp.setSugFirstName(sugUserAct == null ? "" : sugUserAct.getFirstName());
				statusResp.setSugLastName(sugUserAct == null ? "" : sugUserAct.getLastName());
				statusResp.setSugImagePath(sugUserAct == null ? "" : sugUserAct.getImagePath());
				statusResp.setFirstName(userAct == null ? "" : userAct.getFirstName());
				statusResp.setLastName(userAct == null ? "" : userAct.getLastName());
			}

			if (userTransAudit == null || !userTransAudit.getIsActive()
			/* || (DateUtil.secondsDiff(userTransAudit.getCreatedOn(), new Date()) > 600) */ ) {
				statusResp.setStatus(CommonConstant.FAILURE);
				statusResp.setMessage(CommonConstant.EXPIRED_OTP);
				statusResp.setInvalidCount("0");
			} else if (!userTransAudit.getOtp().equals(decodedBytePwd)) {
				if (userAct.getUserGroup().getUserGroupId() == 19 || userAct.getUserGroup().getUserGroupId() == 20) {
					statusResp.setStatus(CommonConstant.FAILURE);
					statusResp.setMessage(CommonConstant.VERIFY_INVALID_CHECK);
					statusResp.setInvalidCount("1");
				} else {
					statusResp = casUtil.getStatusRespWithSecCodeCount(userAct, decodedBytePwd, statusResp);
				}

			} else {
				statusResp.setStatus(CommonConstant.SUCCESS);
				statusResp.setMessage(CommonConstant.VERIFY_VALID_CHECK);
				statusResp.setInvalidCount("0");
				userSecTransAuditRepo.updateUserSecTransAudit(userAct.getUserAccountId(), reqData.getMode());
				statusResp.setRandId(setTokenInactiveDev(userAct));
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return statusResp;
	}

	private String setTokenInactiveDev(UserAccount userAct) {
		String randId = "";
		UserSecTransAudit audit = null;
		try {
			for (String mode : RCUserUtil.getModeList()) {
				audit = userSecTransAuditService.fetchIPCaptureActiveUserSecTransAudit(userAct.getUserAccountId(),
						mode);
				if (audit != null) {
					userSecTransAuditService.updateUserSecTransAudit(audit.getUserSecTransAuditId());
				}
			}
			randId = UUID.randomUUID().toString();
			userSecTransAuditRepo.userSecTransAuditActiveUpdate(userAct.getUserAccountId(), List.of("PasswordUpdate"));
			UserSecTransAudit secTransAudit = new UserSecTransAudit();
			secTransAudit.setUserAccount(userAct);
			secTransAudit.setIsActive(true);
			secTransAudit.setCreatedOn(new Date());
			secTransAudit.setRandomId(randId);
			secTransAudit.setMode("PasswordUpdate");
			userSecTransAuditService.saveUserSecTransAudit(secTransAudit);
//			statusResp.setValue(randId);

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return randId;
	}

	@Override
	public PatientFlagResponseData getEmailorPhExistsFlagByPatient(PatientStatusDeviceData patientData) {
		PatientFlagResponseData flagResp = new PatientFlagResponseData();
		PatientDevice patDevice = null;
		try {
			String handShakeKey = patientData.getHandshakekey();
			if (handShakeKey != null) {
				patDevice = patientDeviceRepo.findByHandshakeKey(handShakeKey).stream().findFirst().orElse(null);
				if (patDevice == null) {
					flagResp.setDevice("Device not Registered");
					flagResp.setStatus(CommonConstant.FAILURE);
				}
			} else {
				flagResp.setDevice("Invalid UserName");
				flagResp.setStatus(CommonConstant.FAILURE);
			}

//			String editJsonString = convertFileAsString(editEmailPhone);
//			editJsonString = RCUserUtil.replaceNullValueIntoEmpty(editJsonString.replace("\\\"", "\""));
			List<PatientVitalData> patVitalDataList = patientData.getPatVitalData();
			sendSmsForOtherUser1(patVitalDataList);
			flagResp = getExisitEmailorMobile(patVitalDataList, flagResp);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return flagResp;
	}

	private PatientFlagResponseData getExisitEmailorMobile(List<PatientVitalData> patVitalDataList,
			PatientFlagResponseData flagResp) {
		try {
			for (PatientVitalData patVitalData : patVitalDataList) {
				PatientDevice patDevice = patientDeviceRepo.findByHandshakeKey(patVitalData.getHandshakekey()).stream()
						.findFirst().orElse(null);
				if ((patVitalData.getIsEmailUpdate() || patVitalData.getIsPhoneUpdate()) && patDevice != null) {
					flagResp = subGetExistEmailorMobile(patVitalData, patDevice, flagResp);

				} else {
					flagResp.setIsEmailUpdate(true);
					flagResp.setIsPhoneUpdate(true);
					flagResp.setIsEmailorPhone("check Email or Phone");
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return flagResp;
	}

	private PatientFlagResponseData subGetExistEmailorMobile(PatientVitalData patVitalData, PatientDevice patDevice,
			PatientFlagResponseData flagResp) {
		try {
			if (patVitalData.getIsEmailUpdate() && !isValidEmail(patVitalData.getPatEmail())) {
				flagResp.setIsEmailUpdate(true);
				flagResp.setIsPhoneUpdate(true);
				flagResp.setIsEmailorPhone("Invalid Email");
				return flagResp;
			}

			if (patVitalData.getIsPhoneUpdate() && !StringUtils.isNumeric(patVitalData.getPatPhone())) {
				flagResp.setIsEmailUpdate(true);
				flagResp.setIsPhoneUpdate(true);
				flagResp.setIsEmailorPhone("Invalid PhoneNo");
				return flagResp;

			}

//			String comType = patVitalData.getComType();

			UserAccount user = null;
			if (patDevice.getCarePartnerId() > 0) {
				user = userRepository.findById(patDevice.getCarePartnerId()).orElse(null);
			} else {

				user = userRepository.findByUserAccountKey(patDevice.getPatient().getPatientId()).stream().findFirst()
						.orElse(null);
			}

			if (user != null) {
				flagResp = getEmailExistbyPatient(patVitalData, user, flagResp);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return flagResp;
	}

	private PatientFlagResponseData getEmailExistbyPatient(PatientVitalData patVitalData, UserAccount user,
			PatientFlagResponseData flagResp) {
		try {
			if (patVitalData.getIsEmailUpdate() || patVitalData.getIsPhoneUpdate()) {
//				UserAccount account = userRepository.findById(user.getUserAccountId());
				Patient patientNew = null;
				if (user != null && user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_PATIENT)) {
					patientNew = patientRepo.findById(user.getUserAccountKey()).orElse(null);
				}

				String oldPhone = user.getPhone() != null ? user.getPhone() : "";
				String oldEmail = user.getEmail() != null ? user.getEmail() : "";
				String oldTeleCode = user.getTeleCode() != null ? user.getTeleCode() : "";

				draftObjectToGetEmailExistbyPatient(flagResp, oldEmail, patVitalData, patientNew, user);

				draftObjectToGetPhoneExistbyPatient(patVitalData, user, patientNew, flagResp);
				user.setComType(RCUserUtil.getComType(patVitalData.getPatEmail(), patVitalData.getPatPhone()));
				String willSendOnBoardWelcomeLink = userAccountService.willSendOnBoardWelcomeLink(
						user.getUserAccountId(), patVitalData.getPatEmail(), patVitalData.getPatPhone());
				if (willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P")) {
					user.setIsOnBoardLinkSent(true);
					user.setOnBoardLinkSentOn(new Date());
				}
				if (patientNew != null
						&& user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_PATIENT))
					patientRepo.save(patientNew);

				userAccRepo.save(user);

				UserAccount updatedAccount = userAccountService
						.getUserAccountByUserNameAndEmail(patVitalData.getPatEmail());
				if (updatedAccount != null) {
					updateOtherAccountByPatient(updatedAccount, oldEmail, oldPhone, oldTeleCode);
				} else {
					updateOtherAccountByPatient(user, oldEmail, oldPhone, oldTeleCode);
				}

				PatientCarePartnerDTO patCpDTO = new PatientCarePartnerDTO();
				flagResp = preEmailPhoneConfigureAndSend(user, patVitalData, willSendOnBoardWelcomeLink, patientNew,
						patCpDTO, flagResp);
				if (!patCpDTO.getPatientSwfList().isEmpty() && patCpDTO.getHsp() != null)
					emailConfigureAndSend(user, patCpDTO, willSendOnBoardWelcomeLink, patientNew);
				flagResp.setIsEmailUpdate(!patVitalData.getIsEmailUpdate());
				flagResp.setIsPhoneUpdate(!patVitalData.getIsPhoneUpdate());
				flagResp.setIsEmailorPhone("Update Sucessfully");
				return flagResp;

			} else {
				flagResp.setIsEmailUpdate(true);
				flagResp.setIsPhoneUpdate(true);
				flagResp.setIsEmailorPhone("Not Update Sucessfully");
				return flagResp;

			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			flagResp.setIsEmailUpdate(true);
			flagResp.setIsPhoneUpdate(true);
			flagResp.setIsEmailorPhone("Not Update Sucessfully");
			return flagResp;
		}
	}

	private void emailConfigureAndSend(UserAccount user, PatientCarePartnerDTO patCpDTO,
			String willSendOnBoardWelcomeLink, Patient patientNew) {
		String existEmailAndNewEqual = patCpDTO.getExistEmailAndNewEqual();
//		String existPhoneAndNewEqual=patCpDTO.getExistPhoneAndNewEqual();
		ResourceBundle rb2 = I18nUtil.getConfigResourceByLanguage(
				patCpDTO.getHsp() != null ? patCpDTO.getHsp().getCountryCode().getLanguage() : "");
		Surgeon sugtemp = patCpDTO.getPatientSwfList().get(0).getHospitalSurgeon().getSurgeon();
		UserGroup loginUserGroup = user.getUserGroup();

		if (willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P")) {
			String smsMsgTxt = rb2.getString("practsmscontent");
			String emailContent = fetchEmailContentFrom(loginUserGroup, user, rb2);
			String encryptedUserId = String.valueOf(user.getUserAccountId());
//			smsMsgTxt = smsMsgTxt.replace("<tinyURL>", applicationProp.getString("tinyurl"));
//			smsMsgTxt = smsMsgTxt.replace("<Practicename>", patCpDTO.getHsp().getName());
//			smsMsgTxt = smsMsgTxt.replace("<userName>", user.getUserName());
//
//			Map<String, String> emailConfigmap = settingsService.getSettingsMapByCategory(CommonConstant.EMAIL);
//			Map<String, String> forgotEmailConfigmap = settingsService.getSettingsMapByCategory(FORGOTEMAIL);
//
//			emailConfigmap.put(CommonConstant.EMAIL_CC_LIST, forgotEmailConfigmap.get(CommonConstant.EMAIL_CC_LIST));
//			emailConfigmap.put(CommonConstant.EMAIL_BC_LIST, forgotEmailConfigmap.get(CommonConstant.EMAIL_BC_LIST));

//			String cc = emailConfigmap.get(CommonConstant.EMAIL_CC_LIST);
//			String bcc = emailConfigmap.get(CommonConstant.EMAIL_BC_LIST);
//			UserAccount surUserAcc = userAccRepo.findByUserAccountKeyAndAndUserGroup_UserGroupIdIn(sugtemp.getSurgeonId(),
//					List.of(UserGroupCons.SURGEON)).get(0);
			String rpsEmailMsgTxtNew = emailContent;
			rpsEmailMsgTxtNew = rpsEmailMsgTxtNew.replaceAll(CommonConstant.PAT_NAME_TEXT,
					user.getFirstName() + " " + user.getLastName());

			if (user.getEmail() != null) {
				rpsEmailMsgTxtNew = rpsEmailMsgTxtNew.replaceAll(CommonConstant.PAT_EMAIL_TEXT, user.getEmail());
			}

			/**
			 * rpsEmailMsgTxtNew =
			 * rpsEmailMsgTxtNew.replaceAll(CommonConstant.SURG_NAME_TEXT,
			 * sugtemp.getSalutation() + sugtemp.getFirstName() + " " +
			 * sugtemp.getLastName());
			 * 
			 * rpsEmailMsgTxtNew = rpsEmailMsgTxtNew.replaceAll("<<hsp_name>>",
			 * patCpDTO.getHsp().getName()); rpsEmailMsgTxtNew =
			 * rpsEmailMsgTxtNew.replace("<<hsp_URL>>", "CareCoach-nearmc.memorial.me ");
			 * 
			 * rpsEmailMsgTxtNew = rpsEmailMsgTxtNew.replaceAll("<<unsub_sms>>",
			 * applicationProp.getString("tinyurlunsubscribe").concat("?eId=" +
			 * encryptedUserId));
			 * 
			 * String serverUrl = applicationProp.getString(CommonConstant.STR_SERVER_URL);
			 * 
			 * String randId = UUID.randomUUID().toString(); UserSecTransAudit secTransAudit
			 * = new UserSecTransAudit(); secTransAudit.setUserAccount(user);
			 * secTransAudit.setIsActive(true); secTransAudit.setCreatedOn(new Date());
			 * secTransAudit.setRandomId(randId); secTransAudit.setMode("AddUser"); if
			 * (willSendOnBoardWelcomeLink.equals("Y") &&
			 * !existEmailAndNewEqual.equals("true")) {
			 * userSecTransAuditService.saveUserSecTransAudit(secTransAudit); }
			 * 
			 * String onboardURL = serverUrl + CommonConstant.STR_WELCOME + randId;
			 * 
			 * onboardURL = new UrlShortener().shortenURL(onboardURL,
			 * user.getUserAccountId()); smsMsgTxt = smsMsgTxt.replaceAll("<hsp_name>",
			 * patCpDTO.getHsp().getName());
			 * 
			 * smsMsgTxt = smsMsgTxt.replaceAll("<onboardURL>", onboardURL); smsMsgTxt =
			 * smsMsgTxt.replaceAll("<Pat_FirstName>", user.getFirstName()); smsMsgTxt =
			 * smsMsgTxt.replaceAll("<surgeon_name>", sugtemp.getSalutation() +
			 * sugtemp.getFirstName() + " " + sugtemp.getLastName());
			 * 
			 * rpsEmailMsgTxtNew = rpsEmailMsgTxtNew.replaceAll("<<server_url>>",
			 * serverUrl); rpsEmailMsgTxtNew = rpsEmailMsgTxtNew.replaceAll("<<randomId>>",
			 * CommonConstant.STR_WELCOME + randId);
			 * 
			 * // rpsEmailMsgTxtNew = rpsEmailMsgTxtNew.replaceAll("<<UnSubscribeURL>>", //
			 * applicationProp.getString("unsubscribeurl")); rpsEmailMsgTxtNew =
			 * rpsEmailMsgTxtNew.replaceAll("<<userAccountId>>",
			 * user.getUserAccountId().toString()); String perverUrl =
			 * applicationProp.getString(PSERVERURL); UserAccount rpsCreatedAccount =
			 * userAccRepo.findById(patCpDTO.getPatientSwfList().get(0).getHspCCId()).orElse
			 * (null); Hospital createdAccountHsp =
			 * hospitalRepo.findById(rpsCreatedAccount.getUserAccountKey()).orElse(null);
			 * String purl = createdAccountHsp.getCode(); purl = purl.toLowerCase();
			 * rpsEmailMsgTxtNew =
			 * rpsEmailMsgTxtNew.replaceAll(CommonConstant.STR_PSERVER_URL, perverUrl +
			 * purl);
			 */
			/** TODO NOTIFICATION */

			/**
			 * String ctxpath = applicationProp.getString("EmailImagePath");
			 * 
			 * 
			 * String ripplecarelogo = rbMessageContent.getString("ripplecarelogo"); String
			 * activate = rbMessageContent.getString("activate"); String jcLogo =
			 * rbMessageContent.getString("JClogo");
			 * 
			 * String notifyUpdateMailTxt = fetchNotifyUpdateMailTxt(patient, rb2); String
			 * notifyUpdateSmsMsgTxt = fetchNotifyUpdateSmsMsgTxt(patient, rb2); String
			 * notifyUpdateMobileMailTxt = fetchNotifyUpdateMobileMailTxt(userAccount, rb2);
			 * String notifyUpdateEmailSmsTxt = fetchNotifyUpdateEmailSmsTxt(userAccount,
			 * rb2);
			 * 
			 * String emailSubject = ""; String[] notifyInfos = {cc, bcc, ctxpath,
			 * ripplecarelogo, activate, jcLogo, surUserAcc.getImagePath(), smsMsgTxt,
			 * emailSubject, rpsEmailMsgTxtNew, notifyUpdateMailTxt, existEmailAndNewEqual,
			 * willSendOnBoardWelcomeLink, notifyUpdateEmailSmsTxt, notifyUpdateSmsMsgTxt,
			 * existPhoneAndNewEqual, notifyUpdateMobileMailTxt};
			 * executeToEmailConfigureAndSend(user, hsp, sugtemp, notifyInfos, rb2);
			 */
		}
	}

	private String fetchEmailContentFrom(UserGroup loginUserGroup, UserAccount userAccount, ResourceBundle rb2) {
		String emailContent = "";
		try {
			if (loginUserGroup.getGroupType().equalsIgnoreCase("PATIENT")) {
				if (userAccount.getComType() != null && userAccount.getComType().equalsIgnoreCase("Both")) {
					emailContent = rb2.getString("practemailcontentwithunsubscribe");
				} else {
					emailContent = rb2.getString("practemailcontentwithoutunsubscribe");
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return emailContent;
	}

	private PatientFlagResponseData preEmailPhoneConfigureAndSend(UserAccount user, PatientVitalData patVitalData,
			String willSendOnBoardWelcomeLink, Patient patient, PatientCarePartnerDTO patCpDTO,
			PatientFlagResponseData flagResp) {
		Hospital hsp = null;
		List<PatientStageWorkflow> patientSwf = new ArrayList<>();
		String existEmailAndNewEqual = "true";
		String existPhoneAndNewEqual = "true";
		String oldPhone = user.getPhone() != null ? user.getPhone() : "";
		String oldEmail = user.getEmail() != null ? user.getEmail() : "";
		if (!oldEmail.equals(patVitalData.getPatEmail())) {
			existEmailAndNewEqual = CommonConstant.FALSE;
		}
		if (willSendOnBoardWelcomeLink.equalsIgnoreCase("Y") && existEmailAndNewEqual.equalsIgnoreCase("true")
				&& !oldPhone.equals(patVitalData.getPatPhone())) {
			existEmailAndNewEqual = CommonConstant.FALSE;
		}
		if (!oldPhone.equals(patVitalData.getPatPhone())) {
			existPhoneAndNewEqual = CommonConstant.FALSE;
		}

		if (user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_PATIENT)) {
			UserAccount patUser = patient.getCreatedByUa();
			hsp = hospitalRepo.findById(patUser.getUserAccountKey()).orElse(null);
			patientSwf = pswfRepo.findByPatient_PatientId(user.getUserAccountKey());
		} else if (user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_CAREPARTNER)) {
			List<CarePartnerMap> cpmlist = carePartnerMapService
					.getActiveCarePartnerMapbyCpUseraccount(user.getUserAccountId());
			if (!cpmlist.isEmpty()) {
				Patient pat = patientRepo.findById(cpmlist.get(0).getPatientId()).orElse(null);
				patientSwf = pswfRepo.findByPatient_PatientId(pat.getPatientId());

				UserAccount cpUser = userRepository.findById(patientSwf.get(0).getHspCCId()).orElse(null);
				hsp = hospitalRepo.findById(cpUser.getUserAccountKey()).orElse(null);

			} else {
				flagResp.setIsEmailUpdate(true);
				flagResp.setIsPhoneUpdate(true);
				flagResp.setIsEmailorPhone("Not Update Sucessfully");
//				return flagResp;

			}
		}
		patCpDTO.setExistEmailAndNewEqual(existEmailAndNewEqual);
		patCpDTO.setExistPhoneAndNewEqual(existPhoneAndNewEqual);
		patCpDTO.setHsp(hsp);
		patCpDTO.setPatientSwfList(patientSwf);
		return flagResp;
	}

	private void updateOtherAccountByPatient(UserAccount patUser, String oldEmail, String oldPhone,
			String oldTeleCode) {
		try {
			String defaultUserName = GenerateOTP.getAlphaNumericForUserName();
			oldTeleCode = oldTeleCode.replace("+", "");
			String oldphonedetails = ((oldPhone != null && !oldPhone.isEmpty()) ? oldTeleCode + "-" + oldPhone : "");
			List<UserAccount> allUser = userAccountService.getUsersByEmailId(oldEmail, oldphonedetails);

			for (UserAccount usrList : allUser) {
				Boolean userNameCheck = patUser.getEmail() != null && patUser.getEmail().contains("@") ? true : false;
				usrList.setUserName(userNameCheck ? patUser.getEmail() : defaultUserName);
				usrList.setEmail(RCUserUtil.getUserContactDetail(patUser.getEmail()));
				usrList.setPhone(patUser.getPhone());
				usrList.setComType(patUser.getComType());
				userAccRepo.save(usrList);
				if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(patUser))) {
					/** TODO NOTIFICATION */
//					messageService.contactPreValidation(patUserId, "Phone");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private PatientFlagResponseData draftObjectToGetPhoneExistbyPatient(PatientVitalData patVitalData, UserAccount user,
			Patient patientNew, PatientFlagResponseData flagResp) {
		try {
			String phone = patVitalData.getPatPhone();
			Boolean phoneFlag = patVitalData.getIsPhoneUpdate();
			String teleCode = "+1";
			String cCode = "USA";
			if (phoneFlag && !phone.isEmpty() && phone.trim().length() != 0) {
				Boolean existPhone = userAccountService.checkIfPhoneNumExists(teleCode, phone);
				if (!existPhone) {
					user.setPhone(RCUserUtil.getNonEmptyString(phone));
					user.setTeleCode(teleCode);
					user.setTeleCountryCode(cCode);

					if (patientNew != null
							&& user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_PATIENT)) {
						patientNew.setPhone(RCUserUtil.getNonEmptyString(phone));
						patientNew.setTeleCode(teleCode);
						patientNew.setTeleCountryCode(cCode);
					}

				} else {

					flagResp.setIsEmailUpdate(false);
					flagResp.setIsPhoneUpdate(true);
					flagResp.setIsEmailorPhone("phoneNo Exist");
					return flagResp;

				}
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return flagResp;
	}

	private PatientFlagResponseData draftObjectToGetEmailExistbyPatient(PatientFlagResponseData flagResp,
			String oldEmail, PatientVitalData patVitalData, Patient patientNew, UserAccount user) {
		try {
			if (patVitalData.getIsEmailUpdate() && patVitalData.getPatEmail() != null
					&& patVitalData.getPatEmail().trim().length() != 0) {
				if (oldEmail.trim().length() == 0 && oldEmail.isEmpty()) {

					String existEmailAndNewEqual1 = userAccountService.checkIfExistUserAndNewEmailSameForPatientId(0l,
							patVitalData.getPatEmail());
					if (existEmailAndNewEqual1.equalsIgnoreCase(CommonConstant.FALSE)) {
						if (patientNew != null
								&& user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_PATIENT)) {
							patientNew.setEmail(RCUserUtil.getUserContactDetail(patVitalData.getPatEmail()));
						}
						user.setEmail(RCUserUtil.getUserContactDetail(patVitalData.getPatEmail()));
						user.setUserName(patVitalData.getPatEmail());
					} else {

						flagResp.setIsEmailUpdate(true);
						flagResp.setIsPhoneUpdate(false);
						flagResp.setIsEmailorPhone("Email Exist");
						return flagResp;
					}

				} else if (!oldEmail.equalsIgnoreCase(patVitalData.getPatEmail())) {

					Boolean existEmail = userAccountService.checkIfPatientEmailExists(0l, patVitalData.getPatEmail());

					if (!existEmail) {
						user.setUserName(patVitalData.getPatEmail());
						user.setEmail(RCUserUtil.getUserContactDetail(patVitalData.getPatEmail()));
						if (patientNew != null
								&& user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_PATIENT)) {
							patientNew.setEmail(RCUserUtil.getUserContactDetail(patVitalData.getPatEmail()));
						}
					} else {
						flagResp.setIsEmailUpdate(true);
						flagResp.setIsPhoneUpdate(false);
						flagResp.setIsEmailorPhone("Email Exist");
						return flagResp;

					}

				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return flagResp;
	}

	private void sendSmsForOtherUser1(List<PatientVitalData> patVitalDataList) {
		for (PatientVitalData patVitalData : patVitalDataList) {
			if (patVitalData.getIsEmailUpdate() || patVitalData.getIsPhoneUpdate()) {
				Boolean isOtherUser = patVitalData.getIsOtherUser();
				String defaultUserName = GenerateOTP.getAlphaNumericForUserName();
				if (Boolean.TRUE.equals(isOtherUser)) {
					Long userId = patVitalData.getUserAccountId();
					UserAccount patUa = userRepository.findById(userId).orElse(null);
					updateOrDeactCp(patVitalData, defaultUserName, patUa);
				} else {

					Patient patient1 = patientRepo.findById(patVitalData.getPatId()).orElse(null);
					UserAccount patUa1 = userAccRepo
							.findByUserAccountKeyAndAndUserGroup_UserGroupIdIn(patVitalData.getPatId(), List.of(19l))
							.get(0);
					List<PatientStageWorkflow> patientSwfList = pswfRepo
							.findByPatient_PatientId(patVitalData.getPatId());
					updateorDeactivatePatient(patVitalData, defaultUserName, patient1, patUa1, patientSwfList);
				}
			}
		}

	}

	private void updateorDeactivatePatient(PatientVitalData patVitalData, String defaultUserName, Patient patient1,
			UserAccount patUa1, List<PatientStageWorkflow> patientSwfList) {
		try {

			String patEmail = patVitalData.getPatEmail();
			String patPhone = patVitalData.getPatPhone();
			patEmail = RCUserUtil.getNonEmptyString(patEmail);
			patPhone = RCUserUtil.getNonEmptyString(patPhone);
			if (patEmail == null && patPhone == null) {
				if ((patUa1.getEmail() != null && !patUa1.getEmail().isEmpty())
						|| (patUa1.getPhone() != null && !patUa1.getPhone().isEmpty())) {
					/**
					 * PatientOldDetail patOldDetail = new PatientOldDetail();
					 * patOldDetail.setEmail(patUa1.getEmail());
					 * patOldDetail.setPhoneWithTelecode(patUa1.getPhone() != null ?
					 * patUa1.getTeleCode()+patUa1.getPhone() : null);
					 * patOldDetail.setPatientUaId(patUa1.getUserAccountId());
					 * patOldDetail.setRemovedDate(new Date());
					 * userService.updatePatientOldDetail(patOldDetail);
					 */
				}

				patUa1.setUserName(defaultUserName);
				patUa1.setEmail(patEmail);
				patUa1.setPhone(patPhone);
				patUa1.setComType(patVitalData.getComType());

				patient1.setEmail(patEmail);
				patient1.setPhone(patPhone);
				patient1.setComType(patVitalData.getComType());

				userAccRepo.save(patUa1);
				patientRepo.save(patient1);
				/***
				 * CarePartnerMap cpm =
				 * careService.getActiveCarePartnerMapByPatient(patient1.getPatientId());
				 * deactivatetheActiveCp(cpm);
				 ***/

			} else {
				UserAccount patUser = null;
				UserAccount loginUser = userRepository.findByUserAccountKey(patVitalData.getPatId()).stream()
						.findFirst().orElse(null);
				Long patientId = patUa1.getUserAccountKey();
				String oldEmailId = RCUserUtil.getString(patUa1.getEmail());
				String oldPhone = RCUserUtil.getString(patUa1.getPhone());
				String oldComType1 = patUa1.getComType();
				Long userAccountId = patUa1.getUserAccountId();
				String userGroupIdStr = String.valueOf(patUa1.getUserGroup().getUserGroupId());
				String comType = patVitalData.getComType();

				if (userGroupIdStr.equals("19")) {
					Patient pat = patientRepo.findById(patientId).orElse(null);
					patUser = userAccountService.getUserAccountByUserAccountId(pat.getCreatedBy());
				}
				Hospital hsp = hospitalRepo.findById(patUser.getUserAccountKey()).orElse(null);
				Boolean userNameCheck = patEmail != null && patEmail.contains("@") ? true : false;
				patUa1.setUserName(userNameCheck ? patEmail : defaultUserName);

				String userValue = "";
				userValue = getUserValue(patUa1);
				UserAccount user = userAccountService.validateUserNew(userValue).stream().findFirst().orElse(null);
				defaultUserName = GenerateOTP.getAlphaNumericForUserName();
				user.setEmail(RCUserUtil.getStringNull(patEmail));
				patient1.setEmail(RCUserUtil.getStringNull(patEmail));
				user.setPhone(RCUserUtil.getStringNull(patPhone));
				patient1.setPhone(RCUserUtil.getStringNull(patPhone));
				Boolean userNameCheck1 = user.getUserName() != null && user.getUserName().contains("@")
						&& user.getUserName().contains("$$") ? true : false;
				Boolean userNameCheck2 = user.getUserName() != null && user.getUserName().contains("@") ? true : false;
				if (userNameCheck1)
					user.setUserName(patEmail + "$$" + user.getUserAccountId());
				else {
					user.setUserName(userNameCheck2 ? patEmail : defaultUserName);
				}

				user.setTeleCode("+1");
				user.setTeleCountryCode("USA");
				user.setComType(RCUserUtil.getComType(patEmail, patPhone));
				patient1.setComType(RCUserUtil.getComType(patEmail, patPhone));
				String willSendOnBoardWelcomeLink = userAccountService.willSendOnBoardWelcomeLink(userAccountId,
						patEmail, patPhone);
				if (willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P")) {
					user.setIsOnBoardLinkSent(true);
					user.setOnBoardLinkSentOn(new Date());
				}
				String existEmailAndNewEqual = userAccountService
						.checkIfExistUserAndNewEmailSameForPatientId(user.getUserAccountId(), user.getEmail());
				userAccRepo.save(user);

				patientRepo.save(patient1);

				String existPhoneAndNewEqual = "true";
				if (!oldEmailId.equals(patEmail) && willSendOnBoardWelcomeLink.equalsIgnoreCase("Y")
						&& existEmailAndNewEqual.equalsIgnoreCase("true")
						&& !oldPhone.equals(patVitalData.getPatPhone())) {
					existEmailAndNewEqual = CommonConstant.FALSE;
				}
				if (!oldPhone.equals(patPhone)) {
					existPhoneAndNewEqual = CommonConstant.FALSE;
				}
				/** TODO NOTIFICATION */
//					String[] devreststrparams2 = { existEmailAndNewEqual, existPhoneAndNewEqual };
//					configEmailandSend(patient1, patientSwfList, loginUser, hsp, user,
//							willSendOnBoardWelcomeLink, devreststrparams2);
				sendSmsforOtherUser(oldComType1, user);

			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	private void updateOrDeactCp(PatientVitalData patVitalData, String defaultUserName, UserAccount patUa) {
		try {

			String cpemail = patVitalData.getPatEmail();
			String cpPhone = patVitalData.getPatPhone();
			cpemail = RCUserUtil.getNonEmptyString(cpemail);
			cpPhone = RCUserUtil.getNonEmptyString(cpPhone);
			if (cpemail == null && cpPhone == null) {
				patUa.setUserName(defaultUserName);
				patUa.setEmail(cpemail);
				patUa.setPhone(cpPhone);
				patUa.setActive(false);

				patUa.setComType(patVitalData.getComType());
				userAccRepo.save(patUa);
				List<CarePartnerMap> carePartnerPatList = carePartnerMapService
						.getCarePartnerPatientList(patUa.getUserAccountId());
				List<Long> cpMapIds = carePartnerPatList.stream().map(CarePartnerMap::getCarePartnerMapId)
						.collect(Collectors.toList());
				deactivateCpRole(cpMapIds);
			} else {
				String oldEmailId = RCUserUtil.getString(patUa.getEmail());
				String oldPhone = RCUserUtil.getString(patUa.getPhone());
				String oldComType = patUa.getComType();

				String email = patVitalData.getPatEmail();
				String phone = patVitalData.getPatPhone();
				String comType = patVitalData.getComType();
				userAccountService.updateUserProfileAccount(patUa, oldEmailId, oldPhone, true, defaultUserName);
				String userValue1 = "";
				userValue1 = getUserValue(patUa);
				updateUserAccAndPAt(defaultUserName, oldPhone, email, phone, comType, userValue1);
				sendSmsforOtherUser(oldComType, patUa);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

	}

	private void sendSmsforOtherUser(String oldComType, UserAccount patUa) {
		if (patUa.getWelcomeFlag()) {
			String newComType = patUa.getComType();

			if ((oldComType.equalsIgnoreCase("None") || oldComType.equalsIgnoreCase(CommonConstant.EMAIL))
					&& (newComType.equalsIgnoreCase("SMS") || newComType.equalsIgnoreCase("TEXT")
							|| newComType.equalsIgnoreCase("BOTH"))) {
				if (patUa.getTeleCode() != null && patUa.getPhone() != null) {
					/** TODO NOTIFICATION */
//					String smsContent = config.getString(CommonConstant.SMS_NOTIFICATION_START);
//					smsContent = smsContent.replace(SERVERURL,
//							applicationProp.getString(CommonConstant.STR_SERVER_URL));
//					new SMS().smsSend(patUa.getTeleCode().concat(patUa.getPhone()), smsContent);
				}
			} else if ((oldComType.equalsIgnoreCase("SMS") || oldComType.equalsIgnoreCase("TEXT")
					|| oldComType.equalsIgnoreCase("BOTH"))
					&& (newComType.equalsIgnoreCase("None") || newComType.equalsIgnoreCase(CommonConstant.EMAIL))
					&& patUa.getTeleCode() != null && patUa.getPhone() != null) {
				/** TODO NOTIFICATION */
//				String smsContent = config.getString(CommonConstant.SMS_NOTIFICATION_STOP);
//				smsContent = smsContent.replace(SERVERURL, applicationProp.getString(CommonConstant.STR_SERVER_URL));
//				new SMS().smsSend(patUa.getTeleCode().concat(patUa.getPhone()), smsContent);
			}
		}
	}

	private void updateUserAccAndPAt(String defaultUserName, String oldPhone, String email, String phone,
			String comType, String userValue1) {
		try {

			UserAccount user = userAccountService.validateUserNew(userValue1).stream().findFirst().orElse(null);
			Long userAccountId = user.getUserAccountId();
			user.setEmail(RCUserUtil.getStringNull(email));
			user.setPhone(RCUserUtil.getStringNull(phone));
			user.setTeleCode("+1");
			user.setTeleCountryCode("USA");
			boolean existFlag = userAccountService.checkIfPatientEmailExists(user.getUserAccountId(), user.getEmail());

			user = setUserName(defaultUserName, email, user, existFlag);
			user.setComType(RCUserUtil.getComType(email, phone));

			String willSendOnBoardWelcomeLink = userAccountService.willSendOnBoardWelcomeLink(userAccountId, email,
					phone);
			if (willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P")) {
				user.setIsOnBoardLinkSent(true);
				user.setOnBoardLinkSentOn(new Date());
			}
			String existEmailAndNewEqual = userAccountService
					.checkIfExistUserAndNewEmailSameForPatientId(user.getUserAccountId(), user.getEmail());
			userAccRepo.save(user);
			if (willSendOnBoardWelcomeLink.equalsIgnoreCase("Y") && existEmailAndNewEqual.equalsIgnoreCase("true")
					&& !oldPhone.equals(phone)) {
				existEmailAndNewEqual = CommonConstant.FALSE;
			}
			updatePatient(user);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	private void updatePatient(UserAccount user) {
		if (user.getUserGroup().getGroupName().equalsIgnoreCase(UserGroupCons.STR_PATIENT)) {
			Patient patt = patientRepo.findById(user.getUserAccountKey()).orElse(null);
			patt.setFirstName(user.getFirstName());
			patt.setLastName(user.getLastName());
			patt.setEmail(user.getEmail());
			patt.setComType(user.getComType());
			patt.setPhone(user.getPhone());
			patt.setImagePath(user.getImagePath());
			patientRepo.save(patt);
		}
	}

	private UserAccount setUserName(String defaultUserName, String email, UserAccount user, boolean existFlag) {
		String updateString = "";
		if (user.getUserName().contains("$$")) {
			updateString = user.getEmail() + "$$" + user.getUserAccountId();
		} else {
			updateString = user.getEmail();
		}
		if (existFlag && user.getEmail() != null) {
			user.setUserName(updateString);
		} else {
			if (email != null && !email.isEmpty()) {
				user.setUserName(email);
			} else {
				user.setUserName(defaultUserName);
			}
		}
		return user;
	}

	private String getUserValue(UserAccount patUa) {
		String userValue;
		if (patUa.getEmail() != null && !patUa.getEmail().isEmpty()) {
			userValue = patUa.getEmail();
		} else if (patUa.getPhone() != null && !patUa.getPhone().isEmpty()) {
			userValue = patUa.getTeleCode() + "-" + patUa.getPhone();
		} else {
			userValue = "0";
		}
		return userValue;
	}

	private void deactivateCpRole(List<Long> cpMapIds) {
		try {
			carePartnerMapRepo.deActivateCarePartnerRole(cpMapIds);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}
}
