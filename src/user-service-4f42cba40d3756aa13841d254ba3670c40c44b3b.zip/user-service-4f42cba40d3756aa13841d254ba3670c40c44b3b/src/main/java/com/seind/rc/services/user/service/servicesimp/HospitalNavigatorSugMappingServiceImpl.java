package com.seind.rc.services.user.service.servicesimp;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.entities.HospitalNavigatorSugMapping;
import com.seind.rc.services.user.repository.HospitalNavigatorSugMappingRepository;
import com.seind.rc.services.user.service.HospitalNavigatorSugMappingService;

@Service
public class HospitalNavigatorSugMappingServiceImpl implements HospitalNavigatorSugMappingService {

	private static final Logger LOGGER = LogManager.getLogger(HospitalNavigatorSugMappingServiceImpl.class);

	@Autowired
	private HospitalNavigatorSugMappingRepository hNSugMapRepo;

	/**
	 * M01
	 */
	@Override
	public List<HospitalNavigatorSugMapping> getHospitalNavigatorSugMappingBysurgeonAccId(Long hspSurgId) {
		List<HospitalNavigatorSugMapping> hNSugMap = null;
		try {
			hNSugMap = hNSugMapRepo.findBysurgeonAccountId(hspSurgId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return hNSugMap;
	}

}
