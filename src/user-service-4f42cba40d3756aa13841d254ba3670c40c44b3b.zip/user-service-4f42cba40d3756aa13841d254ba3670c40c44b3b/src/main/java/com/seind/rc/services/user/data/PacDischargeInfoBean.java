package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PacDischargeInfoBean {

	private Long patientPacMasterMapId;
	private String anonymousDischargeId;
	private String anonymousDischargeHospitalMasterId;
	private String anonymousPrevDiscTypeId;
	private boolean isPacFinished;
}