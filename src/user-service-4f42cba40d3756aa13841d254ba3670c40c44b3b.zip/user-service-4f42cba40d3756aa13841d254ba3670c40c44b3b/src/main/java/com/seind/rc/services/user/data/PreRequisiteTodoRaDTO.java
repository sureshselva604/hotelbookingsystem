package com.seind.rc.services.user.data;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PreRequisiteTodoRaDTO {

	private List<PatInfoAllTodoViewData> patInfoAllTodoViewData;
	private List<Long> allCnIdsList;
	private Map<String, PatInfoAllTodoViewData> patientInfoAllTodoViewMap;
	private TodoInfoBean todoInfoBean;
	private List<AllTodoListViewData> allTodoListViewDataList;
	private int totalPages;
	private long totalElements;
	private List<Long> patientSwFIdList;
	private Boolean hasSearch;
	private String todoListingSectionAPI;
}