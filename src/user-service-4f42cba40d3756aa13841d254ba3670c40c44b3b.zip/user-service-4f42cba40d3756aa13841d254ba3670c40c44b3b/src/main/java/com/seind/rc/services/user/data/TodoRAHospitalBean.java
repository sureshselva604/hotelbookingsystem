package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class TodoRAHospitalBean {

	private Long hospitalId;
	private String name;
	private boolean multiStatus;
	private boolean isOverlap;
	private boolean isSelected;
	private List<TodoRAHospitalMultiSOSBean> todoRAHospitalMultiSOSBean;
}
