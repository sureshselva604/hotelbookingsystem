package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "LoginHistory")
public class LoginHistory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long historyId;
	private String userName;
	private String password;
	private Date loginTime;
	private String mode;
	private String iPAddress;
	private String browser;
	private Boolean passwordValid;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserAccountId")
	private UserAccount userAccountId;

	

}
