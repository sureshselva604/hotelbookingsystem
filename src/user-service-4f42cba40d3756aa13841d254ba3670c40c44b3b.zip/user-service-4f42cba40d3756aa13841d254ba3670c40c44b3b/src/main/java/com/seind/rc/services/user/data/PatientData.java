package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor

public class PatientData {
	private Long patientId;
	private Long practiceSurgeonId;
	private Long hospitalPracticeId;
	private String code;
	private String firstName;
	private String lastName;
	private Date dob;
	private String email;
	private String phone;
	private String description;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String country;
	private String zipcode;
	private Boolean active;
	private Boolean isUploaded;
	private Date createdDate;
	private Long createdBy;
	private Date lastModifiedDate;
	private Long lastModifiedBy;
	private Date deactivatedDate;
	private String imagePath;
	private String randomId;
	private Boolean isDelete;
	private String gender;
	private Long notificationId;
	private String onOffTrackStatus;
	private String mrn;
	private String chiefComplaint;
	private Long hospitalSurgeonId;
	private String bloodGroup;
	private Boolean hasCarePartner;
	private String adherence;
	private String engagement;
	private String readmitPercent;
	private String comType;
	private String medicare;
	private Long payorType;
	private String ssn;
	private Date dos;
	private String cjr;
	private String mako;
	private String cardLayout;
	private Long height;
	private Long inch;
	private Long weight;
	private String bmi;
	private String hic;
	private String landLine;
	private Boolean isRegularSmoker;
	private Boolean isDiabetic;
	private Boolean isBloodPressure;
	private String teleCode;
	private String teleCountryCode;
	private Boolean isImageUploadDone;
	private Boolean isProfileDone;
	private Boolean isSupportDone;
	private Long enrolledBy;
	private String emailValidStatus;
	private String phoneValidStatus;
	private Boolean activityData;
	private Date activityDataAcceptedOn;
}
