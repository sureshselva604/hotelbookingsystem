package com.seind.rc.services.user.service.servicesimp;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SaveSecQuesAnsData;
import com.seind.rc.services.user.data.SeqQuesSyncModel;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.data.UserSecQuestionAnsData;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecResultDetails;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserSecQuesRepository;
import com.seind.rc.services.user.repository.UserSecResDetRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecResDetService;
import com.seind.rc.services.user.util.DCCPUtil;
import com.seind.rc.services.user.util.OnBoardUtil;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.SSOSyncUtil;
import com.seind.rc.services.user.util.StringEncrypter;

@Service
public class UserSecResDetServiceImpl implements UserSecResDetService {

	private static final Logger LOGGER = LogManager.getLogger(UserSecResDetServiceImpl.class);
	private static final String ONBOARD = "onboard";

	@Autowired
	private UserSecResDetRepository userSecResRepo;

	@Autowired
	private UserSecQuesRepository userSecQuesRepo;

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepo;

	@Autowired
	private UserAccountRepository userAccountRepo;

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private DCCPUtil dccpUtil;

	@Autowired
	private SSOSyncUtil ssosyncUtil;

	@Autowired
	private OnBoardUtil onBoardUtil;

	/**
	 * M01
	 * 
	 * Get all User Security Questions and Answer for a Particular User
	 */
	@Override
	public List<UserSecQuestionAnsData> getSecQuesAns(Long userAccountId) {
		List<UserSecQuestionAnsData> quesAns = new ArrayList<>();
		try {
			UserSecResultDetails userSecResultDetails = userSecResRepo
					.findByUserAccountIdOrderByUserSecResultDetailsIdDesc(userAccountId).stream().findFirst()
					.orElse(null);
			if (userSecResultDetails != null) {

				UserSecQuestionAnsData resDataOne = new UserSecQuestionAnsData(userSecResultDetails.getQuestion1(),
						getQuestion(userSecResultDetails.getQuestion1()), userSecResultDetails.getAnswer1());
				UserSecQuestionAnsData resDataTwo = new UserSecQuestionAnsData(userSecResultDetails.getQuestion2(),
						getQuestion(userSecResultDetails.getQuestion2()), userSecResultDetails.getAnswer2());
				UserSecQuestionAnsData resDataThree = new UserSecQuestionAnsData(userSecResultDetails.getQuestion3(),
						getQuestion(userSecResultDetails.getQuestion3()), userSecResultDetails.getAnswer3());
				quesAns.add(resDataOne);
				quesAns.add(resDataTwo);
				quesAns.add(resDataThree);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return quesAns;
	}

	/**
	 * M02
	 */
	public String getQuestion(Long questionId) {
		String ques = null;
		try {
			ques = userSecQuesRepo.findById(questionId).get().getQuestion();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return ques;
	}

	/**
	 * M03
	 */
	@Override
	public UserSecResultDetails getUserSecResultDetails(Long userAccountId) {
		try {
			List<Long> userAccountIds = userAccountService.fetchUserAccountIdsForMultiUserLogin(userAccountId);
			if (userAccountIds == null) {
				userAccountIds = new ArrayList<>();
			}
			List<UserSecResultDetails> userSecResultDetailList = userSecResRepo.findByUserAccountIdIn(userAccountIds);
			if (userSecResultDetailList != null && !userSecResultDetailList.isEmpty())
				return userSecResultDetailList.get(0);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	/**
	 * M04
	 * 
	 * Find UserAccount using randId and mode in userSecTransAudit then
	 * {@link getSelectedQuestnListByUserSub}
	 */
	@Override
	public List<UserSecQuestionAnsData> getSelectedQuestnListByUser(UpdatePwdData payload) {
		List<UserSecQuestionAnsData> response = new ArrayList<>();
		try {
			UserAccount userAccount = userSecTransAuditRepo
					.findUserAccountByRandomIdAndModeAndIsActive(payload.getRandId(), "ForgetPassword", true).get(0)
					.getUserAccount();
			if (userAccount == null) {
				userAccount = userSecTransAuditRepo
						.findUserAccountByRandomIdAndModeAndIsActive(payload.getRandId(), "ResetPassword", true).get(0)
						.getUserAccount();
			}
			if (userAccount.getActive()) {
				response = getSelectedQuestnListByUserSub(userAccount.getUserAccountId(),
						payload.getWrongUserSecQuestionId());

				LOGGER.debug("showing question successfully");
			} else {
				LOGGER.debug("showing question unsuccessfully");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M05
	 * 
	 * Randomly Selected User Security Question based on conditions
	 * {@link getUserQuestionAnsList}
	 */
	private List<UserSecQuestionAnsData> getSelectedQuestnListByUserSub(Long userAccountId,
			List<Long> wrongUserSecQuestionId) {
		List<UserSecQuestionAnsData> response = new ArrayList<>();
		try {
			List<UserSecQuestionAnsData> userResAns = getSecQuesAns(userAccountId);
			if (wrongUserSecQuestionId != null && !wrongUserSecQuestionId.isEmpty()) {
				response = userResAns.stream().filter(a -> !wrongUserSecQuestionId.contains(a.getQuestionId()))
						.map(a -> {
							a.setAns("");
							return a;
						}).collect(Collectors.toList());
			} else {
				UserSecQuestionAnsData data = new UserSecQuestionAnsData(userResAns.get(0).getQuestionId(),
						userResAns.get(0).getQuestion(), "");
				data.setUserAccountId(userAccountId);
				response.add(data);
			}
			Random randomGenerator = SecureRandom.getInstanceStrong();
			if (!response.isEmpty()) {
				int randomQuestionInt = randomGenerator.nextInt(response.size());
				UserSecQuestionAnsData randomData = response.get(randomQuestionInt);
				randomData.setUserAccountId(userAccountId);
				response.clear();
				response.add(randomData);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	public Boolean staffChecking(UserAccount useracc) {
		Boolean isStaff = false;
		if (useracc.getUserGroup().getUserGroupId() != 19L && useracc.getUserGroup().getUserGroupId() != 20L) {
			isStaff = true;
		} else {
			List<UserAccount> uaList = userAccountService.getUsersByEmailId(useracc.getEmail(),
					(useracc.getPhone() != null ? useracc.getTeleCode() + "-" + useracc.getPhone() : ""));
			for (UserAccount ua : uaList) {
				if (ua.getUserGroup().getUserGroupId() != 19L && ua.getUserGroup().getUserGroupId() != 20L) {
					isStaff = true;
					break;
				}
			}
		}
		return isStaff;
	}

	private void secQuestionUpdateDC(UserAccount useracc, Long questionOne, Long questionTwo, Long questionThree,
			String answerOne, String answerTwo, String answerThree) throws IOException {
		if (useracc != null && useracc.getEmail() != null && !useracc.getEmail().isEmpty()) {
			SeqQuesSyncModel seqQuesSyncModel = new SeqQuesSyncModel();
			seqQuesSyncModel.setQuesIdOne(questionOne);
			seqQuesSyncModel.setQuesIdTwo(questionTwo);
			seqQuesSyncModel.setQuesIdThree(questionThree);
			seqQuesSyncModel.setAnsOne(answerOne);
			seqQuesSyncModel.setAnsTwo(answerTwo);
			seqQuesSyncModel.setAnsThree(answerThree);
			dccpUtil.updateSecQuestInDCCP(useracc.getEmail(), seqQuesSyncModel);
		}
	}

	public void casUpdate(UserAccount useracc, Long[] ques, String[] ans) {
		ExecutorService executorService1 = Executors.newFixedThreadPool(5);
		executorService1.execute(() -> {
			try {
				if (Boolean.TRUE.equals(SSOSyncUtil.validSsoUser(useracc))) {
					/***
					 * String userName = useracc.getUserName(); Long casUserId =
					 * CasUtil.getCasUserIdByUserName(userName); if (casUserId != null) {
					 * CasUtil.deleteExistingSecQues(casUserId);
					 * CasUtil.insertionInCasSecQues(ques[0], ques[1], ques[2], ans[0],
					 * ans[1],ans[2], casUserId); }
					 ***/
					String hroURL = ssosyncUtil.getSSOAPIURL("hro");
					String onboardURL = ssosyncUtil.getSSOAPIURL(ONBOARD);
					SsoSyncData ssoSync = new SsoSyncData();
					ssoSync.setQuesId1(ques[0]);
					ssoSync.setQuesId2(ques[1]);
					ssoSync.setQuesId3(ques[2]);
					ssoSync.setAns1(ans[0]);
					ssoSync.setAns2(ans[1]);
					ssoSync.setAns3(ans[2]);
					ssoSync.setUserName(new StringEncrypter("DES").encrypt(useracc.getEmail()));
					new SSOSyncUtil().updateSecQuestions(ssoSync, hroURL);
					new SSOSyncUtil().updateSecQuestions(ssoSync, onboardURL);
				}
			} catch (Exception e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
			}
		});
		/*** ThreadShutdown ***/
		new RCUserUtil().threadShutdown(executorService1);
	}

	public void obUpdate(Long[] ques, String[] ans, UserAccount useracc) {
		if (useracc.getRcOnBoardId() != null && useracc.getRcOnBoardId() != 0L) {
			onBoardUtil.insertOrUpdateSecQues(useracc, ques[0], ques[1], ques[2], ans[0], ans[1], ans[2]);
		}
	}

	@Override
	public ResponseMessage saveSecurityQuestionAnswer(SaveSecQuesAnsData saveSecQuesData, Long userId) {
		ResponseMessage response = new ResponseMessage();
		UserAccount userAccount = userAccountRepo.findById(userId).orElse(null);
		String languageCode = "";
		try {
			if (userAccount.getUserAccountId() == null) {
				response.setMessage("");
				response.setStatus(CommonConstant.FAILURE);
				return response;
			}
			languageCode = userAccountService.getLanguageCode(userAccount);
			Boolean isStaff = staffChecking(userAccount);
			if (userAccount.getIsdelete() == null || !userAccount.getIsdelete()) {
				Long questionOne = 0L;
				Long questionTwo = 0L;
				Long questionThree = 0L;
				String answerOne = "";
				String answerTwo = "";
				String answerThree = "";
				if (Boolean.TRUE.equals(isStaff) || (userAccount.getUserGroup().getUserGroupId() != 19L
						&& userAccount.getUserGroup().getUserGroupId() != 20L)) {
					questionOne = saveSecQuesData.getSecQuestionOne();
					questionTwo = saveSecQuesData.getSecQuestionTwo();
					questionThree = saveSecQuesData.getSecQuestionThree();
					answerOne = saveSecQuesData.getSecAnswerOne();
					answerTwo = saveSecQuesData.getSecAnswerTwo();
					answerThree = saveSecQuesData.getSecAnswerThree();
					List<UserSecResultDetails> list = userSecResRepo
							.findByUserAccountId(userAccount.getUserAccountId());
					UserSecResultDetails userSecResDetails = null;
					if (!list.isEmpty()) {
						userSecResDetails = list.get(0);
					}
					if (userSecResDetails == null) {
						userSecResDetails = new UserSecResultDetails();
					}
					userSecResDetails.setUserAccountId(userId);
					userSecResDetails.setQuestion1(questionOne);
					userSecResDetails.setQuestion2(questionTwo);
					userSecResDetails.setQuestion3(questionThree);
					userSecResDetails.setAnswer1(answerOne.trim());
					userSecResDetails.setAnswer2(answerTwo.trim());
					userSecResDetails.setAnswer3(answerThree.trim());
					userSecResDetails.setCreatedOn(new Date());
					userSecResDetails.setIrrelevantAns("No");
					userSecResDetails.setWrongAnswerAttempts(0);
					userSecResDetails.setMode("Web");

					Long userSecId = userAccountService.getUserSecResultDetailsAlreadyExist(userId);
					userAccountService.insertOrUpdateUserSecResultDetails(userSecId, userSecResDetails);
				}
				if (userAccount.getUserGroup().getUserGroupId() != 19L
						|| userAccount.getUserGroup().getUserGroupId() != 20L) {
					userAccount.setWelcomeFlag(false);
					userAccountRepo.save(userAccount);
				}
				response.setStatus("Success");
				Long[] quesValues = { questionOne, questionTwo, questionThree };
				String[] ansValues = { answerOne, answerTwo, answerThree };
				casUpdate(userAccount, quesValues, ansValues);
				obUpdate(quesValues, ansValues, userAccount);
				secQuestionUpdateDC(userAccount, questionOne, questionTwo, questionThree, answerOne, answerTwo,
						answerThree);
			} else {
				response.setMessage(rcUserUtil.getSettingsValue(CommonConstant.DEACTIVE_ACCOUNT, languageCode));
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

}
