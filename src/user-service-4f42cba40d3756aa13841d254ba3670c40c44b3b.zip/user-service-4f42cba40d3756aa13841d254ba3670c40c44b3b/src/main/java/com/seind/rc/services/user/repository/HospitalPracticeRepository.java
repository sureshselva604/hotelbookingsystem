package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.seind.rc.services.user.data.TodoHospitalOverlapBean;
import com.seind.rc.services.user.data.TodoRAPracticeOverlapHospitalsData;
import com.seind.rc.services.user.entities.HospitalPractice;

import feign.Param;

public interface HospitalPracticeRepository extends JpaRepository<HospitalPractice, Long> {

	public List<HospitalPractice> findByHospitalId(Long hospitalId);

	public List<HospitalPractice> findByPracticeId(Long practiceId);

	// TODO todo Service
	List<HospitalPractice> findDistinctByPracticeIdAndHospitalIdInAndPractice_DirectClientTrueAndHospital_DirectClientTrue(
			Long practiceId, List<Long> hospitalIds);

	List<HospitalPractice> findByPracticeIdAndActiveTrue(Long hospitalId);

	List<HospitalPractice> findByHospitalIdAndActiveTrue(Long hospitalId);

	public HospitalPractice findDistinctBySecHospitalIdInAndIsOverLapTrue(List<Long> raHospitalIdsList);

	public List<HospitalPractice> findByHospitalIdAndIsOverLapTrue(Long hospitalId);

	public List<HospitalPractice> findByPracticeIdAndIsOverLapFalse(Long practiceId);

	public List<HospitalPractice> findByHospitalIdAndPracticeId(Long hospitalId, Long practiceId);

	public List<HospitalPractice> findByHospitalIdAndIsOverLapFalse(Long loginPracticeOrHspId1);

	@Query(value = "select NEW com.seind.rc.services.user.data.TodoHospitalOverlapBean(ua.userAccountId,ua.firstName,ua.lastName,ua.userGroupId,ug.groupName,0 as isCareCoordinator,h.name) "
			+ " from HNSurgMapToClient hnsmc join HospitalNavigatorSugMapping hnsm on hnsm.hnsugMappingid = hnsmc.hNSurgMapId "
			+ " join HospitalSurgeon hs on hs.surgeon.surgeonId = hnsm.surgeonId  "
			+ " join HospitalPractice hp on hp.practiceId = hs.hospitalId "
			+ " join UserAccount ua on ua.userAccountKey = hp.practiceId and ua.userGroupId in (17) "
			+ " join UserGroup ug on ug.userGroupId  = ua.userGroupId "
			+ " join Hospital h on h.hospitalId = ua.userAccountKey "
			+ " where hnsmc.hospitalId = :hospitalId  order by isCareCoordinator desc  ")
	List<TodoHospitalOverlapBean> getraHospitalOverlapPractice(@Param("hospitalId") Long hospitalId);

	@Query(value = " SELECT NEW com.seind.rc.services.user.data.TodoRAPracticeOverlapHospitalsData(h.hospitalId,sh.name,p.name as practiceName,true as isOverLap,hpp.secHospitalId)"
			+ " from HospitalPractice hp "
			+ " join Hospital h on h.hospitalId = hp.hospitalId and hp.practiceId = :useraccountkey "
			+ " and hp.isOverLap = true join Hospital p on p.hospitalId = hp.practiceId and p.directClient = true "
			+ " join HospitalPractice hpp on hpp.hospitalId = hp.hospitalId "
			+ " join Hospital sh on sh.hospitalId = hpp.secHospitalId ")
	List<TodoRAPracticeOverlapHospitalsData> todoRAPracticeOverlapHospitals(@Param("useraccountkey") Long useraccountkey);

	public List<HospitalPractice> findByPracticeIdAndHospitalId(Long practiceId, Long hospitalId);

	public List<HospitalPractice> findByPracticeIdAndSecHospitalId(Long practiceId, Long hospitalId);

	public List<HospitalPractice> findByPracticeIdAndSecHospitalIdAndIsOverLapTrue(Long dischargeHospitalId,
			Long dischargeSecHospitalId);

	public List<HospitalPractice> findByPracticeIdAndIsOverLapTrue(Long practiceId);
}
