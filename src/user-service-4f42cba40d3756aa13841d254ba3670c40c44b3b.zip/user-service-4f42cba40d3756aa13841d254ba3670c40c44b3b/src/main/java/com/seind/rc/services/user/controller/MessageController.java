package com.seind.rc.services.user.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.data.CCMessageData;
import com.seind.rc.services.user.data.CCpatientInfoForMessage;
import com.seind.rc.services.user.data.EpisodeAppointmentInfo;
import com.seind.rc.services.user.data.MessageApptData;
import com.seind.rc.services.user.data.MessageReqData;
import com.seind.rc.services.user.data.NotesPatientDashBoard;
import com.seind.rc.services.user.data.UserMsgRespData;
import com.seind.rc.services.user.service.UserAccountService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

/**
 * C03
 */
@CrossOrigin
@RestController
@RequestMapping("/api/message")
@RequiredArgsConstructor
public class MessageController {

	private static final Logger LOGGER = LogManager.getLogger(MessageController.class);

	@Autowired
	private UserAccountService userService;

	/**
	 * @param patNotesData--sendBy
	 * @return To return the PatientorCC Name
	 */
	@Operation(summary = "fetch Patient Or CC Name")
	@PostMapping(value = "/getPatientOrCCNameResp")
	public List<NotesPatientDashBoard> getPatientOrCCNameResponse(
			@RequestBody List<NotesPatientDashBoard> patNotesData) {
//		NotesPatientDashBoard patNotesData1 = patNotesData;
		try {
			patNotesData = userService.getPatientOrCCNameResponse(patNotesData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return patNotesData;
	}

	@Operation(summary = "Get cc Patient info for message List Orchectration")
	@PostMapping(value = "/ccPatientInfoForMessages")
	public List<CCpatientInfoForMessage> getCCPatientInfoForMessages(@RequestBody MessageReqData objvalue,
			@RequestHeader(value = "x-user") String xUser) {
		List<CCpatientInfoForMessage> users = null;
		try {
			users = userService.getCCPatientInfoForMessages(objvalue, xUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return users;
	}

	@Operation(summary = "Get User Datas For Message")
	@PostMapping(value = "/getUsersInfoForMessage")
	public List<UserMsgRespData> getUsersInfoForMessage(@RequestBody MessageReqData objvalue) {
		List<UserMsgRespData> users = null;
		try {
			users = userService.getUsersInfoForMessage(objvalue);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return users;
	}

	@PostMapping(value = "/getPPUnReadTotMsgCount")
	public CCMessageData getPPUnReadTotMsgCount(@RequestBody CCMessageData ccMessageData) {
		try {
			ccMessageData = userService.getPPUnReadTotMsgCount(ccMessageData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return ccMessageData;
	}

	@Operation(summary = "Get User Datas For Appointment Message")
	@PostMapping(value = "/getUsersInfoForApptMsg/{title}")
	public MessageApptData getUsersInfoForApptMsg(@RequestBody EpisodeAppointmentInfo apptInfo,@PathVariable String title) {
		MessageApptData msgData = null;
		try {
			msgData = userService.getUsersInfoForApptMsg(apptInfo, title);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return msgData;
	}
}
