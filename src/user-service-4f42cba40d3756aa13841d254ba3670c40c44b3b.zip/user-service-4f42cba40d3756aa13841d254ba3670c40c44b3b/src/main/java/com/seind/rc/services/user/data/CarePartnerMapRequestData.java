package com.seind.rc.services.user.data;
import lombok.Data;

@Data
public class CarePartnerMapRequestData {
	private Long carePartnerId;
	private Long patientId;
	private Boolean isCarePartner;
	private Long loginUserAccountId;
}
