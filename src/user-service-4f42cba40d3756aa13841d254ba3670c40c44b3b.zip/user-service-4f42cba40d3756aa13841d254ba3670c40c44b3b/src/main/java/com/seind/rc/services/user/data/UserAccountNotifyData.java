package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UserAccountNotifyData{
	
	private Long userAccountId;
	private String firstName;
	private String lastName;
	private String gender;
	private Long userAccountKey;
	private String comType;
	private Long whoseCarePartner;
	private String email;
	private String phone;
	private String imagePath;
	private String teleCode;
	private Integer pushNotification;
	private Long userGroupId;
	

}
