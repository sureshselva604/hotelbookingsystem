package com.seind.rc.services.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "NonOverlapViewOnDemand")
@Data
public class NonOverlapViewOnDemand {
	@Id
	private Long Id;
	private Long patientSwfId;
	private Long hospitalId;
	private Long mode;
	private Long hspCCId;
	private Long userAccountId;

}
