package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class TimeZoneData {
	
	private Long zoneId;
    private String zoneCode;
    private String uTCCode;
}
