package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.entities.Cardstatus;

public interface NightJobService {
	
	String getCurrentPatientSwfIds();

	void saveCardStatus(List<Cardstatus> cardStatus);
}
