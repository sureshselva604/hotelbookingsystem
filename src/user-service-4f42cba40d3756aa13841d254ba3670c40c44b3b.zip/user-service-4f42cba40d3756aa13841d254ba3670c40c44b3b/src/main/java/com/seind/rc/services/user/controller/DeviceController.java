package com.seind.rc.services.user.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CareFamilyGroupData;
import com.seind.rc.services.user.data.CareFamilyMessageData;
import com.seind.rc.services.user.data.CarePartnerMapData;
import com.seind.rc.services.user.data.CarePartnerMapRequestData;
import com.seind.rc.services.user.data.CheckPatient;
import com.seind.rc.services.user.data.DeviceActivationData;
import com.seind.rc.services.user.data.DeviceLoginData;
import com.seind.rc.services.user.data.FcmTokenData;
import com.seind.rc.services.user.data.ForgotAttemptData;
import com.seind.rc.services.user.data.ForgotSecQuesData;
import com.seind.rc.services.user.data.HospitalDeviceData;
import com.seind.rc.services.user.data.HospitalListDeviceData;
import com.seind.rc.services.user.data.HospitalSurgeonDeviceData;
import com.seind.rc.services.user.data.LoginRoles;
import com.seind.rc.services.user.data.MenuConfigData;
import com.seind.rc.services.user.data.PatientDeviceRequest;
import com.seind.rc.services.user.data.PatientDeviceResponse;
import com.seind.rc.services.user.data.PatientFlagResponseData;
import com.seind.rc.services.user.data.PatientRequestData;
import com.seind.rc.services.user.data.PatientStatusData;
import com.seind.rc.services.user.data.PatientStatusDeviceData;
import com.seind.rc.services.user.data.PhoneTypeData;
import com.seind.rc.services.user.data.ProfileQuestionsData;
import com.seind.rc.services.user.data.ProfileResultDetailsData;
import com.seind.rc.services.user.data.ResetPatPassReq;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SecurityCredentialData;
import com.seind.rc.services.user.data.StatusResponse;
import com.seind.rc.services.user.data.SurgeonDeviceData;
import com.seind.rc.services.user.data.TimeZoneData;
import com.seind.rc.services.user.data.UpdateCarePartnerMapData;
import com.seind.rc.services.user.data.UpdatePatientData;
import com.seind.rc.services.user.data.UpdateUserDeviceData;
import com.seind.rc.services.user.data.UserDeviceData;
import com.seind.rc.services.user.data.UserGroupData;
import com.seind.rc.services.user.data.UserSecAnsData;
import com.seind.rc.services.user.service.DeviceService;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.HospitalSurgeonService;
import com.seind.rc.services.user.service.PatientDeviceService;
import com.seind.rc.services.user.service.SurgeonService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * C11
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/device")
@RequiredArgsConstructor
public class DeviceController {

	private static final Logger LOGGER = LogManager.getLogger(DeviceController.class);

	@Autowired
	private DeviceService deviceService;

	@Autowired
	private PatientDeviceService patientDeviceService;

	@Autowired
	private HospitalService hospitalService;

	@Autowired
	private HospitalSurgeonService hospitalSurgeonService;

	@Autowired
	private SurgeonService surgeonService;

	@PostMapping(value = "/service/device/getDeviceVersion")
	public @ResponseBody String getDeviceVersion(@RequestBody JsonObject string, HttpServletRequest request) {
		return deviceService.getDeviceVersion(string, request);
	}

	@Operation(summary = "Fetch the phoneType list based on seqNo.")
	@GetMapping(value = "/getPhoneTypeList")
	public List<PhoneTypeData> getPhoneType() {
		List<PhoneTypeData> response = null;
		try {
			response = deviceService.getPhoneType();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Fetch the TimeZone")
	@GetMapping(value = "/getTimeZone")
	public List<TimeZoneData> getTimeZone() {
		List<TimeZoneData> response = null;
		try {
			response = deviceService.getTimeZone();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Fetch the all userGroup list")
	@GetMapping(value = "/getAllUserGroup")
	public List<UserGroupData> getAllUserGroup() {
		List<UserGroupData> response = null;
		try {
			response = deviceService.getAllUserGroup();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Fetch the active carePartner based on patientId or userAccountId")
	@PostMapping(value = "/getCarePartnerMap")
	public List<CarePartnerMapData> getActiveCarePartnerMap(@RequestBody CarePartnerMapRequestData carePartnerMap) {
		List<CarePartnerMapData> response = null;
		try {
			response = deviceService.getActiveCarePartnerMap(carePartnerMap.getIsCarePartner(),
					carePartnerMap.getCarePartnerId(), carePartnerMap.getPatientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@PostMapping(value = "/getBiographyQuestionData")
	public List<ProfileQuestionsData> getBiographyQuestionData() {
		List<ProfileQuestionsData> profileData = null;
		try {
			profileData = deviceService.getBiographyQuestionData();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return profileData;
	}

	@PostMapping(value = "/getBiographyQuestionAnswerData")
	public List<ProfileResultDetailsData> getBiographyQuestionAnswerData(
			@RequestBody PatientRequestData patientReqData) {

		List<ProfileResultDetailsData> profileData = null;
		try {
			profileData = deviceService.getBiographyQuestionAnswerData(patientReqData.getPatientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return profileData;
	}

	@PostMapping(value = "/getHopsitalDetailsByPatientId")
	public HospitalDeviceData getHopsitalDetailsByPatientId(@RequestBody PatientRequestData patientReqData) {
		HospitalDeviceData hsp = null;
		try {
			hsp = deviceService.getHopsitalDetailsByPatientId(patientReqData.getPatientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return hsp;
	}

	@Operation(summary = "Patient and Care Partner Flag Status")
	@PostMapping(value = "/patientStatus")
	public PatientStatusData patientStatus(@RequestBody PatientStatusDeviceData patientData) {
		PatientStatusData patientStatusData = new PatientStatusData();
		try {
			if (patientData.getPatientId() != null && patientData.getPatientId() > 0
					&& (patientDeviceService.findByHandShakeKey(patientData.getHandshakekey())) != null) {
				patientStatusData = patientDeviceService.getPatientStatusDetails(patientData.getPatientId());
			} else {
				patientStatusData.setMessage("Invalid Handshakekey");
				patientStatusData.setStatus("Failure");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return patientStatusData;
	}

	@PostMapping(value = "/forgotAttempt")
	public ResponseMessage forgotAttempt(@RequestBody ForgotAttemptData forgotData) {
		ResponseMessage response = null;
		try {
			response = deviceService.setForgotattemptFailed(forgotData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@PostMapping(value = "/forgotSecurityQuestion")
	public ResponseMessage forgotSecurityQuestion(@RequestBody ForgotSecQuesData forgotData) {
		ResponseMessage response = null;
		try {
			response = deviceService.setForgetSucessAnswer(forgotData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "HospitalList Data for Device Sync")
	@PostMapping(value = "/getHospitalListInfoByPatientId")
	private List<HospitalListDeviceData> getHospitalListInfoByPatientId(@RequestBody CheckPatient request) {

		List<HospitalListDeviceData> response = null;
		try {
			response = hospitalService.getHospitalListInfoByPatientId(request.getPatientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "HospitalSurgeon Data for Device Sync")
	@PostMapping(value = "/getHospitalSurgeonInfoByPatientId")
	private HospitalSurgeonDeviceData getHospitalSurgeonInfoByPatientId(@RequestBody CheckPatient request) {

		HospitalSurgeonDeviceData response = null;
		try {
			response = hospitalSurgeonService.getHospitalSurgeonInfoByPatientId(request.getPatientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Surgeon Data for Device Sync")
	@PostMapping(value = "/getSurgeonInfoByPatientId")
	private List<SurgeonDeviceData> getSurgeonInfoByPatientId(@RequestBody CheckPatient request) {

		List<SurgeonDeviceData> response = null;
		try {
			response = surgeonService.getSurgeonInfoByPatientId(request.getPatientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "All Users Data for Device Sync")
	@PostMapping(value = "/getUsersInfoByPatientId")
	private List<UserDeviceData> getUsersInfoByPatientId(@RequestBody CheckPatient request) {

		List<UserDeviceData> response = null;
		try {
			response = deviceService.getUsersInfoByPatientId(request.getPatientId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * To get Patient or Carepartner Status
	 * 
	 * @param reqData
	 * @return
	 */
	@Operation(summary = "Device Registration for Patient or CarePartner")
	@PostMapping(value = "/patientOrCarepartnerCheckStatus")
	private PatientDeviceResponse patientOrCarepartnerCheckStatus(@RequestBody PatientDeviceRequest reqData) {
		PatientDeviceResponse response = null;
		try {
			response = patientDeviceService.patientOrCarepartnerCheckStatus(reqData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Fetch the HospitalCareNavigatorDetails and CareNavigatorDetails")
	@PostMapping(value = "/getCareFamilyGroup")
	public CareFamilyGroupData getCareFamilyMapping(@RequestBody CarePartnerMapRequestData carePartnerMap) {
		CareFamilyGroupData response = new CareFamilyGroupData();
		try {
			response = deviceService.getCareFamilyGroup(carePartnerMap.getPatientId(),
					carePartnerMap.getLoginUserAccountId());
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION , e);
		}
		return response;
	}

	@Operation(summary = "Fetch the CareNavigatorDetails")
	@PostMapping(value = "/getCareFamilyByMessage")
	public CareFamilyMessageData getCareFamilyByMessageSent(@RequestBody CarePartnerMapRequestData carePartnerMap) {
		CareFamilyMessageData response = new CareFamilyMessageData();
		try {
			response = deviceService.getCareFamilyByMessageSent(carePartnerMap);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "save the Device login data in userLoginAuidt")
	@PostMapping(value = "/deviceLogin")
	public ResponseMessage saveUserLoginAudit(@RequestBody DeviceLoginData deviceLoginData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = deviceService.saveUserLoginAudit(deviceLoginData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "save the DeviceActivationData in userSecTransAudit")
	@PostMapping(value = "/deviceActivation")
	public ResponseMessage saveUserSecTransAudit(@RequestBody DeviceActivationData deviceActivationLoginData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = deviceService.saveUserSecTransAudit(deviceActivationLoginData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * To all Patient Data using Group
	 * 
	 * @param reqData
	 * @return
	 */
	@Operation(summary = "Active Patient Body Part for Care Partner")
	@PostMapping(value = "/activeBodyPartListforCarePartner")
	private List<LoginRoles> activeBodyPartListforCarePartner(@RequestBody PatientDeviceRequest reqData) {
		List<LoginRoles> roleList = new ArrayList<LoginRoles>();
		try {
			roleList = patientDeviceService.activeBodyPartListforCarePartner(reqData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return roleList;
	}

	/**
	 * To get OTPValidation Response
	 * 
	 * @param reqData
	 * @return
	 */
	@Operation(summary = "validateOtpDev")
	@PostMapping(value = "/validateOtpDev")
	private StatusResponse validateOtp(@RequestBody PatientDeviceRequest reqData) {
		StatusResponse statusResp = new StatusResponse();
		try {
			statusResp = patientDeviceService.validateOtpDev(reqData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return statusResp;
	}

	/**
	 * To get patient's Email or Phone Exists Flag Status
	 * 
	 * @param patientData
	 * @return
	 */
	@Operation(summary = "Get Email or Phone Exists Flag Status")
	@PostMapping(value = "/getEmailExistsFlag")
	private PatientFlagResponseData getEmailorPhExistsFlagByPatient(@RequestBody PatientStatusDeviceData patientData) {
		PatientFlagResponseData flagResp = new PatientFlagResponseData();
		try {
			flagResp = patientDeviceService.getEmailorPhExistsFlagByPatient(patientData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return flagResp;
	}

	@Operation(summary = "Save ProfileResultDetails for Device ")
	@PostMapping(value = "/saveProfileResultDetails")
	private ResponseMessage saveProfileResultDetails(@RequestBody List<ProfileResultDetailsData> profileResDataList) {
		ResponseMessage response = null;
		try {
			response = deviceService.saveProfileResultDetails(profileResDataList);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Forgot Attempt Failed Save for Device")
	@PostMapping(value = "/getpatientfogotPassfilesync/forgotAttempt")
	private ResponseMessage forgotAttempt(@RequestBody List<ForgotAttemptData> forgotAttemtData) {

		ResponseMessage response = null;
		try {

			response = deviceService.setForgotattemptFailedUnregisteredUSer(forgotAttemtData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Device Patient password reset")
	@PostMapping(value = "/resetPatientPassword")
	public ResponseMessage resetPatientPassword(@RequestBody ResetPatPassReq patPassReq) {
		ResponseMessage response = null;
		try {
			response = deviceService.resetPatientPassword(patPassReq);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@Operation(summary = "Device Get Password by Patinet DeviceActivation data")
	@PostMapping(value = "/getpasswordbypatient/deviceActivation")
	public ResponseMessage saveLoginAuditForLater(@RequestBody DeviceActivationData deviceActivationData) {
		ResponseMessage response = null;
		try {
			response = deviceService.saveLoginAuditForLater(deviceActivationData);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@Operation(summary = "Device Get Password by Patinet UserSecAnswer data")
	@PostMapping(value = "/getpasswordbypatient/userSecAnswer")
	public ResponseMessage getPassWordUpdatebyPatient(@RequestBody UserSecAnsData userSecAnsData) {
		ResponseMessage response = null;
		try {
			response = deviceService.getPassWordUpdatebyPatient(userSecAnsData);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@Operation(summary = "Save FcmToken for Device")
	@PostMapping(value = "/fcmToken")
	public ResponseMessage saveFcmToken(@RequestBody FcmTokenData fcmToken) {
		ResponseMessage response = null;
		try {
			response = deviceService.saveFcmToken(fcmToken);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@Operation(summary = "Save UserDetails for Device")
	@PostMapping(value = "/user")
	public ResponseMessage updateUserDataDeviceSync(@RequestBody List<UpdateUserDeviceData> userData) {
		ResponseMessage response = null;
		try {
			response = deviceService.updateUserDataDeviceSync(userData);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@Operation(summary = "Update verified status to carePartner")
	@PostMapping(value = "/carePartnerMap")
	public ResponseMessage updateCarePartnerMap(@RequestBody UpdateCarePartnerMapData updateCP) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = deviceService.updateCarePartnerMap(updateCP);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Deactive the SecurityCredentials based on mode")
	@PostMapping(value = "/deactivateSecurityCredentialsByMode")
	public ResponseMessage deactivateSecurityCredentials(@RequestBody SecurityCredentialData secCredential) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = deviceService.deactivateSecurityCredentialsByMode(secCredential);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "update the patientData in patient and userAccount")
	@PostMapping(value = "/updatePatient")
	private ResponseMessage updatePatient(@RequestBody List<UpdatePatientData> updatePatient) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = deviceService.updatePatient(updatePatient);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}
	
	@Operation(summary = "Get Contact Us HTML file")
	@GetMapping(value = "/getContactUsHtml/{patientId}")
	public String getContactUsHtml(@PathVariable Long patientId) {
		return deviceService.getContactUsHtml(patientId);
	}
	
	@Operation(summary = "Get Contact Us JSON")
	@GetMapping(value = "/getContactUsJson/{patientId}")
	public List<MenuConfigData> getContactUsJson(@PathVariable Long patientId) {
		return deviceService.getContactUsJson(patientId);
	}

}
