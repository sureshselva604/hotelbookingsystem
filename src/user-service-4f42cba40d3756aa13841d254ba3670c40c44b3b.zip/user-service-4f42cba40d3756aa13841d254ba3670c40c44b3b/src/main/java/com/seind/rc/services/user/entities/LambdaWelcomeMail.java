package com.seind.rc.services.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Builder;
import lombok.Data;


@Entity
@Data
@Builder
public class LambdaWelcomeMail {

	@Id
	private Long id;
	private Long userAccountId;
	private String email;
	private String patientName;
	private String surgeonName;
	private String imagePath;
	private String hspName;
	private String hspLogo;
	private String code;
	private String randomId;
	private String salutation;
	private String emailAlias;
	private Long zoneId;
	private Long cnactid;
	private Long patientId;
	private Long currentEpisodeId ;
	private Long patientSWFId;
	private Integer createdDate;
	
}
