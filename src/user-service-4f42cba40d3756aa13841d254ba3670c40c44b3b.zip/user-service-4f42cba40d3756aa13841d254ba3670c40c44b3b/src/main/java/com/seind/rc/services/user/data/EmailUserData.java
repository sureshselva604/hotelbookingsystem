package com.seind.rc.services.user.data;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class EmailUserData {
	
	 private String status;
	 private String message;
	 private Long userAccountId;
	 private String firstName;
	 private String lastName;
	 @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy HH:mm:ss.SSS")
	 private Date dob;
	 private String gender;
	 private Long userGroupId;
	 private String groupName;
	 private String mrn;
	 private String ssn;
	 private String hic;
	 private String weight;
	 private String height;
	 private String inch;
	 private String bmi;
	 private String email;
	 private String teleCountryCode;
	 private String teleCode;
	 private String phone;
	 private String otherPhone;
	 private String otherTeleCode;
	 private String otherTeleCountryCode;
	 private String otherPhoneType;
	 private String title;
	 private String imagePath;
	 private String comType;
	 private String notificationFrequency;
	 private boolean realTimeAlert;
	 private boolean realTimeMessage;

}