package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class ProfileResultDetailsData {

	private Long profileResultDetailId;
	private Long userAccountId;
	private String questionIds;
	private String answers;
	private String randomId;
	private Long patientId;
	private Long practiceId;

	public void setAnswer(String answers) {
		this.answers = answers != null ? answers : "";
	}

	public void setRandomId(String randomId) {
		this.randomId = randomId != null ? randomId : "";
	}

}
