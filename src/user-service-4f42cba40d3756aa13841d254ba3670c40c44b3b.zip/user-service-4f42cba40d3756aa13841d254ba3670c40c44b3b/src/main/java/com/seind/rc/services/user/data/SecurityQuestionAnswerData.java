package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class SecurityQuestionAnswerData {
	
	private String randId;
	private Long QuestionId;
	private String answer;

}
