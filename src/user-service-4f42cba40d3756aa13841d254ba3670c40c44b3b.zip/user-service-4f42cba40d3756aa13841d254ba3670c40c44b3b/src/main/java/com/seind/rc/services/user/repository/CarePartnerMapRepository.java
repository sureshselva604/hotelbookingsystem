package com.seind.rc.services.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.seind.rc.services.user.entities.CarePartnerMap;

import jakarta.transaction.Transactional;

@Transactional
public interface CarePartnerMapRepository extends JpaRepository<CarePartnerMap, Long> {

	List<CarePartnerMap> findByUserAccount_UserAccountIdAndPatientId(Long userAccountId, Long patientId);

	List<CarePartnerMap> findByUserAccount_UserAccountIdAndUserAccount_UserGroup_UserGroupIdAndUserAccount_ActiveAndActive(
			Long userAccountId, Long userGroupId, Boolean cpUserAccActive, Boolean cpActive);

	List<CarePartnerMap> findByPatientIdAndActive(Long patientId, Boolean active);

	List<CarePartnerMap> findByPatientIdAndActiveTrueAndUserAccount_UserGroup_UserGroupId(
			Long patientId, Long userGroupId);

	@Modifying
	@Query(value = "update CarePartnerMap  set active=0 where userAccountId not IN :userAccountId and patientId = :patientId", nativeQuery = true)
	Integer updateCarePartnerActive(@Param("patientId") Long patientId,
			@Param("userAccountId") List<Long> userAccountId);

	List<CarePartnerMap> findByPatientId(Long patientId);

	@Modifying
	@Query(value = "update CarePartnerMap  set active=1 where userAccountId  IN :userAccountId and patientId = :patientId", nativeQuery = true)
	Integer updateCarePartnerActiveTrue(@Param("patientId") Long patientId,
			@Param("userAccountId") List<Long> userAccountId);

	@Modifying
	@Query(value = "update CarePartnerMap set verified = 1  where carePartnerMapId =:mappingId", nativeQuery = true)
	Integer updateCarePartnerVerified(@Param("mappingId") Long mappingId);

	List<CarePartnerMap> findByActiveIsTrueAndUserAccount_userAccountIdAndUserAccount_UserGroup_UserGroupId(
			Long carePartnerId, Long userGroupId);

	List<CarePartnerMap> findByActiveAndUserAccount_UserAccountIdAndPatientIdIn(boolean active, Long userAccountId,
			List<Long> patientIds);

	List<CarePartnerMap> findByUserAccount_EmailAndActive(String userName, boolean b);

	List<CarePartnerMap> findByUserAccount_PhoneAndActive(String userName, boolean b);
	
	@Modifying
	@Query(value = "update CarePartnerMap set active = 0  where carePartnerMapId IN :mappingIds", nativeQuery = true)
	void deActivateCarePartnerRole(@Param("mappingIds") List<Long> cpMapIds);
	
	CarePartnerMap findByPatientIdAndActiveTrueAndUserAccount_UserGroup_UserGroupIdAndUserAccount_isdelete(
			Long patientId, Long userGroupId,boolean isdelete);

	List<CarePartnerMap> findByActiveTrueAndUserAccount_UserAccountId(Long userAccountId);
	
	List<CarePartnerMap> findByPatientIdInAndActiveTrueAndUserAccount_UserGroup_UserGroupIdAndUserAccount_isdelete(
			List<Long> patientIdList, Long userGroupId,boolean isdelete);

	Optional<CarePartnerMap> findByPatientIdAndActiveTrue(Long patientId);
	
	List<CarePartnerMap> findByPatientIdIn(List<Long> patientIdList);

}
