package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "UserEvents")
public class UserEvents {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long eventId;
	private Date eventDate;
	private Long adminId;
	private Long clientId;
	private Long loginUserId;
	private Long carepartnerId;
	private Long patientId;
	private Long patSwfId;
	private String category;
	private String comments;
	private Long createdBy;
	private Long adminKey;
	private Long adminRole;
	private Long loginRole;
	private Long cnId;
	

}
