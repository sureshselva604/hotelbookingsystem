package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SurgeonDeviceData {
	
	private Long surgeonId;
	private String degree;
	private String firstName;
	private String lastName;
	private String title;
	private String email;
	private Boolean customWorkflow;
	private String imagePath;
	

	
}
 