package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PracticeCoordinatorHSPMapping;


public interface PracticeCoordinatorHSPMappingRepository extends JpaRepository<PracticeCoordinatorHSPMapping,Long> {

	List<PracticeCoordinatorHSPMapping> findByHospitalPracticeId(Long hospitalPracticeId);
	List<PracticeCoordinatorHSPMapping> findDistinctByHospitalPracticeIdAndActiveTrue(Long hspPracticeId);

	List<PracticeCoordinatorHSPMapping> findByPcUserid(Long userAccountId);

	List<PracticeCoordinatorHSPMapping> findByHospitalPracticeIdAndPcUserAccount_CareFamilyShowTrueAndActiveTrue(
			Long hospitalPracticeId);
	
	List<PracticeCoordinatorHSPMapping> findByHospitalId(Long nonOverlapSelectedSosId);
	
	List<PracticeCoordinatorHSPMapping> findByHspPractice_PracticeIdAndHspPractice_IsOverLapFalse(Long practiceId);

}
