package com.seind.rc.services.user.data;

import java.util.Map;

import lombok.Data;

@Data
public class PacPreValidationBean {
	private Long patientSwfId;
	private Map<Integer, PacDischargeInfoBean> opLocationMap;
	private Long loginUaId;
	private Long userAccountKey;
	private Long dischargeHspId;
	private Long dischargeHospitalId;
	private Long newStageworkFlowId;
	private Long newEpisodeId;

}