package com.seind.rc.services.user.controller;

import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CountryCodeData;
import com.seind.rc.services.user.data.CountryCodeInfo;
import com.seind.rc.services.user.data.EmailUserData;
import com.seind.rc.services.user.data.PatientRequestData;
import com.seind.rc.services.user.data.ProfileData;
import com.seind.rc.services.user.data.ProfileQuestionsData;
import com.seind.rc.services.user.data.ProfileQuestionsList;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SaveSecQuesAnsData;
import com.seind.rc.services.user.data.StatusMessage;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.data.UserExistsReqData;
import com.seind.rc.services.user.data.UserExistsResponse;
import com.seind.rc.services.user.data.UserProfileData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.UserSecQuestionAnsData;
import com.seind.rc.services.user.data.UserUploadImgData;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.CarePartnerMapService;
import com.seind.rc.services.user.service.ProfileResultDetailsService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecResDetService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * C04
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/myprofile")
@RequiredArgsConstructor
public class MyProfileController {

	private static final Logger LOGGER = LogManager.getLogger(MyProfileController.class);

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private UserSecResDetService userSecResDetService;

	@Autowired
	private ProfileResultDetailsService profileResDetailsService;

	@Autowired
	private CarePartnerMapService carePartnerMapService;

	@Autowired
	private UserAccountRepository userRepo;

	@Autowired
	private ModelMapper modelMap;

	/**
	 * Retrieve UserAccount using UserAccountId
	 */
	@Operation(summary = "Retrieve UserAccount using UserAccountId")
	@PostMapping(value = "/getUserAccountByUserAccountId/{userAccountId}")
	public UserAccountData getUserAccountById(@PathVariable("userAccountId") Long userAccountId) {
		UserAccountData userAccountData = null;
		try {
			UserAccount userAccount = userRepo.findById(userAccountId).orElse(null);
			if (userAccount != null) {
				modelMap.getConfiguration().setAmbiguityIgnored(true);
				userAccountData = modelMap.map(userAccount, UserAccountData.class);
				userAccountData.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
				userAccountData.setGroupType(userAccount.getUserGroup().getGroupType());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userAccountData;
	}

//	/**
//	 * Retrieve UserAccount using UserAccountKey
//	 */
//	@Operation(summary = "Retrieve UserAccount using UserAccountKey")
//	@PostMapping(value = "/getUserAccountByUserAccountKey")
//	public UserAccount getUserAccountByKey(@RequestBody CommonObjectData objData) {
//		UserAccount userAccount = null;
//		try {
//			userAccount = userAccountService.getUserAccountByUserAccountKey(objData.getUserAccountKey());
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return userAccount;
//	}

	

	/**
	 * Get SecurityQuestions and Answers for login users
	 */
	@Operation(summary = "Get SecurityQuestions and Answers for login users")
	@PostMapping(value = "/getSecQuesAns")
	public List<UserSecQuestionAnsData> getSecQuesAns(HttpServletRequest request) {
		String xUser = request.getHeader("x-user");
		Long userId = Long.valueOf(xUser);
		List<UserSecQuestionAnsData> userSecQuestionAnsData = null;
		try {
			userSecQuestionAnsData = userSecResDetService.getSecQuesAns(userId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userSecQuestionAnsData;
	}

	/**
	 * Get Profile data for a login user
	 */
	@Operation(summary = "Get Profile data for a login user")
	@PostMapping(value = "/getProfile")
	public UserProfileData getProfile(HttpServletRequest request) {
		String xUser = request.getHeader("x-user");
		Long userId = Long.valueOf(xUser);
		UserProfileData response = new UserProfileData();
		try {
			response = userAccountService.getUserProfile(userId);
		} catch (Exception e) {
			LOGGER.info(e);
		}
		return response;
	}

	/**
	 * Update Profile Questions for a login user
	 */
	@Operation(summary = "Update Profile Questions for a login user")
	@PostMapping(value = "/updateprofilequestions")
	public ResponseMessage updateAboutMe(@RequestBody ProfileQuestionsList profileQues, @RequestHeader(value = "x-user", defaultValue = "1") String xUser)
			throws IOException {
		ResponseMessage statusResponse = new ResponseMessage();
		Long loginUserId = Long.valueOf(xUser);
		try {
			statusResponse = profileResDetailsService.updateProfileAboutMe(profileQues, loginUserId);
		} catch (Exception e) {
			statusResponse.setStatus(CommonConstant.FAILURE);
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return statusResponse;
	}

	/**
	 * Get Profile Question and Answer list for patient
	 */
	@Operation(summary = "Get Profile Question and Answer list for patient")
	@PostMapping(value = "/getUserProfileQuestionsList")
	public ProfileQuestionsList getUserProfileQuestionsList(@RequestHeader(value = "x-user", defaultValue = "1") String xUser) {
		ProfileQuestionsList profileData = new ProfileQuestionsList();
		Long loginUserId = Long.valueOf(xUser);
		try {
			profileData = profileResDetailsService.getUserProfileQuestionsList(loginUserId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return profileData;
	}

	/**
	 * Update Profile data for CC/Patient/CP
	 */
	@Operation(summary = "Update Profile data for CC/Patient/CP")
	@PostMapping(value = "/profileUpdate")
	public ResponseMessage profileUpdate(HttpServletRequest request, @RequestBody ProfileData profileData)
			throws IOException {
		String xUser = request.getHeader("x-user");
		Long userId = Long.valueOf(xUser);
		ResponseMessage response = new ResponseMessage();
		try {
			response = userAccountService.profileUpdate(profileData, userId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@Operation(summary = "Get Country Code")
	@PostMapping(value = "/getphonebycountrycode")
	public CountryCodeData getPhoneNumber(@RequestBody CountryCodeInfo countryCodeInfo) {
		CountryCodeData countryCodeData = new CountryCodeData();
		try {
			countryCodeData = userAccountService.getPhoneNumber(countryCodeInfo);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return countryCodeData;
	}

	/**
	 * Check User Already Exists in RC/MultiRole Check
	 */
	@Operation(summary = "Get User Details by Email or Phone")
	@PostMapping(value = "/getUserByEmailorPhone")
	public EmailUserData getUserByEmailorPhone(@RequestBody UserRequestData reqData) {
		EmailUserData response = new EmailUserData();
		try {
			response = userAccountService.getUserByEmailorPhone(reqData.getUserName(), response);

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * Check User Already Exists in RC/MultiRole Check
	 */
	@Operation(summary = "Get User Exists")
	@PostMapping(value = "/getUserExists")
	public UserExistsResponse getUserExists(@RequestBody UserExistsReqData request) {
		UserExistsResponse response = new UserExistsResponse();
		try {
			response = carePartnerMapService.getUserExists(request, response);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@PostMapping(value = "/getBioGraph")
	public List<ProfileQuestionsData> getBiograph(@RequestBody PatientRequestData patientReqData) {
		List<ProfileQuestionsData> profileData = null;
		try {
			profileData = userAccountService.getBiograph(patientReqData.getPatientId());
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return profileData;
	}

	@PostMapping(value = "/updatePatientDetails")
	public ResponseMessage updatePatientDetails(HttpServletRequest request, @RequestBody ProfileData profileData) {
		String xUser = request.getHeader("x-user");
		Long loginUserId = Long.valueOf(xUser);
		ResponseMessage response = new ResponseMessage();
		try {
			response = userAccountService.updatePatientDetails(profileData, loginUserId);
		} catch (Exception e) {
			response.setUpdateStatus(CommonConstant.FAIL);
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return response;
	}
	
	@PostMapping(value = "/saveSecQuesAns")
	public ResponseMessage saveSecurityQuestionAnswer(HttpServletRequest request,
			@RequestBody SaveSecQuesAnsData saveSecQuesData) {
		String xUser = request.getHeader("x-user");
		Long userId = Long.valueOf(xUser);
		ResponseMessage response = new ResponseMessage();
		try {
			response = userSecResDetService.saveSecurityQuestionAnswer(saveSecQuesData, userId);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	@Operation(summary = "Update User Upload Image")
	@PostMapping(value = "/updateUserUploadImg")
	public StatusMessage updateUserUploadImg(@RequestBody UserUploadImgData userUploadImgData) {
		StatusMessage message = new StatusMessage();
		try {
			return userAccountService.updateUserUploadImg(userUploadImgData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			message.setStatus(false);
		}
		message.setStatus(true);
		return message;
	}
}
