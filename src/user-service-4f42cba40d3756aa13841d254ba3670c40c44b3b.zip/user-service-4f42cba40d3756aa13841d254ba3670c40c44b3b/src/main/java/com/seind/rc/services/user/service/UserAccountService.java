package com.seind.rc.services.user.service;

import java.util.List;

import org.hibernate.service.spi.ServiceException;

import com.seind.rc.services.user.data.CCMessageData;
import com.seind.rc.services.user.data.CCpatientInfoForMessage;
import com.seind.rc.services.user.data.ClientInfo;
import com.seind.rc.services.user.data.ClientList;
import com.seind.rc.services.user.data.CountryCodeData;
import com.seind.rc.services.user.data.CountryCodeInfo;
import com.seind.rc.services.user.data.DobValidationReq;
import com.seind.rc.services.user.data.DobValidationResponse;
import com.seind.rc.services.user.data.EmailUserData;
import com.seind.rc.services.user.data.EpisodeAppointmentInfo;
import com.seind.rc.services.user.data.HospitalContactData;
import com.seind.rc.services.user.data.HospitalPracticeApptInfo;
import com.seind.rc.services.user.data.MessageApptData;
import com.seind.rc.services.user.data.MessageReqData;
import com.seind.rc.services.user.data.NotesPatientDashBoard;
import com.seind.rc.services.user.data.PatientSWFInfo;
import com.seind.rc.services.user.data.ProfileData;
import com.seind.rc.services.user.data.ProfileQuestionsData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SaveUserData;
import com.seind.rc.services.user.data.StatusMessage;
import com.seind.rc.services.user.data.SurgeonDetailsData;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.data.UserDetails;
import com.seind.rc.services.user.data.UserMsgRespData;
import com.seind.rc.services.user.data.UserProfileData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.UserUploadImgData;
import com.seind.rc.services.user.data.UserValidateModel;
import com.seind.rc.services.user.data.UsersData;
import com.seind.rc.services.user.entities.PayorType;
import com.seind.rc.services.user.entities.RKUserAccount;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecResultDetails;

public interface UserAccountService {

	UserAccount getUserAccountByUserAccountId(Long userAccountId);

	List<UsersData> getUsersByHospital(Long hospitalId);

	ResponseMessage saveUser(SaveUserData userDetails, Long loginUserId);

	Long getUserSecResultDetailsAlreadyExist(Long userAccountId);

	boolean insertOrUpdateUserSecResultDetails(Long userSecResultDetailsId, UserSecResultDetails userSecResultDetails);

	public String willSendOnBoardWelcomeLink(Long userAccountId, String newEmail, String newPhone)
			throws ServiceException;

	public void updateUserProfileAccount(UserAccount userAccount, String oldEmailid, String oldPhone, boolean flag,
			String defaultUserName);

	ResponseMessage profileUpdate(ProfileData profileData, Long userId);

	// void updateUserAccount(UserAccount userAccount);

	ResponseMessage validateEmailorPhone(UserValidateModel objData);

	// void saveUserAccountDetails(UserAccount userAccount);

	UserAccount getUserAccountByUserNameAndEmail(String userName);

	List<UserAccount> validateUserNew(String userName);

	List<Long> fetchUserAccountIdsForMultiUserLogin(Long userAccountId);

	RKUserAccount rkValidate(String email);

	List<UserAccount> getUsersByEmailId(String emailId, String phoneNumber);

	List<UserAccount> getUsersByEmailId(String emailId, String phoneNumber, Long userId);

	String getLanguageCode(UserAccount userAccount);

	void activationUpdate(Long userAccountId, String activationMode);

	void updateUserAccountActivationStatusForBothSingleOrMultiRoleUaByEmailOrPhone(UserAccount userAcct);

	void updateSecurityQuestnAttemptsBothSingleAndMultiRole(Long userAccountId, int count);

	List<PayorType> getPayorTypes(Long hospitalId);

	List<UserDetails> getAllCnInSameHospital(UserRequestData data);

	List<UserDetails> getUsersByStrykerAct();

	List<NotesPatientDashBoard> getPatientOrCCNameResponse(List<NotesPatientDashBoard> patNotesData);

	boolean checkIfPatientEmailExists(Long patientId, String email);

	String checkIfExistUserAndNewEmailSameForPatientId(Long userId, String email);

	UserProfileData getUserProfile(Long userId);

	List<UserAccountData> getUserAccountByUserGroupIdAndUserAccountKey(Long userAccountKey, List<Long> userGroupIdIN);

	List<CCpatientInfoForMessage> getCCPatientInfoForMessages(MessageReqData objvalue, String xUser);

	UserAccount getUserExistByUserNameGroupId(String userName, String format, Long userGroupId);

	void updateSecurityQuestionAttempts(Long userAccountId, int count);

	String getCountryCodebyUseraccountKey(Long patientId);

	void updateUserAccountActiveAndLastModifiedDate(Long userAccountId, boolean active);

	Boolean checkIfPhoneNumExists(String teleCode, String phone);

	UserAccount getUserByUserNameAndUserGroup(String userName, String userNameFormat, List<Long> groupIds);

	List<UserMsgRespData> getUsersInfoForMessage(MessageReqData objvalue);

	void contactPreValidation(UserAccount userAccount);

	UserAccount getUserAccountByUserAccountKeyAndUserGroupId(Long userAccountKey, Long userGroupId);

	Long getPhoneLength(String code);

	CCMessageData getPPUnReadTotMsgCount(CCMessageData ccMessageData);

	List<HospitalPracticeApptInfo> fetchMultiHosptialPracticeByHspId(UserAccountData apptRequest);

	CountryCodeData getPhoneNumber(CountryCodeInfo countryCodeInfo);

	EmailUserData getUserByEmailorPhone(String userName, EmailUserData response);

	SurgeonDetailsData getSurveyPartialResult(PatientSWFInfo pSWData);

	List<UserAccountData> getCarePartnerList(Long patientId);

	MessageApptData getUsersInfoForApptMsg(EpisodeAppointmentInfo apptInfo, String title);

	String getSSOAPIURL(String value);

	List<ProfileQuestionsData> getBiograph(Long patientId);

	ResponseMessage updatePatientDetails(ProfileData profileData, Long loginUserId);

	DobValidationResponse getEmailWelcome(DobValidationReq dobValidationReq);

	DobValidationResponse validateuserbyrandid(DobValidationReq dobValidationReq);

	ClientInfo getClientDetails(ClientList client);

	HospitalContactData getContactustemplate(ClientList client);

	StatusMessage updateUserUploadImg(UserUploadImgData userUploadImgData);

}
