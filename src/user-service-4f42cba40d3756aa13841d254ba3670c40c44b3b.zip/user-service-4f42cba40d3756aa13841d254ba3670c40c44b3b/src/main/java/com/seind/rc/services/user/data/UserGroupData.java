package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UserGroupData {
	
	private Long userGroupId;
	private String groupName;
	private String groupType;
	
}
