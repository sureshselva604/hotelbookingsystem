package com.seind.rc.services.user.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.ClientDashboardData;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.AdminService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/admin")
@RequiredArgsConstructor
public class AdminController {

	private static final Logger LOGGER = LogManager.getLogger(AdminController.class);

	

	private final AdminService adminService;	
	private final UserAccountRepository userAccountRepository;
	
	@Operation(summary =  "Client Dashboard Graph Details")
	@GetMapping(value = "/clientDashBoard/{hospitalId}")
	public ClientDashboardData clientDashboardData(@PathVariable Long hospitalId) {

		try {

			return adminService.clientDashboardData(hospitalId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return new ClientDashboardData();
		}
	}
	
//	@GetMapping(value = "/emailcheck/{email}")
//	public int userCheck(@PathVariable String email) {
//		
//	try {
//		
//		return userAccountRepository.findByEmail(email).stream().findFirst().get().getMultiUsers().size();
//	}
//	 catch (Exception e) {
//   	  LOGGER.error(CommonConstant.EXCEPTION,e);
//   	  return 0;
//	}
//		
//		
//	}
//	


	@Operation(summary = "Get DashBoard Count")
	@GetMapping(value = "/dashboardcount")
	public ClientDashboardData getDashBoardCount() {
		try {
			return adminService.getDashBoardCount();
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return new ClientDashboardData();
		}
	}
}
