package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.HospitalContact;

public interface HospitalContactRepository extends JpaRepository<HospitalContact, Long>{

	List<HospitalContact> findByHospitalId(Long clientId);

}
