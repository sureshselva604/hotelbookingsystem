package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class DobValidationResponse {
	private String name;
	private String userName;
	private String firstName;
	private String lastName;
	private String clientLogo;
	private String imagePath;
	private String salutation;
	private String randId;
	private String status;
	private String message;
}
