package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TodoHospitalOverlapBean {

	private Long userAccountId;
	
	private String firstName;
	
	private String lastName;
	
	private Long userGroupId;
	
	private String groupName;
	
	private Integer isCareNavigator;
	
	private String name;
}