package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class DashboardTransactionBean {

	private Long dashboardTransactionId;
	private Long requestedBy;
	private Long clientId;
	private boolean completed;
	private Date requestedDate;
	private Date dosFrom;
	private Date completedDate;
	private String hospitalPracticeId;
	private Date dosTo;
	private String bpcia;
	private String hspSugId;
	private String filePath;
	private String procedureType;
	private String pacEventName;
	private boolean viewStatus;
}
