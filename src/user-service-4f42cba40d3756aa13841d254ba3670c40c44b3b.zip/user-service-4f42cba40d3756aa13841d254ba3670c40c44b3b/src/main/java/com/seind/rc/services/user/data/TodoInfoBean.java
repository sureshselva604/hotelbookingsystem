package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class TodoInfoBean {
	
	private Long clientId;
	private Long loginUaId;
	private Long selectedCnUaId;

	private Long patientSwfId;
	private String startDateRange;
	private String endDateRange;

	private String pracOrHsp;
	private String todoViewMode;
	private Long loginHspOrPracId;

	private Long todoCategoryId;

	private String raSurgeonIds;
	private String raHospitalIds;
	private boolean raHospitalIsOverlap;
	private boolean raSurgeonIsOverlap;
	private Long userGroupId;
	private Pagination page;
	/** SEARCH **/
	private String searchStr;
	/** FILTER **/	
	private String filterTodoBRTypeId;
	private String filterTodoCategoryName;
	private String filterSurgicalStage;
	private String filterProcedureType;
	private String filterSiteOfService;
	
	private String allCnIdsStr;
	
	private Long todoCarePlanSurveyId;
	private Long strykerAdminId;
	private String surveyCode;
	private Long hspsmId;
	
}
