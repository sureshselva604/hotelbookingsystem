package com.seind.rc.services.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.Settings;


public interface SettingsRepository extends JpaRepository<Settings, Long>{
	
	Optional<Settings> findByCategoryAndName(String category, String name);

	List<Settings> findByNameAndCategoryOrderBySettingIdDesc(String value, String ssosync);

	List<Settings> findByCategory(String category);
	
	Settings findByNameAndCategory(String value, String ssosync);

}
