package com.seind.rc.services.user.data;


import lombok.Data;

@Data
public class DownloadInfoBean {
	private String ptype;
	private Long userId;
	private Long productId;
	private String dataMode;
	private boolean preview;
	private boolean watermark;
	private String hspPatSurveyId;
	private Long patientSwfId;
	private String stageCategoryId;
	private String vtype;
	private String type;
	private String bundlePatientId;
	private String loginUserId;
	private String docType;
	private String formType;
	private String assignedId;
}
