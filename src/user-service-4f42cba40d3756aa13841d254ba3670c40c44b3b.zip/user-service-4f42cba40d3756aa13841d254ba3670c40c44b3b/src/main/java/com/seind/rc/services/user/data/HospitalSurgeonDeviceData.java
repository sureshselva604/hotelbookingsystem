package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HospitalSurgeonDeviceData {

	private Long hospitalSurgeonId;
	private Long hospitalId;
	private Long surgeonId;

}
