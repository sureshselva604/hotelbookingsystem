package com.seind.rc.services.user.data;



import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MessageReqData {
	private Long userAccountId;
	@Default
	private Long cnUserId=0l;
	private Long loginUaId;
	private Long patientSwfId;
	private String mode;

}
