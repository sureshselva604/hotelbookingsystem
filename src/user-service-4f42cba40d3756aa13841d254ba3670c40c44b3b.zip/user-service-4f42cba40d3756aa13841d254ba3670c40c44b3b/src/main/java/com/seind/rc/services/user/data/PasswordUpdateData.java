package com.seind.rc.services.user.data;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PasswordUpdateData {

	private Long userAccountId;
	private Long userGroupId;
	private List<Long> patientSwfIds;
	private String userEmail;
	private String userName;
	private String surgeonName;
	private String surgeonImage;
	private String surUserGroup;
	private String message;
	private List<NotifyReqData> notifyData;

}
