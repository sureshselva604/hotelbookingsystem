package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SaveSecQuesAnsData;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.data.UserSecQuestionAnsData;
import com.seind.rc.services.user.entities.UserSecResultDetails;

public interface UserSecResDetService {

	List<UserSecQuestionAnsData> getSecQuesAns(Long userAccountId);

	public UserSecResultDetails getUserSecResultDetails(Long userAccountId);

	List<UserSecQuestionAnsData> getSelectedQuestnListByUser(UpdatePwdData payload);

	ResponseMessage saveSecurityQuestionAnswer(SaveSecQuesAnsData saveSecQuesData, Long userId);

}
