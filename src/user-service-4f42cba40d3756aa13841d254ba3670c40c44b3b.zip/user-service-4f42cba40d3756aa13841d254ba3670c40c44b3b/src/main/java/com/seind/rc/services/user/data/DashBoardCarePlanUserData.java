package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class DashBoardCarePlanUserData {
	
	private Date dos;	
	private Date dischargeDate;
	private Long secHospitalId;
	private String hspname;	
	private Date plannedDischargeDate;
	private String dischargeType;
	private String dischargeTo;
	private String casemanager;
	private Long patientSwfId;
}
