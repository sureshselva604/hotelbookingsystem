package com.seind.rc.services.user.util;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringUtils;

import com.seind.rc.services.user.constants.CommonConstant;

public class I18nUtil {
	
	public static ResourceBundle getConfigResourceByLanguage(String language) {
		ResourceBundle rb;
		language = (language == null) ? "" : language;
		language = language.equalsIgnoreCase("en_us") ? "" : language;
		if (!StringUtils.trimToEmpty(language).isEmpty()) {
			language = "_" + language;
		}
		try {
			rb = ResourceBundle.getBundle("messages.config" + language);
		} catch (Exception e) {
			rb = ResourceBundle.getBundle("messages.config");
		}
		return rb;
	}
	
//	public static final String DATE_FORMAT = "dd-MM-yyyy hh:mm:ss a";
//	public static final String MMDDYYYY = CommonConstant.STR_MM_DD_YYYY;
//	public static final String STR_MM_DD_YYYY_HH_MM_A = CommonConstant.STR_MM_DD_YYYY_HH_MM_A;
//	public static final String DDMMYYYY = "dd/MM/yyyy";
//	public static final String STR_DD_MM_YYYY_HH_MM_A = "dd/MM/yyyy hh:mm a";
//	public static final String HHMMA = "hh:mm a";
//	
//	protected static final Map<String, String> DATE_FORMAT_MAP = new HashMap<>();
//
//	static {
//		DATE_FORMAT_MAP.put("MMDDYYYY", MMDDYYYY);
//		DATE_FORMAT_MAP.put("MMDDYYYYhhmma", STR_MM_DD_YYYY_HH_MM_A);
//		DATE_FORMAT_MAP.put("DDMMYYYY", DDMMYYYY);
//		DATE_FORMAT_MAP.put("DDMMYYYYhhmma", STR_DD_MM_YYYY_HH_MM_A);
//		DATE_FORMAT_MAP.put("HHMMA", HHMMA);
//	}
//
//	
//	public static Map<String, String> getDateFormatMap() {
//		return DATE_FORMAT_MAP;
//	}

}
