package com.seind.rc.services.user.service;

import java.util.Date;
import java.util.List;

import com.seind.rc.services.user.data.AddCarePartner;
import com.seind.rc.services.user.data.CareServiceData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.UserExistsReqData;
import com.seind.rc.services.user.data.UserExistsResponse;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.UserAccount;

public interface CarePartnerMapService {

	CarePartnerMap getCarePartnerMapById(Long carePartnerMapId);

	CarePartnerMap getCarePartnerMap(Long userAccountId, Long patientId);

	List<CarePartnerMap> getCarePartnerPatientList(Long userAccountId);

	CareServiceData getPatientIdUsingCarePartner(Long carePartnerId);

	String getCarePartnerInfoByPatientId(Long patientId);

	ResponseMessage carePartnerInfoDetails(AddCarePartner data);

	boolean successCheckEmailOrPhoneExists(String groupId, String oldEmailId, String oldPhone, String oldTeleCode,
			String email, String phone, String teleCode, String mode);

	ResponseMessage checkPatient(Date dob, Long patientId, Long mappingid);

	List<CarePartnerMap> getActiveCarePartnerMapbyCpUseraccount(Long userAccountId);

	CarePartnerMap getActiveCarePartnerMapByPatient(Long patientId);

	List<UserAccount> carePartnerList(Long patientId);

	UserExistsResponse getUserExists(UserExistsReqData request, UserExistsResponse response);

}
