package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.entities.PasswordHistory;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecResultDetails;
import com.seind.rc.services.user.entities.UserSecTransAudit;

public interface UserSecTransAuditService {

	List<UserSecTransAudit> fetchTopFirstRandidByUserAccountId(Long userAccountId);
	
	public void savePasswordHistory(PasswordHistory pwdHistory);

	void saveUserSecTransAudit(UserSecTransAudit secTransAudit);

	UserSecTransAudit getUserSecTransAuditByRandomId(String trim);

	void updateWelcomeflagForSecurityQuestion(UserAccount uacc);

	UserSecTransAudit fetchIPCaptureActiveUserSecTransAudit(Long userAccountId, String mode);

	void updateUserSecTransAudit(Long userSecTransAuditId);

	UserSecResultDetails validateSelectedQuestnAnsByUser(Long userAccountId, Long questionId, String answer);

}
