package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.UserPwdAudit;

public interface UserPwdAuditRepository extends JpaRepository<UserPwdAudit,Long>{

}
