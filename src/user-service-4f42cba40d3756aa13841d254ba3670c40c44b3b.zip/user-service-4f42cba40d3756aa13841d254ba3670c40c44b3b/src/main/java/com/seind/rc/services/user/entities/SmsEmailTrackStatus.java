package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "SmsEmailTrackStatus")
public class SmsEmailTrackStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long smsEmailTrackId;
	private Long userAccountId;
	private String sentTo;
	private String type;
	private String reason;
	@Temporal(TemporalType.TIMESTAMP)
	private Date sendDate;
	private String statusCode;
	private Boolean active;
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastModifiedDate;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	private Boolean validStatus;

}
