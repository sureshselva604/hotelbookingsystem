package com.seind.rc.services.user.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CheckValidationData;
import com.seind.rc.services.user.data.DobValidationReq;
import com.seind.rc.services.user.data.DobValidationResponse;
import com.seind.rc.services.user.data.ForgotPwdUserDatas;
import com.seind.rc.services.user.data.PasswordRequestData;
import com.seind.rc.services.user.data.PasswordUpdateData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SecurityQuestionAnswerData;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.UserSecQuesObjData;
import com.seind.rc.services.user.data.UserSecQuestionAnsData;
import com.seind.rc.services.user.data.UserSecQuestionsData;
import com.seind.rc.services.user.data.ValidateDobData;
import com.seind.rc.services.user.data.WelcomeInfoData;
import com.seind.rc.services.user.service.OnboardService;
import com.seind.rc.services.user.service.PasswordService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecQuesService;
import com.seind.rc.services.user.service.UserSecResDetService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

/**
 * C05
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/account")
@RequiredArgsConstructor
public class AccountController {

	private static final Logger LOGGER = LogManager.getLogger(AccountController.class);
	private static final String UNAUTHORIZED_ACCESS = "Unauthorized Access";

	private final OnboardService onboardService;

	private final PasswordService passwordService;

	private final UserSecResDetService userSecResService;

	private final UserSecQuesService userSecQuesService;

	private final UserAccountService userService;

	/**
	 * This API is responsible for validating user information and providing the
	 * necessary Response for Corresponding UserName.
	 * 
	 */
	@Operation(summary = "validate the user")
	@PostMapping(value = "/checkvalidation")
	public CheckValidationData checkUserValidation(@RequestBody UserRequestData payload) {
		return onboardService.checkUserValidation(payload);
	}

	/**
	 * This API retrieves the welcome Information for a patient based on the
	 * Database's onboarding properties provided.
	 */
	@Operation(summary = "Get Patient Welcome Info")
	@PostMapping(value = "/getPatientWelcomeInfo")
	public WelcomeInfoData getPatientWelcomeInfo(@RequestBody UpdatePwdData pwdData) {
		WelcomeInfoData welcomeInfoData = new WelcomeInfoData();
		welcomeInfoData.setStatus(CommonConstant.FAILURE);
		welcomeInfoData.setMessage(UNAUTHORIZED_ACCESS);
		try {
			welcomeInfoData = onboardService.getPatientWelcomeInfo(pwdData, welcomeInfoData);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return welcomeInfoData;
	}

	/**
	 * Validate DOB for Patient / CP for resetPassword
	 * 
	 * @param request
	 * @return
	 */
	@Operation(summary = "Validate DOB for Patient / CP")
	@PostMapping(value = "/validateDOB")
	public ResponseMessage validateDOB(@RequestBody ValidateDobData request) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.validateDOB(request);
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return response;
	}

	/**
	 * This API Check password whether it has been used in last five times.
	 * 
	 * @param userAccountId
	 * @param userPassword
	 */
	@Operation(summary = "Check password whether it has been used in last 5 times.")
	@PostMapping(value = "/isLastUsedPassword")
	public ResponseMessage isLastUsedPassword(@RequestBody PasswordRequestData payload) {
		ResponseMessage response = new ResponseMessage();

		try {
			response = passwordService.isLastUsedPassword(payload.getUserPassword(), payload.getUserAccountId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * This API Save the given password in passwordHistory table.
	 * 
	 * @param userAccountId
	 * @param userPassword
	 */
	@Operation(summary = "Save Password History")
	@PostMapping(value = "/savePwdHistory")
	public ResponseMessage savePasswordHistory(@RequestBody PasswordRequestData payload) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.savePasswordHistory(payload.getUserPassword(), payload.getUserAccountId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * @param emailId
	 * @return ResponseMessage Check the User is able to resetPassword
	 */
	@Operation(summary = "Sends reset password link email to user")
	@PostMapping(value = "/resetpassword")
	public ResponseMessage resetPassword(@RequestBody UserRequestData payload) {
		ResponseMessage response = null;
		try {
			response = passwordService.resetPassword(payload.getEmailId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * @param randomId
	 * @return Randomly Selected User Security Question Randomly Selected User
	 *         Security Question
	 */
	@Operation(summary = "GetSelectedQuestnListByUser")
	@PostMapping(value = "/getSelectedQuestnListByUser")
	public List<UserSecQuestionAnsData> getSelectedQuestnListByUser(@RequestBody UpdatePwdData payload) {
		List<UserSecQuestionAnsData> response = new ArrayList<>();
		try {
			response = userSecResService.getSelectedQuestnListByUser(payload);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * This method is used to update password for User
	 * 
	 * @param objData
	 * @return
	 */
	@Operation(summary = "Get Patient PassWord Update")
	@PostMapping(value = "/updateUserPassWord")
	public PasswordUpdateData updateUserPassWord(@RequestBody UpdatePwdData pwdData) {
		PasswordUpdateData passwordData = new PasswordUpdateData();
		try {
			passwordData = passwordService.updateUserPassWord(pwdData, passwordData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return passwordData;
	}

	/**
	 * This API Check the given userAccount is active or blocked.
	 * 
	 * @param randId
	 */
	@Operation(summary = "IsAccountActiveORBlocked")
	@PostMapping(value = "/isAccountActiveORBlocked")
	public ResponseMessage isAccountActiveORBlocked(@RequestBody UpdatePwdData payload) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.isAccountActiveORBlocked(payload.getRandId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * This API Validate the selected security question and answer.
	 * 
	 * @param randId
	 * @param questionId
	 * @param answer
	 */
	@Operation(summary = "ValidateSelectedQuestnAnsByUser")
	@PostMapping(value = "/validateSelectedQuestnAnsByUser")
	public ResponseMessage validateSelectedQuestnAnsByUser(@RequestBody SecurityQuestionAnswerData payload) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.validateSelectedQuestnAnsByUser(payload, response);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * To save the secQuestions with RandId and Mode
	 * 
	 * @param secQuesObjData
	 * @return
	 */
	@Operation(summary = "save Security Questions")
	@PostMapping(value = "/saveSecurityQuestions")
	public ResponseMessage saveSecurityQuestions(@RequestBody UserSecQuesObjData secQuesObjData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.saveSecurityQuestions(secQuesObjData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * To get the userDetail with userName
	 * 
	 * @param objData
	 * @return
	 */
	@Operation(summary = "Get User details for forgot password")
	@PostMapping(value = "/getForgotPasswordInfo")
	public ForgotPwdUserDatas getForgotPasswordInfo(@RequestBody UserRequestData payload) {
		ForgotPwdUserDatas userData = new ForgotPwdUserDatas();
		try {
			userData = passwordService.getForgotPasswordInfo(payload);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userData;
	}

	/**
	 * This API Validate the Security Dictionary based on password.
	 * 
	 * @param encodedSecurityDict
	 */
	@Operation(summary = "Security Dictionary Validation")
	@PostMapping(value = "/isValidSecurityDict")
	public ResponseMessage isValidSecurityDict(@RequestBody UpdatePwdData objData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = passwordService.isValidSecurityDict(objData.getEncodedSecurityDict());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Get All SecurityQuestionList
	 */
	@Operation(summary = "Get All SecurityQuestionList")
	@PostMapping(value = "/getSecurityQuestionList")
	public List<UserSecQuestionsData> getQuestions() {
		List<UserSecQuestionsData> userSecQuestionsData = null;
		try {
			userSecQuestionsData = userSecQuesService.getUserSecQuestions();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userSecQuestionsData;
	}

	@PostMapping(value = "/getEmailWelcome")
	public ResponseEntity<DobValidationResponse> getEmailWelcome(@RequestBody DobValidationReq dobValidationReq) {
		try {
			DobValidationResponse body = userService.getEmailWelcome(dobValidationReq);
			return ResponseEntity.ok(body);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return ResponseEntity.status(400).build();
		}
	}

	@PostMapping(value = "/validateuserbyrandid")
	public ResponseEntity<DobValidationResponse> validateuserbyrandid(@RequestBody DobValidationReq dobValidationReq) {
		try {
			DobValidationResponse body = userService.validateuserbyrandid(dobValidationReq);
			return ResponseEntity.ok(body);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return ResponseEntity.status(400).build();
		}
	}

}
