package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdfLambdaBean {
	
	private Long patientSWFId;
	private Long patientId;
	private Long hspCCId;
	private Long hspSurgId;
	private Long servicelineId;
	private Long hospitalPracticeId;
	private String casemanager;
	private Date dos;
	private Long payorId;
	private String hic;
	private String dischargeLocation;
	private Date dischargeDate;
	private String facilityName;
	private String dischargeLocPhone;
	private String dischargeLocContact;
	private String dischargeTeleCode;
	private String procedureType;
	private String patientStatus;
	private Long currentStageId;
	private Long currentEpisodeId;
	private Boolean patientSnfStatus;
	private Long patientStatusOrder;
	private Date snfDischargeDate;
	private String dischargeType;
	private String dischargeTo;
	private Long hospitalSurgeonId;
	private Date plannedDischargeDate;
	private Date plannedSnfDischargeDate;
	private Integer plannedDischargeId;
	private Integer actualDischargeId;
	private Integer plannedDischargeHospitalMasterId;
	private Integer actualDischargeHospitalMasterId;
	private Integer plannedLOS;
	private Integer actualLOS;
	private String bpci;
	private String patientDbScore;
	private Boolean firstLogin;
	private Boolean fracture;
	private Date plannedAdmissionDate;
	private Date actualAdmissionDate;
	private String plannedVisit;
	private String actualVisit;
	private Integer admissionId;
	private Long firstSOSId;
	private Long firstSOSHpId;
	private Boolean pswIsActive;
	private String otherservicelabel;
	private Long userAccountKey;
	private Long hospitalSpMasterId;
	private Long payerType;
	private String healthScore;
	private String youScore;
	private String dosStr;
	private String dischargeDateStr;
	private String currentPac;
	private Float homeScore;
	private String laterality;
	private Long stageWorkflowId;

	private Long patUseraccountId;
	private String patFirstName;
	private String patLastName;
	private Date patDob;
	private String patGender;
	private String patPhone;
	private String patEmail;
	private String patTelecode;
	private String patPhoneFormat;
	private String patImagePath;
	private String patMrn;
	private String patBmi;
	private Long otherPhoneTypeId;
	private String phoneTypeDesc;
	private String otherPhone;
	private String otherTeleCode;
	private Long patHeight;
	private Long patWeight;
	private Long patInch;
	private Long patAge;

	private Long ccUserAccountId;
	private String ccFirstName;
	private String ccLastName;
	private Long ccUsergroupId;

	private Long sugUaId;
	private String sugFirstName;
	private String sugLastName;
	private String salutation;
	private String sugTitle;
	
	private Long hospitalId;
	private String hospitalName;
	private String hspCode;
	private String hspLogo;
	private Boolean commercialType;
	private Long countryCodeId;
	private String hspZoneCode;
	private String phoneFormat;
	private String countryCode;
	private String countryCodeDateFormat;
	
	private String cpFirstName;
	private String cpLastName;
	private String cpRelationship;
	private String cpEmail;
	private String cpPhone;
	private String cpTeleCode;
	
}
