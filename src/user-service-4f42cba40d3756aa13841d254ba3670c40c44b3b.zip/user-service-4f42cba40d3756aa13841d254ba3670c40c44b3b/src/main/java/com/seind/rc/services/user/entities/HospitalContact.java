package com.seind.rc.services.user.entities;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "HospitalContact")
public class HospitalContact {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "hospitalContactid", unique = true, nullable = false)
	private Long hospitalContactid;
	private Long hospitalId;
	private String contacttext;
	private String deviceContacttext;

}
