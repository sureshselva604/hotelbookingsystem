package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ForgotPwdUserDatas {
	private Long userId;
	private String userName;
	private String firstName;
	private String lastName;
	private String groupName;
	private String status;
	private String address;
	private String city;
	private String state;
	private String practiceName;
	private String description;
	private String zipcode;
	private String phone;
	private String imagePath;
	private String userShow;
	private String salutation;
	private Boolean careFamilyShow;	
	private String message;
	private Long userGroupId;
	private Long patientId;
	private String patFirstName;
	private String patLastName;
	private String dateFormat;
	private Boolean allowPasswordChange;
	private String countryCode;
	private String welcomeFlag;
	private String clientLogoPath;



}
