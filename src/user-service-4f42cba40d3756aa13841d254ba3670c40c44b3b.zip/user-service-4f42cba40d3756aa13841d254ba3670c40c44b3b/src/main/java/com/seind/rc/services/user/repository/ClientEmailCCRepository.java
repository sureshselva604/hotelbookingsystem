package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.ClientEmailCC;

public interface ClientEmailCCRepository extends JpaRepository<ClientEmailCC, Long> {

	public ClientEmailCC findByClientId(Long clientId);
	
	List<ClientEmailCC> findByHospital_TimeZone_ZoneIdAndHospital_CreatedByComTypeNotNullAndHospital_CreatedByComTypeAndHospital_AllowPatNotificationTrueAndActiveTrue(
			Long zoneId, String comType);
}
