package com.seind.rc.services.user.service.servicesimp;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.entities.PracticeCoordinatorHSPMapping;
import com.seind.rc.services.user.repository.PracticeCoordinatorHSPMappingRepository;
import com.seind.rc.services.user.service.PracticeCoordinatorHSPMappingService;

@Service
public class PracticeCoordinatorHSPMappingServiceImpl implements PracticeCoordinatorHSPMappingService {

	private static final Logger LOGGER = LogManager.getLogger(PracticeCoordinatorHSPMappingServiceImpl.class);

	@Autowired
	PracticeCoordinatorHSPMappingRepository pracCoOdHSPMapRepo;

	/**
	 * M01
	 */
	@Override
	public List<PracticeCoordinatorHSPMapping> getPracticeCoordinatorHSPMappingByHspPracticeId(
			Long hospitalPracticeId) {
		List<PracticeCoordinatorHSPMapping> pracCoOdHSPMap = null;
		try {
			pracCoOdHSPMap = pracCoOdHSPMapRepo.findByHospitalPracticeId(hospitalPracticeId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return pracCoOdHSPMap;
	}

}
