package com.seind.rc.services.user.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "MenuConfiguration")
public class MenuConfiguration {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mConfigId", unique = true, nullable = false)
	private int mConfigId;
	private Boolean status;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "menuId")
	private Menu menu;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mGroupId")
	private MenuGroup menuGroup;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PracticeId")
	private Hospital hospital;

}
