package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatusResponse {
	
	private String status;
	private String message;
	private String value;
	private Boolean captchaRequired;
	private String invalidCount;
	private String userMode;
	private String sugFirstName;
	private String sugLastName;
	private String sugImagePath;
	private String firstName;
	private String lastName;
	private String randId;

}
