package com.seind.rc.services.user.service.servicesimp;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.data.UserSecQuestionsData;
import com.seind.rc.services.user.entities.UserSecQuestions;
import com.seind.rc.services.user.repository.UserSecQuesRepository;
import com.seind.rc.services.user.service.UserSecQuesService;

@Service
public class UserSecQuesServiceImpl implements UserSecQuesService {

	private static final Logger LOGGER = LogManager.getLogger(UserSecQuesServiceImpl.class);

	@Autowired
	private UserSecQuesRepository userSecQuestionRepo;

	/**
	 * M01
	 * 
	 * Get all User Security Questions
	 */
	@Override
	public List<UserSecQuestionsData> getUserSecQuestions() {
		List<UserSecQuestionsData> userSecQuestions = null;
		try {
			List<UserSecQuestions> questionsList = userSecQuestionRepo.findAll();
			userSecQuestions = questionsList.stream()
					.map(u -> new UserSecQuestionsData(u.getUserSecQuestionsId(), u.getQuestion())).toList();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return !userSecQuestions.isEmpty() ? userSecQuestions : null;
	}

}
