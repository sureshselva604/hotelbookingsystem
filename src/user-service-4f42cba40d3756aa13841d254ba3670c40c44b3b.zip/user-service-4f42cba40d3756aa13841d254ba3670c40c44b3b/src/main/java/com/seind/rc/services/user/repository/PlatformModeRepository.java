package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PlatformMode;

public interface PlatformModeRepository extends JpaRepository<PlatformMode, Long>{

}
