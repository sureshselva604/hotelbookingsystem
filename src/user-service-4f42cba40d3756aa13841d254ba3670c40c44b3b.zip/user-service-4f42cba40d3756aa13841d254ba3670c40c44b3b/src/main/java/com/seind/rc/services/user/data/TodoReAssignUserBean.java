package com.seind.rc.services.user.data;

import java.util.Map;

import lombok.Data;

@Data
public class TodoReAssignUserBean {
/** INPUT DATA **/
	private Long todoReAssignedToUaId;
	private Long todoReAssignedFromUaId;
	private Long todoReAssignedLoginUaId;
	
	/** OUTPUT DATA **/
	private String firstNameFromUaCc;
	private String LastNameFromUaCc;
	private String firstNameToUaCc;
	private String LastNameToUaCc;
	private String[] allondmdstrparams1;
	
	private Map<Long, ReAssignNotify> todoReAssingMap;
}


