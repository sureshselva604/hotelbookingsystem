package com.seind.rc.services.user.constants;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public final class CommonConstant {

	public static final class DateFormatRC {
		private DateFormatRC() {
		}

		public static final String YYYY_MM_DD = "yyyy-MM-dd";
		public static final String MM_DD_YYYY = "MM/dd/yyyy";
		public static final String DD_MM_YYYY = "dd/MM/yyyy";
		public static final String YYYY_DD_MM = "yyyy-dd-MM";
		public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss.SSS";
		public static final String MM_DD_YYYY_HH_MM_A = "MM/dd/yyyy hh:mm a";
		public static final String MM_DD_YYYY_HH_MM_SS = "MM/dd/yyyy HH:mm:ss";
		public static final String DD_MM_YYYY_HH_MM_A = "dd/MM/yyyy hh.mm a";
		public static final String HH_MM_A = "hh:mm a";
		public static final String HH_MM = "HH:mm";
		public static final String STR_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
		public static final String STR_YYYY_MM_DD_HH_MM_SS2 = "yyyy-MM-dd HH:mm:ss";

	}

	protected static final Map<String, String> DATE_FORMAT_MAP = new HashMap<>();

	static {
		DATE_FORMAT_MAP.put("MMDDYYYY", DateFormatRC.MM_DD_YYYY);
		DATE_FORMAT_MAP.put("MMDDYYYYhhmma", DateFormatRC.MM_DD_YYYY_HH_MM_A);
		DATE_FORMAT_MAP.put("DDMMYYYY", DateFormatRC.DD_MM_YYYY);
		DATE_FORMAT_MAP.put("DDMMYYYYhhmma", DateFormatRC.DD_MM_YYYY_HH_MM_A);
		DATE_FORMAT_MAP.put("HHMMA", DateFormatRC.HH_MM_A);
	}

	public static Map<String, String> getDateFormatMap() {
		return DATE_FORMAT_MAP;
	}

	public static final ResourceBundle uriRB = ResourceBundle.getBundle("messages.uri");
	public static final String EXCEPTION = "Exception: ";
	public static final String FALSE = "false";
	public static final String SSOSECKEY = "SSO_SECKEY";
	public static final String SSOSYNC = "SSOSYNC";
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	public static final String FAIL = "Failed";
	public static final String True = "true";
	public static final String SLASH = "/";
	public static final String NEW_SCH_MSGTITLE = "NewlyScheduleAppmnt";
	public static final String DEL_SCH_MSGTITLE = "DeletedScheduleAppmnt";

	public static final String MYRECOVERYCOACH_MAIL = "@myrecoverycoach.com";

	public static final String STR_PATIENT_PATH = uriRB.getString("STR_PATIENT_PATH");
	public static final String STR_IMAGEPATH = "imagePath";
	public static final String DAM_CLIENT_PATH = uriRB.getString("damClientPath");
	public static final String CARE_COORDINATOR = "cc_";
	public static final String STR_PATIENT = "patient_";
	public static final String COMPLETED = "Completed";
	public static final String STR_HSP = "HOSPITAL";
	public static final String STR_SURGEON = "Surgeon";
	public static final String STR_CARE_OUTCOME = "Care Outcomes Manager";
	public static final String STR_CARE_COORDINATOR = "Care Coordinator";
	public static final String STR_PRAC_COORDI = "Practice Coordinator";
	public static final String STR_HSP_NAVIGATOR = "Hospital Navigator";
	public static final String STR_CAREPARTNER = "Care Partner";
	public static final String STR_PATIENT1 = "Patient";
	public static final String STR_MM_DD_YYYY = "MM/dd/yyyy";
	public static final String STR_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String SOMETHINGWNT = "Something Went Wrong!";

	public static final String CLOUD = "cloud";
	public static final String EMAIL = "EMAIL";
	public static final String NOT_YET_STARTED = "Not Yet Started";
	public static final String DEFAULT_PATM_IMAGE = "defaultMaleImgPath";
	public static final String DEFAULT_PATF_IMAGE = "defaultFemaleImgPath";
	public static final String USER_VALIDATE = "uservalidate/";
	public static final String STR_SERVER_URL = "serverurl";

	public static final String EMAIL_CC_LIST = "EMAIL_CC_LIST";
	public static final String EMAIL_BC_LIST = "EMAIL_BC_LIST";

	public static final String ON_BOARD = "onboard";
	public static final String HRO_LBL = "hro";

	public static final String STR_WELCOME = "welcome/";
	public static final String EMAILADDRESSUPDATE = "EmailAddressUpdate";
	public static final String PHONENUMBERUPDATE = "PhoneNumberUpdate";
	public static final String EMAILADDRESSANDPHONENUMBERUPDATE = "EmailAddressAndPhoneNumberUpdate";

	public static final String ERROR = "error";
	public static final String MESSAGE2 = "message";
	public static final String ACCESS_ERR_MSG = "UnAuthorzied Access";
	public static final String USER_NOTENROLLED_MSG = "Entered username is not enrolled in RecoveryCOACH. So Please contact your healthcare provider.";
	public static final String ACCOUNT_DEACTIVATED = "Your account is deactivated.";

	/*** bodypartdeactiveate ***/
	public static final String BODYPARTDEACTIVEATE = "Your account has been deactivated. If you have any questions, please contact patient care.";
	public static final String BODYPARTDEACTIVEATE_CP = "Your <<pat_name>>'s account has been deactivated. If you have any questions, please contact patient care.";
	public static final String ERR_MSG_TEXT = "You have entered an incorrect username. Please try your email or phone number";
	public static final String ERR_MSG_TEXT2 = "Your account has been deactivated. If you have any questions, please contact patient care.";
	public static final String INVALIDUSER = "Invalid user";
	public static final String ERR_NOT_PAT_USER = "Login user not a patient";
	public static final String EXPIRED_OTP = "OTP is Expired.";
	public static final String VERIFY_VALID_CHECK = "The verification code is correct.";
	public static final String VERIFY_INVALID_CHECK = "The verification code is incorrect.";
	public static final String ERR_ATTEMPTS_MANY = "Too Many Requests. Please try after 1 min..";
	/*** Host Model Type : CLOUD or VM ***/
	public static final String HOSTEDMODEL = "CLOUD";

	/*** deactiveated email content ***/
	public static final String LATESTACTIVELINK = "Your email has been updated. Please click on the activation link sent to this updated email address to get started with your journey in RecoverCOACH.";
	public static final String ACTIVELINKEXPIRED = "Onboarded already, the activation link got expired.";
	public static final String USERVALIDATIONCHECK1 = "Invalid User or User not Active";
	public static final String USERVALIDATIONCHECK2 = "Email or PhoneNumber Already Exists";
	public static final String USERVALIDATIONCHECK3 = "Please enter valid email or phone number.";

	public static final String AWS_S3_REAL_PATH = "awsS3RealPath";

	public static final String PAT_NAME_TEXT = "<<pat_name>>";
	public static final String PAT_EMAIL_TEXT = "<<pat_email>>";
	public static final String SURG_NAME_TEXT = "<<surgeon_name>>";
	public static final String STR_PSERVER_URL = "<<pserver_url>>";

	/*** DC ***/
	public static final String USERNAME = "userName";
	public static final String SECKEY = "secKey";
	public static final String SECKEYCAPITAL = "SecKey";

	public static final String INTRO = "intro/";

	public static final String CONFLICTSTATUS = "conflictStatus";
	public static final String EMPTY_BLOCK = "Empty Block";
	public static final String EMAIL_EXISTS = "Email address already exists";
	public static final String PHONE_EXISTS = "Phone aldready exists";
	public static final String ADDUSER = "AddUser";
	public static final String ACTIVE = "Active";
	public static final String BLOCKED = "Blocked";
	public static final String SMS_NOTIFICATION_START = "SMSNotificationStart";
	public static final String SMS_NOTIFICATION_STOP = "SMSNotificationStop";
	public static final String PHONEINVALID = "Phone number has not valid characters";
	public static final String EMAILINVALID = "Email has not valid characters";
	public static final String INVALID_DATA = "Input value is Invalid";
	public static final String PASSWORDCHECK = "This password was recently used. Please create a password that is different from your last 5 passwords.";
	public static final String LOG_DEVICE_ERROR = "device Error.";
	public static final String DEACTIVE_ACCOUNT = "deactiveAccount";

	/*** change password ***/
	public static final String PASSWORD_MISMATCH = "Old password mismatch!";
	public static final String PASSWORD_RULE = "New password should not be same as old password!";
	public static final String FAILED_PASSWORD_CHANGE = "Failed to change password";
	public static final String SUCCESS_PASSWORD_CHANGE = "Password changed successfully!";
	public static final String PASSWORD_NOT_MATCH = "New password does not match with confirm password!";

}
