package com.seind.rc.services.user.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.AddCarePartner;
import com.seind.rc.services.user.data.CareServiceData;
import com.seind.rc.services.user.data.CheckPatient;
import com.seind.rc.services.user.data.PatientRequestData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.service.CarePartnerMapService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * C01
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/care")
@RequiredArgsConstructor
public class CarePartnerController {

	private static final Logger LOGGER = LogManager.getLogger(CarePartnerController.class);

	@Autowired
	private CarePartnerMapService careMapService;

	@PostMapping(value = "/getPatientIdByCarePartnerId")
	public CareServiceData getPatientIdByCarePartnerId(@RequestBody PatientRequestData payload) {
		CareServiceData response = null;
		try {
			response = careMapService.getPatientIdUsingCarePartner(payload.getCarePartnerId());
		} catch (Exception e) {

			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@PostMapping(value = "/getCarePartnerByPatientId")
	public String getCarePartnerInfoByPatientId(@RequestBody PatientRequestData payload) {
		String response = null;
		try {
			response = careMapService.getCarePartnerInfoByPatientId(payload.getPatientId());
		} catch (Exception e) {

			LOGGER.error(e.getMessage());
		}
		return response;
	}

	@Operation(summary = "Add Care Partner")
	@PostMapping(value = "/carePartnerInfoDetails")
	public ResponseMessage carePartnerInfoDetails(@RequestBody AddCarePartner data) {
		ResponseMessage response = null;
		try {
			response = careMapService.carePartnerInfoDetails(data);

		} catch (Exception e) {
			LOGGER.error(e);
		}
		return response;
	}

	@Operation(summary = "userCheking with DOB")
	@PostMapping(value = "/checkPatient")
	public ResponseMessage checkPatient(@RequestBody CheckPatient data) {
		ResponseMessage response = null;
		try {
			response = careMapService.checkPatient(data.getDob(), data.getPatientId(), data.getMappingId());

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}


}
