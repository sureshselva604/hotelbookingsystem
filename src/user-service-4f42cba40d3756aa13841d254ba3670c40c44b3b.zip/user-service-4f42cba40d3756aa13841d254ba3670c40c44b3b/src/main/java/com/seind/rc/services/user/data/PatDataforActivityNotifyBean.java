package com.seind.rc.services.user.data;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.seind.rc.services.user.entities.PatientDevice;

import lombok.Data;

@Data
public class PatDataforActivityNotifyBean {

	private Long hospitalid;
	private Long userAccountId;
	private Long userAccountkey;
	private String firstName;
	private String lastName;
	private String email;
	private String teleCode;
	private String phone;
	private String gender;
	private String code;
	private String comType;
	private String surgeonName;
	private String interval;
	private Date activationDate;
	private String emailAlias;
	private Long patientSWFId;
	private Boolean welcomeFlag;
	private Long cpaccountid;
	private String cpfirstname;
	private String cplastname;
	private String cpemail;
	private String cptelecode;
	private String cpphone;
	private String cpcomtype;
	private String cpwelcomeflag;
	private Integer pushNotification;
	private Integer cpPushNotification;
	private Integer patTokenCount;
	private Integer cpTokenCount;
	private Integer patInstallCount;
	private Integer cpInstallCount;
	private Long countryCodeId;
	private Long zoneId;
	private Long patientId;
	
	List<SettingsData>  settingsList ;
	/** PushNotification  **/
	Map<String, PatientDevice> patDeviceMap ;
	List<Long> patientSWFIds;
	
	
}