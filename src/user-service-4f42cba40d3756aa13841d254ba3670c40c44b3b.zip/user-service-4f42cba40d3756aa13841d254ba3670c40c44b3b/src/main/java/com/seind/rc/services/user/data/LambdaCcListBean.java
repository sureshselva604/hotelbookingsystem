package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class LambdaCcListBean {

	private String firstName;
	private String lastName;
	private String email;
	private String phone;
	private String telecode;
	private String groupName;
	private String mode;
	private String triggerComType;
	private Long hospitalId;
	private String code;
	private String clientName;
	private String emailCc;
	private String comType;
	private String ccNotification;
	private Long useraccountId;
	private Long userAccountkey;
	private List<Long> patientSWFId;

}
