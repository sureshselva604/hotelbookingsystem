package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.entities.PracticeCoordinatorHSPMapping;


public interface PracticeCoordinatorHSPMappingService {

	List<PracticeCoordinatorHSPMapping> getPracticeCoordinatorHSPMappingByHspPracticeId(Long hospitalPracticeId);

}
