package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "UserPrivilege")
public class UserPrivilege {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long privilegeId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserGroupId")
	private UserGroup userGroup;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserScreenId")
	private Menu menu;

	@Column(nullable = false)
	private Long userId;
	@Column(nullable = false)
	private Boolean isList;
	@Column(nullable = false)
	private Boolean isCreate;
	@Column(nullable = false)
	private Boolean isView;
	@Column(nullable = false)
	private Boolean isEdit;
	@Column(nullable = false)
	private Boolean isDelete;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CreatedBy")
	private UserAccount createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date lastModifiedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LastModifiedBy")
	private UserAccount lastModifiedBy;

	private Boolean status;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PracticeId")
	private Hospital practiceId;

}
