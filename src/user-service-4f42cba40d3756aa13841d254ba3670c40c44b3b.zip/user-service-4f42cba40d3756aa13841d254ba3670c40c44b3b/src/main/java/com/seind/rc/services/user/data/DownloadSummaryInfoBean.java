package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class DownloadSummaryInfoBean {
	private String bpcia;
	private String hsp_Sug_Id;
	private String procedureType;
	private String dosFrom;
	private String dosTo;
	private String clientId;
	private String hospitalPracticeId;
	private String userAccountId;
	private String currentPacEvent;
	private Boolean completed;
}
