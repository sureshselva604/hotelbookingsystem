package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class CountryDischargeMapData {
	
	private Long dischargeTypeId;
	
	private Long countryCodeId;

	private String altDischargeType;
}
