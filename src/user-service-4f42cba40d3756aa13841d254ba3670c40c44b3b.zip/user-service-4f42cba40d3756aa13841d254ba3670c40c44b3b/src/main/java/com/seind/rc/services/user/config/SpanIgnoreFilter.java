package com.seind.rc.services.user.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.server.observation.ServerRequestObservationContext;

import io.micrometer.observation.Observation;
import io.micrometer.observation.Observation.Context;
import io.micrometer.observation.ObservationFilter;
import io.micrometer.observation.ObservationPredicate;

@Configuration
public class SpanIgnoreFilter {
	// This adds the http.url keyvalue to security observations from the root (mvc) observation
	// You add an ignoreSpan=true keyValue instead if you want, or something that can signal to the SpanExportingPredicate what to ignore
	//@Bean
	ObservationFilter urlObservationFilter() {
	    return context -> {
	        if (context.getName().startsWith("spring.security.")) {
	            Context root = getRoot(context);
	            if (root.getName().equals("http.server.requests")) {
	                context.addHighCardinalityKeyValue(root.getHighCardinalityKeyValue("http.url"));
	            }
	        }

	        return context;
	    };
	}

	private Observation.Context getRoot(Observation.Context context) {
	    if (context.getParentObservation() == null) {
	        return context;
	    }
	    else {
	        return getRoot((Context) context.getParentObservation().getContextView());
	    }
	}
	
	@Bean
	ObservationPredicate noActuatorServerObservations() {
	    return (name, context) -> {
	    	Observation.Context root = getRoot(context);
	        if (root instanceof ServerRequestObservationContext serverContext) {
	            return !serverContext.getCarrier().getRequestURI().startsWith("/actuator");
	        }
	        else {
	            return true;
	        }
	    };
	}
	

	// This ignores actuator spans but its logic depends on the ObservationFilter above
	// Auto-configuration for SpanExportingPredicate was added in 3.1.0-M1
	// So either you use 3.1.x or you can add the same to your config : https://github.com/spring-projects/spring-boot/pull/34002
	/**@Bean
	SpanExportingPredicate actuatorSpanExportingPredicate() {
	    return span -> !span.getTags().get("http.url").startsWith("/actuator");
	}**/
	
}
