package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.UserGroupHspPracMap;

public interface UserGroupHspPracMapRepository extends JpaRepository<UserGroupHspPracMap, Long>{

	List<UserGroupHspPracMap> findByHospitalPracticeIdIn(List<Long> hsppIds);

}
