package com.seind.rc.services.user.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.seind.rc.services.user.constants.CasCommonConstant;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.SeqQuesSyncModel;
import com.seind.rc.services.user.data.SsoSyncData;

@Component
public class DCCPUtil {

	private static final Logger LOGGER = LogManager.getLogger(DCCPUtil.class);
	static ResourceBundle res = ResourceBundle.getBundle("application");
	private static final String COUNT = "count";

	static String dccpurlallowed = "No";
	static String secKey = "";

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private SSOSyncUtil ssoSyncUtil;

	public String getAPIURL(String name) {
		String apiURL = "";
		try {
			apiURL = rcUserUtil.getSettingValue(name, CasCommonConstant.SSOSYNC);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return apiURL;
	}

	public String dccpStatus() {
		try {
			dccpurlallowed = rcUserUtil.getSettingValue("SSODC_ENABLED_STATUS", CasCommonConstant.SSOSYNC);
			secKey = rcUserUtil.getSettingValue("SSO_SECKEY", CasCommonConstant.SSOSYNC);
		} catch (Exception e) {
			dccpurlallowed = "No";
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return dccpurlallowed;
	}

	public String checkUserExistsInDCCP(String userName) throws IOException {
		String body = "false";
		SsoSyncData data = new SsoSyncData();
		dccpurlallowed = dccpStatus();
		if (dccpurlallowed != null && !dccpurlallowed.isEmpty() && dccpurlallowed.equalsIgnoreCase("yes")) {
			CloseableHttpClient httpClient = null;
			try {
				data.setUserName(RCUserUtil.rcEncrypt(userName));
				String checkUserExistUrl = getAPIURL(
						"DCCPCheckUserExistsURL");/*** res.getString("DCCPCheckUserExistsURL"); ***/
				HttpPost postCheck = new HttpPost(checkUserExistUrl);
				data.setApiName(postCheck.toString());
				List<NameValuePair> params = new ArrayList<>();
				params.add(new BasicNameValuePair(CommonConstant.USERNAME, userName));
				params.add(new BasicNameValuePair(CommonConstant.SECKEY, secKey));
				postCheck.setEntity(new UrlEncodedFormEntity(params));

				httpClient = HttpClients.createDefault();
				HttpResponse response = httpClient.execute(postCheck);
				ResponseHandler<String> handler = new BasicResponseHandler();
				body = handler.handleResponse(response);
				ssoSyncUtil.saveSSOAuditLog(data);
			} catch (Exception e) {
				data.setError(e.getMessage());
				ssoSyncUtil.saveSSOAuditLog(data);
				LOGGER.error(CommonConstant.EXCEPTION, e.getMessage());
			} finally {
				if (httpClient != null)
					httpClient.close();
			}
		}

		return body;
	}

	public void updatePwdInDCCP(String userName, String pwd, String csrFlag) throws IOException {
		SsoSyncData data = new SsoSyncData();
		dccpurlallowed = dccpStatus();
		if (dccpurlallowed != null && !dccpurlallowed.isEmpty() && dccpurlallowed.equalsIgnoreCase("yes")) {
			CloseableHttpClient httpClient = null;
			try {
				data.setUserName(RCUserUtil.rcEncrypt(userName));
				data.setUserPwd(RCUserUtil.rcEncrypt(pwd));
				String updateUrl = getAPIURL("DCCPUpdatePwdURL");
				String encodePwd = Base64.getEncoder().encodeToString(pwd.getBytes());

				HttpPost postUpdate = new HttpPost(updateUrl);
				data.setApiName(postUpdate.toString());
				List<NameValuePair> params = new ArrayList<>();
				params.add(new BasicNameValuePair(CommonConstant.USERNAME, userName));
				params.add(new BasicNameValuePair(CommonConstant.SECKEY, secKey));
				params.add(new BasicNameValuePair("pwd", encodePwd));
				params.add(new BasicNameValuePair("csrFlag", csrFlag));
				postUpdate.setEntity(new UrlEncodedFormEntity(params));
				httpClient = HttpClients.createDefault();
				httpClient.execute(postUpdate);
				ssoSyncUtil.saveSSOAuditLog(data);
				LOGGER.info("pwd updated in dc....");
			} catch (Exception e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
				data.setError(e.getMessage());
				ssoSyncUtil.saveSSOAuditLog(data);
			} finally {
				if (httpClient != null)
					httpClient.close();
			}
		}
	}

	public void updateSecQuestionFailure(String userName, int count) throws IOException {
		SsoSyncData data = new SsoSyncData();
		dccpurlallowed = dccpStatus();
		LOGGER.info("dccpurlallowed.{}", dccpurlallowed);
		if (dccpurlallowed != null && !dccpurlallowed.isEmpty() && dccpurlallowed.equalsIgnoreCase("yes")) {
			CloseableHttpClient httpClient1 = null;
			try {
				data.setUserName(RCUserUtil.rcEncrypt(userName));
				data.setCount(count);
				String updateUrl = getAPIURL("DCCPForgotPwdSecurity");
				LOGGER.debug("updateUrl.{}", updateUrl);
				HttpPost postUpdate = new HttpPost(updateUrl);
				data.setApiName(postUpdate.toString());
				List<NameValuePair> params = new ArrayList<>();
				params.add(new BasicNameValuePair(CommonConstant.USERNAME, userName));
				params.add(new BasicNameValuePair(CommonConstant.SECKEY, secKey));
				params.add(new BasicNameValuePair(COUNT, String.valueOf(count)));

				postUpdate.setEntity(new UrlEncodedFormEntity(params));
				httpClient1 = HttpClients.createDefault();
				httpClient1.execute(postUpdate);
				LOGGER.info("Updated Wrong Security Answer count in DC....");
				ssoSyncUtil.saveSSOAuditLog(data);
			} catch (Exception e) {
				data.setError(e.getMessage());
				ssoSyncUtil.saveSSOAuditLog(data);
				LOGGER.error(CommonConstant.EXCEPTION, e);
			} finally {
				if (httpClient1 != null)
					httpClient1.close();
			}
		}
	}

	public void updateInvalidSecCodeAuditDCCP(String userName, int attemptCount, String secCode, String attemptMode)
			throws IOException {
		SsoSyncData data = new SsoSyncData();
		dccpurlallowed = dccpStatus();
		LOGGER.info("dccpurlallowed{}", dccpurlallowed);
		if (dccpurlallowed != null && !dccpurlallowed.isEmpty() && dccpurlallowed.equalsIgnoreCase("yes")) {
			CloseableHttpClient httpClient = null;
			try {
				data.setUserName(RCUserUtil.rcEncrypt(userName));
				String updateUrl = getAPIURL("DCCPUpdateOTP");/*** res.getString("DCCPUpdateOTP"); ***/
				LOGGER.info("updateUrl.{}", updateUrl);
				HttpPost postUpdate = new HttpPost(updateUrl);
				data.setApiName(postUpdate.toString());
				data.setCount(attemptCount);
				data.setTeleCode(secCode);
				data.setTitle(attemptMode);
				List<NameValuePair> params = new ArrayList<>();
				params.add(new BasicNameValuePair(CommonConstant.USERNAME, userName));
				params.add(new BasicNameValuePair(CommonConstant.SECKEY, secKey));
				params.add(new BasicNameValuePair("secCode", secCode));
				params.add(new BasicNameValuePair("attemptCount", String.valueOf(attemptCount)));
				params.add(new BasicNameValuePair("attemptMode", attemptMode));
				postUpdate.setEntity(new UrlEncodedFormEntity(params));
				httpClient = HttpClients.createDefault();
				httpClient.execute(postUpdate);
				LOGGER.info("OTP Validation dc....");
				ssoSyncUtil.saveSSOAuditLog(data);
			} catch (Exception e) {
				data.setError(e.getMessage());
				ssoSyncUtil.saveSSOAuditLog(data);
				LOGGER.error(CommonConstant.EXCEPTION, e);
			} finally {
				if (httpClient != null)
					httpClient.close();
			}
		}
	}

	public void updateSecQuestInDCCP(String userName, SeqQuesSyncModel seqQuesSyncModel) throws IOException {
		SsoSyncData data = new SsoSyncData();
		dccpurlallowed = dccpStatus();
		if (dccpurlallowed != null && !dccpurlallowed.isEmpty() && dccpurlallowed.equalsIgnoreCase("yes")) {
			CloseableHttpClient httpClient = null;
			try {
				data.setUserName(RCUserUtil.rcEncrypt(userName));
				data.setQuesId1(seqQuesSyncModel.getQuesIdOne());
				data.setQuesId2(seqQuesSyncModel.getQuesIdTwo());
				data.setQuesId3(seqQuesSyncModel.getQuesIdThree());
				data.setAns1(seqQuesSyncModel.getAnsOne());
				data.setAns2(seqQuesSyncModel.getAnsTwo());
				data.setAns3(seqQuesSyncModel.getAnsThree());

				String updateUrl = getAPIURL("DCCPUpdateSecQues"); /*** res.getString("DCCPUpdateSecQues"); ***/
				HttpPost postUpdate = new HttpPost(updateUrl);
				data.setApiName(postUpdate.toString());
				List<NameValuePair> params = new ArrayList<>();
				params.add(new BasicNameValuePair("userName", userName));
				params.add(new BasicNameValuePair(CommonConstant.SECKEY, res.getString(CommonConstant.SECKEYCAPITAL)));

				params.add(new BasicNameValuePair("quesIdOne", seqQuesSyncModel.getQuesIdOne().toString()));
				params.add(new BasicNameValuePair("answerOne", seqQuesSyncModel.getAnsOne()));

				params.add(new BasicNameValuePair("quesIdTwo", seqQuesSyncModel.getQuesIdTwo().toString()));
				params.add(new BasicNameValuePair("answerTwo", seqQuesSyncModel.getAnsTwo()));

				params.add(new BasicNameValuePair("quesIdThree", seqQuesSyncModel.getQuesIdThree().toString()));
				params.add(new BasicNameValuePair("answerThree", seqQuesSyncModel.getAnsThree()));

				postUpdate.setEntity(new UrlEncodedFormEntity(params));
				httpClient = HttpClients.createDefault();
				HttpResponse response = httpClient.execute(postUpdate);
				ResponseHandler<String> handler = new BasicResponseHandler();
				String body = handler.handleResponse(response);
				LOGGER.debug(body);
				ssoSyncUtil.saveSSOAuditLog(data);
			} catch (Exception e) {
				data.setError(e.getMessage());
				ssoSyncUtil.saveSSOAuditLog(data);
				LOGGER.error(CommonConstant.EXCEPTION, e);
			} finally {
				if (httpClient != null) {
					httpClient.close();
				}
			}
		}
	}

}
