package com.seind.rc.services.user.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.seind.rc.services.user.entities.UserAccount;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
@Table(name = "PatientEpisodeCareCircle")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PatientEpisodeCareCircle {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long patientCareCircleId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "patientId")
	private Patient patient;
	@Temporal(TemporalType.TIMESTAMP)
	private Date assignedDate;
	private Long episodeId;
	private String randomId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "patientStageWorkflowId")
	private PatientStageWorkflow patientStageWorkflow;
	private Long userAccountId;
	private String rating;

	@Transient
	private Long patientId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserAccountId", updatable = false, insertable = false)
	private UserAccount userAccount;

}
