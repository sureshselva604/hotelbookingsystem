package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class ClientInfo {
	
	private Long hospitalId;
	private String name;
	private String email;
	private String phone;
	private String description;
	private String address1;
	private String address2;
	private String city;
	private String country;
	private String zipcode;
	private String code;
	private String logo;
	private String backdropImage;
	private String mode;
	private Integer contacttype;
	private String clientType;
	private String state;


}
