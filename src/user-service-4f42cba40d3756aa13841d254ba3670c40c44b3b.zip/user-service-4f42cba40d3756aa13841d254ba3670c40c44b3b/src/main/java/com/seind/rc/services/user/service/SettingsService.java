package com.seind.rc.services.user.service;

import java.util.Map;

public interface SettingsService {
	
	Map<String, String> getSettingsMapByCategory(String email);

}
