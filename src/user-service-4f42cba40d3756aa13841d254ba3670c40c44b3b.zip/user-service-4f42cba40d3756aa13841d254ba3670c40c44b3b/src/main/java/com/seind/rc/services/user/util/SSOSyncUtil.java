package com.seind.rc.services.user.util;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.http.HttpResponse;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.seind.rc.services.user.constants.CasCommonConstant;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CasSecDetails;
import com.seind.rc.services.user.data.ResponseMessageSSO;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.entities.SSOAuditLog;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.SSOAuditLogRepository;

@Component
public class SSOSyncUtil {

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private SSOAuditLogRepository auditLogRepository;

	private static final Logger logger = LogManager.getLogger(SSOSyncUtil.class);
	private static final String CRD_UPDATE = "updatePwd";

	public ResponseMessageSSO checkUserExists(String userName, String ssoUrl) {
		String body = "";
		CloseableHttpClient httpClient = null;
		ResponseMessageSSO responseDto = new ResponseMessageSSO();
		SsoSyncData data = new SsoSyncData();
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			String ssoSecKey = rcUserUtil.getSettingValue(CasCommonConstant.SSOSECKEY, CasCommonConstant.SSOSYNC);
			HttpPost postCheck = new HttpPost(ssoUrl + "checkUserExists");
			data.setApiName(postCheck.toString());
			data.setSecretKey(ssoSecKey);
			data.setUserName(RCUserUtil.rcEncrypt(userName));
			logger.debug("postCheck ---> checkUserExists & data ---> {} ssoUrl ---> {}", data, ssoUrl);
			String newDocBody = data.toString();
			postCheck.setEntity(new StringEntity(newDocBody));
			httpClient = HttpClients.createDefault();
			HttpResponse response = httpClient.execute(postCheck);
			ResponseHandler<String> handler = new BasicResponseHandler();
			body = handler.handleResponse(response);
			responseDto = objectMapper.readValue(body, ResponseMessageSSO.class);
			saveSSOAuditLog(data);
		} catch (Exception e) {
			data.setError(e.getMessage());
			saveSSOAuditLog(data);
			logger.error(e);
			responseDto.setStatus(false);
		} finally {
			if (httpClient != null) {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error("Exception {}", e.getMessage());
				}
			}
		}

		return responseDto;
	}

	public void createUser(SsoSyncData data, String ssoUrl) {
		try {
			apiCall(data, ssoUrl, "createUser");
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public void updateProfileDetailsSSO(SsoSyncData data, String ssoUrl) {
		try {
			apiCall(data, ssoUrl, "updateProfile");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	private void apiCall(SsoSyncData data, String ssoUrl, String serviceName)
			throws SQLException, ClassNotFoundException, IOException {
		logger.debug("postCheck ---> {}, data ---> {}, ssoUrl ---> {}", serviceName, data, ssoUrl);
		String ssoEnabled = rcUserUtil.getSettingValue(CasCommonConstant.SSO_ENABLED_STATUS, CasCommonConstant.SSOSYNC);
		if (!ssoUrl.isEmpty() && ssoEnabled != null && !ssoEnabled.isEmpty() && ssoEnabled.equalsIgnoreCase("Yes")) {
			CloseableHttpClient httpClient = null;
			try {
				String ssoSecKey = rcUserUtil.getSettingValue(CasCommonConstant.SSOSECKEY, CasCommonConstant.SSOSYNC);
				logger.debug(" ssoSecKey ->> {}", ssoSecKey);
				data.setSecretKey(ssoSecKey);
				HttpPost postReq = new HttpPost(ssoUrl + serviceName);
				data.setApiName(postReq.toString());
				String newDocBody = data.toString();
				postReq.setEntity(new StringEntity(newDocBody));
				httpClient = HttpClients.createDefault();
				httpClient.execute(postReq);
				logger.debug(" postReq ->> {}", postReq);
				saveSSOAuditLog(data);
			} catch (Exception e) {
				data.setError(e.getMessage());
				saveSSOAuditLog(data);
				logger.error(e.getMessage());
			} finally {
				if (httpClient != null)
					httpClient.close();
			}
		}
	}

	public SsoSyncData getUserInfo(String userName, String ssoUrl) throws IOException {
		String body = "";
		SsoSyncData ssoSyncDTO = new SsoSyncData();
		SsoSyncData data = new SsoSyncData();
		CloseableHttpClient httpClient = null;
		try {
			String ssoSecKey = rcUserUtil.getSettingValue(CasCommonConstant.SSOSECKEY, CasCommonConstant.SSOSYNC);
			HttpPost postCheck = new HttpPost(ssoUrl + "getUserInfo");
			logger.debug("-->getUserInfo {}", ssoUrl);
			data.setApiName(postCheck.toString());
			data.setSecretKey(ssoSecKey);
			data.setUserName(RCUserUtil.rcEncrypt(userName));
			String newDocBody = data.toString();
			postCheck.setEntity(new StringEntity(newDocBody));
			httpClient = HttpClients.createDefault();
			HttpResponse response = httpClient.execute(postCheck);
			ResponseHandler<String> handler = new BasicResponseHandler();
			body = handler.handleResponse(response);
			Gson gson = new GsonBuilder().registerTypeAdapter(Date.class, new GsonUTCDateAdapter()).create();

			ssoSyncDTO = gson.fromJson(body, SsoSyncData.class);
			saveSSOAuditLog(data);
			logger.debug("-->ssoSyncDTO {}", ssoSyncDTO);
		} catch (Exception e) {
			data.setError(e.getMessage());
			saveSSOAuditLog(data);
			logger.error(e.getMessage());
		} finally {
			if (httpClient != null) {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
		return ssoSyncDTO;
	}

	public static CasSecDetails getCASSecQuesAns(SsoSyncData ssoSyncData) {
		CasSecDetails casSec = new CasSecDetails();
		try {

			if (ssoSyncData != null) {
				casSec.setPassword(ssoSyncData.getUserPwd());
				casSec.setPwdCreatedOn(ssoSyncData.getUserPwdCreatedOn());
				casSec.setQuestion1(ssoSyncData.getQuesId1());
				casSec.setQuestion2(ssoSyncData.getQuesId2());
				casSec.setQuestion3(ssoSyncData.getQuesId3());
				casSec.setAnswer1(ssoSyncData.getAns1());
				casSec.setAnswer2(ssoSyncData.getAns2());
				casSec.setAnswer3(ssoSyncData.getAns3());
			}

		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
		}
		return casSec;
	}

	public void passwordUpdateSSO(String uName, String pwd, String apiURL) {
		SsoSyncData obj = new SsoSyncData();
		obj.setUserName(uName);
		obj.setUserPwd(pwd);
		try {
			updatePassword(obj, apiURL);
		} catch (Exception e) {
			logger.error("Exception : ", e);
		}
	}

	public void updatePassword(SsoSyncData data, String ssoUrl) {
		try {
			apiCall(data, ssoUrl, CRD_UPDATE);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

	public void updateSecQuestions(SsoSyncData data, String ssoUrl) {
		try {
			apiCall(data, ssoUrl, "updateSecQues");
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public void unlockAccount(SsoSyncData data, String ssoUrl) throws IOException {
		try {
			apiCall(data, ssoUrl, "unlockAccount");
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public static boolean validSsoUser(UserAccount uacc) {

		Boolean ssoUser = false;
		if (uacc.getUserGroup().getUserGroupId() == 17l || uacc.getUserGroup().getUserGroupId() == 9l
				|| uacc.getUserGroup().getUserGroupId() == 7l || uacc.getUserGroup().getUserGroupId() == 13l
				|| uacc.getUserGroup().getUserGroupId() == 18l || uacc.getUserGroup().getUserGroupId() == 30l
				|| uacc.getUserGroup().getUserGroupId() == 31l || uacc.getUserGroup().getUserGroupId() == 32l
				|| uacc.getUserGroup().getUserGroupId() == 33l || uacc.getUserGroup().getUserGroupId() == 27l
				|| uacc.getUserGroup().getUserGroupId() == 28l || uacc.getUserGroup().getUserGroupId() == 34l) {
			ssoUser = true;
		}
		return ssoUser;

	}

	public void onboardRCAccess(SsoSyncData data, String ssoUrl) {
		try {
			apiCall(data, ssoUrl, "updateOnboardRCAccess");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	public void processOnActivation(SsoSyncData data, String api) {
		try {
			apiCall(data, api, "updateActivationFromSSO");
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public void updateSecurityAttemptCAS(SsoSyncData data, String obUrl) {
		try {
			apiCall(data, obUrl, "failureSecQuesCount");
		} catch (Exception e) {
			logger.error(e);
		}

	}

	public void updateAccountLock(SsoSyncData data, String ssoUrl) throws IOException {
		try {
			apiCall(data, ssoUrl, "accountLock");
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public void updateInvalidSecCodeAudit(SsoSyncData data, String ssoUrl) throws IOException {
		try {
			apiCall(data, ssoUrl, "updateInvalidSecCodeAudit");
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public static boolean ssoStatus(String ssoEnabled) {
		boolean ssoStatus = ssoEnabled != null && !ssoEnabled.isEmpty() && ssoEnabled.equalsIgnoreCase("Yes") ? true
				: false;
		return ssoStatus;
	}

	public String getSSOAPIURL(String value) {
		String apiUrl = "";
		try {
			if (value.equalsIgnoreCase(CasCommonConstant.HRO_LBL))
				apiUrl = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_HRO_SYNCURL);
			else if (value.equalsIgnoreCase(CasCommonConstant.ONBOARD))
				apiUrl = rcUserUtil.getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_RCOB_SYNCURL);
		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
		}
		return apiUrl;
	}

	public void saveSSOAuditLog(SsoSyncData data) {
		try {
			SSOAuditLog auditLog = new SSOAuditLog();
			auditLog.setUserName(data.getUserName());
			auditLog.setApiName(data.getApiName());
			auditLog.setCreatedDate(new Date());
			auditLog.setApiJson(convertObjectToJsonNonNull(data));
			auditLog.setError(data.getError());
			auditLogRepository.save(auditLog);
		} catch (Exception e) {
			logger.error("Save Audit Log Error: ", e);
		}
	}

	private static String convertObjectToJsonNonNull(SsoSyncData data) {
		DateFormat dateFormat = new SimpleDateFormat(CommonConstant.DateFormatRC.STR_YYYY_MM_DD_HH_MM_SS2);
		String response = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			objectMapper.setDateFormat(dateFormat);
			response = objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			logger.error(e);
		}
		return response;
	}

}