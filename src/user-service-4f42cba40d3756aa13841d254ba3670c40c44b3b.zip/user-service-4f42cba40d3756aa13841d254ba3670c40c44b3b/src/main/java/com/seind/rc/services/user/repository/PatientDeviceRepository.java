package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.seind.rc.services.user.entities.PatientDevice;

@Repository
public interface PatientDeviceRepository extends JpaRepository<PatientDevice, Long> {
	
	List<PatientDevice> findByHandshakeKey(String handshakeKey);

	List<PatientDevice> findByPatient_PatientIdAndSerialNumber(Long patientId, String serialNo);
	
	List<PatientDevice> findByCarePartnerIdAndSerialNumber(Long carePartnerId, String serialNo);

	List<PatientDevice> findByCarePartnerIdAndSerialNumberAndPatient_PatientIdIn(Long carePartnerId, String serialNumber,
			List<Long> patientIds);

	List<PatientDevice>  findByTokenId(String fcmToken);
	
	List<PatientDevice> findByPatient_PatientId(Long patientId);

	List<PatientDevice> findByPatient_PatientIdInOrCarePartnerIdInAndValidToken(List<Long> patientId, List<Long> carePatnerId,int validToken);
	
	
	List<PatientDevice> findByPatient_PatientIdInOrderByCreatedDate(List<Long> patientIds);
	
	List<PatientDevice> findByCarePartnerIdInOrderByCreatedDate(List<Long> carePartnerIds);

}
