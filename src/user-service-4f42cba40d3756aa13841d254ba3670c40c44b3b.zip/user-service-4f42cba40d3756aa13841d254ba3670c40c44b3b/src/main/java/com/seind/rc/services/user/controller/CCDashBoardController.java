package com.seind.rc.services.user.controller;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.data.CarePlanAssessment;
import com.seind.rc.services.user.data.CarePlanUserOrchAssessment;
import com.seind.rc.services.user.data.CommonObjectData;
import com.seind.rc.services.user.data.CustomTodoForMultiPatient;
import com.seind.rc.services.user.data.HospitalData;
import com.seind.rc.services.user.data.NonOverlapViewOnDemandData;
import com.seind.rc.services.user.data.OverlapViewOnDemandData;
import com.seind.rc.services.user.data.PatientData;
import com.seind.rc.services.user.data.PatientStageWorkflowData;
import com.seind.rc.services.user.data.TodoOverlapOnDemandData;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.data.UserCcDashBoard;
import com.seind.rc.services.user.data.UserCcDashboardData;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.NonOverlapViewOnDemand;
import com.seind.rc.services.user.entities.OverlapViewOnDemand;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.PatientStageWorkflowSevice;
import com.seind.rc.services.user.service.TodoService;
import com.seind.rc.services.user.service.UserAccountService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/user/orchestration/ccdashboard")
@RequiredArgsConstructor
@CrossOrigin
public class CCDashBoardController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TodoController.class);
	private static final String SURGEON = "Surgeon";

	private final TodoService todoService;

	private final UserAccountService userAccountService;

	private final ModelMapper modelMap;

	private final PatientStageWorkflowSevice patientStageWorkflowSevice;

	private final HospitalService hospitalService;
	
	private final PatientRepository patientRepo;
	
	
	
	
	@PostMapping("/fetchUserServiceForDashboardCarePlan")
	public UserCcDashboardData fetchUserServiceForDashboardCarePlan(@RequestBody UserCcDashBoard userCcDashboard) {
		UserCcDashboardData userTodoData = null;
		try {
			/** USER INFO **/
			UserAccount loginCcUa = userAccountService.getUserAccountByUserAccountId(userCcDashboard.getUserId());
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			UserAccountData loginCcUaData = modelMap.map(loginCcUa, UserAccountData.class);
			
			UserAccountData strykerAdminUaData = null;
			if (userCcDashboard.getStykerAdminId() != null && !userCcDashboard.getStykerAdminId().isEmpty()) {
				UserAccount strykerAdminUa = userAccountService.getUserAccountByUserAccountId(Long.valueOf(userCcDashboard.getStykerAdminId()));
				strykerAdminUaData = modelMap.map(strykerAdminUa, UserAccountData.class);
			}

			/** CLIENT INFO **/
			Hospital hospital = hospitalService.getHospitalById(loginCcUaData.getUserAccountKey());
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			HospitalData hospitalData = modelMap.map(hospital, HospitalData.class);
			String countryCode = hospital.getCountryCode().getCountryCode();
			String language = hospital.getCountryCode().getLanguage();
			hospitalData.setCountryCode(countryCode);
			hospitalData.setLanguage(language);

			/** PATIENTSWF INFO **/
			PatientStageWorkflow patientStageWorkflow = patientStageWorkflowSevice
					.getPatientStageWorkflowByPatientSWFId(userCcDashboard.getPatientSwfId());
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			PatientStageWorkflowData patientStageWorkflowData = modelMap.map(patientStageWorkflow,
					PatientStageWorkflowData.class);
			patientStageWorkflowData.setUserAccountKey(patientStageWorkflow.getCCUserAccount().getUserAccountKey());
			patientStageWorkflowData.setPatientId(patientStageWorkflow.getPatient().getPatientId());
			patientStageWorkflowData.setHspCCId(patientStageWorkflow.getCCUserAccount().getUserAccountId());

			/** PATIENT INFO **/
			Patient patient = patientRepo.findById(patientStageWorkflowData.getPatientId()).orElse(null);
			PatientData patientData = modelMap.map(patient, PatientData.class);

			/** PATIENT UA INFO **/
			UserAccount patientSwfCcUa = userAccountService.getUserAccountByUserAccountId(patientStageWorkflowData.getHspCCId());
			UserAccountData patientSwfCcUaData = modelMap.map(patientSwfCcUa, UserAccountData.class);
			Long UserGroupId = 19l;
			UserAccount patUserAcc = userAccountService
					.getUserAccountByUserAccountKeyAndUserGroupId(patientStageWorkflowData.getPatientId(), UserGroupId);
			UserAccountData patUserAccData = modelMap.map(patUserAcc, UserAccountData.class);

			/** EXCLUDE & INCLUDE TODO **/
			String BPCI = "%BPCI%";
			Hospital Hospital = hospitalService.fetchHospitalByHospitalIdAndClientType(hospital.getHospitalId(), BPCI);
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			boolean willMytodoBeImpacted = false;
			if (Hospital != null) {
				HospitalData MytodoBeImpactedInfo = modelMap.map(Hospital, HospitalData.class);
				willMytodoBeImpacted = findWillMytodoBeImpacted(patientStageWorkflowData, MytodoBeImpactedInfo);
			}

			

			/** ORCHESTRATE ALL THE INFO **/
			 userTodoData = UserCcDashboardData.builder().loginCcUaData(loginCcUaData).strykerAdminUaData(strykerAdminUaData)
					.patUseAccData(patUserAccData).hospitalData(hospitalData).patientSwfData(patientStageWorkflowData)
					.patientData(patientData).willMytodoBeImpacted(willMytodoBeImpacted)
					.patientSwfCcUaData(patientSwfCcUaData).build();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userTodoData;
	}

	
	private boolean findWillMytodoBeImpacted(PatientStageWorkflowData patientStageWorkflowData,
			HospitalData MytodoBeImpactedInfo) {
		boolean willMytodoBeImpacted = false;
		if (MytodoBeImpactedInfo != null && patientStageWorkflowData.getBpci().equalsIgnoreCase("N")
				&& patientStageWorkflowData.getPayorId().equals("2")) {
			if (Boolean.FALSE.equals(patientStageWorkflowData.getExcludeMyTodo())) {
				willMytodoBeImpacted = false;
			} else {
				willMytodoBeImpacted = true;
			}
		}
		return willMytodoBeImpacted;
	}

	/** download **/
	/* Overlap ondemannd Sp ***/
	
	@PostMapping("getOverLapPatientDetails/{patientSWFId}")
	public TodoOverlapOnDemandData getOverlapAndNonOverlapPatientDetails(@PathVariable Long patientSWFId) {
		try {
			TodoOverlapOnDemandData todoOverlapOnDemandData = new TodoOverlapOnDemandData();
		OverlapViewOnDemand overLapPatientDetails = todoService.getOverLapPatientDetails(patientSWFId);
		OverlapViewOnDemandData overlapdata = modelMap.map(overLapPatientDetails, OverlapViewOnDemandData.class);
		todoOverlapOnDemandData.setOverLapPatientDetail(overlapdata);

		NonOverlapViewOnDemand nonOverLapPatientDetails = todoService.getNonOverLapPatientDetails(patientSWFId);
		if(nonOverLapPatientDetails!=null) {
		NonOverlapViewOnDemandData nonOverLapData = modelMap.map(nonOverLapPatientDetails,
				NonOverlapViewOnDemandData.class);
		todoOverlapOnDemandData.setNonOverLapPatientDetail(nonOverLapData);
		}
		String mode = todoService.getPatientStageWorkflowDetails(patientSWFId);
		todoOverlapOnDemandData.setMode(mode);
		return todoOverlapOnDemandData;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}
	
	@PostMapping(value = "/fetchUserDataForDashboardAssessment/{loginUaId}/{patientswfId}")
	public CarePlanUserOrchAssessment fetchUserDataForDashboardAssessment(@PathVariable("loginUaId") Long loginUaId,
			@PathVariable("patientswfId") Long patientswfId) {
		CarePlanUserOrchAssessment carePlanUserOrchAssessment = null;
		try {
			carePlanUserOrchAssessment = todoService.fetchHospitalDataByloginCnUaId(loginUaId, patientswfId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return carePlanUserOrchAssessment;
	}
	
	@PostMapping(value = "/saveCustomTodoForMultiPatients")
	public CustomTodoForMultiPatient saveCustomTodoForMultiPatients(@RequestBody CommonObjectData commonObjectData) {
		
		return todoService.saveCustomTodoForMultiPatients(commonObjectData.getPatientSwfIdList());
	}
}
