package com.seind.rc.services.user.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.PatientDashBoardTransaction;

public interface PatientDashBoardTransactionRepository extends JpaRepository<PatientDashBoardTransaction, Long> {

	List<PatientDashBoardTransaction> findByPatientSwfIdInAndHospitalPracticeIdIn(List<Long> patientSwfIdList,List<Long> hospitalPracticeIdList);

	List<PatientDashBoardTransaction> findByHspSurgIdInAndPatientSwfIdIn(List<Long> hspSugIdList, List<Long> pswList);

	List<PatientDashBoardTransaction> findByBpciAndPatientSwfIdIn(String bpcia, List<Long> patientStageWorkflowIdList);

	List<PatientDashBoardTransaction> findByPatientSwfIdInAndProcedureType(List<Long> patientStageWorkflowIdList,
			String procedureType);

	List<PatientDashBoardTransaction> findByPatientSwfIdInAndDosBetween(List<Long> patientStageWorkflowIdList,
			Date dosFrom, Date dosTo);

	List<PatientDashBoardTransaction> findByPayorType(Long payorType);

	List<PatientDashBoardTransaction> findByPayorTypeIsNot(Long payorType);

	List<PatientDashBoardTransaction> findByPatientSwfIdIn(List<Long> patientSwfIdList);

}
