package com.seind.rc.services.user.data;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CCpatientInfoForMessage {

	private Long patientSwfId;
	private Long unReadTotalCount;
	private Date sentDate;
	private Long patientId;
	private Long userAccountId;
	private String dob;
	private String dos;
	private String firstName;
	private String lastName;
	private String imagePath;
	private Integer unReadMsgCount;
	private String serviceLine;
	private String fracture;
	private Long createdBy;
	private Boolean pswIsActive;
	private Boolean enableMarkAsReadUnread;
	private String error;
	private String message;
	
	
}
