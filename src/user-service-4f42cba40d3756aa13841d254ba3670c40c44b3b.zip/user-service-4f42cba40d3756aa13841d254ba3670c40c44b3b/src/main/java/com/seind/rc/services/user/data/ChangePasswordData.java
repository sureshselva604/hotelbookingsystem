package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class ChangePasswordData {
	private String oldPassword;
	private String newPassword;
	private String confirmPassword;

}
