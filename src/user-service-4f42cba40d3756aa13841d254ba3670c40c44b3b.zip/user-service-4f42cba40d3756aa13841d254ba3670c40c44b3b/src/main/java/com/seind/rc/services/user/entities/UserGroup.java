package com.seind.rc.services.user.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name = "UserGroup")
@JsonIgnoreProperties({ "createdDate", "createdBy", "lastModifiedDate", "lastModifiedBy", "careCircleStatus",
		"groupCategory", "shortTitle", "seqno" })
public class UserGroup {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserGroupId", unique = true, nullable = false)
	private Long userGroupId;
	private String groupName;
	private String groupType;
	private Date createdDate;
	private Long createdBy;
	private Date lastModifiedDate;
	private Long lastModifiedBy;
	private Boolean careCircleStatus;
	private String groupCategory;
	private String description;
	private String shortTitle;
	private Integer seqno;

}
