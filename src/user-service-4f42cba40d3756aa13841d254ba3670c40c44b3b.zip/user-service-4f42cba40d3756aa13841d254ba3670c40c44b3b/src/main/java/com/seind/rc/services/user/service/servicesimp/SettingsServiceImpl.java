package com.seind.rc.services.user.service.servicesimp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.entities.Settings;
import com.seind.rc.services.user.repository.SettingsRepository;
import com.seind.rc.services.user.service.SettingsService;

@Service
public class SettingsServiceImpl implements SettingsService {

	@Autowired
	private SettingsRepository settingsRepo;

	/**
	 * M01
	 * 
	 * Get Settings Record By Category And Name
	 */
	@Override
	public Map<String, String> getSettingsMapByCategory(String category) {
		Map<String, String> settingValue = new HashMap<String, String>();
		try {
			List<Settings> setting = settingsRepo.findByCategory(category);
			for (Settings sets : setting) {
				settingValue.put(sets.getName(), sets.getValue());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return settingValue;
	}

}
