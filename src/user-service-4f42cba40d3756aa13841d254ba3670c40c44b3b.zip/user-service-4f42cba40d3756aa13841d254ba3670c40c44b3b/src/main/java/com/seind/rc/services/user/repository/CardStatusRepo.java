package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.transaction.annotation.Transactional;

import com.seind.rc.services.user.entities.Cardstatus;

public interface CardStatusRepo extends JpaRepository<Cardstatus, Long> {

	@Modifying
    @Transactional
    @Query(value = "TRUNCATE TABLE CardStatus", nativeQuery = true)	
	void truncateTable();
	
	@Procedure(procedureName = "SP_UPDATE_PATIENT_CARD_STATUS")
	void updateCardStatus();
	
}
