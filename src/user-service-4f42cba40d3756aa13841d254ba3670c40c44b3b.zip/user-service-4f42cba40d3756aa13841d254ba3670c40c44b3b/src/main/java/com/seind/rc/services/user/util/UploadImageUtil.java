package com.seind.rc.services.user.util;

import java.io.ByteArrayInputStream;
import java.util.Base64;
import java.util.List;
import java.util.ResourceBundle;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.ImageData;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.UserAccount;

public class UploadImageUtil {
	static ResourceBundle appProp = ResourceBundle.getBundle("application");
	private static final Logger LOGGER = LoggerFactory.getLogger(UploadImageUtil.class);
	static String accessKey = appProp.getString("accessKey");
	static String secretKey = appProp.getString("secretKey");
	static String bucketName = appProp.getString("bucketname");

	static String s3URL = appProp.getString("awsS3RealPath");
	

	
	   public static  String uploadUserImage(UserAccount userAccount,Hospital hsp,List<ImageData> userImgData) {
		String imagePath = "";
		try {
			Long groupId = userAccount.getUserGroupId();
			String userGroup = "User";
			if(groupId.equals(UserGroupCons.SURGEON)) {
				userGroup = "Surgeon";
			}else if(groupId.equals(UserGroupCons.CARE_COORDINATOR)) {
				userGroup = "CC";
			}else if(groupId.equals(UserGroupCons.CARE_PARTNER)) {
				userGroup = "CarePartner";
			}else if(groupId.equals(UserGroupCons.PATIENT)) {
				userGroup = "Patient";
			}
			String damPath = "/dam/client/"+hsp.getCode()+"/"+userGroup;
			if(userImgData != null)
				imagePath = saveListAttachment(userImgData, damPath,userGroup);
			
			} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return imagePath;
	}

	public static String saveListAttachment(List<ImageData> imageDatas, String inputfilePath, String userGroup) {
		String imgPath = "";
		for (ImageData imageData : imageDatas) {
			imgPath=saveAttachment(imageData, inputfilePath, userGroup);
		}
		return getNonEmptyString(imgPath);
	}
	public static String saveAttachment(ImageData imageData, String inputfilePath, String userGroup) {
		String imgPath = "";
		try {
			if (imageData != null && imageData.getValue() != null && imageData.getFileType() != null
					&& imageData.getFileName() != null) {
				String uploadImage = imageData.getValue();
				if (uploadImage != null) {
					UUID randomId = UUID.randomUUID();
					if (!inputfilePath.trim().equalsIgnoreCase("")) {
						inputfilePath = inputfilePath.replaceAll("//", "/");
					}
					String[] fileType=imageData.getFileType().split("/");
					String fileNameWithExtension = userGroup.concat("_").concat(randomId.toString()).concat(".").concat(fileType[1]);
					uploadAttachment(imageData.getValue(), fileNameWithExtension, inputfilePath);
					imgPath = inputfilePath.concat("/").concat(fileNameWithExtension);
				}
			
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return getNonEmptyString(imgPath);
		
	}
	 public static void uploadAttachment(String imageContent, String fileNameWithExtension, String filePath) {
		byte[] imageByteArray = null;
		try {
			imageByteArray = Base64.getMimeDecoder().decode(StringUtils.chomp(imageContent));
			ByteArrayInputStream bis = new ByteArrayInputStream(imageByteArray);
			AmazonS3Client s3Client = getS3Client();
			ObjectMetadata metadata = new ObjectMetadata();
		    // Compliant: specifies the content length of the stream.
		    metadata.setContentLength(imageByteArray.length);
			PutObjectRequest s3Put = new PutObjectRequest(/*bucketName.concat(*/filePath, fileNameWithExtension, bis, metadata)
					.withCannedAcl(CannedAccessControlList.PublicReadWrite);
			s3Client.putObject(s3Put);

		} catch (Exception e) {
			LOGGER.error(e.toString());
		}
	}

	public static AmazonS3Client getS3Client() {
		AWSCredentials creds = new BasicAWSCredentials(accessKey, secretKey);
		String hostelModel = appProp.getString("HostedModel");
		if (hostelModel.equalsIgnoreCase("VM")) {
			return (AmazonS3Client) AmazonS3Client.builder().withCredentials(new AWSStaticCredentialsProvider(creds))
					.build();
		} else {
			return (AmazonS3Client) AmazonS3ClientBuilder.standard()
					.withEndpointConfiguration(
							new AwsClientBuilder.EndpointConfiguration(s3URL, Regions.US_EAST_1.getName()))
					.withPathStyleAccessEnabled(true).withCredentials(new AWSStaticCredentialsProvider(creds)).build();
		}
	}
	
	public static String getNonEmptyString(String input) {
		return (input == null || StringUtils.trim(input).isEmpty()) ? null : input;
	}


}
