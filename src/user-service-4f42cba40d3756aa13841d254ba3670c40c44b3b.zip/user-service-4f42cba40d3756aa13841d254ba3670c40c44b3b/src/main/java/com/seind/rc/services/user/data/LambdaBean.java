package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LambdaBean {
	
	private Long patientSWFId;
	private Long patientId;
	private String patientStatus;
	private Long currentEpisodeId;
	private String procedureType;
	private Long hspCcId;
	private String cnFirstName;
	private String cnLastName;
	private Long hspSurgId;
	private String patEmail;
	private String patPhone;
	private String patComType;
	private String patTeleCode;
	private String patFirstName;
	private String patLastName;
	private Long hospitalPracticeId;
	private Long servicelineId;
	private String serviceLineName;
	private String serviceLineLocation;
	private Long hospitalId;
	private String hospitalName;
	private String hspCode;
	private String hspTriggerComType;
	private Boolean allowPatNotification;
	private Long patUaId;
	private String surgFirstName;
	private String surgLastName;
	private String surgGender;
	private String salutation;
	private Long cpAccountId;
	private String cpFirstname;
	private String cpLastname;
	private String cpEmail;
	private String cpTelecode;
	private String cpPhone;
	private String cpComtype;
	private String patGender;
	private Boolean cpAvailable;
	private Boolean patWelcomeflag;
	private Boolean cpWelcomeflag;
	private Boolean emailAlias;
	private Boolean patPushNotification;
	private Boolean cpPushNotification;
	private Long cardOverdueCount;
	private Long cardUptoSpeedCount;
	private Long assigningTodayCount;
	private Boolean hasCheckInCheckUp;
	private String stageCategory;

	private String surgeonName;
	private Date patDos;
	private String appoTitle;
	private String appoMode;
	private Date appointmentDate;
	private String appointmentTime;
	private String appoTime;
	private Long appointmentwith;
	private Long appointmentid;
	private String otherAppmntHspMasterName;
	private Long appmntHspId;

	private Long sentBy;
	private Long recievedBy;
	
	private String patientIdStr;
	private String patientSwfIdStr;
}
