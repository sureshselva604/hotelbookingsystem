package com.seind.rc.services.user.util;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.ResponseMessageSSO;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.data.StatusResponse;
import com.seind.rc.services.user.entities.CaptchaAudit;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserRequestAudit;
import com.seind.rc.services.user.entities.UserSecCodeAudit;
import com.seind.rc.services.user.repository.CaptchaAuditRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserRequestAuditRepository;
import com.seind.rc.services.user.repository.UserSecCodeAuditRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.SSOService;
import com.seind.rc.services.user.service.UserAccountService;

@Component
public class CasUtil {

	public static final Logger logger = LogManager.getLogger(CasUtil.class);

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private SSOService ssoService;

	@Autowired
	private UserSecCodeAuditRepository userSecCodeRepo;

	@Autowired
	private UserSecTransAuditRepository userTransAuditRepo;

	@Autowired
	private UserAccountService userService;

	@Autowired
	private CaptchaAuditRepository captchaAuditRepo;

	@Autowired
	private UserRequestAuditRepository userRequestAuditRepo;

	@Autowired
	private DCCPUtil dccpUtil;

	@Autowired
	private SSOSyncUtil ssoSynUtil;

	@Autowired
	private UserAccountRepository userRepo;

	private static final String HRO_LBL = "hro";
	private static final String ON_BOARD = "onboard";

	public int checkSecurityCodeCount(UserAccount userAct, String casSecCode, String mode) {
		int dbCount = 0;
		int secCount = 0;
		String attempt = "";
		try {
			String count = "";
			if (mode.equalsIgnoreCase("Captcha")) {
				count = rcUserUtil.getSettingValue("CaptchaAttempts", "OTPValidation");
			} else {
				mode = "";
				attempt = (userAct.getUserGroup().getUserGroupId() == 19
						|| userAct.getUserGroup().getUserGroupId() == 20) ? "PatientOTPAttempts" : "OTPAttempts";
				count = rcUserUtil.getSettingValue(attempt, "OTPValidation");
			}

			dbCount = getSecodeCount(userAct.getUserAccountId(), mode);
			secCount = Integer.parseInt(count);

			if (dbCount < secCount) {
				if (userAct.getActive()) {
					insertUserSecCodeAudit(userAct.getUserAccountId(), casSecCode, mode);
					obcascodeInsert(casSecCode, mode, userAct, dbCount);
				}
				dbCount = getSecodeCount(userAct.getUserAccountId(), mode);
			}
			logger.info(" dbCount " + dbCount);
			logger.info(" secCount " + secCount);
			if (dbCount == secCount) {
				rccasobaccountlock(userAct);
			}

		} catch (Exception e) {
			logger.error(e);
		}
		return dbCount;

	}

	/** Security ****/
	private void obcascodeInsert(String casSecCode, String mode, UserAccount userAct, int dbCount) {

		ExecutorService executorService1 = Executors.newFixedThreadPool(5);
		executorService1.execute(() -> {
			String apiUrl = "";
			try {
				/*** Security ****/
				/*** Long casuserId = getCasUserIdByUserName(userAct.getEmail()); ***/
				/*** boolean chkCASUserExists = (casuserId == null) ?false:true ; ***/
				boolean chkCASUserExists = casuserExists(userAct.getEmail(), "hro");
				if (chkCASUserExists) {
					SsoSyncData hrodata = new SsoSyncData();
					hrodata.setUserName(RCUserUtil.rcEncrypt(userAct.getEmail()));
					hrodata.setCount(dbCount);
					hrodata.setTeleCode(casSecCode);
					hrodata.setTitle(mode);
					apiUrl = ssoSynUtil.getSSOAPIURL(HRO_LBL);
					ssoSynUtil.updateInvalidSecCodeAudit(hrodata, apiUrl);
					/*** insertCasUserSecCodeAudit(casuserId, casSecCode, mode); ***/
				}
			} catch (Exception e) {
				logger.error(e);
			}

			try {
				/*** Long obuserId = OnBoardUtil.getOBUserIdByUserName(userAct.getEmail()); ***/
				/*** boolean chkRCObUserExists = (obuserId == null) ?false:true ; ***/
				boolean chkRCObUserExists = casuserExists(userAct.getEmail(), ON_BOARD);
				if (chkRCObUserExists) {
					SsoSyncData obdata = new SsoSyncData();
					obdata.setUserName(RCUserUtil.rcEncrypt(userAct.getEmail()));
					obdata.setCount(dbCount);
					obdata.setTeleCode(casSecCode);
					obdata.setTitle(mode);
					apiUrl = ssoSynUtil.getSSOAPIURL(ON_BOARD);
					ssoSynUtil.updateInvalidSecCodeAudit(obdata, apiUrl);
					/*** insertCasUserSecCodeAudit(casuserId, casSecCode, mode); ***/

				}
			} catch (Exception e) {
				logger.error(e);
			}

			try {
				String emptyStr = RCUserUtil.getNonEmptyWithBlank(userAct.getEmail());
				String dccpUserExist = dccpUtil.checkUserExistsInDCCP(emptyStr);
				if (dccpUserExist != null && dccpUserExist.equalsIgnoreCase("true")) {
					dccpUtil.updateInvalidSecCodeAuditDCCP(userAct.getEmail(), dbCount, casSecCode, mode);
				}
			} catch (Exception e) {
				logger.error(e);
			}

		});
		/*** ThreadShutdown ***/
		new RCUserUtil().threadShutdown(executorService1);
	}

	private void rccasobaccountlock(UserAccount userAct) {
		try {
			accountLockByRc(userAct);
			updateUserSecTransAudit(userAct.getUserAccountId());
			/***
			 * casAccountlock(userAct); obAccountlock(userAct);
			 ***/
		} catch (Exception e) {
			logger.error(e);
		}

	}

	public boolean casuserExists(String userName, String url) {
		boolean chkCASUserExists = false;
		try {
			String urlValue = ssoSynUtil.getSSOAPIURL(url);
			ResponseMessageSSO body = ssoSynUtil.checkUserExists(userName, urlValue);
			chkCASUserExists = body.getStatus();

		} catch (Exception e) {
			logger.error(e);
		}
		return chkCASUserExists;
	}

	public int getSecodeCount(Long userId, String mode) {
		int ct = 0;

		try {
			List<UserSecCodeAudit> secCodeAudit = userSecCodeRepo.findByUserAccount_UserAccountIdAndStatus(userId,
					true);
			if (StringUtils.isNotBlank(mode)) {
				secCodeAudit = userSecCodeRepo.findByUserAccount_UserAccountIdAndStatusAndModeLike(userId, true,
						mode.toUpperCase());
			}
			ct = !secCodeAudit.isEmpty() && secCodeAudit != null ? secCodeAudit.size() : 0;

		} catch (Exception e) {
			logger.error(e);
		}

		return ct;
	}

	public void insertUserSecCodeAudit(Long userId, String casSecCode, String mode) {
		try {
			UserSecCodeAudit secCodeAudit = new UserSecCodeAudit();
			UserAccount user = userRepo.findById(userId).orElse(null);
			secCodeAudit.setUserAccount(user);
			secCodeAudit.setSecCode(casSecCode);
			secCodeAudit.setMode(mode);
			secCodeAudit.setStatus(true);
			secCodeAudit.setCreatedDate(new Date());
			userSecCodeRepo.save(secCodeAudit);

		} catch (Exception e) {
			logger.error(e);
		}

	}

	private void accountLockByRc(UserAccount userAct) {
		try {
			userService.updateUserAccountActiveAndLastModifiedDate(userAct.getUserAccountId(), false);
			if (userAct.getWelcomeFlag()) {
				resetUserSecCodeAudit(userAct);
				userRequestAuditIns(userAct, "Blocked-New");
			} else {
				resetUserSecCodeAudit(userAct);
				userRequestAuditIns(userAct, "Blocked-SecurityAnswer");
			}
		} catch (Exception e) {
			logger.error(e);
		}
		/** SSO Captcha **/
		insertCaptchaAuditValues(userAct.getUserAccountId());

	}

	private void insertCaptchaAuditValues(Long userAccountId) {
		try {
			CaptchaAudit captcha = new CaptchaAudit();
			UserAccount user = userRepo.findById(userAccountId).orElse(null);
			captcha.setUserId(user);
			captcha.setLockStatus(true);
			captcha.setLockedDate(new Date());
			captchaAuditRepo.save(captcha);

		} catch (Exception e) {
			logger.error(e);
		}

	}

	public void resetUserSecCodeAudit(UserAccount userAct) {
		try {
			userSecCodeRepo.userSecCodeAuditUpdate(false, userAct.getUserAccountId());
		} catch (Exception e) {
			logger.error(e);
		}

	}

	public void userRequestAuditIns(UserAccount userAct, String mode) {

		try {
			UserRequestAudit reqAudit = new UserRequestAudit();
			reqAudit.setUserAccount(userAct);
			reqAudit.setMode(mode);
			reqAudit.setStatus("Pending");
			reqAudit.setCreatedOn(new Date());
			userRequestAuditRepo.save(reqAudit);
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public void updateUserSecTransAudit(Long userId) {
		try {
			userTransAuditRepo.updateUserSecTransAuditActiveByUserId(userId);
		} catch (Exception e) {
			logger.error(e);
		}

	}

	public void captchaReActive(Long userId, String captcha) {
		try {
			userTransAuditRepo.updateUserSecTransAuditActiveByModeAndOtp(true, userId, "captcha", captcha);
		} catch (Exception e) {
			logger.error(e);
		}

	}

	public StatusResponse getStatusRespWithSecCodeCount(UserAccount userAct, String decodedBytePwd,
			StatusResponse statusResp) {
		int count = checkSecurityCodeCount(userAct, decodedBytePwd, "NewActivation");
//				LOGGER.info("Count {}",count);
//		count++;
		String attempt = "OTPAttempt" + count;
		try {
			String msg = rcUserUtil.getSettingValue(attempt, "OTPValidation");
			statusResp.setMessage(msg);
			statusResp.setStatus(CommonConstant.FAILURE);
			statusResp.setInvalidCount("" + count);
		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
		}
		return statusResp;
	}
}