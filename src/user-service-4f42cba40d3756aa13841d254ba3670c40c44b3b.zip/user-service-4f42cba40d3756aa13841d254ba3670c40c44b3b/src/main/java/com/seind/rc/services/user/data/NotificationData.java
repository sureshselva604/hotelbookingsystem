package com.seind.rc.services.user.data;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
public class NotificationData {
	@NonNull
	private String notificationType;
	
	@NonNull
	private Long toUser;
	
	@NonNull
	private Long hspId;

	private Long staffUserId;
	private Long cpUserId;
	private Long surgeonId;
	private Long patientId;
	private Long patientSwfId;
	private Long servicelineId;

	private String randID;
	private String surveyName;
	private String oldDOS;
	private String newDOS;
	private String appScheduled;
	private String appOnAppmtDate;
	private String relationship;
	private String stageCategory;
	private String count;
	private String todocount;
	private String password;
	private String nextInterval;
	private String days;
	private String notificationMode;
	private String serverUrl;
	private String path;
	private String portalName;

}
