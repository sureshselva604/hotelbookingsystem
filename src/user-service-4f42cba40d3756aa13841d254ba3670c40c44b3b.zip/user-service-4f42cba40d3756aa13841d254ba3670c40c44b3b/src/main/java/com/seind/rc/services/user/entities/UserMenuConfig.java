package com.seind.rc.services.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "UserMenuConfig")
public class UserMenuConfig {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userMenuConfigId;
	private Long userMenuId;
	private Long userAccountId;
	private Boolean status;
}
