package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.SurgeonData;
import com.seind.rc.services.user.data.SurgeonDeviceData;
import com.seind.rc.services.user.entities.Surgeon;

public interface SurgeonService {

	List<SurgeonData> getSurgeonList(Long hospitalId);

	Surgeon getSurgeonByPatientId(Long userAccountKey);

	List<SurgeonDeviceData> getSurgeonInfoByPatientId(Long patientId);

	Surgeon getSurgeonByIdAndActive(Long surgeonId);

}
