package com.seind.rc.services.user.util;

import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class GenerateOTP {

	private GenerateOTP() {
	}

	protected static final Log logger = LogFactory.getLog(GenerateOTP.class);
	private static final String ALPHANUM = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz";
	private static final String LOG_ERR_GENERATE_OTP = "GenerateOTP: ";

	public static String getAlphaNumericForUserName() {
		StringBuilder sb = new StringBuilder();
		try {
			Random rnd = RCUserUtil.getRandom();
			while (sb.length() <= 40) {
				int index = rnd.nextInt(61);
				sb.append(ALPHANUM.charAt(index));
			}
		} catch (Exception e) {
			logger.error(LOG_ERR_GENERATE_OTP + e);
		}
		return sb.toString();
	}

	public static String getAlphaNumericRandomPwd() {
		StringBuilder sb = new StringBuilder();
		try {
			Random rnd = RCUserUtil.getRandom();
			while (sb.length() <= 8) {
				int index = rnd.nextInt(61);
				sb.append(ALPHANUM.charAt(index));
			}
		} catch (Exception e) {
			logger.error(LOG_ERR_GENERATE_OTP + e);
		}
		return sb.toString();
	}
}