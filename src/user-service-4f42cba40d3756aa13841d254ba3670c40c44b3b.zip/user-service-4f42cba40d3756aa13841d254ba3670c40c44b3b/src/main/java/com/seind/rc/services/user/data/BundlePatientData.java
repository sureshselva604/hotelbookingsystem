package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class BundlePatientData {
	private String firstName;
	private String lastName;
	private Date dob;
	private String email;
	private String gender;
	private String imagePath;
	private String ssn;
	private String teleCode;
	private String teleCountryCode;
	private String phone;
	private String mrn;
	private String otherTeleCode;
	private String otherPhone;
	private String otherTeleCountryCode;
	private Long otherPhoneType;
	private Long patientId;
}
