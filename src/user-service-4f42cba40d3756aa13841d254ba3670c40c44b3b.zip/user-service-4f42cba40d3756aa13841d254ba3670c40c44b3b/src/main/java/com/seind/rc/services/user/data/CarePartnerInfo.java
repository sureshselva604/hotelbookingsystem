package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CarePartnerInfo {
	
	private Long userAccountId;
	private String firstName;
	private String lastName;
	private Long whoseCarePartner;
	private String imagePath;
	private String title;
	private String email;
	private String phone;
	private String gender;
	@Default
	private String randomId= "";
	private Boolean active;
	private Integer sequenceNo;

}
