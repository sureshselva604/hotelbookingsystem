package com.seind.rc.services.user.data;

import java.util.Date;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NotesPatientDashBoard {

private Date sentDate;
private String strSentTime;
private Long ccUserAccountId;
private String description;
private String strSentDate;
private String patientOrCcName;
private String userRole;
@NotNull
private Long sentBy;
private Long receivedBy;
private String sendByFirstName;
private String sendByLastName;
private String receivedByFirstName;
private String receivedByLastName;


}


