package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.data.SurgeonData;
import com.seind.rc.services.user.data.SurgeonDeviceData;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.SurgeonRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.SurgeonService;

@Service
public class SurgeonServiceImpl implements SurgeonService {

	private static final Logger LOGGER = LogManager.getLogger(SurgeonServiceImpl.class);

	@Autowired
	private SurgeonRepository surgeonRepo;

	@Autowired
	private HospitalSurgeonRepository hspSugRepo;

	@Autowired
	private UserAccountRepository userRepository;

	@Autowired
	private PatientStageWorkflowRepository pswfRepo;

	@Autowired
	private ModelMapper modelMap;

	/**
	 * M01
	 * 
	 * Get Surgeon Details By HospitalId
	 */
	@Override
	public List<SurgeonData> getSurgeonList(Long hospitalId) {
		List<SurgeonData> response = new ArrayList<SurgeonData>();
		try {
			List<Long> userAccountKey = hspSugRepo.findByHospitalId(hospitalId).stream()
					.map(HospitalSurgeon::getSurgeon).map(Surgeon::getSurgeonId).collect(Collectors.toList());
			List<Surgeon> sugData = surgeonRepo.findBySurgeonIdIn(userAccountKey);
			for (Surgeon sug : sugData) {
				SurgeonData surgeonData = new SurgeonData();
				surgeonData.setFirstName(sug.getFirstName());
				surgeonData.setLastName(sug.getLastName());
				surgeonData.setSurgeonId(sug.getSurgeonId());
				UserAccount sugUa = userRepository.findByUserAccountKey(sug.getSurgeonId()).stream().findFirst()
						.orElse(null);
				surgeonData.setSurgeonUserAccId(sugUa != null ? sugUa.getUserAccountId() : null);
				Long hspSugId = hspSugRepo
						.findBySurgeon_SurgeonIdAndHospitalIdOrderByHospitalSurgeonIdDesc(sug.getSurgeonId(),
								hospitalId)
						.get(0).getHospitalSurgeonId();
				surgeonData.setHospitalSurgeonId(hspSugId);
				response.add(surgeonData);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * M02
	 */
	@Override
	public Surgeon getSurgeonByPatientId(Long userAccountKey) {
		Surgeon surg = null;
		try {
			PatientStageWorkflow stgFlow = pswfRepo.findByPatient_PatientId(userAccountKey).stream().findFirst()
					.orElse(null);
			UserAccount sugUa = userRepository.findByUserAccountKey(stgFlow.getHspSurgId()).stream().findFirst()
					.orElse(null);
			surg = surgeonRepo.findById(sugUa != null ? sugUa.getUserAccountId() : 0L).orElse(null);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return surg;
	}

	/**
	 * M03
	 */
	@Override
	public List<SurgeonDeviceData> getSurgeonInfoByPatientId(Long patientId) {
		List<SurgeonDeviceData> surgeonDeviceData = null;
		try {
			List<PatientStageWorkflow> pswf = pswfRepo.findByPatient_PatientId(patientId);
			surgeonDeviceData = pswf.stream()
					.map(a -> modelMap.map(a.getSurgeonUserAccount().getSurgeon(), SurgeonDeviceData.class)).toList();

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return surgeonDeviceData;
	}

	/**
	 * M04
	 */
	@Override
	public Surgeon getSurgeonByIdAndActive(Long surgeonId) {
		Surgeon surgeon = null;
		try {
			surgeon = surgeonRepo.findBySurgeonIdAndActive(surgeonId, true);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return surgeon;
	}

}
