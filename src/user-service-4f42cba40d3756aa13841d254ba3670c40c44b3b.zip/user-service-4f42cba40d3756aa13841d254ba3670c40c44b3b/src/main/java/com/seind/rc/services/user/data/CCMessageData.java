package com.seind.rc.services.user.data;

import java.util.Map;

import lombok.Data;

@Data
public class CCMessageData {
	private Map<Long, Long> sentBy;
	private Long patientSwfId;
}
