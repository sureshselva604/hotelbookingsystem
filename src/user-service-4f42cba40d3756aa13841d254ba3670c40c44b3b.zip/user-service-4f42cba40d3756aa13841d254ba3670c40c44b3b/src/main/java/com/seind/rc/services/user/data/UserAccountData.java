package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserAccountData {
	private String firstName;
	private String lastName;
	private String address1;
	private String city;
	private String state;
	private String zipcode;
	private String email;
	private String title;
	private String gender;
	private String phone;
	private String teleCode;
	private String teleCountryCode;
	private String imagePath;
	private Long userGroupId;
	private Long userAccountKey;
	private Boolean deIdFlag;
	private Boolean isdelete;
	private String description;
	private String comType;
	private Long whoseCarePartner;
	private Boolean welcomeFlag;
	private String randId;
	private String groupType;
	private String groupName;
	private Long userAccountId;
	private String otherPhoneType;
	private String phoneTypeDesc;
	private String otherTeleCode;
	private String otherTeleCountryCode;
	private String otherPhone;
	private Boolean cpActive;
	private String relationShip;
	private boolean isPhoneValid;
	private boolean isEmailValid;
}
