package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
public class SSOAuditLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LogId", unique = true, nullable = false)
	private Long logId;
	private String userName;
	private String apiName;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	private String apiJson;
	private String error;

}
