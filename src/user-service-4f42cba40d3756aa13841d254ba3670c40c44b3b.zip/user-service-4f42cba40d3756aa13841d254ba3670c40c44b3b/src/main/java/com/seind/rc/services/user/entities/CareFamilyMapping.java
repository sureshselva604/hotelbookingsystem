package com.seind.rc.services.user.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name = "CareFamilyMapping")
public class CareFamilyMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "careFamilyMapId", unique = true, nullable = false)
	private Long careFamilyMapId;
	private Long userAccId;
	@NotNull
	private Boolean active;
	private Long hospitalId;
	@NotNull
	private Long clientId;
	private Long payorTypeId;
	private String procedureType;
	@NotNull
	private Long careGiver;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "careGiver", updatable = false, insertable = false)
	private UserAccount careGiverUa;

}
