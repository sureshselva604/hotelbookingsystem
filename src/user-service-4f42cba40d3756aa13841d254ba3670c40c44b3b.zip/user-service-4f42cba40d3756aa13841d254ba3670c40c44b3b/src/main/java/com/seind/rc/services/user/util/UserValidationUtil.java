package com.seind.rc.services.user.util;

import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.LogDeviceTransAuditData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.UserValidateModel;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.service.UserAccountService;

@Component
public class UserValidationUtil {
	
	@Autowired
	public UserAccountService userService;
	
	private static final Logger logger = LogManager.getLogger(UserValidationUtil.class);

	
	public ResponseMessage validateEmailorPhone(UserValidateModel emailPhone) {
		ResponseMessage response = userService.validateEmailorPhone(emailPhone);
		return response;
	}
	
	public static Long getAgewithDOB(Date dob, Date createdDate) {
		Calendar today = Calendar.getInstance();
		Calendar birthDate = Calendar.getInstance();

		long userAge = 0;

		birthDate.setTime(dob);
		if (birthDate.after(today)) {
			throw new IllegalArgumentException("Can't be born in the future");
		}

		userAge = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);

		if (((birthDate.get(Calendar.DAY_OF_YEAR) - today.get(Calendar.DAY_OF_YEAR) > 3)
				|| (birthDate.get(Calendar.MONTH) > today.get(Calendar.MONTH)))
				|| (birthDate.get(Calendar.MONTH) == today.get(Calendar.MONTH)
						&& (birthDate.get(Calendar.DAY_OF_MONTH) > today.get(Calendar.DAY_OF_MONTH)))) {
			userAge--;
		}
		return  userAge;
		
	}
	
	
	/**
	 * Set OnBoardLinkSent(true) in UserAccount if OnBoardLinkSent to User
	 */
	public static UserAccount getUserAccOnboardLinkon(UserAccount userAccount, String willSendOnBoardWelcomeLink) {
		if (willSendOnBoardWelcomeLink.equals("Y") || willSendOnBoardWelcomeLink.equals("P")) {
			userAccount.setIsOnBoardLinkSent(true);
			userAccount.setOnBoardLinkSentOn(new Date());
		}else {
			userAccount.setIsOnBoardLinkSent(false);
			userAccount.setOnBoardLinkSentOn(null);
		}
		return userAccount;
	}
	
	public static LogDeviceTransAuditData deviceLoginAudit(Long patientId, Long patientSwfId, String moduleName, String type, String events) {
		LogDeviceTransAuditData logData = new LogDeviceTransAuditData();
		try {
			logData.setPatientId(patientId);
			logData.setPatientSwfId(patientSwfId);
			logData.setModuleName(moduleName);
			logData.setType(type);
			logData.setEvents(events);
		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
		}
		return logData;
	}


}
