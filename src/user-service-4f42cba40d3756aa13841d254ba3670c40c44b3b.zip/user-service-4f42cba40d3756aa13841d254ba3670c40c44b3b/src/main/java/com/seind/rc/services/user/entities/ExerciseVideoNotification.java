package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "ExerciseVideoNotification")
public class ExerciseVideoNotification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long patientSwfId;
	private Long patientId;
	private Long userAccountId;
	private Long currentEpisodeId;
	private String firstName;
	private String lastName;
	private String email;
	private String teleCode;
	private String phone;
	private String Gender;
	private String code;
	private String comType;
	private String surgeonName;
	private String stageCategory;
	private Date dos;
	private Boolean emailAlias;
	private Long cpaccountid;
	private String cpfirstname;
	private String cplastname;
	private String cpemail;
	private String cptelecode;
	private String cpphone;
	private String cpcomtype;
	private Boolean patwelcomeflag;
	private Boolean cpwelcomeflag;
	private Boolean pushNotification;
	private Boolean cpPushNotification;
	private Long zoneId;

}
