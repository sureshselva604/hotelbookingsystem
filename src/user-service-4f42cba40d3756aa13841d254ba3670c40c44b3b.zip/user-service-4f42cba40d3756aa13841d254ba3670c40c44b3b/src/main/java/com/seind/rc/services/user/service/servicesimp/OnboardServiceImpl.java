package com.seind.rc.services.user.service.servicesimp;

import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CheckValidationData;
import com.seind.rc.services.user.data.UpdatePwdData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.ValidationMessage;
import com.seind.rc.services.user.data.WelcomeInfoData;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.RKUserAccount;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.CarePartnerMapService;
import com.seind.rc.services.user.service.OnboardService;
import com.seind.rc.services.user.service.PatientService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecTransAuditService;

@Service
public class OnboardServiceImpl implements OnboardService {

	private static final Logger LOGGER = LogManager.getLogger(OnboardServiceImpl.class);

	private static final String INVALID_USER = "Invalid user";
	private static final String ERR_MSG = " Your account is no longer active. So Please contact your healthcare provider or administrator for details.";
	private static final String LOG_ACCOUNTACTIVEMESSGE = "Your Account is already Activated.";
	private static final String PAT_NAME = "<<pat_name>>";
	private static final String ADD_USER = "AddUser";

	private ResourceBundle applicationProp = ResourceBundle.getBundle("application");

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private PatientService patientService;

	@Autowired
	private UserSecTransAuditService userSecTransAuditService;

	@Autowired
	private CarePartnerMapService careService;

	@Autowired
	private HospitalRepository hospitalRepo;

	@Autowired
	private HospitalSurgeonRepository hospitalSurgeonRepo;

	@Autowired
	private UserAccountRepository userAccountRepo;

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;

	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepo;

	@Autowired
	private PatientStageWorkflowRepository pswfRepo;

	/**
	 * M01
	 * 
	 * Validates user credentials based on the provided UserName.
	 *
	 * @param objData The CommonObjectData containing user information.
	 * @return CheckValidationData containing validation results.
	 */
	@Override
	public CheckValidationData checkUserValidation(UserRequestData payload) {
		CheckValidationData checkValData = new CheckValidationData();
		String userName = payload.getUserName();
		if (userName != null && !userName.isEmpty()) {
			UserAccount userAccount = userAccountService.validateUserNew(userName).stream().findFirst().orElse(null);
			if (userAccount == null) {
				draftArchiveUserAccountTocheckUserValidation(userName, checkValData);
			} else {
				executeIfUserAccountNotNull(userAccount, checkValData);
			}
		} else {
			draftByStatus(401, false, checkValData);
			draftByErrorMessage(CommonConstant.USER_NOTENROLLED_MSG, CommonConstant.USER_NOTENROLLED_MSG, checkValData);
		}
		return checkValData;
	}

	/**
	 * M02
	 * 
	 * This method is used to check whether the User is Archived or Not
	 */
	private void draftArchiveUserAccountTocheckUserValidation(String email, CheckValidationData checkValData) {
		try {
			RKUserAccount archievedUa = userAccountService.rkValidate(email);

			if (archievedUa != null && archievedUa.getEmail().equals(email)) {
				draftByStatus(401, false, checkValData);
				draftByErrorMessage(CommonConstant.ACCOUNT_DEACTIVATED, CommonConstant.BODYPARTDEACTIVEATE,
						checkValData);
			} else {
				draftByStatus(401, false, checkValData);
				draftByErrorMessage(CommonConstant.USER_NOTENROLLED_MSG, CommonConstant.USER_NOTENROLLED_MSG,
						checkValData);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M03
	 * 
	 * This method is used to draft JSON for Response Status
	 */
	private void draftByStatus(int statusCode, boolean status, CheckValidationData checkValData) {
		try {
			checkValData.setStatusCode(statusCode);
			checkValData.setStatus(status);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M04
	 * 
	 * This method is used to draft JSON for Error Message
	 */
	private void draftByErrorMessage(String messageOneValue, String messageTwoValue, CheckValidationData checkValData) {
		try {
			checkValData.setError(messageOneValue);
			checkValData.setMessage(messageTwoValue);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M05
	 * 
	 * This method is used to verify the User and draft response based upon the
	 * business logic
	 */
	private void executeIfUserAccountNotNull(UserAccount userAccount, CheckValidationData checkValData) {
		try {
			ValidationMessage validation = findIfCheckAllowedWithMsg(userAccount);
			if (validation.isCheckAllowed()) {
				executeIfCheckAllowed(userAccount, checkValData);
			} else {
				draftByStatus(401, false, checkValData);
				draftByErrorMessage(validation.getMessage(), validation.getMessage(), checkValData);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M06
	 * 
	 * This Method is for Checking body part and draft response based upon the
	 * status of the body part for patient
	 */
	private ValidationMessage findIfCheckAllowedWithMsg(UserAccount userAccount) {
		ValidationMessage validation = new ValidationMessage();
		boolean isCheckAllowed = validation.isCheckAllowed();
		String msg = validation.getMessage();
		try {
			int activeBodypart = 0;
			if ((userAccount.getUserGroup().getUserGroupId()).equals(19L)) {
				activeBodypart = patientService.activeBodypart(userAccount.getUserAccountKey());
				if (activeBodypart == 0) {
					isCheckAllowed = false;
				}
				msg = CommonConstant.BODYPARTDEACTIVEATE;
				validation.setCheckAllowed(isCheckAllowed);
				validation.setMessage(msg);
			} else if ((userAccount.getUserGroup().getUserGroupId()).equals(20L)) {
				validation = subFindIfCheckAllowedWithMsgForCP(userAccount);
			} else {
				validation.setCheckAllowed(isCheckAllowed);
				validation.setMessage(msg);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return validation;
	}

	/**
	 * M07
	 * 
	 * This Method is for Checking body part and draft response based upon the
	 * status of the body part for Care Partner
	 */
	private ValidationMessage subFindIfCheckAllowedWithMsgForCP(UserAccount userAccount) {
		ValidationMessage validation = new ValidationMessage();
		try {
			boolean checkAllowed = validation.isCheckAllowed();
			String msg = validation.getMessage();

			Patient patient = patientRepo.findById(userAccount.getWhoseCarePartner()).orElse(null);
			boolean bodyPartStatus = false;
			List<PatientStageWorkflow> pswList = pswfRepo.findByPatient_PatientId(userAccount.getWhoseCarePartner());
			for (PatientStageWorkflow patientStageWorkflow : pswList) {
				if (patientStageWorkflow.getPswIsActive()) {
					bodyPartStatus = true;
					break;
				}
			}
			if (!bodyPartStatus) {
				int activeBodypart = patientService.activePatientBodypartforCP(userAccount.getUserAccountId());
				if (activeBodypart == 0) {
					checkAllowed = false;
				}
				msg = CommonConstant.BODYPARTDEACTIVEATE_CP;
				msg = msg.replaceAll(PAT_NAME, patient.getFirstName());
			}
			validation.setCheckAllowed(checkAllowed);
			validation.setMessage(msg);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return validation;
	}

	/**
	 * M08
	 * 
	 * This Method is for Checking Isdelete flag and draft response
	 */
	private void executeIfCheckAllowed(UserAccount userAccount, CheckValidationData checkValData) {
		try {
			List<UserSecTransAudit> userSecAuditList = userSecTransAuditService
					.fetchTopFirstRandidByUserAccountId(userAccount.getUserAccountId());
			if (Boolean.TRUE.equals(userAccount.getIsdelete())) {
				draftByStatus(401, false, checkValData);
				draftByErrorMessage(CommonConstant.ACCOUNT_DEACTIVATED, CommonConstant.BODYPARTDEACTIVEATE,
						checkValData);
			} else {
				executeIfNotIsDeleteInUserAccount(userAccount, checkValData, userSecAuditList);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			draftByStatus(401, false, checkValData);
			draftByErrorMessage(INVALID_USER, INVALID_USER, checkValData);
		}
	}

	/**
	 * M09
	 * 
	 * This Method is for Checking Isdelete flag and draft response for patients and
	 * care partner
	 */
	private void executeIfNotIsDeleteInUserAccount(UserAccount userAccount, CheckValidationData checkValData,
			List<UserSecTransAudit> userSecAuditList) {
		try {
			if (userAccount.getUserGroup().getUserGroupId() == 19
					|| userAccount.getUserGroup().getUserGroupId() == 20) {
				boolean cpActive = true;
				if (userAccount.getUserGroup().getUserGroupId() == 20) {
					List<CarePartnerMap> cpList = careService.getCarePartnerPatientList(userAccount.getUserAccountId());
					if (cpList != null && !cpList.isEmpty()) {
						cpActive = true;
					} else {
						cpActive = false;
					}
				}
				if (!userSecAuditList.isEmpty() && cpActive) {
					draftInfoWhenUserSecAuditListNotNullAndCpActive(userAccount, checkValData, userSecAuditList);
				} else {
					draftByStatus(401, false, checkValData);
					draftByErrorMessage(INVALID_USER, INVALID_USER, checkValData);
				}
			} else {
				draftInfoWhenUserSecAuditListNotNullAndCpActive(userAccount, checkValData, userSecAuditList);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M10
	 * 
	 * Draft Over all Response based upon the business logic
	 */
	private void draftInfoWhenUserSecAuditListNotNullAndCpActive(UserAccount userAccount,
			CheckValidationData checkValData, List<UserSecTransAudit> userSecAuditList) {
		try {
			if (userAccount.getActive() && userAccount.getWelcomeFlag() == true
					&& userSecAuditList.get(0).getMode().equalsIgnoreCase(ADD_USER)) {
				if(userSecAuditList.get(0).getIsActive()) {
					checkValData.setRandId(userSecAuditList.get(0).getRandomId());
					checkValData.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
					draftByStatus(200, true, checkValData);
				}else {
					draftByStatus(401, false, checkValData);
					draftByErrorMessage(LOG_ACCOUNTACTIVEMESSGE, LOG_ACCOUNTACTIVEMESSGE, checkValData);
				}
			} else if (!userAccount.getActive() && userAccount.getWelcomeFlag() == true
					&& userSecAuditList.get(0).getMode().equalsIgnoreCase(ADD_USER)
					&& userSecAuditList.get(0).getIsActive()) {
				draftByStatus(401, true, checkValData);
				draftByErrorMessage(ERR_MSG, ERR_MSG, checkValData);

			} else if (userAccount.getActive() && userAccount.getWelcomeFlag() == false) {
				draftByStatus(401, false, checkValData);
				draftByErrorMessage(LOG_ACCOUNTACTIVEMESSGE, LOG_ACCOUNTACTIVEMESSGE, checkValData);

			} else if (!userAccount.getActive() && userAccount.getWelcomeFlag() == false) {
				draftByStatus(401, false, checkValData);
				draftByErrorMessage(ERR_MSG, ERR_MSG, checkValData);

			} else {
				draftByStatus(401, false, checkValData);
				draftByErrorMessage(INVALID_USER, INVALID_USER, checkValData);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M11
	 * 
	 * This method is for get Patient Details for Dashboard
	 */
	@Override
	public WelcomeInfoData getPatientWelcomeInfo(UpdatePwdData pwdData, WelcomeInfoData welcomeInfoData) {
		String randId = pwdData.getRandId();
		if (randId != null && !randId.isEmpty()) {
			UserSecTransAudit userSecTransAuditObj = userSecTransAuditRepo.findByRandomId(randId);
			UserAccount userAccount = userSecTransAuditObj != null ? userSecTransAuditObj.getUserAccount() : null;
			if (userAccount != null)
				onBoardPatient(userSecTransAuditObj, welcomeInfoData);
		}
		return welcomeInfoData;
	}

	/**
	 * M12
	 * 
	 * This method is responsible for get and map the data for response
	 * 
	 * @param userSecTransAudit
	 * @param haveOnboarded
	 * @param welcomeInfoData
	 * @return
	 */
	public WelcomeInfoData onBoardPatient(UserSecTransAudit userSecTransAudit, WelcomeInfoData welcomeInfoData) {
		Hospital hospital = null;
		UserAccount createdBy = null;
		String onBehalfHalf = "";
		switch (userSecTransAudit.getUserAccount().getUserGroup().getUserGroupId().toString()) {

		case "18":
			List<HospitalSurgeon> hospitalSurgeons = hospitalSurgeonRepo
					.findBySurgeon_SurgeonId(userSecTransAudit.getUserAccount().getUserAccountKey());
			List<Long> hospitalIds = hospitalSurgeons.stream().map(HospitalSurgeon::getHospitalId).distinct()
					.collect(Collectors.toList());
			hospital = hospitalRepo.findByHospitalIdInAndDirectClient(hospitalIds, true);
			break;

		case "19":
			createdBy = userAccountRepo.findById(userSecTransAudit.getUserAccount().getCreatedBy()).orElse(null);
			hospital = hospitalRepo.findById(createdBy.getUserAccountKey()).orElse(null);
			break;

		case "20":
			Patient patient = patientRepo.findById(userSecTransAudit.getUserAccount().getWhoseCarePartner())
					.orElse(null);
			UserAccount patientUserAccount = userAccountRepo
					.findByUserAccountKeyAndUserGroup_GroupType(patient.getPatientId(), "PATIENT");
			List<CarePartnerMap> carePartnerMaps = carePartnerMapRepo.findByActiveTrueAndUserAccount_UserAccountId(
					userSecTransAudit.getUserAccount().getUserAccountId());

			onBehalfHalf = carePartnerMaps.stream().map(CarePartnerMap::getUserAccount).map(UserAccount::getFirstName)
					.distinct().findFirst().orElse(null);

			createdBy = userAccountRepo.findById(patientUserAccount.getCreatedBy()).orElse(null);
			hospital = hospitalRepo.findById(createdBy.getUserAccountKey()).orElse(null);
			break;

		default:
			createdBy = userSecTransAudit.getUserAccount();
			hospital = hospitalRepo.findById(createdBy.getUserAccountKey()).orElse(null);
		}

		welcomeInfoData.setPatientName(userSecTransAudit.getUserAccount().getFirstName() + " "
				+ userSecTransAudit.getUserAccount().getLastName());
		welcomeInfoData.setPatientFirstName(userSecTransAudit.getUserAccount().getFirstName());
		welcomeInfoData.setPatientLastName(userSecTransAudit.getUserAccount().getLastName());
		welcomeInfoData.setDateFormat(hospital.getCountryCode().getDateFormat().toUpperCase());
		welcomeInfoData.setOnbehalfName(onBehalfHalf);

		welcomeInfoData.setClientLogoPath(setLogopath(hospital));

		welcomeInfoData.setUserAccountId(userSecTransAudit.getUserAccount().getUserAccountId());
		welcomeInfoData.setUserGroupId(userSecTransAudit.getUserAccount().getUserGroup().getUserGroupId());
		welcomeInfoData.setEmail(userSecTransAudit.getUserAccount().getEmail());
		welcomeInfoData.setTeleCode(userSecTransAudit.getUserAccount().getTeleCode());
		welcomeInfoData.setPhone(userSecTransAudit.getUserAccount().getPhone());

		welcomeInfoData.setStatus("Success");
		welcomeInfoData.setMessage("Success");

		if (userSecTransAudit.getUserAccount().getWelcomeFlag() == false) {
			welcomeInfoData.setStatus(CommonConstant.FAILURE);
			welcomeInfoData.setMessage(CommonConstant.ACTIVELINKEXPIRED);
		} else if (userSecTransAudit.getIsActive() == false) {
			welcomeInfoData.setStatus(CommonConstant.FAILURE);
			welcomeInfoData.setMessage(CommonConstant.LATESTACTIVELINK);
		}
		return welcomeInfoData;
	}

	/**
	 * M13
	 * 
	 * Setting logo path for response
	 * 
	 * @param hsp
	 * @return
	 */
	public String setLogopath(Hospital hsp) {
		String logopathlocalvar = "";
		if (CommonConstant.HOSTEDMODEL.equalsIgnoreCase("cloud")) {
			logopathlocalvar = applicationProp.getString(CommonConstant.AWS_S3_REAL_PATH) + hsp.getLogo();
		} else {
			logopathlocalvar = applicationProp.getString("VMURL") + hsp.getLogo();
		}
		return logopathlocalvar;
	}
}
