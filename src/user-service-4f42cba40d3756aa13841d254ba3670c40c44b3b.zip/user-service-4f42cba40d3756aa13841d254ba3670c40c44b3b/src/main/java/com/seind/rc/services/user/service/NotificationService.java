package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.NotificationDTO;
import com.seind.rc.services.user.data.NotifyReqData;
import com.seind.rc.services.user.data.TokenListData;

public interface NotificationService {

	List<TokenListData> getTokenListbyPatientorCpId(Long userAccountId);

	NotificationDTO getUsersData(NotifyReqData notifyReqData);

	List<NotifyReqData> workflowNotificationData(Long patientSWFId);

}
