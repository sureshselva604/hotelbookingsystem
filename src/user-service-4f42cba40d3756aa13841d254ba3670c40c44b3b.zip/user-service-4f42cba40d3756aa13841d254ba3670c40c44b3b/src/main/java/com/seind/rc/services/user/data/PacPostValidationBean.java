package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PacPostValidationBean {
	private Long patientId;
	private Long patientSwfId;
	private Long currentStageWorkflowId;
	private Long newStageWorkflowId;
	private Long newCurrentEpisodeId;
	private int patientAdmissionId;

	private String oldSwfId;
	private String newSwfId;

}