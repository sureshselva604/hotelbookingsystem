package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PatientDeviceRequest {
	
		private String userName;
		private String password;
		private String version;
		private String deviceName;
		private String serialNo;
		private Long patientSwfId;
		private Long userAccountId;
		private String mode;
		private String otp;
		

}
