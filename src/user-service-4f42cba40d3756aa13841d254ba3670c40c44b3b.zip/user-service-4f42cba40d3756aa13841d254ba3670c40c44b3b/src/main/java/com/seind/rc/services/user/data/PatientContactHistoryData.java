package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class PatientContactHistoryData {
	private Long id;
	private Long patientUaId;
	private String email;
	private String phoneWithTelecode;
	private Date removedDate;
}
