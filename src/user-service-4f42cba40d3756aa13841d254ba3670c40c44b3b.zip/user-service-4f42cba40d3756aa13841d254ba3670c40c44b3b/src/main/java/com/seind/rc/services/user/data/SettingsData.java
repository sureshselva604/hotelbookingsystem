package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class SettingsData {

	private String name;
	private String value;
}
