package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UserValidateModel {
	
	private String userName;
	private String firstName;
	private String lastName;
	private String email;
	private String age;
	private String teleCode;
	private String phone;
	private String title;

}
