package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UserDeviceData {
	
	
	public Long userAccountId; 
	public Long userAccountKey;
	public String firstName; 
	public String lastName; 
	public String userName;
	public String imagePath; 
	public String email; 
	public String comType;
	public String title;
	public String gender;
	public Boolean active; 
	public Boolean careFamilyShow;
	public Long patientId;
	public Long createdBy; 
	public Boolean pushNotification; 
	public String dob; 
	public Boolean primaryCarePartner; 
	public Long whoseCarePartner;
	public String userTitle; 
	public String otherPhoneType;
	public Integer sequenceNo; 
	public Long userGroupId; 
	public String userGroupName;
	public String phone;
	public String otherPhone;
	public String teleCode;
	public String teleCountryCode;
	public String otherTeleCode;
	public String otherTeleCountryCode;
	public String userPassword;
	
	
	





}
