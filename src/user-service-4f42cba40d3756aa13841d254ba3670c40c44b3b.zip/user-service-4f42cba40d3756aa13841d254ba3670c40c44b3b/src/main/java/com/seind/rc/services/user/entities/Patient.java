package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
@Table(name = "Patient")
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long patientId;
	private Long practiceSurgeonId;
	private Long hospitalPracticeId;
	private String code;
	private String firstName;
	private String lastName;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DOB")
	private Date dob;
	private String email;
	private String phone;
	private String description;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String country;
	private String zipcode;
	private Boolean active;
	private Boolean isUploaded;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	private Long createdBy;
	@Temporal(TemporalType.TIMESTAMP)
	private Date LastModifiedDate;
	private Long LastModifiedBy;
	@Temporal(TemporalType.TIMESTAMP)
	private Date deactivatedDate;
	private String imagePath;
	private String randomId;
	private Boolean isDelete;
	private String gender;
	private Long notificationId;
	private String onOffTrackStatus;
	@Column(name = "MRN")
	private String mrn;
	private String chiefComplaint;
	private Long hospitalSurgeonId;
	private String bloodGroup;
	private Boolean hasCarePartner;
	private String adherence;
	private String engagement;
	private String readmitPercent;
	private String comType;
	private String medicare;
	private Long PayorType;
	@Column(name = "SSN")
	private String ssn;
	@Column(name = "DOS")
	private Date dos;
	@Column(name = "CJR")
	private String cjr;
	@Column(name = "MAKO")
	private String mako;
	private String cardLayout;
	private Long height;
	@Column(name = "Inch")
	private Long inch;
	private Long weight;
	@Column(name = "BMI")
	private String bmi;
	@Column(name = "HIC")
	private String hic;
	private String landLine;
	private Boolean isRegularSmoker;
	private Boolean isDiabetic;
	private Boolean isBloodPressure;
	private String teleCode;
	private String teleCountryCode;
	private Boolean isImageUploadDone;
	private Boolean isProfileDone;
	private Boolean isSupportDone;
	private Long enrolledBy;
	private String emailValidStatus;
	private String phoneValidStatus;
	private Boolean activityData;
	@Temporal(TemporalType.TIMESTAMP)
	private Date activityDataAcceptedOn;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "createdBy", insertable = false, updatable = false)
	private UserAccount createdByUa;

	@Transient
	private String editStatus;

	@OneToOne
	@JoinColumn(name = "PatientId", referencedColumnName = "userAccountKey" ,insertable = false, updatable = false)
	private UserAccount patientUserAcct;
}