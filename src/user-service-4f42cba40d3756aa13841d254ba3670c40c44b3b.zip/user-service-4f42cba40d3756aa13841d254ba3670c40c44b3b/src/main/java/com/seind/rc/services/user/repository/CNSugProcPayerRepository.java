package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.CNSugProcPayer;

public interface CNSugProcPayerRepository extends JpaRepository<CNSugProcPayer, Integer>{

	List<CNSugProcPayer> findByproceduretypeAndPayoridAndSurgeonUaIdAndPracticeid(String procedureType, Long payorId,
			Long hspSurgId, Long userAccountKey);

	List<CNSugProcPayer>  findTop1ByPracticeidAndAssignedHspTo(Long hospitalId, long l);
	
	List<CNSugProcPayer> findByproceduretypeAndPayoridAndSurgeonidAndAssignedHspTo(String procedureType, Long payorId,
			Long hspSurgId, Long userAccountKey);

}
