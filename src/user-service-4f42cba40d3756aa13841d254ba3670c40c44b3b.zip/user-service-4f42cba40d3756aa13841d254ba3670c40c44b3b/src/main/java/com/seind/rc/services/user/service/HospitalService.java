package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.HospitalListDeviceData;
import com.seind.rc.services.user.data.HospitalPracticeApptInfo;
import com.seind.rc.services.user.data.HospitalPracticeData;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.UserAccount;

public interface HospitalService {

	Hospital getHospitalById(Long hospitalId);

	String getDateFormatForHospital(Long hospitalId);

	Hospital getHospitalBySurgeonUserAccountId(Long userAccountId);

    Hospital getHospitalIdForAnyUserAccount(UserAccount userAccount);

	List<Hospital> getHospitalByMode(String mode, int superClientId);

	List<Long> getHospitalByType(Long hospitalId);
	
	List<HospitalPracticeData> getHospitalPracticeByType(Long hospitalId);

	List<HospitalListDeviceData> getHospitalListInfoByPatientId(Long patientId);

	List<HospitalPracticeApptInfo> findHospitalByPractice(UserAccountData user);

	List<HospitalPracticeApptInfo> fetchMultiHosptialPracticeByHspId(Long userAccountKey);
	
	Hospital fetchHospitalByHospitalIdAndClientType(Long hospitalId, String client);
	//HospitalDeviceData getHopsitalInfoByCNId(Long cnAccountId);

}
