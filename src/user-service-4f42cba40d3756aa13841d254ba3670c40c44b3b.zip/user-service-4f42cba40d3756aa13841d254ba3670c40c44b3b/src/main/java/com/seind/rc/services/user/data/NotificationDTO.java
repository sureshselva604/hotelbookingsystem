package com.seind.rc.services.user.data;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Data
@RequiredArgsConstructor
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NotificationDTO {
	
	@NonNull
	private String notificationType;
	
	@NonNull
	private UserAccountNotifyData toUser;
	
	@NonNull
	private HospitalNotifyData hsp;

	private UserAccountNotifyData staffUser;
	private UserAccountNotifyData cpUser;
	private UserAccountNotifyData surgeon;
	private UserAccountNotifyData patient;
	private PSWFNotifyData patientSwf;
	//private Serviceline serviceline;
    private List<TokenListData> tokenData;
	
	private String randID;
	private String surveyName;
	private String oldDOS;
	private String newDOS;
	private String appScheduled;
	private String appOnAppmtDate;
	private String relationship;
	private String stageCategory;
	private String count;
	private String todocount;
	private String password;
	private String nextInterval;
	private String days;
	private String notificationMode;
	private String serverUrl;
	private String path;
	private String portalName;
	private String deviceCode;
	//private EmailParamsDTO emailParamsDTO;
	private Map<String,String> emailList;
	public String getNotificationMode() {
		return notificationMode == null ? "" : notificationMode.toString();
	}

}
