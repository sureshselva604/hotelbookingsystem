package com.seind.rc.services.user.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.seind.rc.services.user.entities.Patient;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {

	List<Patient> findByPatientIdAndDob(Long patientId, Date dob);

	List<Patient> findByMrn(String mrn);
	
	List<Patient> findByCreatedByIn(List<Long> cnList);
	
}
