package com.seind.rc.services.user.data;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class CarePlanUserOrchAssessment {

	private Long patientSwfId;
	private Float youPartialScore;
	private Float youScore;
	private Float healthPartialScore;
	private Float healthScore;
	private Long age;
	private String gender;
	
	private HospitalData hospitalData;
}
