package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "CaptchaAudit")
public class CaptchaAudit {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long captchaAuditId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserId")
	private UserAccount userId;
	private Date lockedDate;
	private Long UnlockedBy;
	private Date UnlockedDate;
	private Boolean LockStatus;
	

}
