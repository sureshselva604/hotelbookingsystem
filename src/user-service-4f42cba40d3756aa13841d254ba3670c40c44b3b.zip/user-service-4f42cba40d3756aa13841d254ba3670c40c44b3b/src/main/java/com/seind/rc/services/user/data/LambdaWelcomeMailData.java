package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class LambdaWelcomeMailData {

	private Long userAccountId;
	private String email;
	private String patientName;
	private String surgeonName;
	private String imagePath;
	private String hspName;
	private String hspLogo;
	private String code;
	private String randomId;
	private String salutation;
	private String emailAlias;
	private Long zoneId;
	private Long cnactid;
	private Long patientId;
	private Long currentEpisodeId ;
	private Long patientSWFId;
	private Integer createdDate;
	private String setting_Email;
	
	
}
