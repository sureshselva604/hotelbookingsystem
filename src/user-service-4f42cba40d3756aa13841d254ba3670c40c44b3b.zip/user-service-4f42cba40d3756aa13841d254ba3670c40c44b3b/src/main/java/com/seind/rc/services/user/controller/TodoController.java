package com.seind.rc.services.user.controller;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CarePlanAssesmentsUserData;
import com.seind.rc.services.user.data.CnList;
import com.seind.rc.services.user.data.ConfigurableData;
import com.seind.rc.services.user.data.DashBoardCarePlanUserData;
import com.seind.rc.services.user.data.DashboardTodoInfoBean;
import com.seind.rc.services.user.data.DashboardTransactionBean;
import com.seind.rc.services.user.data.DashboardTransactionData;
import com.seind.rc.services.user.data.DownloadInfoBean;
import com.seind.rc.services.user.data.DownloadPacDocPatientData;
import com.seind.rc.services.user.data.DownloadSummaryInfoBean;
import com.seind.rc.services.user.data.DownloadSummaryPatientData;
import com.seind.rc.services.user.data.HospitalData;
import com.seind.rc.services.user.data.HospitalOverlapData;
import com.seind.rc.services.user.data.HospitalOverlapSurgeonsData;
import com.seind.rc.services.user.data.HospitalPraticeData;
import com.seind.rc.services.user.data.NonOverlapViewOnDemandData;
import com.seind.rc.services.user.data.OverlapViewOnDemandData;
import com.seind.rc.services.user.data.PacPostValidationBean;
import com.seind.rc.services.user.data.PacPreValidationBean;
import com.seind.rc.services.user.data.PatInfoAllTodoViewData;
import com.seind.rc.services.user.data.PatientData;
import com.seind.rc.services.user.data.PatientDetails;
import com.seind.rc.services.user.data.PatientReadmissionShowData;
import com.seind.rc.services.user.data.PatientStageWorkflowData;
import com.seind.rc.services.user.data.PracticeOverlapViewData;
import com.seind.rc.services.user.data.PreRequisiteTodoRaDTO;
import com.seind.rc.services.user.data.RaTodoOverlapPreRequisiteBean;
import com.seind.rc.services.user.data.TodoInfoBean;
import com.seind.rc.services.user.data.TodoOverlapOnDemandData;
import com.seind.rc.services.user.data.TodoRACareUserBean;
import com.seind.rc.services.user.data.TodoRAPracticeOverlapHospital;
import com.seind.rc.services.user.data.TodoReAssignUserBean;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.data.UserCcDashBoard;
import com.seind.rc.services.user.data.UserCcDashboardData;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.NonOverlapViewOnDemand;
import com.seind.rc.services.user.entities.OverlapViewOnDemand;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientDashBoardTransaction;
import com.seind.rc.services.user.entities.PatientInfoAllTodoView;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.Settings;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.SettingsRepository;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.PatientStageWorkflowSevice;
import com.seind.rc.services.user.service.TodoService;
import com.seind.rc.services.user.service.UserAccountService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * C09
 */

@RestController
@RequestMapping("/api/v1/user/orchestration/todo")
@RequiredArgsConstructor
@CrossOrigin
public class TodoController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TodoController.class);

	private static final ResourceBundle applicationProp = ResourceBundle.getBundle("application");

	private final TodoService todoService;

	private final UserAccountService userAccountService;

	private final ModelMapper modelMap;

	private final PatientStageWorkflowSevice patientStageWorkflowSevice;

	private final HospitalService hospitalService;

	private final HospitalRepository hospitalRepo;

	private final PatientRepository patientRepo;

	private final SettingsRepository settingsRepo;

	@PostMapping("/fetchPatientSwfInfoForFetchingAllTodo")
	public PreRequisiteTodoRaDTO fetchPatientSwfInfoForFetchingAllTodo(@RequestBody TodoInfoBean todoInfoBean1) {
		List<PatInfoAllTodoViewData> patInfoAllTodoViewDataList = new ArrayList<PatInfoAllTodoViewData>();
		PreRequisiteTodoRaDTO preRequisiteTodoRaDTO = new PreRequisiteTodoRaDTO();
		try {
			LOGGER.debug("Method Name -", "fetchPatientSwfInfoForFetchingAllTodo");
			LOGGER.debug("Input -", todoInfoBean1);

			List<PatientInfoAllTodoView> clientLevelPatList = new ArrayList<>();
			/** SEARCH OPERATION **/
			if (todoInfoBean1.getSearchStr() != null && !todoInfoBean1.getSearchStr().isEmpty()) {
				clientLevelPatList = todoService.buildClientLevelPatListWhenSearch(todoInfoBean1.getSearchStr(),
						clientLevelPatList, todoInfoBean1.getClientId(), todoInfoBean1.getPracOrHsp());
			} /** FILTER OPERATION **/
			else if (todoInfoBean1.getFilterSurgicalStage() != null && !todoInfoBean1.getFilterSurgicalStage().isEmpty()
					|| todoInfoBean1.getFilterProcedureType() != null && !todoInfoBean1.getFilterProcedureType().isEmpty()
					|| todoInfoBean1.getFilterSiteOfService() != null && !todoInfoBean1.getFilterSiteOfService().isEmpty()) {
				clientLevelPatList = todoService.buildClientLevelPatListWhenFilter(todoInfoBean1, clientLevelPatList);
			} else {
				clientLevelPatList = todoService.fetchPatientSwfInfoForFetchingAllTodo(todoInfoBean1.getClientId(),
						clientLevelPatList);
			}
			UserAccount userAccount = userAccountService.getUserAccountByUserAccountId(todoInfoBean1.getLoginUaId());
			List<Long> allCnIdList = fetchAllCnByPractice(userAccount.getUserAccountKey(), todoInfoBean1.getLoginUaId(),
					userAccount);

			patInfoAllTodoViewDataList = clientLevelPatList.stream()
					.filter(distinctByKey(PatientInfoAllTodoView::getPatientSWFId))
					.map(patsList -> modelMap.map(patsList, PatInfoAllTodoViewData.class)).toList();

			Map<String, PatInfoAllTodoViewData> patInfoAllTodoViewMap = patInfoAllTodoViewDataList
					.parallelStream().collect(
							Collectors.toMap(patInfoAllTodoView -> String.valueOf(patInfoAllTodoView.getPatientSWFId()),
									patInfoAllTodoView -> patInfoAllTodoView));

			preRequisiteTodoRaDTO.setAllCnIdsList(allCnIdList);
			preRequisiteTodoRaDTO.setPatientInfoAllTodoViewMap(patInfoAllTodoViewMap);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return preRequisiteTodoRaDTO;
	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {

		Map<Object, Boolean> seen = new ConcurrentHashMap<>();
		return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}

	@PostMapping("/buildPatientDataForAllTodoList")
	public PreRequisiteTodoRaDTO buildPatientDataForAllTodoList(@RequestBody PreRequisiteTodoRaDTO preRequisiteTodoRaDTO) {
		try {
			return todoService.draftOverlapLoopNotCompleted(preRequisiteTodoRaDTO);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return null;

	}

	@Operation(summary = "Get CnList by Login User")
	@GetMapping(value = "/getCnList")
	public List<CnList> getCnList(HttpServletRequest req) {
		try {
			Long loginUaId = Long.valueOf(req.getHeader("x-user"));
			Optional<UserAccount> optUser = todoService.getUserAccountByUserAccountId(loginUaId);
			if (optUser.isPresent()) {
				UserAccount userAccount = optUser.get();
				List<Long> cnList = fetchAllCnByPractice(userAccount.getUserAccountKey(), loginUaId, userAccount);
				List<UserAccount> cnUsers = todoService.getUserAccountBycnIds(cnList);
				return cnUsers.stream().map(a -> CnList.builder().cnName(a.getFirstName() + ' ' + a.getLastName())
						.cnId(a.getUserAccountId()).build()).toList();
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return Collections.emptyList();
	}

	public List<Long> fetchAllCnByPractice(Long hospitalId, Long loginUserAccountId, UserAccount userAccount) {

		List<Long> cnlist = new ArrayList<>();
		Long ugid = 0l;
		try {
			Optional<UserAccount> userAccount1 = todoService.getUserAccountByUserAccountId(loginUserAccountId);
			String userGroupIdStr = String.valueOf(userAccount1.get().getUserGroup().getUserGroupId());

			if (userGroupIdStr.equals("17") || userGroupIdStr.equals("13")) {
				ugid = 17L;
				cnlist = todoService.getCNListByPSG(hospitalId, ugid, userAccount);
			} else if (userGroupIdStr.equals("9") || userGroupIdStr.equals("7")) {
				ugid = 9L;
				cnlist = todoService.getCNListByPSG(hospitalId, ugid, userAccount);
			} else if (userGroupIdStr.equals("31") || userGroupIdStr.equals("30")) {
				cnlist = todoService.getCNListByPSG(hospitalId, userAccount.getUserGroup().getUserGroupId(),
						userAccount);
			} else if (userGroupIdStr.equals("32") || userGroupIdStr.equals("33")) {
				cnlist = todoService.getCNListByPSG(hospitalId, userAccount.getUserGroup().getUserGroupId(),
						userAccount);
			} else {
				ugid = userAccount.getUserGroup().getUserGroupId();
				cnlist = todoService.getCNListByPSG(userAccount.getUserAccountKey(), ugid, userAccount);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return cnlist;

	}

	@PostMapping("/pacDownloadData")
	public DownloadPacDocPatientData pacDownloadData(@RequestBody DownloadInfoBean downloadBean) {
		String hospitalName = "";
		try {
			DownloadPacDocPatientData downloadPacPatientData = new DownloadPacDocPatientData();
			PatientStageWorkflowData psw = todoService
					.getPatientStageWorkflowByPatientSWFId(Long.valueOf(downloadBean.getProductId()));

			PatientData patientData = todoService.getPatientStageWorkflowByPatient(psw.getPatientId());
			UserAccountData ccUa = getCCUser(Long.valueOf(downloadBean.getUserId()), psw);
			UserAccountData sugUa = null;
			sugUa = getSurgUser(psw, sugUa);
			HospitalData hsp = todoService.getHospitalDataByHospitalId(ccUa.getUserAccountKey());
			hospitalName = todoService.getHospitalAndPracticeById(psw.getHospitalPracticeId());
			UserAccountData patUAccount = todoService.getUserAccountDataByPatientd(patientData.getPatientId());
			HospitalPraticeData hp = todoService.findHospitalPracticeById(psw.getHospitalPracticeId());

			if (hp.getSecHospitalId() == null) {
				hospitalName = todoService.getHospitalDataByHospitalId(hp.getHospitalId()).getName();
			} else {
				hospitalName = todoService.getHospitalDataByHospitalId(hp.getSecHospitalId()).getName();
			}
			String serverPath = getServerPath();
			String filePath = serverPath;

			PatientDetails carePatnerDetails = todoService.getCarePatnerDetails(psw.getPatientId());
			downloadPacPatientData.setRealPath(filePath);
			downloadPacPatientData.setPatientStageWorkflowData(psw);
			downloadPacPatientData.setPatientData(patientData);
			downloadPacPatientData.setCcUserAccountdata(ccUa);
			downloadPacPatientData.setSugUserAccountdata(sugUa);
			downloadPacPatientData.setHospitalData(hsp);
			downloadPacPatientData.setHospitalName(hospitalName);
			downloadPacPatientData.setPatUAccount(patUAccount);
			/**
			 * downloadPacPatientData.setCountryDischargeMapList(CountryDischargeMapList);
			 **/
			downloadPacPatientData.setHospitalPractice(hp);
			downloadPacPatientData.setCarePatnerDetails(carePatnerDetails);
			return downloadPacPatientData;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return null;

	}

	public UserAccountData getCCUser(Long loggedInUserId, PatientStageWorkflowData patientStageWorkFlowData) {
		UserAccountData userAccountCCUaData = null;
		try {
			if (patientStageWorkFlowData.getHspCCId() == null) {
				UserAccount userAccount = userAccountService.getUserAccountByUserAccountId(loggedInUserId);
				userAccountCCUaData = modelMap.map(userAccount, UserAccountData.class);
				userAccountCCUaData.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
				userAccountCCUaData.setGroupType(userAccount.getUserGroup().getGroupType());

			} else {
				UserAccount userAccount = userAccountService
						.getUserAccountByUserAccountId(patientStageWorkFlowData.getHspCCId());
				userAccountCCUaData = modelMap.map(userAccount, UserAccountData.class);
				userAccountCCUaData.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
				userAccountCCUaData.setGroupType(userAccount.getUserGroup().getGroupType());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userAccountCCUaData;
	}

	public UserAccountData getSurgUser(PatientStageWorkflowData psw, UserAccountData sugUa) {
		UserAccountData userAccountSurgUser = null;
		try {
			if (psw.getHspSurgId() != null) {
				UserAccount userAccount = userAccountService.getUserAccountByUserAccountId(psw.getHspSurgId());
				userAccountSurgUser = modelMap.map(userAccount, UserAccountData.class);
				userAccountSurgUser.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
				userAccountSurgUser.setGroupType(userAccount.getUserGroup().getGroupType());

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userAccountSurgUser;
	}

	/** download **/
	/* Overlap ondemannd Sp ***/

	@PostMapping("getOverLapPatientDetails/{patientSWFId}")
	public TodoOverlapOnDemandData getOverlapAndNonOverlapPatientDetails(@PathVariable Long patientSWFId) {
		try {
			TodoOverlapOnDemandData todoOverlapOnDemandData = new TodoOverlapOnDemandData();
			OverlapViewOnDemand overLapPatientDetails = todoService.getOverLapPatientDetails(patientSWFId);
			OverlapViewOnDemandData overlapdata = modelMap.map(overLapPatientDetails, OverlapViewOnDemandData.class);
			todoOverlapOnDemandData.setOverLapPatientDetail(overlapdata);

			NonOverlapViewOnDemand nonOverLapPatientDetails = todoService.getNonOverLapPatientDetails(patientSWFId);
			if (nonOverLapPatientDetails != null) {
				NonOverlapViewOnDemandData nonOverLapData = modelMap.map(nonOverLapPatientDetails,
						NonOverlapViewOnDemandData.class);
				todoOverlapOnDemandData.setNonOverLapPatientDetail(nonOverLapData);
			}
			String mode = todoService.getPatientStageWorkflowDetails(patientSWFId);
			todoOverlapOnDemandData.setMode(mode);
			return todoOverlapOnDemandData;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@PostMapping("/getPatientStageWorkflowDetails/{patientSWFId}")
	public String getPatientStageWorkflowDetails(@PathVariable Long patientSWFId) {
		return todoService.getPatientStageWorkflowDetails(patientSWFId);

	}

	@PostMapping("/fetchUserServiceForDashboardCarePlan")
	public UserCcDashboardData fetchUserServiceForDashboardCarePlan(@RequestBody UserCcDashBoard userCcDashboard) {
		UserCcDashboardData userTodoData = null;
		try {
			/** USER INFO **/
			UserAccount loginCcUa = userAccountService.getUserAccountByUserAccountId(userCcDashboard.getUserId());
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			UserAccountData loginCcUaData = modelMap.map(loginCcUa, UserAccountData.class);

			UserAccountData strykerAdminUaData = null;
			if (userCcDashboard.getStykerAdminId() != null && !userCcDashboard.getStykerAdminId().isEmpty()) {
				UserAccount strykerAdminUa = userAccountService
						.getUserAccountByUserAccountId(Long.valueOf(userCcDashboard.getStykerAdminId()));
				strykerAdminUaData = modelMap.map(strykerAdminUa, UserAccountData.class);
			}

			/** CLIENT INFO **/
			Hospital hospital = hospitalService.getHospitalById(loginCcUaData.getUserAccountKey());
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			HospitalData hospitalData = modelMap.map(hospital, HospitalData.class);
			String countryCode = hospital.getCountryCode().getCountryCode();
			String language = hospital.getCountryCode().getLanguage();
			hospitalData.setCountryCode(countryCode);
			hospitalData.setLanguage(language);

			/** PATIENTSWF INFO **/
			PatientStageWorkflow patientStageWorkflow = patientStageWorkflowSevice
					.getPatientStageWorkflowByPatientSWFId(userCcDashboard.getPatientSwfId());
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			PatientStageWorkflowData patientStageWorkflowData = modelMap.map(patientStageWorkflow,
					PatientStageWorkflowData.class);
			patientStageWorkflowData.setUserAccountKey(patientStageWorkflow.getCCUserAccount().getUserAccountKey());
			patientStageWorkflowData.setPatientId(patientStageWorkflow.getPatient().getPatientId());
			patientStageWorkflowData.setHspCCId(patientStageWorkflow.getCCUserAccount().getUserAccountId());

			/** PATIENT INFO **/
			Patient patient = patientRepo.findById(patientStageWorkflowData.getPatientId()).orElse(null);
			PatientData patientData = modelMap.map(patient, PatientData.class);

			/** PATIENT UA INFO **/
			UserAccount patientSwfCcUa = userAccountService
					.getUserAccountByUserAccountId(patientStageWorkflowData.getHspCCId());
			UserAccountData patientSwfCcUaData = modelMap.map(patientSwfCcUa, UserAccountData.class);
			Long UserGroupId = 19l;
			UserAccount patUserAcc = userAccountService
					.getUserAccountByUserAccountKeyAndUserGroupId(patientStageWorkflowData.getPatientId(), UserGroupId);
			UserAccountData patUserAccData = modelMap.map(patUserAcc, UserAccountData.class);

			/** EXCLUDE & INCLUDE TODO **/
			String BPCI = "%BPCI%";
			Hospital Hospital = hospitalService.fetchHospitalByHospitalIdAndClientType(hospital.getHospitalId(), BPCI);
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			HospitalData MytodoBeImpactedInfo = modelMap.map(Hospital, HospitalData.class);

			boolean willMytodoBeImpacted = findWillMytodoBeImpacted(patientStageWorkflowData, MytodoBeImpactedInfo);

			/** ORCHESTRATE ALL THE INFO **/
			userTodoData = UserCcDashboardData.builder().loginCcUaData(loginCcUaData)
					.strykerAdminUaData(strykerAdminUaData).patUseAccData(patUserAccData).hospitalData(hospitalData)
					.patientSwfData(patientStageWorkflowData).patientData(patientData)
					.willMytodoBeImpacted(willMytodoBeImpacted).patientSwfCcUaData(patientSwfCcUaData).build();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userTodoData;
	}

	private boolean findWillMytodoBeImpacted(PatientStageWorkflowData patientStageWorkflowData,
			HospitalData MytodoBeImpactedInfo) {
		boolean willMytodoBeImpacted = false;
		if (MytodoBeImpactedInfo != null && patientStageWorkflowData.getBpci().equalsIgnoreCase("N")
				&& patientStageWorkflowData.getPayorId().equals("2")) {
			if (Boolean.FALSE.equals(patientStageWorkflowData.getExcludeMyTodo())) {
				willMytodoBeImpacted = false;
			} else {
				willMytodoBeImpacted = true;
			}
		}
		return willMytodoBeImpacted;
	}

	@PostMapping("/fetchRACareUserListForTodoPracticeOverlap")
	public List<TodoRACareUserBean> fetchRACareUserListForTodoPracticeOverlap(@RequestBody
			HospitalOverlapData practiceOverlapData) {
		try {
			return todoService.fetchRACareUserListForTodoPracticeOverlap(practiceOverlapData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@PostMapping(value = "/fetchHospitalOverlapData")
	public List<TodoRACareUserBean> fetchHospitalOverlapData(
			@RequestBody HospitalOverlapData hospitalOverlapData) {
		try {
			List<TodoRACareUserBean> todoRACareUserBeanList = todoService
					.fetchHospitalOverlapData(hospitalOverlapData);

			return todoRACareUserBeanList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@PostMapping(value = "/fetchTodoRAHospitalOverlapSurgeons/{loginUaId}")
	public List<HospitalOverlapSurgeonsData> fetchTodoRAHospitalOverlapSurgeons(@PathVariable("loginUaId") Long loginUaId) {
		try {
			return todoService.fetchTodoRAHospitalOverlapSurgeons(loginUaId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return new ArrayList<>();
	}

	@PostMapping(value = "/fetchRaTodoOverlapPreRequisiteInfo")
	public boolean fetchRaTodoOverlapPreRequisiteInfo(
			@RequestBody RaTodoOverlapPreRequisiteBean raTodoOverlapPreRequisiteBean) {
		try {
			return todoService.fetchRaTodoOverlapPreRequisiteInfo(raTodoOverlapPreRequisiteBean);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return false;
	}

	@PostMapping(value = "/fetchTodoRAPracticeOverlapHospitals/{loginUaId}")
	public List<TodoRAPracticeOverlapHospital> fetchTodoRAPracticeOverlapHospitals(
			@PathVariable("loginUaId") Long loginUaId) {
		try {
			return todoService.getTodoRAPracticeOverlapHospitals(loginUaId);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@PostMapping("/fetchDashBoardUserDataByPatientSwfId/{patientSwfId}")
	public DashBoardCarePlanUserData fetchDashBoardUserDataByPatientSwfId(
			@PathVariable("patientSwfId") Long patientSwfId) {
		DashBoardCarePlanUserData dbCareplanData = null;
		try {
			return dbCareplanData = todoService.fetchDashBoardUserDataByPatientSwfId(patientSwfId);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return dbCareplanData;

	}

	@PostMapping("/preRequisiteDashboardMyTodo")
	public DashboardTodoInfoBean preRequisiteDashboardMyTodo(@RequestBody DashboardTodoInfoBean dashboardTodoInfoBean) {
		try {
			return dashboardTodoInfoBean = todoService.preRequisiteDashboardMyTodo(dashboardTodoInfoBean);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return dashboardTodoInfoBean;
	}

	@GetMapping("/fetchCarePlanUsersDataByPatientSwfId/{patientswfId}")
	public CarePlanAssesmentsUserData fetchCarePlanUsersDataByPatientSwfId(
			@PathVariable("patientswfId") Long patientswfId) {
		CarePlanAssesmentsUserData assesmentsUserData = null;
		try {
			assesmentsUserData = todoService.fetchCarePlanUsersDataByPatientSwfId(patientswfId);
			ObjectMapper ob = new ObjectMapper();
			LOGGER.info(ob.writeValueAsString(assesmentsUserData));
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return assesmentsUserData;
	}

	@PostMapping("/executeIfOpLocationMapIsNotNull")
	public PacPostValidationBean executeIfOpLocationMapIsNotNull(@RequestBody PacPreValidationBean preValidationBean) {
		PacPostValidationBean postValidationBean = null;
		try {
			return postValidationBean = todoService.executeIfOpLocationMapIsNotNull(preValidationBean);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return postValidationBean;
	}

	@PostMapping("/downloadCarePlan")
	public DownloadSummaryPatientData downloadSummary(@RequestBody DownloadSummaryInfoBean downloadSummaryInfoBean) {
		DownloadSummaryPatientData downloadSumarrypatientData = new DownloadSummaryPatientData();
		try {

			String bpcia = downloadSummaryInfoBean.getBpcia();
			String hspSugId = downloadSummaryInfoBean.getHsp_Sug_Id();
			String procedureType = downloadSummaryInfoBean.getProcedureType();
			String dosFrom = downloadSummaryInfoBean.getDosFrom();
			String dosTo = downloadSummaryInfoBean.getDosTo();
			Long clientId = Long.valueOf(downloadSummaryInfoBean.getClientId());
			String hospitalPracticeId = downloadSummaryInfoBean.getHospitalPracticeId();
			Long requestedBy = Long.valueOf(downloadSummaryInfoBean.getUserAccountId());
			Hospital hsp = hospitalRepo.findById(clientId).get();
			downloadSumarrypatientData.setMode(hsp.getMode());

			if (hsp != null && hsp.getMode().equalsIgnoreCase("h")) {
				hospitalPracticeId = "";
			}

			String currentPacEvent = "";
			try {
				currentPacEvent = downloadSummaryInfoBean.getCurrentPacEvent();
			} catch (Exception e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
			}

			UserAccount userAccount = userAccountService.getUserAccountByUserAccountId(requestedBy);
			String userGroupName = userAccount.getUserGroup().getGroupName();
			downloadSumarrypatientData.setUserGroupName(userGroupName);
			downloadSumarrypatientData.setDownloadBean(downloadSummaryInfoBean);

			DashboardTransactionData dt = new DashboardTransactionData();
			try {
				dt.setBpcia(bpcia);
				dt.setHspSugId(hspSugId);
				dt.setProcedureType(procedureType);
				if (dosFrom != null && !dosFrom.isEmpty()) {
					dt.setDosFrom(new SimpleDateFormat(CommonConstant.STR_YYYY_MM_DD).parse(dosFrom));
				}
				if (dosTo != null && !dosTo.isEmpty()) {
					dt.setDosTo(new SimpleDateFormat(CommonConstant.STR_YYYY_MM_DD).parse(dosTo));
				}
				dt.setClientId(clientId);
				dt.setHospitalPracticeId(hospitalPracticeId);
				dt.setPacEventName(currentPacEvent);
				dt.setRequestedBy(requestedBy);
				dt.setGroupName(userGroupName);
				dt.setCompleted(downloadSummaryInfoBean.getCompleted());

				downloadSumarrypatientData.setCountryCodeId(hsp.getCountryCode().getCountryCodeId());
				downloadSumarrypatientData.setCountryCodeDateFormat(hsp.getCountryCode().getDateFormat());
				DownloadSummaryPatientData fetchDashboardCarePlanList = todoService.fetchDashboardCarePlanList(dt);
				String serverPath = getServerPath();
				String filePath = serverPath;
				fetchDashboardCarePlanList.setFilePath(filePath);
				fetchDashboardCarePlanList.setMode(hsp.getMode());
				fetchDashboardCarePlanList.setCountryCodeDateFormat(hsp.getCountryCode().getDateFormat());
				fetchDashboardCarePlanList.setUserGroupName(userGroupName);
				fetchDashboardCarePlanList.setCountryCodeId(hsp.getCountryCode().getCountryCodeId());
				List<PatientDashBoardTransaction> patientDashBoardTransactionList = fetchDashboardCarePlanList
						.getPatientDashBoardTransaction();
				List<Long> patientIdList = patientDashBoardTransactionList.stream()
						.map(PatientDashBoardTransaction::getPatientId).collect(Collectors.toList());
				List<PatientDetails> carePatnerDetailsList = todoService
						.getCarePatnerDetailsByPatientIds(patientIdList);
				fetchDashboardCarePlanList.setCarePatnerDetailsList(carePatnerDetailsList);
				return fetchDashboardCarePlanList;
			} catch (Exception e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}

		return null;

	}

	public String getServerPath() throws SQLException, ClassNotFoundException {
		String filePath = "";
		String pathselection = applicationProp.getString("PathSelection");
		if (pathselection.equalsIgnoreCase("DB")) {
			String hostedModel = applicationProp.getString("HostedModel");
			Settings settings = settingsRepo.findByNameAndCategory("DeviceStorage", hostedModel);
			filePath = settings.getValue();
		} else {
			filePath = applicationProp.getString("LocalPath");
		}
		return filePath;
	}

	@PostMapping(value = "/fetchUserserviceForTodoCarePlanSurveyById/{patientSwfId}")
	public ConfigurableData fetchUserserviceForTodoCarePlanSurveyById(@PathVariable Long patientSwfId) {
		ConfigurableData configurableData = todoService.getHospitalDataByPatientStageWorkflowDetails(patientSwfId);
		return configurableData;

	}

	@PostMapping(value = "/getwillReAdmissionBeShownByPatientSwfId/{patientSWFId}")
	public PatientReadmissionShowData getwillReAdmissionBeShownByPatientSwfId(@PathVariable Long patientSWFId) {
		PatientReadmissionShowData patientReadmissionShowData = new PatientReadmissionShowData();
		try {
			patientReadmissionShowData = todoService.willReAdmissionBeShown(patientSWFId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return patientReadmissionShowData;
	}

	@PostMapping("/saveDashboardTransaction")
	public String saveDashboardTransaction(@RequestBody DashboardTransactionBean dashboardTransactionBean) {
		String countSize = "";
		try {
			countSize = todoService.saveDashboardTransaction(dashboardTransactionBean);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return countSize;
	}

	@PostMapping("/getHospitalDataByHospitalId/{hospitalId}")
	public HospitalData getHospitalDataByHospitalId(@PathVariable("hospitalId") Long hospitalId) {
		try {
			return todoService.getHospitalDataByHospitalId(hospitalId);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return null;
	}

	@PostMapping("/reassingTodo")
	public TodoReAssignUserBean reassingTodo(@RequestBody TodoReAssignUserBean todoReAssignUserBean) {
		try {
			TodoReAssignUserBean reassingTodo = todoService.reassingTodo(todoReAssignUserBean);
			return reassingTodo;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return null;
	}

	@PostMapping("/getPatientStageWorkflowData/{patientSWFId}")
	public PatientStageWorkflowData getPatientStageWorkflowData(@PathVariable("patientSWFId") Long patientSWFId) {
		return todoService.getPatientStageWorkflowByPatientSWFId(patientSWFId);
	}
}
