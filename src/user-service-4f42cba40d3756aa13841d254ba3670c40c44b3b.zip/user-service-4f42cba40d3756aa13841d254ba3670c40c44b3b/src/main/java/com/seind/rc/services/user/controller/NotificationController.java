package com.seind.rc.services.user.controller;

import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.NotificationDTO;
import com.seind.rc.services.user.data.NotifyReqData;
import com.seind.rc.services.user.data.TokenListData;
import com.seind.rc.services.user.service.NotificationService;

import lombok.RequiredArgsConstructor;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/notification")
@RequiredArgsConstructor
public class NotificationController {

	private static final Logger LOGGER = LogManager.getLogger(NotificationController.class);
	
	@Autowired
	private NotificationService notificationService;
	
	
	@GetMapping(value = "/getTokenListbyPatientorCpId/{userAccountId}")
	private List<TokenListData> getTokenListbyPatientorCpId(@PathVariable("userAccountId") Long userAccountId){
		try {
		
			return notificationService.getTokenListbyPatientorCpId(userAccountId);
			
		}
		catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
			return Collections.emptyList(); 
		}	
		
	}
	
	@PostMapping(value = "/usersData")
	private NotificationDTO getUsersData(@RequestBody NotifyReqData notifyReqData) {
		NotificationDTO response = new NotificationDTO();
		try {
			
			response = notificationService.getUsersData(notifyReqData);
			
		}
		catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
			
		return response;
	}
	
	@GetMapping(value = "/workflowNotificationData/{patientSWFId}")
	private List<NotifyReqData> workflowNotificationData(@PathVariable("patientSWFId") Long patientSWFId ){
		
		try {
			
			return notificationService.workflowNotificationData(patientSWFId);
		}
		catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
			return Collections.emptyList();
		}
		
	}

	
	

}
