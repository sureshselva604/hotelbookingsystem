package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class DeviceLoginData {

	private Long carePartnerId;
	private Long patientId;
	private String modeOfLogin;
	private Date isLoginTime;
	private String appVersion;
	private String osVersion;

}
