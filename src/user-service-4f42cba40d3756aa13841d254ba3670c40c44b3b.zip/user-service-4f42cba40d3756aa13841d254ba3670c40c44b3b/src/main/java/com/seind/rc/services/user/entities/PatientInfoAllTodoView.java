package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "PatientInfoAllTodoView")
@Data
public class PatientInfoAllTodoView {

	@Id
	private Long id;
	private Long patientSWFId;
	private String imagePath;
	private Long hspCCId;
	private Long payorId;
	private Boolean excludeMyTodo;
	private String cjr;
	private String procedureType;
	private String mako;
	private Date dos;
	private String name;
	private Long hospitalId;
	private Boolean isOverLap;
	private String sugFirstName;
	private String sugLastName;
	private Long surgeonId;
	private String otherTeleCode;
	private String otherPhone;
	private String otherTeleCountryCode;
	private String bpci;
	private Boolean fracture;
	private String patFirstname;
	private String patLastname;
	private Long firstSOSHospitalId;
	private String phone;
	private String teleCode;
	private String teleCountryCode;
	private String patientStatus;
	private Date dob;
	private String email;
	private String mrn;
	private Date dischargeDate;
	private String currentPac;
	private Float healthScore;
	private String surgicalStage;
	private String procedureCode;
	private Long  practiceId;
	private String firstSOSName;
}
