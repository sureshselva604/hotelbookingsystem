package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "UserPwdAudit")
public class UserPwdAudit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userPwdAuditId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserAccountId")
	private UserAccount userAccountId;
	private String userPwd;
	private Date createdDate;
	private Long createdBy;

}