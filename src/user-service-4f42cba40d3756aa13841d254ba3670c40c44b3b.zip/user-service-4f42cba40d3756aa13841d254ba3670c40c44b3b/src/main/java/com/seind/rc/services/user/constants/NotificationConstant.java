package com.seind.rc.services.user.constants;

public class NotificationConstant {

	public static final String WELCOMEINVITE = "PatientWelcomeInvitation";
	public static final String STAFFWELCOMEEMAILALREADYACTIVATED = "StaffWelcomeEmailAlreadyActivated";
	public static final String SMSDISCLAIMER = "SMSDisclaimer";
	public static final String FORGOTPWDBEFOREACTIVATION = "ForgotPasswordBeforeActivation";
	
	public static final String PASSWORDUPDATEDNOTIFICATION = "PasswordUpdatedNotification";
	public static final String ACCOUNTACTIVATION = "AccountActivation";
	public static final String ACCOUNTLOCKEDSECQUS = "AccountLockedSecQus";
	public static final String ACCOUNTDEACTIVATION = "AccountDeactivation";
	public static final String EMAILADDRESSUPDATE = "EmailAddressUpdate";
	public static final String PHONENUMBERUPDATE = "PhoneNumberUpdate";
	public static final String EXERCISENOTIFICATION = "ExerciseNotification";

}
