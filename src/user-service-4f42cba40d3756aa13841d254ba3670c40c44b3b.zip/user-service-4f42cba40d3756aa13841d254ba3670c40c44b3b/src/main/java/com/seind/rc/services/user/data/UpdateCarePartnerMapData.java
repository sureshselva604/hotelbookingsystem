package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UpdateCarePartnerMapData {
	private Long userAccountId;
	private Long patientId;
	private boolean verified;
	private Long carePartnerId;
}
