package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UserMsgRespData {
	
	private String name;
	private String imagePath;
	private String role;
	private Long ccUserAccountId;
	private Long patUserId;
	private String userTitle;
	private String type;
//	private Long unReadMsgCount;
	private Long patientSwfId;
	private Long patientId;

}
