package com.seind.rc.services.user.data;

import java.util.Date;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EpisodeAppointmentInfo {
	
	private Long patientSWFId;
	private Long appointmentId;
	private String appointmentName;
	private Long strykerAdminId;
	private Long reScheduleStatus;
	private Long patientEpisodeTrackId;
	private Date createdDate;
	private Date appointmentDate;
	private String randomId;
	private Long appointmentWith;
	private Long createdBy;
	private Long episodeId;
	private Long patientId;
	private String description;
	private Long isCurrentAppointment;
	private String title;
	private String appointmentStatus;
	private String time;
	private Long isCompleted;
	private Date completedDate;
	private Integer seqNo;
	private Boolean isActive;
	private String mode;
	private Boolean isNotifyDone;
	private Boolean isPriorNotifyDone;
	private Long otherAppmntHspMasterId;
	private Long appmntHspId;
	private Long appmntScheduledBy;
	private Date appmntScheduledOn;
	private Long clientAppmntConfIdFK;
	private Map<Long, String> appmntStatus;
	private String hospitalName;
	private String patientSurgeonName;
	private String dateFormat;

}
