package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.UserDetails;
import com.seind.rc.services.user.data.UserGroupPrivilegeData;
import com.seind.rc.services.user.entities.UserGroup;

public interface UserGroupService {

	List<UserGroup> findAllUserGroup(Long clientId);
	
	List<UserGroupPrivilegeData> getUserPrivilegeByUserId(Long userId);

	List<UserGroupPrivilegeData> getUserGroupPrivelegeByGroupId(Long userGroupId);

	List<UserDetails> getUsersByUserGroupId(Long userGroupId);


}
