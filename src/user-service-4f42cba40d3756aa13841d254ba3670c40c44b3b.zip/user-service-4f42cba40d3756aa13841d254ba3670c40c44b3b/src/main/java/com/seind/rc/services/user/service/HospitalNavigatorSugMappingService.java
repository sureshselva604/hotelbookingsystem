package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.entities.HospitalNavigatorSugMapping;

public interface HospitalNavigatorSugMappingService {

	List<HospitalNavigatorSugMapping> getHospitalNavigatorSugMappingBysurgeonAccId(Long hspSurgId);

}
