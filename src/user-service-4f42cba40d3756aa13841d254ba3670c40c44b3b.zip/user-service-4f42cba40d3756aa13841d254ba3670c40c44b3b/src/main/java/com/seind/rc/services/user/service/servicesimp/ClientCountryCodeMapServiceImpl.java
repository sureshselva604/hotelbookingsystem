package com.seind.rc.services.user.service.servicesimp;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CountryCodeMapData;
import com.seind.rc.services.user.entities.ClientCountryCodeMap;
import com.seind.rc.services.user.entities.CountryCode;
import com.seind.rc.services.user.repository.ClientCountryCodeMapRepository;
import com.seind.rc.services.user.service.ClientCountryCodeMapService;

@Service
public class ClientCountryCodeMapServiceImpl implements ClientCountryCodeMapService {

	@Autowired
	private ClientCountryCodeMapRepository clientCtryCodeMapRepo;

	@Autowired
	private ModelMapper modelMapper;

	private static final Logger logger = LogManager.getLogger(ClientCountryCodeMapService.class);

	/**
	 * M01
	 * 
	 * Get ClientCountryCodeMap Record using ClientCountryCodeMapId
	 */
	@Override
	public ClientCountryCodeMap getClientCountryCodeMapById(Long clientCountryCodeMapId) {
		Optional<ClientCountryCodeMap> clientCCMap = null;
		try {
			clientCCMap = clientCtryCodeMapRepo.findById(clientCountryCodeMapId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return clientCCMap.isPresent() ? clientCCMap.get() : null;
	}

	@Override
	public List<CountryCodeMapData> fetchCountryCodeByHspOrPracId(Long hospitalId) {
		try {
			List<ClientCountryCodeMap> clientCtryCodeMap = clientCtryCodeMapRepo.findByHospital_HospitalId(hospitalId);
			List<CountryCode> countryCodeList = clientCtryCodeMap.stream().map(ClientCountryCodeMap::getCountryCode)
					.toList();
			return countryCodeList.stream().map(a -> modelMapper.map(a, CountryCodeMapData.class)).toList();
		} catch (Exception e) {
			logger.error(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}

	}
}
