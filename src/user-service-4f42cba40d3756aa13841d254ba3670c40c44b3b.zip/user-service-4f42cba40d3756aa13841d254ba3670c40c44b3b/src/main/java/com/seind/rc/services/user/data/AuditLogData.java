package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class AuditLogData {

	private Long IdValue;
	private Date modifiedDate;
	private String operation;
	private Long patient;
	private String tableName;
	private Long patientDeviceId;
	private Long hospitalId;
	
}
