package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.data.PatientStageWorkflowData;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.service.PatientStageWorkflowSevice;

@Service
public class PatientStageWorkflowSeviceImpl implements PatientStageWorkflowSevice {

	private static final Logger LOGGER = LogManager.getLogger(PatientStageWorkflowSeviceImpl.class);

	@Autowired
	private PatientStageWorkflowRepository patientSWFRepo;

	@Override
	public PatientStageWorkflow getPatientStageWorkflowByPatientSWFId(Long patientSWFId) {
		Optional<PatientStageWorkflow> patientSWF = null;
		try {
			patientSWF = patientSWFRepo.findById(patientSWFId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return patientSWF.isPresent() ? patientSWF.get() : null;
	}

	@Override
	public List<PatientStageWorkflow> getPatientStageWorkflowByPatientId(Long patientId) {
		List<PatientStageWorkflow> patientSWF = null;
		try {
			patientSWF = patientSWFRepo.findPatientSWFIdByPatient_PatientId(patientId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return !patientSWF.isEmpty() ? patientSWF : new ArrayList<>();

	}

	@Override
	public List<PatientStageWorkflowData> getPatientStageWorkflowByPatientIdForDownLoad(Long patientId) {
		List<PatientStageWorkflowData> patientSWFData = new ArrayList<>();
		try {
			PatientStageWorkflowData patientStageWorkflowData = new PatientStageWorkflowData();
			List<Object[]> downloadList = patientSWFRepo.getDownloadList(patientId);
			if (downloadList != null) {
				for (Object[] object : downloadList) {
					Long patientSWFId = Long.valueOf(object[0].toString());
					String currentpac = object[1].toString();
					patientStageWorkflowData.setPatientSWFId(patientSWFId);
					patientStageWorkflowData.setCurrentPac(currentpac);
					patientSWFData.add(patientStageWorkflowData);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return patientSWFData;

	}

}
