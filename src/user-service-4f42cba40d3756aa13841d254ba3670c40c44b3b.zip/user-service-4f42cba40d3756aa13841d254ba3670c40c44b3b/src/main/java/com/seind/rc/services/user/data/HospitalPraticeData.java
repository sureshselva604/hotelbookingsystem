package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HospitalPraticeData {

	private Long hospitalId;
	private Long practiceId;
	private boolean isOverLap;
	private Long secHospitalId;
}