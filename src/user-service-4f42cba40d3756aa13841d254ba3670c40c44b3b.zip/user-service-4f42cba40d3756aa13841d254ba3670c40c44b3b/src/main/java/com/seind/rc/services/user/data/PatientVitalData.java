package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PatientVitalData {

	private Long patId;
	private String patEmail;
	private String patPhone;
	private String comType;
	private Boolean isPhoneUpdate;
	private Boolean isEmailUpdate;
	private Boolean isOtherUser;
	private Long userAccountId;
	private String handshakekey;
	
}
