package com.seind.rc.services.user.data;


import java.util.List;

import lombok.Data;

@Data
public class NotifyUserData {
	
	
	private UserAccountNotifyData toUser;
	
	
	private HospitalNotifyData hsp;

	private UserAccountNotifyData staffUser;
	private UserAccountNotifyData cpUser;
	private UserAccountNotifyData surgeon;
	private UserAccountNotifyData patient;
	private PSWFNotifyData patientSwf;
    private List<TokenListData> tokenData;


}
