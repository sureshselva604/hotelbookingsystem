package com.seind.rc.services.user.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seind.rc.services.user.entities.HospitalPractice;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.UserAccount;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "PatientStageWorkflow")
public class PatientStageWorkflow {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long patientSWFId;
	private Long patientId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "patientId", insertable = false, updatable = false)
	private Patient patient;
	private Long stageWorkflowId;
	@Temporal(TemporalType.TIMESTAMP)
	private Date admittedDate;
	@Column(name = "HSP_CC_Id")
	private Long hspCCId;
	@Column(name = "HSP_Surg_Id")
	private Long hspSurgId;
	private String randomId;
	private Long servicelineId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HospitalPracticeId")
	private HospitalPractice hospitalPractice;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DOS")
	private Date dos;
	@Column(name = "CJR")
	private String cjr;
	@Column(name = "MAKO")
	private String mako;
	@Column(name = "PayorType")
	private Long payorId;
	@Column(name = "HIC")
	private String hic;
	private String dischargeLocation;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dischargeDate;
	private String dischargeTime;
	private String facilityName;
	private String dischargeLocPhone;
	private String dischargeLocContact;
	private String procedureType;
	private String patientStatus;
	private Long currentStageId;
	private Long currentEpisodeId;
	private Boolean patientSnfStatus;
	private Long patientStatusOrder;
	@Temporal(TemporalType.TIMESTAMP)
	private Date snfDischargeDate;
	private String dischargeType;
	private String dischargeTo;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dischargeInitiatedOn;
	private String workflowMode;
	@Temporal(TemporalType.TIMESTAMP)
	private Date fbNotifySentOn;
	@Temporal(TemporalType.TIMESTAMP)
	private Long hospitalSurgeonId;
	@Temporal(TemporalType.TIMESTAMP)
	private Date upNotifySentOn;
	@Temporal(TemporalType.TIMESTAMP)
	private Date plannedDischargeDate;
	@Temporal(TemporalType.TIMESTAMP)
	private Date plannedSnfDischargeDate;
	private Integer plannedDischargeId;
	private Integer actualDischargeId;
	private Integer plannedDischargeHospitalMasterId;
	private Integer actualDischargeHospitalMasterId;
	private Integer plannedLOS;
	private Integer actualLOS;
	@Column(name = "BPCI")
	private String bpci;
	@Temporal(TemporalType.TIMESTAMP)
	private Date fbNotifySentOnSixMonth;
	@Temporal(TemporalType.TIMESTAMP)
	private Date fbNotifySentOnOneYear;
	private String patientDbScore;
	private Boolean firstLogin;
	private Boolean fracture;
	private String dischargeTeleCode;
	private String dischargeTeleCountryCode;
	@Temporal(TemporalType.TIMESTAMP)
	private Date plannedAdmissionDate;
	@Temporal(TemporalType.TIMESTAMP)
	private Date actualAdmissionDate;
	private Boolean excludeMyTodo;
	private String plannedVisit;
	private String actualVisit;
	@Column(name = "HSP_CC_SECID")
	private Long hspCCSecid;
	private Boolean excludeCareCards = false;
	private String otherservicelabel;
	private Long enrolledBy;
	private String excludeReason;
	private Long bundleUpdatedByUsrAccID;
	@Temporal(TemporalType.TIMESTAMP)
	private Date bundleLastUpdated;
	private Long caseManagerId;
	@Column(name = "CNReAsFromConfigId")
	private Long cNReAsFromConfigId;
	@Column(name = "CNReAsFromConfigCNUserId")
	private Long cNReAsFromConfigCNUserId;
	private Integer admissionId;
	private Long firstSOSId;
	private Long firstSOSHpId;
	private Integer firstSOSAdmissionId;
	private Boolean pswIsActive;
	private Boolean goodByeFlag;
	private Boolean WelcomeBackFlag;
	private String caseStatusIndicator;
	private String surgicalStageDetail;
	private String procedureCode;

	private String currentPac;
	private Float youScore = 0.0f;
	private Float healthScore = 0.0f;
	private Float partialYouScore = 0.0f;
	private Float partialHealthScore = 0.0f;

	private String laterality;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hospitalSurgeonId", insertable = false, updatable = false)
	private HospitalSurgeon hospitalSurgeon;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HSP_Surg_Id", insertable = false, updatable = false)
	private UserAccount SurgeonUserAccount;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HSP_CC_Id", insertable = false, updatable = false)
	private UserAccount CCUserAccount;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HSP_CC_SECID", insertable = false, updatable = false)
	private UserAccount SECUserAccount;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PatientId",referencedColumnName = "UserAccountKey",insertable = false,updatable = false)
	private UserAccount patUserAccount;

}
