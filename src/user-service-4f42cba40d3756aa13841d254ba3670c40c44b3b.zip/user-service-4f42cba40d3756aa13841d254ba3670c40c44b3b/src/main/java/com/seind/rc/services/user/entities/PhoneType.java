package com.seind.rc.services.user.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name = "PhoneType")
public class PhoneType {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PhoneTypeId", unique = true, nullable = false)
	private Long phoneTypeId;
	@NotNull
	private String phoneTypeDesc;
	@NotNull
	private boolean active;
	@NotNull
	private int seqNo;

}
