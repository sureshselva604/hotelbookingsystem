package com.seind.rc.services.user.data;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class SaveUserData {
	
	private String firstName;
	private String lastName;
	private String userGroupName;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd")
	private Date dob;
	private String gender;
	private String address;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private String email;
	private Long hospitalId;
	private List<ImageData> uploadImage;
	private String userShow;
}
