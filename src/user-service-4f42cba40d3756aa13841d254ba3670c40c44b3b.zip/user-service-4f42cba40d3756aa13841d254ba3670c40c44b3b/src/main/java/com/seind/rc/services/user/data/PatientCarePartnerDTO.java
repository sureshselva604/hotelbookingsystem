package com.seind.rc.services.user.data;

import java.util.List;

import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.PatientStageWorkflow;

import lombok.Data;

@Data
public class PatientCarePartnerDTO {
	
	private Hospital hsp;
	private List<PatientStageWorkflow> patientSwfList;
	private String existPhoneAndNewEqual;
	private String existEmailAndNewEqual;

}
