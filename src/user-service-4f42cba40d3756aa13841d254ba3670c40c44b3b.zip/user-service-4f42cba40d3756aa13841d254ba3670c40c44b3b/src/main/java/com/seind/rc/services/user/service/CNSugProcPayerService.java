package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.entities.CNSugProcPayer;
import com.seind.rc.services.user.entities.PatientStageWorkflow;

public interface CNSugProcPayerService {

	List<CNSugProcPayer> getCNSugProcPayerBypayorAndtypeAndSurgeonUaIdAndpracticeid(
			PatientStageWorkflow patSWF, Long userAccountKey);

}
