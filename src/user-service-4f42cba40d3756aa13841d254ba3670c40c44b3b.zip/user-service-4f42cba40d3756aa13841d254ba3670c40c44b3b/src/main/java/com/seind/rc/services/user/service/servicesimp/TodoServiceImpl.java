package com.seind.rc.services.user.service.servicesimp;

import java.text.SimpleDateFormat;
import java.util.AbstractMap;
/**
 * M01
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.util.StringUtils;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.CarePlanAssesmentsUserData;
import com.seind.rc.services.user.data.CarePlanUserOrchAssessment;
import com.seind.rc.services.user.data.ConfigurableData;
import com.seind.rc.services.user.data.CountryDischargeMapData;
import com.seind.rc.services.user.data.CustomTodoForMultiPatient;
import com.seind.rc.services.user.data.DashBoardCarePlanUserData;
import com.seind.rc.services.user.data.DashboardTodoInfoBean;
import com.seind.rc.services.user.data.DashboardTransactionBean;
import com.seind.rc.services.user.data.DashboardTransactionData;
import com.seind.rc.services.user.data.DownloadCareplanBean;
import com.seind.rc.services.user.data.DownloadSummaryPatientData;
import com.seind.rc.services.user.data.HospitalData;
import com.seind.rc.services.user.data.HospitalOverlapData;
import com.seind.rc.services.user.data.HospitalOverlapSurgeonsData;
import com.seind.rc.services.user.data.HospitalPraticeData;
import com.seind.rc.services.user.data.PacDischargeInfoBean;
import com.seind.rc.services.user.data.PacPostValidationBean;
import com.seind.rc.services.user.data.PacPreValidationBean;
import com.seind.rc.services.user.data.PatInfoAllTodoViewData;
import com.seind.rc.services.user.data.PatientData;
import com.seind.rc.services.user.data.PatientDetails;
import com.seind.rc.services.user.data.PatientReadmissionShowData;
import com.seind.rc.services.user.data.PatientStageWorkflowData;
import com.seind.rc.services.user.data.PatientV1DTO;
import com.seind.rc.services.user.data.PracticeOverlapViewData;
import com.seind.rc.services.user.data.PreRequisiteTodoRaDTO;
import com.seind.rc.services.user.data.RaTodoOverlapPreRequisiteBean;
import com.seind.rc.services.user.data.TodoHospitalOverlapBean;
import com.seind.rc.services.user.data.TodoInfoBean;
import com.seind.rc.services.user.data.TodoRACareUserBean;
import com.seind.rc.services.user.data.TodoRAHospitalBean;
import com.seind.rc.services.user.data.TodoRAHospitalMultiSOSBean;
import com.seind.rc.services.user.data.TodoRAPracticeOverlapHospital;
import com.seind.rc.services.user.data.TodoRAPracticeOverlapHospitalsData;
import com.seind.rc.services.user.data.TodoReAssignUserBean;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.ClientEmailCC;
import com.seind.rc.services.user.entities.HNSurgMapToClient;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.HospitalNavigatorSugMapping;
import com.seind.rc.services.user.entities.HospitalPractice;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.NonOverlapViewOnDemand;
import com.seind.rc.services.user.entities.OverlapViewOnDemand;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientDashBoardTransaction;
import com.seind.rc.services.user.entities.PatientInfoAllTodoView;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.PracticeCoordinatorHSPMapping;
import com.seind.rc.services.user.entities.RaHspOverlapSurgeon;
import com.seind.rc.services.user.entities.RaHspOverlapSurgeonMapToClient;
import com.seind.rc.services.user.entities.Settings;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.ClientEmailCCRepository;
import com.seind.rc.services.user.repository.HNSurgMapToClientRepository;
import com.seind.rc.services.user.repository.HospitalNavigatorSugMappingRepository;
import com.seind.rc.services.user.repository.HospitalPracticeRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.NonOverlapViewOnDemandRepository;
import com.seind.rc.services.user.repository.OverlapViewOnDemandRepository;
import com.seind.rc.services.user.repository.PatientDashBoardTransactionRepository;
import com.seind.rc.services.user.repository.PatientListViewRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.PracticeCoordinatorHSPMappingRepository;
import com.seind.rc.services.user.repository.RaHspOverlapSurgeonMapToClientRepository;
import com.seind.rc.services.user.repository.RaHspOverlapSurgeonRepository;
import com.seind.rc.services.user.repository.SettingsRepository;
import com.seind.rc.services.user.repository.SurgeonRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.BatchNotificationService;
import com.seind.rc.services.user.service.TodoService;

@Service
public class TodoServiceImpl implements TodoService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TodoServiceImpl.class);
	private static final String DELETE = "Delete";
	private static final String HOSPITAL = "HOSPITAL";
	private static final String PRACTICE = "PRACTICE";
	private static final String NO_OVERLAP="Non-Overlap";

	@Autowired
	private UserAccountRepository useraccountRepo;

	@Autowired
	private HospitalSurgeonRepository hospitalSurgeonRepo;

	@Autowired
	private HospitalPracticeRepository hospitalPracticeRepo;

	@Autowired
	private PatientListViewRepository patientListViewrepository;

	@Autowired
	private HospitalRepository hospitalRepository;

	@Autowired
	private HospitalSurgeonRepository hospitalSurgeonRepository;

	@Autowired
	private PracticeCoordinatorHSPMappingRepository practiceCoordinatorHSPMappingRepo;
	
	@Autowired
	private HospitalNavigatorSugMappingRepository hospitalNavigatorSugMappingRepo;

	@Autowired
	private PatientStageWorkflowRepository patientStageWorkflowRepo;

	@Autowired
	private PatientRepository PatientRepo;

	@Autowired
	private HospitalRepository hospitalRepo;

	@Autowired
	private CarePartnerMapRepository carePartnerMapRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private OverlapViewOnDemandRepository overlapViewOnDemandRepo;

	@Autowired
	private NonOverlapViewOnDemandRepository nonOverlapViewOnDemandRepo;

	@Autowired
	private HNSurgMapToClientRepository hnSurgMapToClientRepository;

	@Autowired
	private SurgeonRepository surgeonRepo;

	@Autowired
	private RaHspOverlapSurgeonMapToClientRepository hospitalOverlapSurgeonsTwoRepo;

	@Autowired
	private RaHspOverlapSurgeonRepository hospitalOverlapSurgeonsOneRepo;

	@Autowired
	private HospitalPracticeRepository hospitalPracticeRepository;

	@Autowired
	private HNSurgMapToClientRepository hNSurgMapToClientRepo;

	@Autowired
	private PatientDashBoardTransactionRepository patientDashBoardTransactionRepo;

	@Autowired
	private ClientEmailCCRepository clientEmailCCRepository;

	@Autowired
	private SettingsRepository settingsRepository;

	@Autowired
	private BatchNotificationService batchNotificationService;

	/**
	 * M01
	 */
	@Override
	public List<PatientInfoAllTodoView> fetchPatientSwfInfoForFetchingAllTodo(Long clientId,
			List<PatientInfoAllTodoView> clientLevelPatList) {
		try {
			String mode = "";
			Optional<Hospital> hospital = hospitalRepository.findById(clientId);
			if (hospital.isPresent()) {
				mode = hospital.get().getMode();
			}
			if (mode.equals("H")) {
				clientLevelPatList = patientListViewrepository.findByHospitalId(clientId);
			}
			if (mode.equals("P")) {
				clientLevelPatList = patientListViewrepository.findByPracticeId(clientId);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return Collections.emptyList();
		}
		return clientLevelPatList;
	}

	@Override
	public Long findHospitalIdBySurgeonId(Long userAccountKey) {
		Long hospitalId = null;
		try {
			List<HospitalSurgeon> HospitalSurgeonList = hospitalSurgeonRepo.findBySurgeon_SurgeonId(userAccountKey);
			hospitalId = HospitalSurgeonList.get(0).getHospitalId();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return hospitalId;
	}

	@Override
	public Long findSelectedCnUaId(List<Long> loginUserGroupIdStr1List, TodoInfoBean todoInfoBean1) {

		Long selectedCnUaId = null;
		try {
			if (!loginUserGroupIdStr1List.contains(32L) && !loginUserGroupIdStr1List.contains(33L)) {
				selectedCnUaId = todoInfoBean1.getSelectedCnUaId();
			} else {
				selectedCnUaId = todoInfoBean1.getLoginUaId();
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return selectedCnUaId;

	}

	@Override
	public List<Long> fetchRaTodoOverlapHospitalFilterOnSurgeonsBasis(Long praticeId, String raHospitalIds,
			boolean isRaHospitalIsOverlap) {

		List<Long> raHspFilteredSurgeons = new ArrayList<Long>();
		try {
			List<Long> raHospitalIdsList = Arrays.stream(raHospitalIds.split(",")).map(Long::valueOf)
					.collect(Collectors.toList());

			if (!raHospitalIds.contains(",")) {
				HospitalPractice hospitalPractice = hospitalPracticeRepo
						.findDistinctBySecHospitalIdInAndIsOverLapTrue(raHospitalIdsList);

				if (hospitalPractice != null) {
					raHospitalIds = hospitalPractice.getHospitalId().toString();
				}
				if (isRaHospitalIsOverlap) {
					List<HospitalSurgeon> hospitalSurgeonList = hospitalSurgeonRepository
							.fetchRaHospitalIsOverlap(praticeId, raHospitalIdsList);
					raHspFilteredSurgeons = hospitalSurgeonList.stream().map(HospitalSurgeon::getSurgeon)
							.map(Surgeon::getSurgeonId).collect(Collectors.toList());

				} else {

					List<HospitalSurgeon> sugIdList = hospitalSurgeonRepository
							.findByHospitalPractice_PracticeId(praticeId);
					List<Long> surgeonIdList = sugIdList.stream().map(HospitalSurgeon::getSurgeon)
							.map(Surgeon::getSurgeonId).collect(Collectors.toList());
					List<HospitalSurgeon> hsugList = hospitalSurgeonRepository
							.findDistinctByHospitalIdAndSurgeon_SurgeonIdIn(praticeId, surgeonIdList);
					raHspFilteredSurgeons = hsugList.stream().map(HospitalSurgeon::getSurgeon)
							.map(Surgeon::getSurgeonId).collect(Collectors.toList());
				}

			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return raHspFilteredSurgeons;

	}

	@Override
	public Optional<UserAccount> getUserAccountByUserAccountId(Long loginUserAccountId) {
		return useraccountRepo.findById(loginUserAccountId);

	}

	public List<UserAccount> getUserAccountBycnIds(List<Long> loginUserAccountId) {
		return useraccountRepo.findAllById(loginUserAccountId);
	}

	@Override
	public Optional<Hospital> fetchHospitalByLoginCredential(Long loginPracticeOrHspId1) {
		return hospitalRepo.findById(loginPracticeOrHspId1);
	}

	@Override
	public List<Long> getCNListByPSG(Long psgId, Long userGroupId, UserAccount userAccount) {
		List<Long> userAccountId = new ArrayList<Long>();
		try {

			List<UserAccount> useraccountdataList = new ArrayList<UserAccount>();
			if (userGroupId == 27L || userGroupId == 40L) {
				List<Long> asList = Arrays.asList(27L, 40L);
				useraccountdataList = useraccountRepo.findByUserAccountKeyAndUserGroup_UserGroupIdIn(psgId,
						Arrays.asList(27L, 40L));
				if (useraccountdataList != null && !useraccountdataList.isEmpty()) {
					userAccountId = useraccountdataList.stream().map(UserAccount::getUserAccountId)
							.collect(Collectors.toList());
				}
			} else if (userGroupId == 28L || userGroupId == 41L) {
				useraccountdataList = useraccountRepo.findByUserAccountKeyAndUserGroup_UserGroupIdIn(psgId,
						Arrays.asList(28L, 41L));
				if (useraccountdataList != null && !useraccountdataList.isEmpty()) {
					userAccountId = useraccountdataList.stream().map(UserAccount::getUserAccountId)
							.collect(Collectors.toList());
				}
			} else if (userGroupId != 18) {
				useraccountdataList = useraccountRepo.findByUserAccountKeyAndUserGroup_UserGroupIdIn(psgId,
						Arrays.asList(userGroupId));
				if (useraccountdataList != null && !useraccountdataList.isEmpty()) {
					userAccountId = useraccountdataList.stream().map(UserAccount::getUserAccountId)
							.collect(Collectors.toList());
				}
			} else {
				List<HospitalSurgeon> hospitalSurgeonList = hospitalSurgeonRepository.findBySurgeon_SurgeonId(psgId);
				List<Long> hospitalIds = hospitalSurgeonList.stream().map(HospitalSurgeon::getHospitalId)
						.collect(Collectors.toList());
				List<UserAccount> useracc = useraccountRepo.findByUserAccountKeyInAndUserGroup_UserGroupId(hospitalIds,
						userGroupId);
				if (useracc != null && !useracc.isEmpty()) {
					userAccountId = useracc.stream().map(UserAccount::getUserAccountId).collect(Collectors.toList());
				}

			}
			return userAccountId;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return Collections.emptyList();
		}
	}

	@Override
	public PatientStageWorkflowData getPatientStageWorkflowByPatientSWFId(Long patientSWFId) {
		try {
			Optional<PatientStageWorkflow> patientStageWorkFlowData = patientStageWorkflowRepo.findById(patientSWFId);
			PatientStageWorkflow patientStageWorkflow = patientStageWorkFlowData.get();
			modelMapper.getConfiguration().setAmbiguityIgnored(true);
			Long hospitalPracticeId = patientStageWorkflow.getHospitalPractice().getHospitalPracticeId();
			PatientStageWorkflowData psw = modelMapper.map(patientStageWorkflow, PatientStageWorkflowData.class);
			psw.setHospitalPracticeId(hospitalPracticeId);
			return psw;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return null;
	}

	@Override
	public PatientData getPatientStageWorkflowByPatient(Long patientId) {
		try {
			Optional<Patient> patientOpt = PatientRepo.findById(patientId);
			Patient patient = patientOpt.get();
			return modelMapper.map(patient, PatientData.class);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return null;
	}

	@Override
	public HospitalData getHospitalDataByHospitalId(Long hospitalId) {
		HospitalData hospitalData = new HospitalData();
		try {
			Optional<Hospital> hospitalOpt = hospitalRepo.findById(hospitalId);
			Hospital hospital = hospitalOpt.get();
			hospitalData.setName(hospital.getName());
			hospitalData.setLogo(hospital.getLogo());
			hospitalData.setZoneCode(hospital.getTimeZone().getZoneCode());
			hospitalData.setPhoneFormat(hospital.getCountryCode().getPhoneFormat());
			hospitalData.setCountryCodeId(hospital.getCountryCode().getCountryCodeId());
			hospitalData.setHospitalId(hospitalId);
			hospitalData.setCountryCode(String.valueOf(hospital.getCountryCode()));
			hospitalData.setMode(hospital.getMode());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return hospitalData;
	}

	@Override
	public String getHospitalAndPracticeById(Long hospitalPracticeId) {
		String hospitalName = "Unknown Hospital";
		try {
			Optional<HospitalPractice> hospitalpraticeOpt = hospitalPracticeRepo.findById(hospitalPracticeId);
			Optional<Hospital> patHsp = hospitalRepo.findById(hospitalpraticeOpt.get().getHospitalId());

			hospitalName = patHsp.get().getName();
		} catch (Exception e) {
			hospitalName = "Unknown Hospital";
		}
		return hospitalName;
	}

	@Override
	public UserAccountData getUserAccountDataByPatientd(Long patientId) {
		try {
			List<UserAccount> userAccountList = useraccountRepo.findByUserAccountKey(patientId);
			UserAccount userAccount = userAccountList.get(0);
			return modelMapper.map(userAccount, UserAccountData.class);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public List<CountryDischargeMapData> getCountryDischargeMapByCountryCodeId(Long countryCodeId) {

		try {
			// List<CountryDischargeMap> countryDischargeList =
			// countryDischargeMapRepo.findByCountryCodeId(countryCodeId);
//			return countryDischargeList.stream()
//					.map(countryDischargeMap -> modelMapper.map(countryDischargeMap, CountryDischargeMapData.class))
//					.collect(Collectors.toList());
		}

		catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public HospitalPraticeData findHospitalPracticeById(Long hospitalPracticeId) {
		try {
			Optional<HospitalPractice> hospitalPracticeOpt = hospitalPracticeRepo.findById(hospitalPracticeId);
			HospitalPractice hospitalPractice = hospitalPracticeOpt.get();
			modelMapper.getConfiguration().setAmbiguityIgnored(true);
			return modelMapper.map(hospitalPractice, HospitalPraticeData.class);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public PatientDetails getCarePatnerDetails(Long patientId) {
		UserAccount cpUa = new UserAccount();
		PatientDetails patDetails = new PatientDetails();
		try {

			CarePartnerMap carepartnerMap = carePartnerMapRepo
					.findByPatientIdAndActiveTrueAndUserAccount_UserGroup_UserGroupIdAndUserAccount_isdelete(patientId,
							20L, false);
			if (carepartnerMap != null) {
				patDetails.setCpRelationship(
						carepartnerMap.getRelationShip() != null ? carepartnerMap.getRelationShip().toString() : "");
				patDetails.setCpFirstName(carepartnerMap.getUserAccount().getFirstName() != null
						? carepartnerMap.getUserAccount().getFirstName().toString()
						: "");
				patDetails.setCpLastName(carepartnerMap.getUserAccount().getLastName() != null
						? carepartnerMap.getUserAccount().getLastName().toString()
						: "");
				patDetails.setCpImagePath(carepartnerMap.getUserAccount().getImagePath() != null
						? carepartnerMap.getUserAccount().getImagePath().toString()
						: "");
				UserGroup ug = new UserGroup();
				ug.setUserGroupId(carepartnerMap.getUserAccount().getUserGroup().getUserGroupId() != null
						? Long.valueOf((carepartnerMap.getUserAccount().getUserGroup().getUserGroupId().toString()))
						: 0l);
				cpUa.setUserGroup(ug);
				patDetails.setCpGroupName(cpUa.getUserGroup().getGroupName());
				patDetails.setCpUserAccountId(carepartnerMap.getUserAccount().getUserAccountId() != null
						? Long.valueOf(carepartnerMap.getUserAccount().getUserAccountId().toString())
						: 0l);
				patDetails.setCpActive(carepartnerMap.getUserAccount().getActive() != null
						&& (boolean) carepartnerMap.getUserAccount().getActive());
				patDetails.setCpTelecode(carepartnerMap.getUserAccount().getTeleCode() != null
						? carepartnerMap.getUserAccount().getTeleCode().toString()
						: "");
				patDetails.setCpTeleCountryCode(carepartnerMap.getUserAccount().getTeleCountryCode() != null
						? carepartnerMap.getUserAccount().getTeleCountryCode().toString()
						: "");
				patDetails.setCpPhone(carepartnerMap.getUserAccount().getPhone() != null
						? carepartnerMap.getUserAccount().getPhone().toString()
						: "");
				patDetails.setCpEmail(carepartnerMap.getUserAccount().getEmail() != null
						? carepartnerMap.getUserAccount().getEmail().toString()
						: "");
				return patDetails;
			}
		}

		catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public OverlapViewOnDemand getOverLapPatientDetails(Long patientSWFId) {
		try {
			return overlapViewOnDemandRepo.findByPatientSwfId(patientSWFId);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public NonOverlapViewOnDemand getNonOverLapPatientDetails(Long patientSWFId) {
		try {
			return nonOverlapViewOnDemandRepo.findByPatientSwfId(patientSWFId);

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public String getPatientStageWorkflowDetails(Long patientSWFId) {
		try {
			Optional<PatientStageWorkflow> pswOpt = patientStageWorkflowRepo.findById(patientSWFId);
			PatientStageWorkflow patientStageWorkflow = pswOpt.get();
			Long hspCCId = patientStageWorkflow.getHspCCId();
			Optional<UserAccount> useAccountOpt = useraccountRepo.findById(hspCCId);
			UserAccount userAccount = useAccountOpt.get();
			Long userAccountKey = userAccount.getUserAccountKey();
			Optional<Hospital> hospitalOpt = hospitalRepo.findById(userAccountKey);
			String mode = hospitalOpt.get().getMode();
			return mode;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public List<TodoRACareUserBean> fetchRACareUserListForTodoPracticeOverlap(HospitalOverlapData hospitalOverlapData) {
		List<TodoRACareUserBean> carelist = new ArrayList<>();
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			UserAccount userAccount = useraccountRepo.findById(hospitalOverlapData.getLoginUaId()).get();
			String userGroupIdStr = userAccount.getUserGroup().getUserGroupId().toString();

			if (!userGroupIdStr.equals("32")) {
				todoHospitalOverlapBeanList = draftSqlIfUserGroupNotEqual32ToFetchRACareUserListForTodoPracticeOverlap(
						hospitalOverlapData.getIsSelectedPracticeOverlap(), userAccount,
						hospitalOverlapData.getNonOverlapSelectedSosId());
			} else {
				todoHospitalOverlapBeanList = draftSqlIfUserGroupEqual32ToFetchRACareUserListForTodoPracticeOverlap(
						hospitalOverlapData.getIsSelectedPracticeOverlap(), userAccount,
						hospitalOverlapData.getNonOverlapSelectedSosId());
			}
			if (todoHospitalOverlapBeanList != null && !todoHospitalOverlapBeanList.isEmpty()) {
				for (TodoHospitalOverlapBean todoHospitalOverlapBean : todoHospitalOverlapBeanList) {
					TodoRACareUserBean careUserBean = new TodoRACareUserBean();
					careUserBean.setCareUserUaId(todoHospitalOverlapBean.getUserAccountId());
					careUserBean.setCareUserName(todoHospitalOverlapBean.getFirstName().concat(" ")
							.concat(todoHospitalOverlapBean.getLastName()));
					careUserBean.setCareUserUgId(todoHospitalOverlapBean.getUserGroupId());

					draftFetchRACareUserListForTodoPracticeOverlap(todoHospitalOverlapBean, careUserBean);
					careUserBean.setClientName(todoHospitalOverlapBean.getName());
					carelist.add(careUserBean);
				}
				carelist = removeDuplicateUsersAndSortByRole(carelist);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return carelist;
	}

	private List<TodoHospitalOverlapBean> draftSqlIfUserGroupEqual32ToFetchRACareUserListForTodoPracticeOverlap(
			Boolean isSelectedPracticeOverlap, UserAccount userAccount, Long nonOverlapSelectedSosId) {
		try {
			if (!isSelectedPracticeOverlap) {
				return notEqualSelectedPracticeOverlapUserGroupEqual32TodoPracticeOverlap(userAccount);
			} else {
				return equalSelectedPracticeOverlapUserGroupEqual32TodoPracticeOverlap(userAccount,
						nonOverlapSelectedSosId);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	private List<TodoHospitalOverlapBean> equalSelectedPracticeOverlapUserGroupEqual32TodoPracticeOverlap(
			UserAccount userAccount, Long nonOverlapSelectedSosId) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			/** QUERY ONE **/
			List<HospitalPractice> hospitalPractice = hospitalPracticeRepository
					.findByPracticeIdAndIsOverLapTrue(userAccount.getUserAccountKey());
			List<Long> hospitalId = hospitalPractice.stream().map(HospitalPractice::getHospitalId)
					.collect(Collectors.toList());
			List<UserAccount> uAccList = useraccountRepo.findByUserAccountKeyInAndUserGroup_UserGroupId(hospitalId, 9l);
			if (uAccList != null && !uAccList.isEmpty()) {
				todoHospitalOverlapBeanList = uAccList.stream().map(userAccount2 -> {
					TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					todoHospitalOverlapBean.setUserAccountId(userAccount2.getUserAccountId());
					todoHospitalOverlapBean.setFirstName(userAccount2.getFirstName());
					todoHospitalOverlapBean.setLastName(userAccount2.getLastName());
					todoHospitalOverlapBean.setUserGroupId(userAccount2.getUserGroupId());
					todoHospitalOverlapBean.setGroupName(userAccount2.getUserGroup().getGroupName());
					todoHospitalOverlapBean.setIsCareNavigator(0);
					todoHospitalOverlapBean.setName(userAccount2.getHospital().getName());
					return todoHospitalOverlapBean;
				}).collect(Collectors.toList());
			}
			/** Query one **/
			List<UserAccount> uAcc = useraccountRepo
					.findDistinctByUserAccountKeyAndUserGroup_UserGroupId(userAccount.getUserAccountKey(), 17l);
			if (uAcc != null && !uAcc.isEmpty()) {
				todoHospitalOverlapBeanList = uAcc.stream().map(userAccount2 -> {
					TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					todoHospitalOverlapBean.setUserAccountId(userAccount2.getUserAccountId());
					todoHospitalOverlapBean.setFirstName(userAccount2.getFirstName());
					todoHospitalOverlapBean.setLastName(userAccount2.getLastName());
					todoHospitalOverlapBean.setUserGroupId(userAccount2.getUserGroupId());
					todoHospitalOverlapBean.setGroupName(userAccount2.getUserGroup().getGroupName());
					todoHospitalOverlapBean.setIsCareNavigator(0);
					todoHospitalOverlapBean.setName(userAccount2.getHospital().getName());
					return todoHospitalOverlapBean;
				}).collect(Collectors.toList());
			}
			/** QUERY THREE **/
			List<PracticeCoordinatorHSPMapping> practiceCoordinatorHSPMappingList = practiceCoordinatorHSPMappingRepo
					.findByHospitalId(nonOverlapSelectedSosId);
			if (practiceCoordinatorHSPMappingList != null && !practiceCoordinatorHSPMappingList.isEmpty()) {
				todoHospitalOverlapBeanList = practiceCoordinatorHSPMappingList.stream()
						.map(practiceCoordinatorHSPMapping -> {
							TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
							todoHospitalOverlapBean.setUserAccountId(
									practiceCoordinatorHSPMapping.getPcUserAccount().getUserAccountId());
							todoHospitalOverlapBean
									.setFirstName(practiceCoordinatorHSPMapping.getPcUserAccount().getFirstName());
							todoHospitalOverlapBean
									.setLastName(practiceCoordinatorHSPMapping.getPcUserAccount().getLastName());
							todoHospitalOverlapBean
									.setUserGroupId(practiceCoordinatorHSPMapping.getPcUserAccount().getUserGroupId());
							todoHospitalOverlapBean.setGroupName(
									practiceCoordinatorHSPMapping.getPcUserAccount().getUserGroup().getGroupName());
							todoHospitalOverlapBean.setIsCareNavigator(1);
							todoHospitalOverlapBean
									.setName(practiceCoordinatorHSPMapping.getPcUserAccount().getHospital().getName());
							return todoHospitalOverlapBean;
						}).collect(Collectors.toList());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return todoHospitalOverlapBeanList;
	}

	private List<TodoHospitalOverlapBean> notEqualSelectedPracticeOverlapUserGroupEqual32TodoPracticeOverlap(UserAccount userAccount) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			/** Query one **/
			List<UserAccount> uAcc = useraccountRepo
					.findDistinctByUserAccountKeyAndUserGroup_UserGroupId(userAccount.getUserAccountKey(), 17l);
			if(uAcc != null && !uAcc.isEmpty()) {
				 todoHospitalOverlapBeanList = uAcc.stream()
					    .map(userAccount2 -> {
					        TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					        todoHospitalOverlapBean.setUserAccountId(userAccount2.getUserAccountId());
					        todoHospitalOverlapBean.setFirstName(userAccount2.getFirstName());
					        todoHospitalOverlapBean.setLastName(userAccount2.getLastName());
					        todoHospitalOverlapBean.setUserGroupId(userAccount2.getUserGroupId());
					        todoHospitalOverlapBean.setGroupName(userAccount2.getUserGroup().getGroupName());
					        todoHospitalOverlapBean.setIsCareNavigator(0);
					        todoHospitalOverlapBean.setName(userAccount2.getHospital().getName());
					        return todoHospitalOverlapBean;
					    })
					    .collect(Collectors.toList());
			}
			/** Query Two **/
			
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return todoHospitalOverlapBeanList;
	}

	private void draftFetchRACareUserListForTodoPracticeOverlap(TodoHospitalOverlapBean todoHospitalOverlapBean,
			TodoRACareUserBean careUserBean) {
		try {
			if (todoHospitalOverlapBean.getGroupName().toString().equalsIgnoreCase(CommonConstant.STR_CARE_COORDINATOR)) {
				careUserBean.setCareUserUgName("CC");
			}
			if (todoHospitalOverlapBean.getGroupName().toString().equalsIgnoreCase(CommonConstant.STR_CARE_OUTCOME)) {
				careUserBean.setCareUserUgName("CN");
			}
			if (todoHospitalOverlapBean.getGroupName().toString().equalsIgnoreCase("Practice Coordinator")) {
				careUserBean.setCareUserUgName("PC");
			}
			if (todoHospitalOverlapBean.getGroupName().toString().equalsIgnoreCase("Hospital Navigator")) {
				careUserBean.setCareUserUgName("HN");
			}
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
	}

	private List<TodoHospitalOverlapBean> draftSqlIfUserGroupNotEqual32ToFetchRACareUserListForTodoPracticeOverlap(
			Boolean isSelectedPracticeOverlap, UserAccount userAccount, Long nonOverlapSelectedSosId) {
		try {
			if (!isSelectedPracticeOverlap) {
				return notIsSelectedPracticeOverlapPractice(userAccount, nonOverlapSelectedSosId);
			} else {
				return isSelectedPracticeOverlapPractice(userAccount, nonOverlapSelectedSosId);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	private List<TodoHospitalOverlapBean> isSelectedPracticeOverlapPractice(UserAccount userAccount,Long nonOverlapSelectedSosId) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			/** QUERY ONE **/
			List<HospitalPractice> hospitalPractice = hospitalPracticeRepository.findByPracticeIdAndIsOverLapTrue(userAccount.getUserAccountKey());
			List<Long> hospitalId = hospitalPractice.stream().map(HospitalPractice :: getHospitalId).collect(Collectors.toList());
			List<UserAccount> uAccList = useraccountRepo.findByUserAccountKeyInAndUserGroup_UserGroupId(hospitalId, 9l);
			if(uAccList !=null && !uAccList.isEmpty()) {
				todoHospitalOverlapBeanList = uAccList.stream()
					    .map(userAccount2 -> {
					        TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					        todoHospitalOverlapBean.setUserAccountId(userAccount2.getUserAccountId());
					        todoHospitalOverlapBean.setFirstName(userAccount2.getFirstName());
					        todoHospitalOverlapBean.setLastName(userAccount2.getLastName());
					        todoHospitalOverlapBean.setUserGroupId(userAccount2.getUserGroupId());
					        todoHospitalOverlapBean.setGroupName(userAccount2.getUserGroup().getGroupName());
					        todoHospitalOverlapBean.setIsCareNavigator(0);
					        todoHospitalOverlapBean.setName(userAccount2.getHospital().getName());
					        return todoHospitalOverlapBean;
					    })
					    .collect(Collectors.toList());
			}
			/** QUERY TWO **/
			List<UserAccount> userAccountList = useraccountRepo.findByUserGroupIdAndUserAccountKey(17l,
					userAccount.getUserAccountKey());
				if(userAccountList != null && userAccountList.isEmpty()) {
					todoHospitalOverlapBeanList = userAccountList.stream()
						    .map(userAccount2 -> {
						        TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
						        todoHospitalOverlapBean.setUserAccountId(userAccount2.getUserAccountId());
						        todoHospitalOverlapBean.setFirstName(userAccount2.getFirstName());
						        todoHospitalOverlapBean.setLastName(userAccount2.getLastName());
						        todoHospitalOverlapBean.setUserGroupId(userAccount2.getUserGroupId());
						        todoHospitalOverlapBean.setGroupName(userAccount2.getUserGroup().getGroupName());
						        todoHospitalOverlapBean.setIsCareNavigator(0);
						        todoHospitalOverlapBean.setName(userAccount2.getHospital().getName());
						        return todoHospitalOverlapBean;
						    })
						    .collect(Collectors.toList());
				}
				/** QUERY THREE **/
				List<PracticeCoordinatorHSPMapping> practiceCoordinatorHSPMappingList = practiceCoordinatorHSPMappingRepo
						.findByHospitalId(nonOverlapSelectedSosId);
				if(practiceCoordinatorHSPMappingList !=null && !practiceCoordinatorHSPMappingList.isEmpty()) {
					todoHospitalOverlapBeanList = practiceCoordinatorHSPMappingList.stream()
						    .map(practiceCoordinatorHSPMapping -> {
						        TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
						        todoHospitalOverlapBean.setUserAccountId(practiceCoordinatorHSPMapping.getPcUserAccount().getUserAccountId());
						        todoHospitalOverlapBean.setFirstName(practiceCoordinatorHSPMapping.getPcUserAccount().getFirstName());
						        todoHospitalOverlapBean.setLastName(practiceCoordinatorHSPMapping.getPcUserAccount().getLastName());
						        todoHospitalOverlapBean.setUserGroupId(practiceCoordinatorHSPMapping.getPcUserAccount().getUserGroupId());
						        todoHospitalOverlapBean.setGroupName(practiceCoordinatorHSPMapping.getPcUserAccount().getUserGroup().getGroupName());
						        todoHospitalOverlapBean.setIsCareNavigator(1);
						        todoHospitalOverlapBean.setName(practiceCoordinatorHSPMapping.getPcUserAccount().getHospital().getName());
						        return todoHospitalOverlapBean;
						    })
						    .collect(Collectors.toList());
				}
			return todoHospitalOverlapBeanList;	
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
		return todoHospitalOverlapBeanList;
	}

	private List<TodoHospitalOverlapBean> notIsSelectedPracticeOverlapPractice( UserAccount userAccount,Long nonOverlapSelectedSosId) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			/** Query one **/
			List<UserAccount> uAcc = useraccountRepo
					.findDistinctByUserAccountKeyAndUserGroup_UserGroupId(userAccount.getUserAccountKey(), 17l);
			if(uAcc != null && !uAcc.isEmpty()) {
				 todoHospitalOverlapBeanList = uAcc.stream()
					    .map(userAccount2 -> {
					        TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					        todoHospitalOverlapBean.setUserAccountId(userAccount2.getUserAccountId());
					        todoHospitalOverlapBean.setFirstName(userAccount2.getFirstName());
					        todoHospitalOverlapBean.setLastName(userAccount2.getLastName());
					        todoHospitalOverlapBean.setUserGroupId(userAccount2.getUserGroupId());
					        todoHospitalOverlapBean.setGroupName(userAccount2.getUserGroup().getGroupName());
					        todoHospitalOverlapBean.setIsCareNavigator(0);
					        todoHospitalOverlapBean.setName(userAccount2.getHospital().getName());
					        return todoHospitalOverlapBean;
					    })
					    .collect(Collectors.toList());
			}
			/** Query two **/
			List<PracticeCoordinatorHSPMapping> practiceCoordinatorHSPMappingList = practiceCoordinatorHSPMappingRepo
					.findByHospitalId(nonOverlapSelectedSosId);
			if (practiceCoordinatorHSPMappingList != null && !practiceCoordinatorHSPMappingList.isEmpty()) {
				todoHospitalOverlapBeanList = practiceCoordinatorHSPMappingList.stream()
					    .map(practiceCoordinatorHSPMapping -> {
					        TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					        todoHospitalOverlapBean.setUserAccountId(practiceCoordinatorHSPMapping.getPcUserAccount().getUserAccountId());
					        todoHospitalOverlapBean.setFirstName(practiceCoordinatorHSPMapping.getPcUserAccount().getFirstName());
					        todoHospitalOverlapBean.setLastName(practiceCoordinatorHSPMapping.getPcUserAccount().getLastName());
					        todoHospitalOverlapBean.setUserGroupId(practiceCoordinatorHSPMapping.getPcUserAccount().getUserGroupId());
					        todoHospitalOverlapBean.setGroupName(practiceCoordinatorHSPMapping.getPcUserAccount().getUserGroup().getGroupName());
					        todoHospitalOverlapBean.setIsCareNavigator(0);
					        todoHospitalOverlapBean.setName(practiceCoordinatorHSPMapping.getPcUserAccount().getHospital().getName());
					        return todoHospitalOverlapBean;
					    })
					    .collect(Collectors.toList());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return todoHospitalOverlapBeanList;
	}

	public void addPracticeOverlapData(List<PracticeOverlapViewData> PracticeOverlapViewDataList,
			List<PracticeOverlapViewData> PracticeOverlapViewDataList2, List<UserAccount> userAccountList,
			List<PracticeCoordinatorHSPMapping> practiceCoordinatorHSPMapping) {
		PracticeOverlapViewDataList.addAll(userAccountList.stream().map(userAccountData -> {
			PracticeOverlapViewData useraccountToPracticeData = new PracticeOverlapViewData();
			useraccountToPracticeData.setUserAccountId(userAccountData.getUserAccountId());
			useraccountToPracticeData.setFirstName(userAccountData.getFirstName());
			useraccountToPracticeData.setLastName(userAccountData.getLastName());
			useraccountToPracticeData.setUserGroupId(userAccountData.getUserGroup().getUserGroupId());
			useraccountToPracticeData.setIsCareNavigator(0);
			useraccountToPracticeData.setName(userAccountData.getHospital().getName());
			return useraccountToPracticeData;
		}).collect(Collectors.toList()));
		PracticeOverlapViewDataList2
				.addAll(practiceCoordinatorHSPMapping.stream().map(practiceCoordinatorHSPMappingList -> {
					PracticeOverlapViewData useraccountToPracticeData = new PracticeOverlapViewData();
					useraccountToPracticeData
							.setUserAccountId(practiceCoordinatorHSPMappingList.getPcUserAccount().getUserAccountId());
					useraccountToPracticeData
							.setFirstName(practiceCoordinatorHSPMappingList.getPcUserAccount().getFirstName());
					useraccountToPracticeData
							.setLastName(practiceCoordinatorHSPMappingList.getPcUserAccount().getLastName());
					useraccountToPracticeData.setUserGroupId(
							practiceCoordinatorHSPMappingList.getPcUserAccount().getUserGroup().getUserGroupId());
					useraccountToPracticeData.setIsCareNavigator(0);
					useraccountToPracticeData
							.setName(practiceCoordinatorHSPMappingList.getPcUserAccount().getHospital().getName());
					return useraccountToPracticeData;
				}).collect(Collectors.toList()));

		PracticeOverlapViewDataList.addAll(PracticeOverlapViewDataList2);
	}


public List<TodoRACareUserBean> fetchHospitalOverlapData(HospitalOverlapData hospitalOverlap) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			UserAccount userAccount = useraccountRepo.findById(hospitalOverlap.getLoginUaId()).get();
			String userGroupIdStr = userAccount.getUserGroup().getUserGroupId().toString();

			if (!userGroupIdStr.equals("33")) {
				 todoHospitalOverlapBeanList = draftIfUserGroupNotEqualTo33ToFetchRACareUserListForTodoHospitalOverlap(hospitalOverlap, userAccount);
			} else {
				draftIfUserGroupEqualTo33ToFetchRACareUserListForTodoHspOverlap(hospitalOverlap, userAccount);
			}
			if(todoHospitalOverlapBeanList != null && !todoHospitalOverlapBeanList.isEmpty()) {
				List<TodoRACareUserBean> todoRACareUserBeanList = processTodoHospitalOverlap(todoHospitalOverlapBeanList);
			return todoRACareUserBeanList;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	private List<TodoHospitalOverlapBean> draftIfUserGroupEqualTo33ToFetchRACareUserListForTodoHspOverlap(
			HospitalOverlapData hospitalOverlap, UserAccount userAccount) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			if (!hospitalOverlap.getIsSelectedPracticeOverlap()) {
				fetchRACareUserListForTodoHspOverlap(userAccount);
			} else {
				todoHospitalOverlapBeanList = fetchRACareUserListForSelectedPracticeOverlap(hospitalOverlap,
						userAccount);
			}
			return todoHospitalOverlapBeanList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return todoHospitalOverlapBeanList;
	}
	
	private List<TodoHospitalOverlapBean> fetchRACareUserListForTodoHspOverlap(UserAccount userAccount) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			/** QUERY ONE **/
			List<UserAccount> userAcc = useraccountRepo
					.findDistinctByUserAccountKeyAndUserGroup_UserGroupId(userAccount.getUserAccountKey(), 9l);
			if (userAcc != null) {
				todoHospitalOverlapBeanList = userAcc.stream().map(userAccount2 -> {
					TodoHospitalOverlapBean todoHospitalOverlapData = new TodoHospitalOverlapBean();
					todoHospitalOverlapData.setUserAccountId(userAccount2.getUserAccountId());
					todoHospitalOverlapData.setFirstName(userAccount2.getFirstName());
					todoHospitalOverlapData.setLastName(userAccount2.getLastName());
					todoHospitalOverlapData.setUserGroupId(userAccount2.getUserGroupId());
					todoHospitalOverlapData.setGroupName(userAccount2.getUserGroup().getGroupName());
					todoHospitalOverlapData.setIsCareNavigator(0);
					todoHospitalOverlapData.setName(userAccount2.getHospital().getName());
					return todoHospitalOverlapData;
				}).collect(Collectors.toList());
			}
			/** QUERY TWO **/
			List<TodoHospitalOverlapBean> hospitalOverlap = hnSurgMapToClientRepository.getHospitalOverlap(null,null);
			if(hospitalOverlap != null && !hospitalOverlap.isEmpty()) {
				todoHospitalOverlapBeanList.addAll(hospitalOverlap);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return todoHospitalOverlapBeanList;
	}
	
	private List<TodoHospitalOverlapBean> fetchRACareUserListForSelectedPracticeOverlap(
			HospitalOverlapData hospitalOverlap, UserAccount userAccount) {
		List<TodoHospitalOverlapBean> TodoHospitalOverlapBeanList = new ArrayList<>();
		List<TodoHospitalOverlapBean> TodoHospitalOverlapBeanList2 = new ArrayList<>();
		List<TodoHospitalOverlapBean> TodoHospitalOverlapBeanList3 = new ArrayList<>();
		try {
			/** QUERY ONE **/
			List<TodoHospitalOverlapBean> todoHospitalOverlapBean = useraccountRepo
					.practiceOverlap(hospitalOverlap.getOverlapSelectedPracticeId(), userAccount.getUserAccountKey());
			if (todoHospitalOverlapBean != null && !todoHospitalOverlapBean.isEmpty()) {
				TodoHospitalOverlapBeanList.addAll(todoHospitalOverlapBean);
			}
			/** QUERY TWO **/
			List<UserAccount> userAcc = useraccountRepo
					.findDistinctByUserAccountKeyAndUserGroup_UserGroupId(userAccount.getUserAccountKey(), 9l);
			if (userAcc != null) {
				TodoHospitalOverlapBeanList2 = userAcc.stream().map(userAccount2 -> {
					TodoHospitalOverlapBean todoHospitalOverlapData = new TodoHospitalOverlapBean();
					todoHospitalOverlapData.setUserAccountId(userAccount2.getUserAccountId());
					todoHospitalOverlapData.setFirstName(userAccount2.getFirstName());
					todoHospitalOverlapData.setLastName(userAccount2.getLastName());
					todoHospitalOverlapData.setUserGroupId(userAccount2.getUserGroupId());
					todoHospitalOverlapData.setGroupName(userAccount2.getUserGroup().getGroupName());
					todoHospitalOverlapData.setIsCareNavigator(0);
					todoHospitalOverlapData.setName(userAccount2.getHospital().getName());
					return todoHospitalOverlapData;
				}).collect(Collectors.toList());

				TodoHospitalOverlapBeanList.addAll(TodoHospitalOverlapBeanList2);
			}
			/** QUERY THREE **/
			Optional<Hospital> hospital = hospitalRepo.findById(userAccount.getUserAccountKey());
			List<HNSurgMapToClient> hnSurgMapToClient = hnSurgMapToClientRepository
					.findByHospitalId(hospital.get().getHospitalId());
			List<Long> hnSugMapId = hnSurgMapToClient.stream().map(HNSurgMapToClient::getHNSurgMapId)
					.collect(Collectors.toList());
			List<HospitalNavigatorSugMapping> hospitalNavigatorSugMappingList = hospitalNavigatorSugMappingRepo
					.findByHnsugMappingidIn(hnSugMapId);
			if (hospitalNavigatorSugMappingList != null && !hospitalNavigatorSugMappingList.isEmpty()) {
				TodoHospitalOverlapBeanList3 = hospitalNavigatorSugMappingList.stream()
						.map(hospitalNavigatorSugMapping -> {
							TodoHospitalOverlapBean todoHospitalOverlap = new TodoHospitalOverlapBean();
							todoHospitalOverlap.setUserAccountId(
									hospitalNavigatorSugMapping.getHNUserAccount().getUserAccountId());
							todoHospitalOverlap
									.setFirstName(hospitalNavigatorSugMapping.getHNUserAccount().getFirstName());
							todoHospitalOverlap
									.setLastName(hospitalNavigatorSugMapping.getHNUserAccount().getLastName());
							todoHospitalOverlap
									.setUserGroupId(hospitalNavigatorSugMapping.getHNUserAccount().getUserGroupId());
							todoHospitalOverlap.setGroupName(
									hospitalNavigatorSugMapping.getHNUserAccount().getUserGroup().getGroupName());
							todoHospitalOverlap.setIsCareNavigator(0);
							todoHospitalOverlap
									.setName(hospitalNavigatorSugMapping.getHNUserAccount().getHospital().getName());
							return todoHospitalOverlap;
						}).collect(Collectors.toList());
				TodoHospitalOverlapBeanList.addAll(TodoHospitalOverlapBeanList3);
			}
			/** QUERY FOUR **/
			List<TodoHospitalOverlapBean> getraHospitalOverlapPractice = hospitalPracticeRepo
					.getraHospitalOverlapPractice(hospitalOverlap.getOverlapSelectedPracticeId());
			if (getraHospitalOverlapPractice != null && !getraHospitalOverlapPractice.isEmpty()) {
				TodoHospitalOverlapBeanList.addAll(getraHospitalOverlapPractice);
			}
			return TodoHospitalOverlapBeanList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return TodoHospitalOverlapBeanList;
	}
	
	private List<TodoRACareUserBean> processTodoHospitalOverlap(
			List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList) {
		List<TodoRACareUserBean> todoRACareUserBeanList = new ArrayList<>();
		try {
			todoRACareUserBeanList = todoHospitalOverlapBeanList.stream().map(todoHospitalOverlapBean -> {
				TodoRACareUserBean todoRACareUserBean = new TodoRACareUserBean();
				todoRACareUserBean.setCareUserUaId(todoHospitalOverlapBean.getUserAccountId());
				todoRACareUserBean.setCareUserName(
						todoHospitalOverlapBean.getFirstName().concat(todoHospitalOverlapBean.getLastName()));
				todoRACareUserBean.setCareUserUgId(todoHospitalOverlapBean.getUserGroupId());

				draftFetchRACareUserListForTodoHospitalOverlap(todoHospitalOverlapBean, todoRACareUserBean);
				todoRACareUserBean.setClientName(todoHospitalOverlapBean.getName());

				return todoRACareUserBean;
			}).collect(Collectors.toList());

			todoRACareUserBeanList = removeDuplicateUsersAndSortByRole(todoRACareUserBeanList);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return todoRACareUserBeanList;
	}
	
	private void draftFetchRACareUserListForTodoHospitalOverlap(TodoHospitalOverlapBean todoHospitalOverlapBean,
			TodoRACareUserBean todoRACareUserBean) {
		try {
			if (todoHospitalOverlapBean.getGroupName().equalsIgnoreCase(CommonConstant.STR_CARE_COORDINATOR)) {
				todoRACareUserBean.setCareUserUgName("CC");
			}
			if (todoHospitalOverlapBean.getGroupName().equalsIgnoreCase(CommonConstant.STR_CARE_OUTCOME)) {
				todoRACareUserBean.setCareUserUgName("CN");
			}
			if (todoHospitalOverlapBean.getGroupName().equalsIgnoreCase("Practice Coordinator")) {
				todoRACareUserBean.setCareUserUgName("PC");
			}
			if (todoHospitalOverlapBean.getGroupName().equalsIgnoreCase("Hospital Navigator")) {
				todoRACareUserBean.setCareUserUgName("HN");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}
	
	private List<TodoRACareUserBean> removeDuplicateUsersAndSortByRole(List<TodoRACareUserBean> todoRACareUserBean) {
		List<TodoRACareUserBean> resultList = new ArrayList<>();
		try {
			HashMap<String, TodoRACareUserBean> map = new HashMap<>();
			int todoRaCareUbSize = todoRACareUserBean.size();
			for (int i = 0; i < todoRaCareUbSize; i++) {
				map.put(todoRACareUserBean.get(i).getCareUserUaId().toString(), todoRACareUserBean.get(i));
			}
			resultList = new ArrayList<>(map.values());
			Collections.sort(resultList, (TodoRACareUserBean c1, TodoRACareUserBean c2) -> {
				try {
					return c1.getCareUserUgName().compareTo(c2.getCareUserUgName());
				} catch (Exception e) {
					return 0;
				}
			});
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return resultList;
	}

	private List<TodoHospitalOverlapBean> draftIfUserGroupNotEqualTo33ToFetchRACareUserListForTodoHospitalOverlap(
			HospitalOverlapData hospitalOverlap, UserAccount userAccount) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		try {
			if (!hospitalOverlap.getIsSelectedPracticeOverlap()) {
				todoHospitalOverlapBeanList = notSelectedPracticeOverlap(userAccount);
			} else {
				todoHospitalOverlapBeanList = SelectedPracticeOverlap(userAccount, hospitalOverlap);
			}
			return todoHospitalOverlapBeanList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return todoHospitalOverlapBeanList;
	}
	
	private List<TodoHospitalOverlapBean> notSelectedPracticeOverlap(UserAccount userAccount) {
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList = new ArrayList<>();
		List<TodoHospitalOverlapBean> todoHospitalOverlapBeanList2 = new ArrayList<>();
		try {
			List<UserAccount> userAcc = useraccountRepo
					.findDistinctByUserAccountKeyAndUserGroup_UserGroupId(userAccount.getUserAccountKey(), 9l);
			if (userAcc != null && !userAcc.isEmpty()) {
				todoHospitalOverlapBeanList = userAcc.stream().map(userAccount2 -> {
					TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					todoHospitalOverlapBean.setUserAccountId(userAccount2.getUserAccountId());
					todoHospitalOverlapBean.setFirstName(userAccount2.getFirstName());
					todoHospitalOverlapBean.setLastName(userAccount2.getLastName());
					todoHospitalOverlapBean.setUserGroupId(userAccount2.getUserGroupId());
					todoHospitalOverlapBean.setGroupName(userAccount2.getUserGroup().getGroupName());
					todoHospitalOverlapBean.setIsCareNavigator(0);
					todoHospitalOverlapBean.setName(userAccount2.getHospital().getName());
					return todoHospitalOverlapBean;
				}).collect(Collectors.toList());
			}

			Optional<Hospital> hospital = hospitalRepo.findById(userAccount.getUserAccountKey());
			List<HNSurgMapToClient> hnSurgMapToClient = hnSurgMapToClientRepository
					.findByHospitalId(hospital.get().getHospitalId());
			List<Long> hnSugMapId = hnSurgMapToClient.stream().map(HNSurgMapToClient::getHNSurgMapId)
					.collect(Collectors.toList());
			List<HospitalNavigatorSugMapping> hospitalNavigatorSugMappingList = hospitalNavigatorSugMappingRepo
					.findByHnsugMappingidIn(hnSugMapId);
			if (hospitalNavigatorSugMappingList != null && !hospitalNavigatorSugMappingList.isEmpty()) {
				hospitalNavigatorSugMappingList.stream().forEach(hospitalNavigatorSugMapping -> {
					TodoHospitalOverlapBean todoHospitalOverlapBean = new TodoHospitalOverlapBean();
					todoHospitalOverlapBean
							.setUserAccountId(hospitalNavigatorSugMapping.getHNUserAccount().getUserAccountId());
					todoHospitalOverlapBean.setFirstName(hospitalNavigatorSugMapping.getHNUserAccount().getFirstName());
					todoHospitalOverlapBean.setLastName(hospitalNavigatorSugMapping.getHNUserAccount().getLastName());
					todoHospitalOverlapBean
							.setUserGroupId(hospitalNavigatorSugMapping.getHNUserAccount().getUserGroupId());
					todoHospitalOverlapBean
							.setGroupName(hospitalNavigatorSugMapping.getHNUserAccount().getUserGroup().getGroupName());
					todoHospitalOverlapBean.setIsCareNavigator(0);
					todoHospitalOverlapBean
							.setName(hospitalNavigatorSugMapping.getHNUserAccount().getHospital().getName());
					todoHospitalOverlapBeanList2.add(todoHospitalOverlapBean);
				});

				todoHospitalOverlapBeanList.addAll(todoHospitalOverlapBeanList);
			}
			return todoHospitalOverlapBeanList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return todoHospitalOverlapBeanList;
	}
	
	private List<TodoHospitalOverlapBean> SelectedPracticeOverlap(UserAccount userAccount, HospitalOverlapData hospitalOverlap) {
		List<TodoHospitalOverlapBean> TodoHospitalOverlapBeanList = new ArrayList<>();
		List<TodoHospitalOverlapBean> TodoHospitalOverlapBeanList2 = new ArrayList<>();
		try {
			/** QUERY ONE **/
			List<TodoHospitalOverlapBean> todoHospitalOverlapBean = useraccountRepo.practiceOverlap(hospitalOverlap.getOverlapSelectedPracticeId(), userAccount.getUserAccountKey());
			if(todoHospitalOverlapBean != null) {
				TodoHospitalOverlapBeanList.addAll(todoHospitalOverlapBean);				
			}
			/** QUERY TWO **/
			List<UserAccount> userAccountByuserAccKey = useraccountRepo
					.findDistinctByUserAccountKeyAndUserGroup_UserGroupId(userAccount.getUserAccountKey(), 9l);
			if(userAccountByuserAccKey != null) {
				 TodoHospitalOverlapBeanList2 = userAccountByuserAccKey.stream()
					    .map(userAccount2 -> {
					        TodoHospitalOverlapBean todoHospitalOverlapData = new TodoHospitalOverlapBean();
					        todoHospitalOverlapData.setUserAccountId(userAccount2.getUserAccountId());
					        todoHospitalOverlapData.setFirstName(userAccount2.getFirstName());
					        todoHospitalOverlapData.setLastName(userAccount2.getLastName());
					        todoHospitalOverlapData.setUserGroupId(userAccount2.getUserGroupId());
					        todoHospitalOverlapData.setGroupName(userAccount2.getUserGroup().getGroupName());
					        todoHospitalOverlapData.setIsCareNavigator(0);
					        todoHospitalOverlapData.setName(userAccount2.getHospital().getName());
					        return todoHospitalOverlapData;
					    })
					    .collect(Collectors.toList());

				TodoHospitalOverlapBeanList.addAll(TodoHospitalOverlapBeanList2);
			}
			/** QUERY THREE **/
			List<TodoHospitalOverlapBean> raHospitalOverlapHnsugMap = hospitalRepo.RaHospitalOverlapHnsugMap(userAccount.getUserAccountKey(),hospitalOverlap.getOverlapSelectedPracticeId());
			if(raHospitalOverlapHnsugMap != null && !raHospitalOverlapHnsugMap.isEmpty()) {
				TodoHospitalOverlapBeanList.addAll(raHospitalOverlapHnsugMap);
			}
			/** QUERY FOUR **/
			List<TodoHospitalOverlapBean> hospitalOverlapRa = hospitalRepo.hospitalOverlapRa(hospitalOverlap.getOverlapSelectedPracticeId());
			if (hospitalOverlapRa != null && !hospitalOverlapRa.isEmpty()) {
				TodoHospitalOverlapBeanList.addAll(hospitalOverlapRa);
			}	
			return TodoHospitalOverlapBeanList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return TodoHospitalOverlapBeanList;
	}
	
	@Override
	public boolean fetchRaTodoOverlapPreRequisiteInfo(RaTodoOverlapPreRequisiteBean raTodoOverlapPreRequisiteBean) {
		boolean preRequisiteStatus = false;
		try {
			if (raTodoOverlapPreRequisiteBean.getLoginClientMode().equalsIgnoreCase("hospital")) {

				List<HospitalPractice> hospitalPracticeList = hospitalPracticeRepo
						.findByHospitalIdAndIsOverLapTrue(raTodoOverlapPreRequisiteBean.getLoginClientId());
				if (hospitalPracticeList != null && !hospitalPracticeList.isEmpty()) {
					return preRequisiteStatus = true;
				}
			} else {

				List<HospitalPractice> hspPracticeList = hospitalPracticeRepo
						.findByPracticeIdAndIsOverLapTrue(raTodoOverlapPreRequisiteBean.getLoginClientId());
				if (hspPracticeList != null && !hspPracticeList.isEmpty()) {
					return preRequisiteStatus = true;
				}
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return preRequisiteStatus;
	}

	@SuppressWarnings("unused")
	@Override
	public List<TodoRAPracticeOverlapHospital> getTodoRAPracticeOverlapHospitals(Long loginUaId) {
		List<TodoRAPracticeOverlapHospital> todoRAPracticeOverlapHospitalList = new ArrayList<>();
		List<TodoRAPracticeOverlapHospitalsData> todoRAPracticeOverlapHospitalDataList = new ArrayList<>();
		try {
			UserAccount userAccountList = useraccountRepo.findById(loginUaId).get();
			String userGroupIdStr = String.valueOf(userAccountList.getUserGroup().getUserGroupId());

			if (userGroupIdStr.equals("17") || userGroupIdStr.equals("32")) {
				/** QUERY ONE **/
				List<TodoRAPracticeOverlapHospitalsData> todoRAPraOverlapHspObj = hospitalPracticeRepository
						.todoRAPracticeOverlapHospitals(userAccountList.getUserAccountKey());
				if (todoRAPraOverlapHspObj != null && !todoRAPraOverlapHspObj.isEmpty()) {
					todoRAPracticeOverlapHospitalDataList.addAll(todoRAPraOverlapHspObj);
				}

				/** QUERY TWO **/
				List<TodoRAPracticeOverlapHospitalsData> todoRAPracOverlapHspObj = hNSurgMapToClientRepo
						.todoRAPracticeOverlapHospital(userAccountList.getUserAccountKey());
				if (todoRAPracOverlapHspObj != null && !todoRAPracOverlapHspObj.isEmpty()) {
					todoRAPracticeOverlapHospitalDataList.addAll(todoRAPracOverlapHspObj);
				}
				/** QUERY THREE **/
				List<PracticeCoordinatorHSPMapping> practiceCoordinatorHSPMappingList = practiceCoordinatorHSPMappingRepo
						.findByHspPractice_PracticeIdAndHspPractice_IsOverLapFalse(userAccountList.getUserAccountKey());
				if (practiceCoordinatorHSPMappingList != null && !practiceCoordinatorHSPMappingList.isEmpty()) {
					for (PracticeCoordinatorHSPMapping practiceCoordinatorHSPMapping : practiceCoordinatorHSPMappingList) {
						TodoRAPracticeOverlapHospitalsData todoRAPracticeOverlapHospital = new TodoRAPracticeOverlapHospitalsData();
						todoRAPracticeOverlapHospital.setHospitalId(practiceCoordinatorHSPMapping.getPcUserAccount().getHospital().getHospitalId());
						todoRAPracticeOverlapHospital.setName(practiceCoordinatorHSPMapping.getPcUserAccount().getHospital().getName());
						todoRAPracticeOverlapHospital.setPracticeName(practiceCoordinatorHSPMapping.getPcUserAccount().getHospital().getName());
						todoRAPracticeOverlapHospital.setIsOverLap(false);
						todoRAPracticeOverlapHospital.setSecHospitalId(practiceCoordinatorHSPMapping.getHspPractice().getSecHospitalId());
						todoRAPracticeOverlapHospitalDataList.add(todoRAPracticeOverlapHospital);
					}
				}
				if (todoRAPracticeOverlapHospitalDataList != null && !todoRAPracticeOverlapHospitalDataList.isEmpty()) {
					executeLoopTofetchTodoRAPracticeOverlapHospitals(todoRAPracticeOverlapHospitalDataList,
							todoRAPracticeOverlapHospitalList);
				} else {
					todoRAPracticeOverlapHospitalList = null;
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return todoRAPracticeOverlapHospitalList;
	}

	private void executeLoopTofetchTodoRAPracticeOverlapHospitals(
			List<TodoRAPracticeOverlapHospitalsData> todoRAPracticeOverlapHospitalDataList,
			List<TodoRAPracticeOverlapHospital> todoRAPracticeOverlapHospitalList) {
		try {
			boolean overlapMultiStatus = false;
			boolean nonOverlapMultiStatus = false;
			String overlappedPracClientName = null;
			String overlappedHspClientName = null;

			List<TodoRAHospitalBean> todoRAHospitalBeanOverLapList = new ArrayList<>();
			List<TodoRAHospitalBean> todoRAHospitalBeanNonOverLapList = new ArrayList<>();
			List<TodoRAHospitalBean> todoRAIndirectHospitalBeanNonOverLapList = new ArrayList<>();

			for (TodoRAPracticeOverlapHospitalsData todoRAPracticeOverlapHospitalsData : todoRAPracticeOverlapHospitalDataList) {

				List<TodoRAHospitalMultiSOSBean> todoRAHospitalBeanOverLapSOSList = new ArrayList<>();
				List<TodoRAHospitalMultiSOSBean> todoRAHospitalBeanNonOverLapSOSList = new ArrayList<>();
				Long primaryHspId = todoRAPracticeOverlapHospitalsData.getHospitalId();
				Long secHspId = todoRAPracticeOverlapHospitalsData.getSecHospitalId() != null ? todoRAPracticeOverlapHospitalsData.getSecHospitalId()
						: todoRAPracticeOverlapHospitalsData.getHospitalId();
				boolean isOverLap = todoRAPracticeOverlapHospitalsData.getIsOverLap().equals("1");
				if (primaryHspId.toString().equals(secHspId.toString()) && isOverLap) {
					overlappedPracClientName = todoRAPracticeOverlapHospitalsData.getPracticeName();
					overlappedHspClientName = todoRAPracticeOverlapHospitalsData.getName();	
				}else if(!todoRAPracticeOverlapHospitalsData.getPracticeName().equalsIgnoreCase(todoRAPracticeOverlapHospitalsData.getName()) && !isOverLap){
					overlappedPracClientName = todoRAPracticeOverlapHospitalsData.getPracticeName();
				}
				
				if (primaryHspId.toString().equals(secHspId.toString())) {
					TodoRAHospitalBean todoRAHospitalBean = new TodoRAHospitalBean();
					todoRAHospitalBean.setHospitalId(primaryHspId);
					todoRAHospitalBean.setName(todoRAPracticeOverlapHospitalsData.getName());
					todoRAHospitalBean.setSelected(false);	
					Object[] clientObjs = {primaryHspId, isOverLap, todoRAHospitalBean};
					if (isOverLap) {	
						overlapMultiStatus = executeInnerIfEqualOverlapToFetchTodoRAPracticeOverlapHospitals(
								clientObjs, todoRAPracticeOverlapHospitalDataList, 
								todoRAHospitalBeanOverLapSOSList,										
								todoRAHospitalBeanOverLapList);
					}else {
						nonOverlapMultiStatus = executeInnerIfNotEqualOverlapToFetchTodoRAPracticeOverlapHospitals(
								todoRAPracticeOverlapHospitalsData, todoRAIndirectHospitalBeanNonOverLapList,
								clientObjs, todoRAPracticeOverlapHospitalDataList,  						 			
								todoRAHospitalBeanNonOverLapSOSList, todoRAHospitalBeanNonOverLapList);
					}
				}
			}	
			
			String[] clientNames = {overlappedPracClientName, overlappedHspClientName};
			boolean[] clientStatuses = {overlapMultiStatus, nonOverlapMultiStatus};
			subIfTodoRAIndirectHospitalBeanNonOverLapListNotEqual(
					todoRAHospitalBeanOverLapList, todoRAHospitalBeanNonOverLapList,
					todoRAIndirectHospitalBeanNonOverLapList, todoRAPracticeOverlapHospitalList,
					clientNames, clientStatuses
					);
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
		
	}
	
	private void subIfTodoRAIndirectHospitalBeanNonOverLapListNotEqual(
			List<TodoRAHospitalBean> todoRAHospitalBeanOverLapList,
			List<TodoRAHospitalBean> todoRAHospitalBeanNonOverLapList,
			List<TodoRAHospitalBean> todoRAIndirectHospitalBeanNonOverLapList,
			List<TodoRAPracticeOverlapHospital> todoRAPracticeOverlapHospitalList, String[] clientNames,
			boolean[] clientStatuses) {
		try {
			String overlappedPracClientName = clientNames[0];
			String overlappedHspClientName = clientNames[1];
			
			boolean overlapMultiStatus = clientStatuses[0];
			boolean nonOverlapMultiStatus = clientStatuses[1];
			TodoRAPracticeOverlapHospital todoRAPracticeOverlapHospital = new TodoRAPracticeOverlapHospital();
			todoRAPracticeOverlapHospital.setSosCategory(NO_OVERLAP);
			todoRAPracticeOverlapHospital.setOverlappedClientName(overlappedPracClientName);
			todoRAPracticeOverlapHospital.setMultiStatus(nonOverlapMultiStatus);
			todoRAPracticeOverlapHospital.setReAssignHospitalBeanList(todoRAHospitalBeanNonOverLapList);
			todoRAPracticeOverlapHospitalList.add(todoRAPracticeOverlapHospital);

			todoRAPracticeOverlapHospital = new TodoRAPracticeOverlapHospital();
			todoRAPracticeOverlapHospital.setSosCategory("Overlap");
			todoRAPracticeOverlapHospital.setOverlappedClientName(overlappedHspClientName);
			todoRAPracticeOverlapHospital.setMultiStatus(overlapMultiStatus);
			todoRAPracticeOverlapHospital.setReAssignHospitalBeanList(todoRAHospitalBeanOverLapList);
			todoRAPracticeOverlapHospitalList.add(todoRAPracticeOverlapHospital);
			
			if (!todoRAIndirectHospitalBeanNonOverLapList.isEmpty()) {
				Iterator<TodoRAHospitalBean> todoRAHospitalBeanIterator = todoRAIndirectHospitalBeanNonOverLapList
						.iterator();
				
				while (todoRAHospitalBeanIterator.hasNext()) {
					TodoRAHospitalBean todoRAHospitalBean = todoRAHospitalBeanIterator.next();
					todoRAPracticeOverlapHospital = new TodoRAPracticeOverlapHospital();
					todoRAPracticeOverlapHospital.setSosCategory(NO_OVERLAP);
					todoRAPracticeOverlapHospital.setOverlappedClientName(todoRAHospitalBean.getName());
					todoRAPracticeOverlapHospital.setMultiStatus(nonOverlapMultiStatus);
					List<TodoRAHospitalBean> todoRAIndirectHospitalBeanNonOverLapfinalList = new ArrayList<>();
					
					if (todoRAHospitalBean.getTodoRAHospitalMultiSOSBean() != null
							&& !todoRAHospitalBean.getTodoRAHospitalMultiSOSBean().isEmpty()) {
						// No stuff
					} else {
						List<TodoRAHospitalMultiSOSBean> todoRAHospitalBeanOverLapSOSList = new ArrayList<>();
						TodoRAHospitalMultiSOSBean todoRAHospitalSOSBean = new TodoRAHospitalMultiSOSBean();
						todoRAHospitalSOSBean.setHospitalId(todoRAHospitalBean.getHospitalId());
						todoRAHospitalSOSBean.setName(todoRAHospitalBean.getName());
						todoRAHospitalSOSBean.setSelected(false);
						todoRAHospitalSOSBean.setOverlap(false);
						todoRAHospitalBeanOverLapSOSList.add(todoRAHospitalSOSBean);
						todoRAHospitalBean.setTodoRAHospitalMultiSOSBean(todoRAHospitalBeanOverLapSOSList);
					}
					todoRAIndirectHospitalBeanNonOverLapfinalList.add(todoRAHospitalBean);
					todoRAPracticeOverlapHospital
							.setReAssignHospitalBeanList(todoRAIndirectHospitalBeanNonOverLapfinalList);
					todoRAPracticeOverlapHospitalList.add(todoRAPracticeOverlapHospital);
					
				}
			}
			
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
		
	}
	
	private boolean executeInnerIfNotEqualOverlapToFetchTodoRAPracticeOverlapHospitals(
			TodoRAPracticeOverlapHospitalsData todoRAPracticeOverlapHospitalsData,
			List<TodoRAHospitalBean> todoRAIndirectHospitalBeanNonOverLapList, Object[] clientObjs,
			List<TodoRAPracticeOverlapHospitalsData> todoRAPracticeOverlapHospitalDataList,
			List<TodoRAHospitalMultiSOSBean> todoRAHospitalBeanNonOverLapSOSList,
			List<TodoRAHospitalBean> todoRAHospitalBeanNonOverLapList) {
		boolean nonOverlapMultiStatus = false;
		try {
			
			Long primaryHspId = (Long) clientObjs[0];			
			boolean isOverLap = (boolean) clientObjs[1];			
			TodoRAHospitalBean todoRAHospitalBean = (TodoRAHospitalBean) clientObjs[2];
			
			if (todoRAPracticeOverlapHospitalsData.getPracticeName().equalsIgnoreCase(todoRAPracticeOverlapHospitalsData.getName()) && !isOverLap) {
				todoRAHospitalBean.setOverlap(false);
				todoRAHospitalBean.setMultiStatus(false);
				todoRAIndirectHospitalBeanNonOverLapList.add(todoRAHospitalBean);
			} else {
				Long previousHsptllId = 0l;
				for (TodoRAPracticeOverlapHospitalsData todoRAPracticeOverlapHospital : todoRAPracticeOverlapHospitalDataList) {
					Long innerPrimaryHspId = todoRAPracticeOverlapHospital.getHospitalId();
					Long innerSecHspId = todoRAPracticeOverlapHospital.getSecHospitalId() != null ? todoRAPracticeOverlapHospital.getSecHospitalId()
							: todoRAPracticeOverlapHospital.getHospitalId();
					boolean innerOverLap = todoRAPracticeOverlapHospital.getIsOverLap().equals("1");
					
					if (primaryHspId.toString().equals(innerPrimaryHspId.toString())
							&& !innerPrimaryHspId.toString().equals(innerSecHspId.toString())
							&& previousHsptllId.toString().equals(innerPrimaryHspId.toString())
							&& !innerOverLap) {
						TodoRAHospitalMultiSOSBean todoRAHospitalSOSBean = new TodoRAHospitalMultiSOSBean();
						todoRAHospitalSOSBean.setHospitalId(innerSecHspId);
						todoRAHospitalSOSBean.setName(todoRAPracticeOverlapHospital.getName());
						todoRAHospitalSOSBean.setSelected(false);
						todoRAHospitalSOSBean.setOverlap(false);
						todoRAHospitalBeanNonOverLapSOSList.add(todoRAHospitalSOSBean);
					}
					previousHsptllId = todoRAPracticeOverlapHospital.getHospitalId();
				}
				todoRAHospitalBean.setOverlap(false);
				nonOverlapMultiStatus = 
						findNonOverlapMultiStatusToInnerIfNotEqualOverlapToFetchTodoRAPracticeOverlapHospitals(
						todoRAHospitalBeanNonOverLapSOSList, todoRAHospitalBean);
				todoRAHospitalBean
				.setTodoRAHospitalMultiSOSBean(todoRAHospitalBeanNonOverLapSOSList);
		todoRAHospitalBeanNonOverLapList.add(todoRAHospitalBean);
			}
			
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
		return nonOverlapMultiStatus;
	}
	
	private boolean findNonOverlapMultiStatusToInnerIfNotEqualOverlapToFetchTodoRAPracticeOverlapHospitals(
			List<TodoRAHospitalMultiSOSBean> todoRAHospitalBeanNonOverLapSOSList,
			TodoRAHospitalBean todoRAHospitalBean) {
		boolean nonOverlapMultiStatus = false;
		try {
			if (todoRAHospitalBeanNonOverLapSOSList != null
					&& !todoRAHospitalBeanNonOverLapSOSList.isEmpty()) {
				todoRAHospitalBean.setMultiStatus(true);
				nonOverlapMultiStatus = true;
			}	
		}catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
		return nonOverlapMultiStatus;
	}
	private boolean executeInnerIfEqualOverlapToFetchTodoRAPracticeOverlapHospitals(Object[] clientObjs,
			List<TodoRAPracticeOverlapHospitalsData> todoRAPracticeOverlapHospitalDataList,
			List<TodoRAHospitalMultiSOSBean> todoRAHospitalBeanOverLapSOSList,
			List<TodoRAHospitalBean> todoRAHospitalBeanOverLapList) {
		boolean overlapMultiStatus = false;
		try {
			Long primaryHspId = (Long) clientObjs[0];
			TodoRAHospitalBean todoRAHospitalBean = (TodoRAHospitalBean) clientObjs[2];
			Long previousHsptllId = 0l;

			for (TodoRAPracticeOverlapHospitalsData todoRAPracticeOverlapHospitalsData : todoRAPracticeOverlapHospitalDataList) {
				Long innerPrimaryHspId = todoRAPracticeOverlapHospitalsData.getHospitalId();
				Long innerSecHspId = todoRAPracticeOverlapHospitalsData.getSecHospitalId() != null
						? todoRAPracticeOverlapHospitalsData.getSecHospitalId()
						: todoRAPracticeOverlapHospitalsData.getHospitalId();

				boolean innerOverLap = todoRAPracticeOverlapHospitalsData.getIsOverLap().equals("1");

				if (primaryHspId.toString().equals(innerPrimaryHspId.toString())
						&& !innerPrimaryHspId.toString().equals(innerSecHspId.toString())
						&& innerPrimaryHspId.toString().equals(previousHsptllId.toString()) && innerOverLap) {
					TodoRAHospitalMultiSOSBean todoRAHospitalSOSBean = new TodoRAHospitalMultiSOSBean();
					todoRAHospitalSOSBean.setHospitalId(innerSecHspId);
					todoRAHospitalSOSBean.setName(todoRAPracticeOverlapHospitalsData.getName());
					todoRAHospitalSOSBean.setSelected(false);
					todoRAHospitalSOSBean.setOverlap(true);
					todoRAHospitalBeanOverLapSOSList.add(todoRAHospitalSOSBean);
				}
				previousHsptllId = todoRAPracticeOverlapHospitalsData.getHospitalId();
			}

			todoRAHospitalBean.setOverlap(true);
			if (todoRAHospitalBeanOverLapSOSList != null && !todoRAHospitalBeanOverLapSOSList.isEmpty()) {
				todoRAHospitalBean.setMultiStatus(true);
				overlapMultiStatus = true;
			}
			todoRAHospitalBean.setTodoRAHospitalMultiSOSBean(todoRAHospitalBeanOverLapSOSList);
			todoRAHospitalBeanOverLapList.add(todoRAHospitalBean);

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return overlapMultiStatus;
	}
	
	@Override
	public List<HospitalOverlapSurgeonsData> fetchTodoRAHospitalOverlapSurgeons(Long loginUaId) {
		List<HospitalOverlapSurgeonsData> hospitalOverlapSurgeonsData1 = new ArrayList<>();
		List<HospitalOverlapSurgeonsData> hospitalOverlapSurgeonsData2 = new ArrayList<>();
		try {
			UserAccount userAccount = useraccountRepo.findById(loginUaId).get();
			String userGroupIdStr = String.valueOf(userAccount.getUserGroup().getUserGroupId());
			if (userGroupIdStr.equals("9") || userGroupIdStr.equals("33")) {
				/** Query ONE **/
				List<RaHspOverlapSurgeon> hospitalOverlapSurgeonsOne = hospitalOverlapSurgeonsOneRepo
						.findByHpHospitalId(userAccount.getUserAccountKey());
				if (hospitalOverlapSurgeonsOne != null && !hospitalOverlapSurgeonsOne.isEmpty()) {
					hospitalOverlapSurgeonsData1 = hospitalOverlapSurgeonsOne.stream()
							.map(HospitalOverlapSurgeonsOne -> modelMapper.map(HospitalOverlapSurgeonsOne,
									HospitalOverlapSurgeonsData.class))
							.collect(Collectors.toList());
				}
				/** Query TWO **/
				List<RaHspOverlapSurgeonMapToClient> hospitalOverlapSurgeonsTwo = hospitalOverlapSurgeonsTwoRepo
						.findByHpHospitalId(userAccount.getUserAccountKey());
				if (hospitalOverlapSurgeonsTwo != null && !hospitalOverlapSurgeonsTwo.isEmpty()) {
					hospitalOverlapSurgeonsData2 = hospitalOverlapSurgeonsTwo.stream()
							.map(HospitalOverlapSurgeonsOne -> modelMapper.map(HospitalOverlapSurgeonsOne,
									HospitalOverlapSurgeonsData.class))
							.collect(Collectors.toList());
					hospitalOverlapSurgeonsData1.addAll(hospitalOverlapSurgeonsData2);
				}
				/** Query THREE **/
				List<HospitalOverlapSurgeonsData> HospitalOverlapSurgeonsDataThree = hospitalSurgeonRepo
						.getRaHospitalOverlapSurgeonsThree(userAccount.getUserAccountKey(),
								userAccount.getUserAccountKey(), userAccount.getUserAccountKey());
				if (HospitalOverlapSurgeonsDataThree != null && !HospitalOverlapSurgeonsDataThree.isEmpty()) {
					HospitalOverlapSurgeonsDataThree.stream().forEach(data -> {
						data.setOLPracName("");
					});
					hospitalOverlapSurgeonsData1.addAll(HospitalOverlapSurgeonsDataThree);
				}
				/** Query FOUR **/
				List<HospitalOverlapSurgeonsData> hospitalOverlapSurgeonsDataFour = surgeonRepo
						.getRaHospitalOverlapSurgeonsFour(userAccount.getUserAccountKey(),
								userAccount.getUserAccountKey());
				if (hospitalOverlapSurgeonsDataFour != null && !hospitalOverlapSurgeonsDataFour.isEmpty()) {
					HospitalOverlapSurgeonsDataThree.stream().forEach(data -> {
						data.setOLPracName("");
					});
					hospitalOverlapSurgeonsData1.addAll(hospitalOverlapSurgeonsDataFour);
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return hospitalOverlapSurgeonsData1;
	}

	@Override
	public DashBoardCarePlanUserData fetchDashBoardUserDataByPatientSwfId(Long patientSwfId) {
		DashBoardCarePlanUserData carePlanUserData = null;
		try {
			Optional<PatientStageWorkflow> pswData = patientStageWorkflowRepo.findById(patientSwfId);
			HospitalPractice hpData = pswData.get().getHospitalPractice();
			Hospital hospital = hpData.getHospital();
			Optional<UserAccount> userAcc = useraccountRepo.findById(pswData.get().getHspCCId());
			if (pswData.isPresent()) {
				carePlanUserData = modelMapper.map(pswData.get(), DashBoardCarePlanUserData.class);
				carePlanUserData.setHspname(hospital.getName());
				carePlanUserData.setSecHospitalId(hpData.getSecHospitalId());
				carePlanUserData.setCasemanager(userAcc.get().getFirstName() + " " + userAcc.get().getLastName());
				carePlanUserData.setPatientSwfId(patientSwfId);
				carePlanUserData.setPlannedDischargeDate(pswData.get().getPlannedDischargeDate());

				return carePlanUserData;
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return carePlanUserData;
	}

	@Override
	public DashboardTodoInfoBean preRequisiteDashboardMyTodo(DashboardTodoInfoBean dashboardTodoInfoBean) {
		try {
			Optional<PatientStageWorkflow> psw = patientStageWorkflowRepo
					.findById(dashboardTodoInfoBean.getPatientSwfId());
			if (psw.isPresent()) {
				Optional<UserAccount> userAcc = useraccountRepo.findById(psw.get().getHspCCId());
			}
			Hospital hsp = psw.get().getHospitalPractice().getHospital();
			setDashboardTodoInfoBeanValues(dashboardTodoInfoBean, psw.get(), hsp);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return dashboardTodoInfoBean;
	}

	private void setDashboardTodoInfoBeanValues(DashboardTodoInfoBean dashboardTodoInfoBean, PatientStageWorkflow psw,
			Hospital hsp) {
		try {
			dashboardTodoInfoBean.setBpci(psw.getBpci());
			dashboardTodoInfoBean.setPswExcludeMyTodo(psw.getExcludeMyTodo());
			dashboardTodoInfoBean.setPayorType(psw.getPayorId().toString());
			dashboardTodoInfoBean.setClientType(hsp.getClientTypeLabel());
			dashboardTodoInfoBean.setPswExcludeCareCards(psw.getExcludeCareCards());
			dashboardTodoInfoBean
					.setIsRevision(Boolean.valueOf(psw.getProcedureType().toString().contains("Revision")));
			dashboardTodoInfoBean.setHospitalId(hsp.getHospitalId());
			dashboardTodoInfoBean.setZoneId(hsp.getTimeZone().getZoneId());
			dashboardTodoInfoBean.setCountryCodeId(hsp.getCountryCode().getCountryCodeId());
			dashboardTodoInfoBean.setCountryCodeIdStr(hsp.getCountryCode().getCountryCodeId().toString());
			dashboardTodoInfoBean.setAdmissionId(psw.getAdmissionId());
			dashboardTodoInfoBean.setStageWorkFlowId(psw.getStageWorkflowId());
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
	}

	@Override
	public CarePlanAssesmentsUserData fetchCarePlanUsersDataByPatientSwfId(Long patientSwfId) {
		CarePlanAssesmentsUserData assesmentsUserData = new CarePlanAssesmentsUserData();
		try {
			Optional<PatientStageWorkflow> psw = patientStageWorkflowRepo.findById(patientSwfId);
			if (psw.isPresent()) {
				PatientStageWorkflow patientStageWorkflow = psw.get();
				Hospital hsp = patientStageWorkflow.getHospitalPractice().getHospital();
				int countryCodeId = hsp.getCountryCode().getCountryCodeId().intValue();
				Optional<Patient> patient = PatientRepo.findById(patientStageWorkflow.getPatient().getPatientId());

				assesmentsUserData.setUseraccountKey(hsp.getHospitalId());
				patient.ifPresent(p -> assesmentsUserData.setPatientId(p.getPatientId()));
				assesmentsUserData.setHSpCcId(patientStageWorkflow.getHspCCId());
				assesmentsUserData.setCountryCodeId(countryCodeId);
				assesmentsUserData.setCountryCode(hsp.getCountryCode().getCountryCode());
				patient.ifPresent(p -> {
					assesmentsUserData.setHeight(p.getHeight());
					assesmentsUserData.setWeight(p.getWeight());
					assesmentsUserData.setInch(p.getInch());
				});
				assesmentsUserData.setPatientswfId(patientSwfId);
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return assesmentsUserData;
	}

	@Override
	public PacPostValidationBean executeIfOpLocationMapIsNotNull(PacPreValidationBean preValidationBean) {
		PacPostValidationBean pacPostValidationBean = null;
		try {
			if (!preValidationBean.getOpLocationMap().isEmpty()) {
				List<Integer> htCountList = new ArrayList<>();
				List<Integer> allPacCountList = new ArrayList<>();
				for (Map.Entry<Integer, PacDischargeInfoBean> opLocationMapEntry : preValidationBean.getOpLocationMap()
						.entrySet()) {
					allPacCountList.add(opLocationMapEntry.getKey());
					if (opLocationMapEntry.getValue().getAnonymousDischargeId().equals("8")) {
						htCountList.add(opLocationMapEntry.getKey());
					}
				}
				Optional<PatientStageWorkflow> saveablePatientSwf = patientStageWorkflowRepo
						.findById(preValidationBean.getPatientSwfId());
				if (!htCountList.isEmpty()) {
					PacDischargeInfoBean pacDischargeInfoBean = preValidationBean.getOpLocationMap()
							.get(htCountList.get(htCountList.size() - 1));
					if (saveablePatientSwf.isPresent()) {
						pacPostValidationBean = updatePatientAdmissionStatus(preValidationBean, "Save",
								saveablePatientSwf.get(), pacDischargeInfoBean, "existingSOS");
					}
				} else {
					PacDischargeInfoBean pacDischargeInfoBean = preValidationBean.getOpLocationMap()
							.get(allPacCountList.get(allPacCountList.size() - 1));
					if (pacDischargeInfoBean.getAnonymousPrevDiscTypeId().isEmpty()
							|| pacDischargeInfoBean.getAnonymousPrevDiscTypeId().equals("8")) {
						if (saveablePatientSwf.isPresent()) {
							pacPostValidationBean = updatePatientAdmissionStatus(preValidationBean, "Save",
									saveablePatientSwf.get(), pacDischargeInfoBean, "firstSOS");
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return pacPostValidationBean;
	}

	public PacPostValidationBean updatePatientAdmissionStatus(PacPreValidationBean preValidationBean, String action,
			PatientStageWorkflow psw, PacDischargeInfoBean pacDischargeInfoBean, String sosStatus) {
		PacPostValidationBean pacPostValidationBean = new PacPostValidationBean();
		try {
			if (psw == null)
				return pacPostValidationBean;

			Long patientSwfId = preValidationBean.getPatientSwfId();
			Long loginUserAccountId = preValidationBean.getLoginUaId();
			Long loginHspOrPracId = preValidationBean.getUserAccountKey();

			Optional<UserAccount> surgeonUa = useraccountRepo.findById(psw.getHspSurgId());
			Optional<Hospital> loginHospital = hospitalRepo.findById(loginHspOrPracId);

			if (surgeonUa.isPresent() && loginHospital.isPresent()) {
				HospitalPractice hp = psw.getHospitalPractice();
				Optional<Hospital> patHsp = Optional
						.ofNullable(hp.getSecHospitalId() != null ? hp.getSecHospital() : hp.getHospital());
				int patientAdmissionId = (sosStatus.equalsIgnoreCase("firstSOS")) ? psw.getFirstSOSAdmissionId()
						: getPatientAdmissionId(preValidationBean, hp);

				if (patientAdmissionId > 0) {
					psw.setAdmissionId(patientAdmissionId);
					patientStageWorkflowRepo.save(psw);
					int sameHpCount = getSameHospitalPracticeCount(patientSwfId, psw.getFirstSOSId());

					PatientV1DTO patientV1DTO = new PatientV1DTO();
					patientV1DTO.setPatientswfid(patientSwfId);
					patientV1DTO.setLoginhsporpracId(loginHspOrPracId);
					patientV1DTO.setPatientadmissionId(patientAdmissionId);
					patientV1DTO.setLoginUseraccountId(loginUserAccountId);
					patientV1DTO.setPsw(psw);
					patientV1DTO.setHp(hp);
					patientV1DTO.setPatHsp(patHsp.get());
					patientV1DTO.setSurgeonUa(surgeonUa.get());
					patientV1DTO.setLoginHospital(loginHospital.get());
					patientV1DTO.setNewStageWorkFlowId(preValidationBean.getNewStageworkFlowId());
					patientV1DTO.setNewEpisodeId(preValidationBean.getNewEpisodeId());

					if (sosStatus.equalsIgnoreCase("firstSOS")) {
						pacPostValidationBean = executeOutpatientLogic(patientV1DTO);
					} else {
						pacPostValidationBean = updatePatAdmissionOutpat(pacDischargeInfoBean, action, patientV1DTO,
								sameHpCount);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return pacPostValidationBean;
	}

	private int getPatientAdmissionId(PacPreValidationBean preValidationBean, HospitalPractice hp) {
		Optional<Hospital> changedHsp = Optional.empty();
		if (preValidationBean.getDischargeHospitalId() != null && hp != null) {
			List<HospitalPractice> hplist = Boolean.TRUE.equals((hp.getIsOverLap()))
					? hospitalPracticeRepo.findByPracticeIdAndSecHospitalIdAndIsOverLapTrue(
							preValidationBean.getDischargeHospitalId(), preValidationBean.getDischargeHospitalId())
					: hospitalPracticeRepo.findByPracticeIdAndHospitalId(preValidationBean.getDischargeHospitalId(),
							preValidationBean.getDischargeHospitalId());
			if (hplist != null && !hplist.isEmpty()) {
				HospitalPractice newHp = hplist.get(0);
				changedHsp = Optional
						.ofNullable(newHp.getSecHospital() != null ? newHp.getSecHospital() : newHp.getHospital());
			}
		}
		return changedHsp.map(Hospital::getAdmissionId).orElse(0);
	}

	private int getSameHospitalPracticeCount(Long patientSwfId, Long firstSOSId) {
		return patientStageWorkflowRepo
				.findByPatientSWFIdAndHospitalPractice_HospitalPracticeIdNot(patientSwfId, firstSOSId).size();
	}

	private PacPostValidationBean updatePatAdmissionOutpat(PacDischargeInfoBean pacDischargeInfoBean, String action,
			PatientV1DTO patientV1DTO2, int sameHpCount) {
		PacPostValidationBean pacPostValidationBean = new PacPostValidationBean();

		if (pacDischargeInfoBean.getPatientPacMasterMapId() > 0l) {
			if (action.equalsIgnoreCase("Save") && sameHpCount > 0 && !pacDischargeInfoBean.isPacFinished()) {
				pacPostValidationBean = executeOutpatientLogic(patientV1DTO2);
			} else if (action.equalsIgnoreCase(DELETE) && sameHpCount > 0) {
				pacPostValidationBean = executeOutpatientLogic(patientV1DTO2);
			}
		} else {
			pacPostValidationBean = executeOutpatientLogic(patientV1DTO2);
		}
		return pacPostValidationBean;
	}

	private PacPostValidationBean executeOutpatientLogic(PatientV1DTO patientV1DTO) {
		PacPostValidationBean pacPostValidationBean = new PacPostValidationBean();
		try {
			Long patientSwfId = patientV1DTO.getPatientswfid();
			Long loginUserAccountId = patientV1DTO.getLoginUseraccountId();
			Long loginHspOrPracId = patientV1DTO.getLoginhsporpracId();
			int patientAdmissionId = patientV1DTO.getPatientadmissionId();
			Hospital patHsp = patientV1DTO.getPatHsp();

			List<Object> objList = updatePatientSOS(patientSwfId, loginUserAccountId, patientV1DTO);
			if (!objList.isEmpty()) {
				patHsp = (Hospital) objList.get(1);
			}

			String oldSwfId = String.valueOf(patientV1DTO.getPsw().getStageWorkflowId());
			String newSwfId = String.valueOf(patientV1DTO.getNewStageWorkFlowId());

			pacPostValidationBean.setOldSwfId(oldSwfId);
			pacPostValidationBean.setNewSwfId(newSwfId);
			pacPostValidationBean.setPatientId(patientV1DTO.getPsw().getPatientId());
			pacPostValidationBean.setPatientSwfId(patientSwfId);
			pacPostValidationBean.setCurrentStageWorkflowId(patientV1DTO.getPsw().getStageWorkflowId());
			pacPostValidationBean.setNewStageWorkflowId(patientV1DTO.getNewStageWorkFlowId());
			pacPostValidationBean.setNewCurrentEpisodeId(patientV1DTO.getNewEpisodeId());
			pacPostValidationBean.setPatientAdmissionId(patientAdmissionId);

			PatientStageWorkflow psw = patientV1DTO.getPsw();
			if (!oldSwfId.equals(newSwfId)) {
				Optional<PatientStageWorkflow> pswf = patientStageWorkflowRepo.findById(patientSwfId);
				if (pswf.isPresent()) {
					psw.setStageWorkflowId(loginHspOrPracId);
					psw.setCurrentEpisodeId(loginHspOrPracId);
					psw.setCurrentStageId(loginHspOrPracId);
				}
				// ---Sp Change To Code ---
				// executeInsertPatientHspPatientMaterialsOnDemandSP(newStageWorkflow.getStageWorkflowId(),
				// psw.getPatientId(), newCurrentEpisode.getEpisodeId(), 0l, patientSwfId);
				/**
				 * patientService.transfigurePatientWhenHospitalTransferOrAdmit(psw.getPatientId(),
				 * patientSwfId, psw.getStageWorkflowId(),
				 * newStageWorkflow.getStageWorkflowId(), newCurrentEpisode.getEpisodeId(),
				 * patientAdmissionId);
				 **/
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return pacPostValidationBean;
	}

	private List<Object> updatePatientSOS(Long patientSwfId, Long loginUserAccountId, PatientV1DTO patientV1DTO) {
		List<Object> objList = new ArrayList<>();
		Optional<Hospital> hosp = null;
		try {
			Optional<UserAccount> loginUserAccount = useraccountRepo.findById(loginUserAccountId);
			if (loginUserAccount.isPresent()) {
				Optional<UserAccount> surgeonUserAccount = useraccountRepo
						.findById(patientV1DTO.getPsw().getHspSurgId());
				if (surgeonUserAccount.isPresent()) {
					String userGroupId = String.valueOf(loginUserAccount.get().getUserGroup().getUserGroupId());
					HospitalPractice hp = patientV1DTO.getHp();
					Hospital hospital = null;
					HospitalPractice hspPractice = null;
					if (String.valueOf(loginUserAccount.get().getUserGroup().getUserGroupId()).equals("9")) {
						HospitalSurgeon hospitalsug = hospitalSurgeonRepository
								.findDistinctBySurgeon_SurgeonIdAndHospitalIdNotAndSurgeon_SurgeonIdNot(
										surgeonUserAccount.get().getUserAccountKey(),
										loginUserAccount.get().getUserAccountKey(), 50000L);
						hospital = hospitalRepo.findById(hospitalsug.getHospitalId()).get();
						if (hospital == null) {
							hospital = hospitalRepo.findByName("Unknown Practice");
							hspPractice = getHospitalPracticeByHspPsgId(patientV1DTO.getLoginHospital().getHospitalId(),
									hospital.getHospitalId(), HOSPITAL);
						} else {
							hspPractice = getHospitalPracticeByHspPsgId(patientV1DTO.getLoginHospital().getHospitalId(),
									hospital.getHospitalId(), PRACTICE);
						}
						if (hspPractice.getHospitalPracticeId() == null) {
							HospitalPractice changeProcHp = new HospitalPractice();
							changeProcHp.setPracticeId(hospital.getHospitalId());
							changeProcHp.setHospitalId(loginUserAccount.get().getUserAccountKey());
							changeProcHp.setActive(true);
							changeProcHp.setCreatedBy(loginUserAccount.get());
							changeProcHp.setCreatedDate(new Date());
							changeProcHp.setIsOverLap(false);
							hospitalPracticeRepo.save(changeProcHp);
							hspPractice = changeProcHp;
						}
					} else {
						hspPractice = patientV1DTO.getHp();
					}
					if (hspPractice != null) {
						Optional<PatientStageWorkflow> patswf = patientStageWorkflowRepo.findById(patientSwfId);
						if (patswf.isPresent()) {
							patswf.get().setHospitalPractice(hspPractice);
						}
						hp = hspPractice;
						hosp = hospitalRepo.findById(
								patientV1DTO.getLoginHospital().getMode().equalsIgnoreCase("P") ? hp.getHospitalId()
										: hp.getSecHospitalId());
					}
					objList.add(hp);
					objList.add(hosp.get());
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return objList;
	}

	private HospitalPractice getHospitalPracticeByHspPsgId(Long practiceId, Long hospitalId, String mode) {
		try {
			List<HospitalPractice> hpList = null;
			if (mode.equals("PRACTICE")) {
				hpList = hospitalPracticeRepo.findByPracticeIdAndHospitalId(practiceId, hospitalId);
			} else if (mode.equals("HOSPITAL")) {
				hpList = hospitalPracticeRepo.findByPracticeIdAndSecHospitalId(practiceId, hospitalId);
			}
			if (hpList != null && !hpList.isEmpty()) {
				return hpList.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	@Override
	public DownloadSummaryPatientData fetchDashboardCarePlanList(DashboardTransactionData dt) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(CommonConstant.STR_YYYY_MM_DD);

			DownloadSummaryPatientData downloadSumarrypatientData = new DownloadSummaryPatientData();

			DownloadCareplanBean careplanBean = new DownloadCareplanBean();

			DownloadCareplanBean setDownloadCareplanBean = setDownloadCareplanBean(careplanBean, dt);

			List<PatientStageWorkflow> pswfList = batchNotificationService
					.getDownloadFullVersionUserCondition(setDownloadCareplanBean);
			List<Long> pswfIdList = pswfList.stream().map(PatientStageWorkflow::getPatientSWFId)
					.collect(Collectors.toList());
			List<PatientDashBoardTransaction> patientDashBoardTransactionList = patientDashBoardTransactionRepo
					.findByPatientSwfIdIn(pswfIdList);

			List<PatientDetails> carePatnerDetailsList = getCarePatnerDetailsList(pswfIdList);
			downloadSumarrypatientData.setCarePatnerDetailsList(carePatnerDetailsList);
			downloadSumarrypatientData.setPatientDashBoardTransaction(patientDashBoardTransactionList);
			return downloadSumarrypatientData;

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	private DownloadCareplanBean setDownloadCareplanBean(DownloadCareplanBean careplanBean,
			DashboardTransactionData dt) {
		DownloadCareplanBean dcp = modelMapper.map(dt, DownloadCareplanBean.class);
		return dcp;
	}

	public List<PatientDetails> getCarePatnerDetailsList(List<Long> patientIdsList) {
		UserAccount cpUa = new UserAccount();
		List<PatientDetails> PatientDetailsList = new ArrayList<PatientDetails>();
		PatientDetails patDetails = new PatientDetails();
		try {

			List<CarePartnerMap> carepartnerMapList = carePartnerMapRepo
					.findByPatientIdInAndActiveTrueAndUserAccount_UserGroup_UserGroupIdAndUserAccount_isdelete(
							patientIdsList, 20L, false);
			for (CarePartnerMap carepartnerMap : carepartnerMapList) {

				if (carepartnerMap != null) {
					patDetails.setCpRelationship(
							carepartnerMap.getRelationShip() != null ? carepartnerMap.getRelationShip().toString()
									: "");
					patDetails.setCpFirstName(carepartnerMap.getUserAccount().getFirstName() != null
							? carepartnerMap.getUserAccount().getFirstName().toString()
							: "");
					patDetails.setCpLastName(carepartnerMap.getUserAccount().getLastName() != null
							? carepartnerMap.getUserAccount().getLastName().toString()
							: "");
					patDetails.setCpImagePath(carepartnerMap.getUserAccount().getImagePath() != null
							? carepartnerMap.getUserAccount().getImagePath().toString()
							: "");
					UserGroup ug = new UserGroup();
					ug.setUserGroupId(carepartnerMap.getUserAccount().getUserGroup().getUserGroupId() != null
							? Long.valueOf((carepartnerMap.getUserAccount().getUserGroup().getUserGroupId().toString()))
							: 0l);
					cpUa.setUserGroup(ug);
					patDetails.setCpGroupName(cpUa.getUserGroup().getGroupName());
					patDetails.setCpUserAccountId(carepartnerMap.getUserAccount().getUserAccountId() != null
							? Long.valueOf(carepartnerMap.getUserAccount().getUserAccountId().toString())
							: 0l);
					patDetails.setCpActive(carepartnerMap.getUserAccount().getActive() != null
							&& (boolean) carepartnerMap.getUserAccount().getActive());
					patDetails.setCpTelecode(carepartnerMap.getUserAccount().getTeleCode() != null
							? carepartnerMap.getUserAccount().getTeleCode().toString()
							: "");
					patDetails.setCpTeleCountryCode(carepartnerMap.getUserAccount().getTeleCountryCode() != null
							? carepartnerMap.getUserAccount().getTeleCountryCode().toString()
							: "");
					patDetails.setCpPhone(carepartnerMap.getUserAccount().getPhone() != null
							? carepartnerMap.getUserAccount().getPhone().toString()
							: "");
					patDetails.setCpEmail(carepartnerMap.getUserAccount().getEmail() != null
							? carepartnerMap.getUserAccount().getEmail().toString()
							: "");
					PatientDetailsList.add(patDetails);

				}
			}
			return PatientDetailsList;
		}

		catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	private List<Long> fetchDashboardCarePlanList() {
		try {
			List<PatientStageWorkflow> allPatientList = patientStageWorkflowRepo.findAll();
			return allPatientList.stream().map(PatientStageWorkflow::getPatientSWFId).collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	private List<PatientDashBoardTransaction> getCommercialCondition(DashboardTransactionData dt,
			Boolean isCommercialClient, List<PatientDashBoardTransaction> addDosConditionList) {

		Optional<UserAccount> userOpt = useraccountRepo.findById(dt.getRequestedBy());
		UserAccount userAccount = userOpt.get();
		if (userAccount.getUserGroupId() == 27)
			addDosConditionList = patientDashBoardTransactionRepo.findByPayorType(1L);
		else if (isCommercialClient) {
			addDosConditionList = patientDashBoardTransactionRepo.findByPayorTypeIsNot(1L);
		}
		return addDosConditionList;

	}

	private Boolean getClientConfig(DashboardTransactionData dt) {
		Boolean isCommercialClient = false;
		try {
			List<Hospital> hospitalList = hospitalRepo.findByHospitalIdIn(Arrays.asList(dt.getClientId()));
			Hospital hospital = hospitalList.get(0);
			isCommercialClient = hospital.getCommercialType();

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return isCommercialClient;

	}

	private List<PatientDashBoardTransaction> addDosCondition(DashboardTransactionData dt, SimpleDateFormat sdf,
			List<PatientDashBoardTransaction> addContionBasedOnProcedureTypeList) {
		List<Long> patientStageWorkflowIdList = new ArrayList<>();
		if (dt.getDosFrom() != null) {
			if (dt.getDosTo() != null) {

				patientStageWorkflowIdList = addContionBasedOnProcedureTypeList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());

				addContionBasedOnProcedureTypeList = patientDashBoardTransactionRepo
						.findByPatientSwfIdInAndDosBetween(patientStageWorkflowIdList, dt.getDosFrom(), dt.getDosTo());

			} else {

				patientStageWorkflowIdList = addContionBasedOnProcedureTypeList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());

				addContionBasedOnProcedureTypeList = patientDashBoardTransactionRepo.findByPatientSwfIdInAndDosBetween(
						patientStageWorkflowIdList, dt.getDosFrom(), dt.getDosFrom());

			}
		}
		return addContionBasedOnProcedureTypeList;
	}

	private List<PatientDashBoardTransaction> addContionBasedOnProcedureType(DashboardTransactionData dt,
			List<PatientDashBoardTransaction> patientDashBoardTransactionList) {
		List<Long> patientStageWorkflowIdList = new ArrayList<>();
		if (dt.getProcedureType() != null && !dt.getProcedureType().trim().isEmpty()) {
			String procedureType = dt.getProcedureType();
			if (procedureType.toLowerCase().contains("other")) {
				procedureType = procedureType + ",Other.";
				patientStageWorkflowIdList = patientDashBoardTransactionList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());
				patientDashBoardTransactionList = patientDashBoardTransactionRepo
						.findByPatientSwfIdInAndProcedureType(patientStageWorkflowIdList, procedureType);
			}
			procedureType = "'" + procedureType.replaceAll(",", "','") + "'";
			patientStageWorkflowIdList = patientDashBoardTransactionList.stream()
					.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());
			patientDashBoardTransactionList = patientDashBoardTransactionRepo
					.findByPatientSwfIdInAndProcedureType(patientStageWorkflowIdList, procedureType);
		}
		return patientDashBoardTransactionList;
	}

	private List<PatientDashBoardTransaction> primarySubQueryForPatientDashBoardTransaction(DashboardTransactionData dt,
			List<PatientDashBoardTransaction> patientDashBoardTransactionList) {
		List<Long> patientStageWorkflowIdList = new ArrayList<>();
		try {

			if (dt.getHospitalPracticeId() != null && !dt.getHospitalPracticeId().trim().isEmpty()) {
				List<Long> hospitalPraticeIdList = Arrays.asList(dt.getHospitalPracticeId().split(",")).stream()
						.map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());
				patientStageWorkflowIdList = patientDashBoardTransactionList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());

				patientDashBoardTransactionList = patientDashBoardTransactionRepo
						.findByPatientSwfIdInAndHospitalPracticeIdIn(patientStageWorkflowIdList, hospitalPraticeIdList);
				patientStageWorkflowIdList = patientDashBoardTransactionList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());

			}
			if (dt.getHspSugId() != null && !dt.getHspSugId().trim().isEmpty()) {
				List<Long> hspSurgIdList = Arrays.asList(dt.getHspSugId().split(",")).stream()
						.map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());

				patientStageWorkflowIdList = patientDashBoardTransactionList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());

				patientDashBoardTransactionList = patientDashBoardTransactionRepo
						.findByHspSurgIdInAndPatientSwfIdIn(hspSurgIdList, patientStageWorkflowIdList);

				patientStageWorkflowIdList = patientDashBoardTransactionList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());

			}
			if (dt.getBpcia() != null && !dt.getBpcia().trim().isEmpty()) {
				patientStageWorkflowIdList = patientDashBoardTransactionList.stream()
						.map(PatientDashBoardTransaction::getPatientSwfId).collect(Collectors.toList());

				patientDashBoardTransactionList = patientDashBoardTransactionRepo
						.findByBpciAndPatientSwfIdIn(dt.getBpcia(), patientStageWorkflowIdList);

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return patientDashBoardTransactionList;

	}

	public static String getNonEmptyWithBlank(String input) {
		return (input == null || StringUtils.trim(input).isEmpty()) ? "" : input;
	}

	@Override
	public ConfigurableData getHospitalDataByPatientStageWorkflowDetails(Long patientSWFId) {
		try {
			Optional<PatientStageWorkflow> pswOpt = patientStageWorkflowRepo.findById(patientSWFId);
			PatientStageWorkflow patientStageWorkflow = pswOpt.get();
			Long hspCCId = patientStageWorkflow.getHspCCId();
			Optional<UserAccount> useAccountOpt = useraccountRepo.findById(hspCCId);
			UserAccount userAccount = useAccountOpt.get();
			Long userAccountKey = userAccount.getUserAccountKey();
			return ConfigurableData.builder().loginUaHspOrPracId(userAccountKey)
					.serviceLineId(patientStageWorkflow.getServicelineId())
					.admissionId(patientStageWorkflow.getAdmissionId()).build();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public PatientReadmissionShowData willReAdmissionBeShown(Long patientSWFId) {
		PatientReadmissionShowData patientReadmissionShowData = new PatientReadmissionShowData();
		try {
			PatientStageWorkflow patientStageWorkflow = patientStageWorkflowRepo
					.findByPatientSWFIdAndHspCCIdIsNotNull(patientSWFId);
			Optional<UserAccount> userAccountOp = useraccountRepo.findById(patientStageWorkflow.getHspCCId());
			patientReadmissionShowData.setDos(patientStageWorkflow.getDos());
			patientReadmissionShowData.setPatientSWFId(patientSWFId);
			if (userAccountOp.isPresent()) {
				Optional<Hospital> hospital = hospitalRepo.findById(userAccountOp.get().getUserAccountKey());
				patientReadmissionShowData.setHospitalId(hospital.get().getHospitalId());
				patientReadmissionShowData.setMode(hospital.get().getMode());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return patientReadmissionShowData;
	}

	@Override
	public String saveDashboardTransaction(DashboardTransactionBean dashboardTransactionBean) {
		int countsize = 0;
		try {
			Hospital hospitalList = hospitalRepo.findById(dashboardTransactionBean.getClientId()).get();
			if (hospitalList != null && hospitalList.getMode().equalsIgnoreCase("h")) {
				dashboardTransactionBean.setHospitalPracticeId("");
			}
			UserAccount userAccount = useraccountRepo.findById(dashboardTransactionBean.getRequestedBy()).get();
			List<PatientStageWorkflow> patientStageWorkflowList = new ArrayList<>();
			Long payerType = 1l;
			if (userAccount != null && userAccount.getUserGroupId().equals("27")
					|| userAccount.getUserAccountId().equals("40")) {
				patientStageWorkflowList = patientStageWorkflowRepo
						.findByPayorIdIsNotAndCCUserAccount_UserAccountKeyAndDosBetween(payerType,
								dashboardTransactionBean.getClientId(), dashboardTransactionBean.getDosFrom(),
								dashboardTransactionBean.getDosTo());
			} else {
				patientStageWorkflowList = patientStageWorkflowRepo
						.findByPayorIdEqualsAndCCUserAccount_UserAccountKeyAndDosBetween(payerType,
								dashboardTransactionBean.getClientId(), dashboardTransactionBean.getDosFrom(),
								dashboardTransactionBean.getDosTo());
			}
			if (patientStageWorkflowList != null && !patientStageWorkflowList.isEmpty()) {
				countsize = patientStageWorkflowList.size();
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return String.valueOf(countsize);
	}

	public CarePlanUserOrchAssessment fetchHospitalDataByloginCnUaId(Long loginUaId, Long patientswfId) {
		try {
			UserAccount userAccount = useraccountRepo.findById(loginUaId).orElse(null);
			Hospital hospital = hospitalRepo.findById(userAccount.getUserAccountKey()).orElse(null);
			HospitalData hospitalData = modelMapper.map(hospital, HospitalData.class);
			hospitalData.setCountryCodeId(hospital.getCountryCode().getCountryCodeId());
			PatientStageWorkflow patientStageWorkflow = patientStageWorkflowRepo.findById(patientswfId).get();

			Patient patient = PatientRepo.findById(patientStageWorkflow.getPatientId()).get();
			Long age = getAge(patient.getDob());
			CarePlanUserOrchAssessment carePlanUserOrchAssessment = CarePlanUserOrchAssessment.builder()
					.healthPartialScore(patientStageWorkflow.getPartialHealthScore())
					.healthScore(patientStageWorkflow.getHealthScore()).youScore(patientStageWorkflow.getYouScore())
					.youPartialScore(patientStageWorkflow.getPartialYouScore()).age(age).gender(patient.getGender())
					.hospitalData(hospitalData).build();
			return carePlanUserOrchAssessment;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	public static Long getAge(Date utilDateOfBirth) {

		Calendar utilToday = Calendar.getInstance();
		Calendar utilBirthDate = Calendar.getInstance();

		int utilAge = 0;

		utilBirthDate.setTime(utilDateOfBirth);
		if (utilBirthDate.after(utilToday)) {
			throw new IllegalArgumentException("Can't be born in the future");
		}

		utilAge = utilToday.get(Calendar.YEAR) - utilBirthDate.get(Calendar.YEAR);
		if (((utilBirthDate.get(Calendar.DAY_OF_YEAR) - utilToday.get(Calendar.DAY_OF_YEAR) > 3)
				|| (utilBirthDate.get(Calendar.MONTH) > utilToday.get(Calendar.MONTH)))
				|| (utilBirthDate.get(Calendar.MONTH) == utilToday.get(Calendar.MONTH)
						&& (utilBirthDate.get(Calendar.DAY_OF_MONTH) > utilToday.get(Calendar.DAY_OF_MONTH)))) {
			utilAge--;
		}

		return (long) utilAge;

	}

	@Override
	public CustomTodoForMultiPatient saveCustomTodoForMultiPatients(List<Long> patientSwfIdList) {
		CustomTodoForMultiPatient customTodoForMultiPatMap = null;
		try {
			List<PatientStageWorkflow> patientStageWorkflowList = patientStageWorkflowRepo
					.findAllById(patientSwfIdList);

			Map<String, String> patientStageWorkflowMap = patientStageWorkflowList.stream()
					.collect(Collectors.toMap(workflow -> String.valueOf(workflow.getPatientSWFId()),
							workflow -> String.valueOf(workflow.getStageWorkflowId())));

			if (!patientStageWorkflowMap.isEmpty()) {
				return customTodoForMultiPatMap = CustomTodoForMultiPatient.builder()
						.patientStageWorkflowMap(patientStageWorkflowMap).build();
			}

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return customTodoForMultiPatMap;
	}

	@Override
	public List<PatientDetails> getCarePatnerDetailsByPatientIds(List<Long> patientId) {
		UserAccount cpUa = new UserAccount();
		PatientDetails patDetails = new PatientDetails();
		List<PatientDetails> patientDetailsList = new ArrayList<>();
		try {

			List<CarePartnerMap> carepartnerMapList = carePartnerMapRepo
					.findByPatientIdInAndActiveTrueAndUserAccount_UserGroup_UserGroupIdAndUserAccount_isdelete(
							patientId, 20L, false);

			carepartnerMapList.stream().forEach(carepartnerMap -> {
				if (carepartnerMap != null) {
					patDetails.setCpRelationship(
							carepartnerMap.getRelationShip() != null ? carepartnerMap.getRelationShip().toString()
									: "");
					patDetails.setCpFirstName(carepartnerMap.getUserAccount().getFirstName() != null
							? carepartnerMap.getUserAccount().getFirstName().toString()
							: "");
					patDetails.setCpLastName(carepartnerMap.getUserAccount().getLastName() != null
							? carepartnerMap.getUserAccount().getLastName().toString()
							: "");
					patDetails.setCpImagePath(carepartnerMap.getUserAccount().getImagePath() != null
							? carepartnerMap.getUserAccount().getImagePath().toString()
							: "");
					UserGroup ug = new UserGroup();
					ug.setUserGroupId(carepartnerMap.getUserAccount().getUserGroup().getUserGroupId() != null
							? Long.valueOf((carepartnerMap.getUserAccount().getUserGroup().getUserGroupId().toString()))
							: 0l);
					cpUa.setUserGroup(ug);
					patDetails.setCpGroupName(cpUa.getUserGroup().getGroupName());
					patDetails.setCpUserAccountId(carepartnerMap.getUserAccount().getUserAccountId() != null
							? Long.valueOf(carepartnerMap.getUserAccount().getUserAccountId().toString())
							: 0l);
					patDetails.setCpActive(carepartnerMap.getUserAccount().getActive() != null
							&& (boolean) carepartnerMap.getUserAccount().getActive());
					patDetails.setCpTelecode(carepartnerMap.getUserAccount().getTeleCode() != null
							? carepartnerMap.getUserAccount().getTeleCode().toString()
							: "");
					patDetails.setCpTeleCountryCode(carepartnerMap.getUserAccount().getTeleCountryCode() != null
							? carepartnerMap.getUserAccount().getTeleCountryCode().toString()
							: "");
					patDetails.setCpPhone(carepartnerMap.getUserAccount().getPhone() != null
							? carepartnerMap.getUserAccount().getPhone().toString()
							: "");
					patDetails.setCpEmail(carepartnerMap.getUserAccount().getEmail() != null
							? carepartnerMap.getUserAccount().getEmail().toString()
							: "");
					patDetails.setPatientId(carepartnerMap.getPatientId());
					patientDetailsList.add(patDetails);
				}
			});
			return patientDetailsList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public TodoReAssignUserBean reassingTodo(TodoReAssignUserBean todoReAssignUserBean) {
		TodoReAssignUserBean todoReAssignUserData = new TodoReAssignUserBean();
		try {

			Long todoReAssignedToUaId = todoReAssignUserBean.getTodoReAssignedToUaId();
			Long todoReAssignedFromUaId = todoReAssignUserBean.getTodoReAssignedFromUaId();
			Long todoReAssignedLoginUaId = todoReAssignUserBean.getTodoReAssignedLoginUaId();
			Optional<UserAccount> todoReAssignedToUacc = useraccountRepo.findById(todoReAssignedToUaId);
			Optional<UserAccount> todoReAssignedFromUacc = useraccountRepo.findById(todoReAssignedFromUaId);
			todoReAssignedFromUacc = !todoReAssignedFromUacc.isEmpty()
					&& todoReAssignedFromUacc.get().getUserAccountId() != null ? todoReAssignedFromUacc
							: useraccountRepo.findById(todoReAssignedLoginUaId);

			String[] allondmdstrparams1 = draftEmailCC(todoReAssignedFromUacc.get().getUserAccountKey());

			todoReAssignUserData.setFirstNameFromUaCc(todoReAssignedFromUacc.get().getFirstName());
			todoReAssignUserData.setLastNameFromUaCc(todoReAssignedFromUacc.get().getLastName());
			todoReAssignUserData.setFirstNameToUaCc(todoReAssignedToUacc.get().getFirstName());
			todoReAssignUserData.setLastNameToUaCc(todoReAssignedToUacc.get().getLastName());
			todoReAssignUserData.setAllondmdstrparams1(allondmdstrparams1);
			return todoReAssignUserData;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return todoReAssignUserData;
	}

	private String[] draftEmailCC(Long userAccountkey) {
		try {

			List<Settings> findByCategory = settingsRepository.findByCategory("Email");
			Map<String, String> settingsMap = new HashMap<>();
			for (Settings settings : findByCategory) {
				settingsMap.put(settings.getName(), settings.getValue());
			}

			ClientEmailCC clientEmailCC = clientEmailCCRepository.findByClientId(userAccountkey);
			if (clientEmailCC != null && !clientEmailCC.getEmailCc().isEmpty()) {
				String ccList = settingsMap.get("EMAIL_CC_LIST");
				ccList = ccList + "," + clientEmailCC.getEmailCc();
				settingsMap.put("EMAIL_CC_LIST", ccList);
			}
			String cc = settingsMap.get("EMAIL_CC_LIST");
			String bcc = settingsMap.get("EMAIL_BC_LIST");
			String[] allondmdstrparams1 = { "ReAssignTodo", cc, bcc };
			return allondmdstrparams1;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	@Override
	public List<PatientInfoAllTodoView> buildClientLevelPatListWhenSearch(String searchKey,
			List<PatientInfoAllTodoView> clientLevelPatList, Long clientId, String pracOrHsp) {
		try {

			if (pracOrHsp.equals("H")) {
				clientLevelPatList = patientListViewrepository
						.findByHospitalIdAndSugFirstNameLikeOrSugLastNameLikeOrPatFirstnameLikeOrPatLastnameLikeOrPatientStatusLikeOrBpciLike(
								clientId, searchKey, searchKey, searchKey, searchKey, searchKey, searchKey);
			}
			if (pracOrHsp.equals("P")) {
				clientLevelPatList = patientListViewrepository
						.findByPracticeIdAndSugFirstNameLikeOrSugLastNameLikeOrPatFirstnameLikeOrPatLastnameLikeOrPatientStatusLikeOrBpciLike(
								clientId, searchKey, searchKey, searchKey, searchKey, searchKey, searchKey);
			}
			return clientLevelPatList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return clientLevelPatList;
	}

	@Override
	public List<PatientInfoAllTodoView> buildClientLevelPatListWhenFilter(TodoInfoBean todoInfoBean1,
			List<PatientInfoAllTodoView> clientLevelPatList) {
		try {
			List<PatientInfoAllTodoView> patientInfoAllTodoView = patientListViewrepository
					.findBySurgicalStageAndProcedureTypeAndFirstSOSName(todoInfoBean1.getFilterSurgicalStage(),
							todoInfoBean1.getFilterProcedureType(), todoInfoBean1.getFilterSiteOfService());

			if (patientInfoAllTodoView != null && !patientInfoAllTodoView.isEmpty()) {
				clientLevelPatList = patientInfoAllTodoView.stream().map(
						PatientInfoAllTodoView -> modelMapper.map(PatientInfoAllTodoView, PatientInfoAllTodoView.class))
						.toList();
			}
			return clientLevelPatList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return clientLevelPatList;
	}

	@Override
	public PreRequisiteTodoRaDTO draftOverlapLoopNotCompleted(PreRequisiteTodoRaDTO preRequisiteTodoRaDTO) {
		try {

			List<Long> patSwfIdList = preRequisiteTodoRaDTO.getPatientSwFIdList();

			Map<String, PatInfoAllTodoViewData> patInfoAllTodoViewDataMap = patientListViewrepository
					.findByPatientSWFIdIn(patSwfIdList).stream().map(patientInfoAllTodoViewItr -> {
						String patientSWFIdString = patientInfoAllTodoViewItr.getPatientSWFId().toString();
						PatInfoAllTodoViewData patInfoAllTodoViewData = modelMapper.map(patientInfoAllTodoViewItr,
								PatInfoAllTodoViewData.class);
						return new AbstractMap.SimpleEntry<>(patientSWFIdString, patInfoAllTodoViewData);
					}).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
							(existing, replacement) -> existing));

			preRequisiteTodoRaDTO.setPatientInfoAllTodoViewMap(patInfoAllTodoViewDataMap);
			return preRequisiteTodoRaDTO;

			/*
			 * Map<String, PatInfoAllTodoViewData> patInfoAllTodoViewDataMap = new
			 * HashMap<String, PatInfoAllTodoViewData>();
			 * 
			 * List<PatientInfoAllTodoView> patientInfoAllTodoViewList =
			 * patientListViewrepository .findByPatientSWFIdIn(patSwfIdList);
			 */
			/*
			 * for (PatientInfoAllTodoView patientInfoAllTodoViewItr :
			 * patientInfoAllTodoViewList) { String patientSWFIdString =
			 * patientInfoAllTodoViewItr.getPatientSWFId().toString();
			 * 
			 * if (patInfoAllTodoViewDataMap == null || patInfoAllTodoViewDataMap.isEmpty()
			 * || !patInfoAllTodoViewDataMap.containsKey(patientSWFIdString)) {
			 * PatInfoAllTodoViewData patInfoAllTodoViewData =
			 * modelMapper.map(patientInfoAllTodoViewItr, PatInfoAllTodoViewData.class);
			 * patInfoAllTodoViewDataMap.put(patientSWFIdString, patInfoAllTodoViewData); }
			 * 
			 * }
			 * preRequisiteTodoRaDTO.setPatientInfoAllTodoViewMap(patInfoAllTodoViewDataMap)
			 * ; return preRequisiteTodoRaDTO;
			 */

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}
}
