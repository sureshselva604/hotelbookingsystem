package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name = "CNSugProcPayer")
public class CNSugProcPayer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cnsugprocpayerid", unique = true, nullable = false)
	private Integer cnsugprocpayerid;
	private Long practiceid;
//	private Long cNUserId;
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CNUserId",referencedColumnName ="userAccountId")
    private UserAccount cnUser;
	private Long surgeonid;
	private String proceduretype;
	private Long payorid;
	private Integer createdby;
	private Date createddate;
	private Boolean IsCaseManager;
	private Long surgeonUaId;
	private Long assignedHspTo;
	private Long oBCNCCMappingIdFK;

}
