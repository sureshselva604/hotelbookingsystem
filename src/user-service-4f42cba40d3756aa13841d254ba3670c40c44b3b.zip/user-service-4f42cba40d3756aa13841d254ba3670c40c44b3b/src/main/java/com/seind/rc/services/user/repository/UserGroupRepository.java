package com.seind.rc.services.user.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.UserGroup;

public interface UserGroupRepository  extends JpaRepository<UserGroup,Long>{
	
	Optional<UserGroup> findGroupNameByUserGroupId(Long userGroupId);

	UserGroup findByGroupName(String userGroupName);

}
