package com.seind.rc.services.user.service.servicesimp;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.openssl.EncryptionException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CasCommonConstant;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.NotificationConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.CCMessageData;
import com.seind.rc.services.user.data.CCpatientInfoForMessage;
import com.seind.rc.services.user.data.CasSecDetails;
import com.seind.rc.services.user.data.ClientInfo;
import com.seind.rc.services.user.data.ClientList;
import com.seind.rc.services.user.data.CountryCodeData;
import com.seind.rc.services.user.data.CountryCodeInfo;
import com.seind.rc.services.user.data.DobValidationReq;
import com.seind.rc.services.user.data.DobValidationResponse;
import com.seind.rc.services.user.data.EmailUserData;
import com.seind.rc.services.user.data.EpisodeAppointmentInfo;
import com.seind.rc.services.user.data.HospitalContactData;
import com.seind.rc.services.user.data.HospitalPracticeApptInfo;
import com.seind.rc.services.user.data.ImageData;
import com.seind.rc.services.user.data.MessageApptData;
import com.seind.rc.services.user.data.MessageReqData;
import com.seind.rc.services.user.data.NotesPatientDashBoard;
import com.seind.rc.services.user.data.NotificationData;
import com.seind.rc.services.user.data.NotifyReqData;
import com.seind.rc.services.user.data.PatientSWFInfo;
import com.seind.rc.services.user.data.ProfileData;
import com.seind.rc.services.user.data.ProfileQuestionsData;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SaveUserData;
import com.seind.rc.services.user.data.SsoSyncData;
import com.seind.rc.services.user.data.StatusMessage;
import com.seind.rc.services.user.data.SurgeonDetailsData;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.data.UserDetails;
import com.seind.rc.services.user.data.UserMsgRespData;
import com.seind.rc.services.user.data.UserProfileData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.UserUploadImgData;
import com.seind.rc.services.user.data.UserValidateModel;
import com.seind.rc.services.user.data.UsersData;
import com.seind.rc.services.user.entities.CNSugProcPayer;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.CountryCode;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.HospitalContact;
import com.seind.rc.services.user.entities.HospitalNavigatorSugMapping;
import com.seind.rc.services.user.entities.HospitalPractice;
import com.seind.rc.services.user.entities.HospitalSurgeon;
import com.seind.rc.services.user.entities.PasswordHistory;
import com.seind.rc.services.user.entities.Patient;
import com.seind.rc.services.user.entities.PatientOldDetail;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.PayorType;
import com.seind.rc.services.user.entities.PhoneType;
import com.seind.rc.services.user.entities.PracticeCoordinatorHSPMapping;
import com.seind.rc.services.user.entities.ProfileQuestions;
import com.seind.rc.services.user.entities.ProfileResultDetails;
import com.seind.rc.services.user.entities.RKUserAccount;
import com.seind.rc.services.user.entities.Surgeon;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.entities.UserPwdAudit;
import com.seind.rc.services.user.entities.UserSecResultDetails;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.CNSugProcPayerRepository;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.CountryCodeRepository;
import com.seind.rc.services.user.repository.HospitalContactRepository;
import com.seind.rc.services.user.repository.HospitalNavigatorSugMappingRepository;
import com.seind.rc.services.user.repository.HospitalPracticeRepository;
import com.seind.rc.services.user.repository.HospitalRepository;
import com.seind.rc.services.user.repository.HospitalSurgeonRepository;
import com.seind.rc.services.user.repository.PatientOldDetailRepository;
import com.seind.rc.services.user.repository.PatientRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.PayorTypeRepository;
import com.seind.rc.services.user.repository.PhoneTypeRepository;
import com.seind.rc.services.user.repository.PracticeCoordinatorHSPMappingRepository;
import com.seind.rc.services.user.repository.ProfileQuestionsRepository;
import com.seind.rc.services.user.repository.ProfileResultDetailsRepository;
import com.seind.rc.services.user.repository.RKUserAccountRepository;
import com.seind.rc.services.user.repository.SurgeonRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserGroupRepository;
import com.seind.rc.services.user.repository.UserPwdAuditRepository;
import com.seind.rc.services.user.repository.UserSecResDetRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.CNSugProcPayerService;
import com.seind.rc.services.user.service.HospitalNavigatorSugMappingService;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.PracticeCoordinatorHSPMappingService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserSecTransAuditService;
import com.seind.rc.services.user.util.GenerateOTP;
import com.seind.rc.services.user.util.I18nUtil;
import com.seind.rc.services.user.util.OnBoardUtil;
import com.seind.rc.services.user.util.RCUserUtil;
import com.seind.rc.services.user.util.SSOSyncUtil;
import com.seind.rc.services.user.util.StringEncrypter;
import com.seind.rc.services.user.util.UploadImageUtil;
import com.seind.rc.services.user.util.UserValidationUtil;

/**
 * 
 */
@Service
public class UserAccountServiceImpl implements UserAccountService {

	private static final Logger LOGGER = LogManager.getLogger(UserAccountServiceImpl.class);

	private ResourceBundle rb = ResourceBundle.getBundle("messages.app");

	@Autowired
	private UserAccountRepository userAccountRepo;

	@Autowired
	private UserSecResDetRepository userSecResDetRepo;

	@Autowired
	private HospitalService hospitalService;

	@Autowired
	private PhoneTypeRepository phoneTypeRepo;

	@Autowired
	private CarePartnerMapRepository careRepo;

	@Autowired
	private UserGroupRepository userGroupRepo;

	@Autowired
	private CountryCodeRepository countryCodeRepo;

	@Autowired
	private SurgeonRepository surgeonRepo;

	@Autowired
	private HospitalSurgeonRepository hspSurgeonRepo;

	@Autowired
	private ModelMapper modelMap;

	@Autowired
	private RKUserAccountRepository rkUserAccountRepo;

	@Autowired
	private SSOSyncUtil ssoUtil;

	@Autowired
	private UserPwdAuditRepository userPwdRepo;

	@Autowired
	private UserSecTransAuditService userSecTransService;

	@Autowired
	private PayorTypeRepository payorTypeRepository;

	@Autowired
	private PatientRepository patientRepo;

	@Autowired
	private HospitalPracticeRepository hspPracRepo;

	@Autowired
	private PatientStageWorkflowRepository patientSWFRepo;

	@Autowired
	private PracticeCoordinatorHSPMappingService pCHspMapService;

	@Autowired
	private HospitalNavigatorSugMappingService hNSugMapService;

	@Autowired
	private HospitalNavigatorSugMappingRepository hspNavSugMappingRepository;

	@Autowired
	private PracticeCoordinatorHSPMappingRepository praCCHspMappingRepository;

	@Autowired
	private CNSugProcPayerService cNSugProcPayerService;

	@Autowired
	private CNSugProcPayerRepository cNSugProcPayerRepo;

	@Autowired
	private HospitalRepository hspRepo;

	@Autowired
	private PatientOldDetailRepository patientOldDetailRepo;

	@Autowired
	private ProfileResultDetailsRepository profileRDRepo;

	@Autowired
	private ProfileQuestionsRepository profileQuesRepo;

	@Autowired
	private UserSecTransAuditRepository userSecTransAuditRepository;

	@Autowired
	private RCUserUtil rcUserUtil;

	@Autowired
	private HospitalContactRepository hspContactRepo;

	private static final ResourceBundle rs = ResourceBundle.getBundle("application");
	private static final ResourceBundle uriRB = ResourceBundle.getBundle("messages.uri");
	private static final String STR_COMMERCIAL_CN = "Commercial care navigator";
	private static final String STR_FINACIAL_CN = "Financial care navigator";
	private static final String STR_CARE_OUTCOME_MANAGER = "Care Outcomes Manager";
	private static final String STR_PRACTICE_ADMIN = "Practice Administrator";
	private static final String STR_HSP_ADMIN = "Hospital Administrator";
	private static final String STR_PERSONAL_ASST = "Personal Asst.";
	public static final String STR_CARE_COORDINATOR = "Care Coordinator";
	private static final String STR_HSP_PAT_ENROLLER = "Hospital Patient Enroller";
	private static final String STR_PRAC_PAT_ENROLLER = "Practice Patient Enroller";
	private static final String STR_PRAC_COORDINATOR = "Practice Coordinator";
	private static final String STR_HSP_NAVIGATOR = "Hospital Navigator";
	private static final String STR_PATIET_PROFILE = "Patient Profile update";
	private static final String STR_CAREPARTNER_PROFILE = "Care Partner Profile update";

	/**
	 * M01
	 * 
	 * Find UserAccount By UserAccountId
	 */
	@Override
	public UserAccount getUserAccountByUserAccountId(Long userAccountId) {
		Optional<UserAccount> userAccount = null;
		try {
			userAccount = userAccountRepo.findById(userAccountId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userAccount.isPresent() ? userAccount.get() : null;
	}

	/**
	 * M02
	 * 
	 * Get CN/Sug List for a hospital in admin
	 */
	@Override
	public List<UsersData> getUsersByHospital(Long hospitalId) {
		List<UsersData> userData = null;
		try {
			List<Long> userAccountKey = new ArrayList<>();
			userAccountKey = hspSurgeonRepo.findByHospitalId(hospitalId).stream().map(HospitalSurgeon::getSurgeon)
					.map(Surgeon::getSurgeonId).collect(Collectors.toList());
			userAccountKey.add(hospitalId);
			String hospitalName = hspRepo.findById(hospitalId).orElse(null).getName();
			List<UserAccount> userAccountList = userAccountRepo.findByUserAccountKeyIn(userAccountKey);
			userData = userAccountList.stream().map(u -> mapUserAccountToUsersData(u, hospitalName)).toList();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userData;
	}

	/**
	 * M03
	 */
	UsersData mapUserAccountToUsersData(UserAccount userAcc, String hospitalName) {
		return UsersData.builder().userId(userAcc.getUserAccountId()).userName(userAcc.getUserName())
				.firstName(userAcc.getFirstName()).lastName(userAcc.getLastName()).isActive(userAcc.getActive())
				.groupName(userAcc.getUserGroup().getGroupName()).city(userAcc.getCity()).state(userAcc.getState())
				.address(userAcc.getAddress1()).description(userAcc.getDescription()).phone(userAcc.getPhone())
				.imagePath(userAcc.getImagePath()).welcomeFlag(userAcc.getWelcomeFlag())
				.careFamilyShow(userAcc.getCareFamilyShow()).practiceName(hospitalName).isdelete(userAcc.getIsdelete())
				.build();
	}

	/**
	 * M04
	 * 
	 * Find UserSecResultDetailsId based on UserAccountId
	 */
	@Override
	public Long getUserSecResultDetailsAlreadyExist(Long userAccountId) {
		try {
			return userSecResDetRepo.findByUserAccountId(userAccountId).stream()
					.map(UserSecResultDetails::getUserSecResultDetailsId).findFirst().orElse(null);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	/**
	 * M05
	 * 
	 * Insert/Update UserSecResultDetails
	 */
	@Override
	public boolean insertOrUpdateUserSecResultDetails(Long userSecResultDetailsId,
			UserSecResultDetails userSecResultDetails) {
		try {
			if (userSecResultDetailsId <= 0) {
				userSecResDetRepo.save(userSecResultDetails);
				return true;
			} else {
				userSecResultDetails.setUserSecResultDetailsId(userSecResultDetailsId);
				userSecResDetRepo.save(userSecResultDetails);
				return true;
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return false;
	}

	/**
	 * M05
	 * 
	 * Get CareNavigator/CarePartner/Patient Profile Data
	 */
	@Override
	public UserProfileData getUserProfile(Long userId) {
		try {
			UserAccount userAccount = userAccountRepo.findById(userId).orElse(null);
			UserProfileData userProfileData = modelMap.map(userAccount, UserProfileData.class);
			CarePartnerMap carePartnerMap = userAccount.getUserGroupId() == 20l
					? careRepo.findByActiveTrueAndUserAccount_UserAccountId(userId).get(0)
					: null;
			/*
			 * Patient patient = userAccount.getUserGroupId()==19l ?
			 * patientRepo.findById(userAccount.getUserAccountKey()).orElse(null) : null;
			 */
			userProfileData.setGroupName(userAccount.getUserGroup().getGroupName());
			userProfileData.setOtherPhoneType(userAccount.getOtherPhoneTypeName());
			userProfileData.setOnBehalf(carePartnerMap != null ? carePartnerMap.getActive() : false);
			userProfileData.setRelationship(carePartnerMap != null ? carePartnerMap.getRelationShip() : "");
			userProfileData.setComType(
					RCUserUtil.getComType(userAccount.getEmail(), userAccount.getPhone()).equals("SMS") ? "TEXT"
							: RCUserUtil.getComType(userAccount.getEmail(), userAccount.getPhone()));

			return userProfileData;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return null;
		}
	}

	/**
	 * M08
	 * 
	 * This service method ensures update and save CC/Patient/CarePartner
	 */
	@Override
	public ResponseMessage profileUpdate(ProfileData profileData, Long userId) {
		ResponseMessage response = new ResponseMessage();
		try {
			UserAccount userAccount = userAccountRepo.findById(userId).orElse(null);
			if (userAccount != null) {
				Long userGroupId = userAccount.getUserGroup().getUserGroupId();
				String oldEmailId = userAccount.getEmail();
				String newEmailId = profileData.getEmail();
				String oldPhoneNo = userAccount.getPhone();
				String newPhoneNo = profileData.getPhone();

				boolean emailCheck = userAccountRepo
						.findByEmailAndUserGroup_UserGroupIdAndUserAccountIdNot(newEmailId, userGroupId, userId)
						.isEmpty();
				boolean phoneCheck = userAccountRepo
						.findByPhoneAndUserGroup_UserGroupIdAndUserAccountIdNot(newPhoneNo, userGroupId, userId)
						.isEmpty();

				if (newEmailId != null && !newEmailId.isBlank()  && !emailCheck) {
					response.setMessage(CommonConstant.EMAIL_EXISTS);
					return response;
				}
				if (newPhoneNo !=null && !newPhoneNo.isBlank() && !phoneCheck) {
					response.setMessage(CommonConstant.PHONE_EXISTS);
					return response;
				}

				boolean isValidEmail = RCUserUtil.isValidEmailAddress(newEmailId);
				Long phoneLength = getPhoneLength(profileData.getTeleCountryCode());
				boolean isValidPhone = RCUserUtil.isValidMobileNo(newPhoneNo, phoneLength);

				if (!isValidEmail) {
					response.setMessage(CommonConstant.EMAILINVALID);
					return response;
				}
				if (!isValidPhone) {
					response.setMessage(CommonConstant.PHONEINVALID);
					return response;
				}

				response.setSendEmailUpdateNotifiCation((newEmailId !=null && !newEmailId.isBlank()) && !userAccount.getWelcomeFlag()
						&& !newEmailId.equalsIgnoreCase(RCUserUtil.getStringValue(oldEmailId)));
				response.setSendPhoneUpdateNotifiCation((newPhoneNo!=null && !newPhoneNo.isBlank()) && !userAccount.getWelcomeFlag()
						&& !newPhoneNo.equalsIgnoreCase(RCUserUtil.getStringValue(oldPhoneNo)));
				response.setSendWelcomeInviteNotification((newEmailId !=null && !newEmailId.isBlank()) && userAccount.getWelcomeFlag()
						&& !newEmailId.equalsIgnoreCase(RCUserUtil.getStringValue(oldEmailId)));

				PatientHistory(userAccount, profileData);
				updateOrDeactCp(userAccount, profileData);
				Hospital hospital = hospitalService.getHospitalIdForAnyUserAccount(userAccount);
				List<UserAccount> userList = multiUserCheck(oldEmailId, oldPhoneNo, userAccount.getTeleCode(),
						newEmailId, newPhoneNo, profileData.getTeleCode());

				if (userList.size() > 1) {
					updateMultiUser(newEmailId, newPhoneNo, profileData, userAccount, userList);
				} else {
					String userName = newEmailId.isBlank() ? GenerateOTP.getAlphaNumericForUserName() : newEmailId;
					userAccount = getUserData(profileData, userAccount, userId, hospital, userName);
					userAccountRepo.save(userAccount);
				}

				if (!userGroupId.equals(UserGroupCons.CARE_PARTNER) && !userGroupId.equals(UserGroupCons.PATIENT)) {
					ssoUpdate(profileData, userAccount);
				}

				if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(userAccount))) {
					// contactPreValidation(userAccount);
				}
				sendNotificationAndLogTransactionForBothCPAndPatient(userAccount, profileData.getPatientSWFId(),
						hospital.getHospitalId(), response);
			}

			response.setUpdateStatus(CommonConstant.True);

		} catch (Exception e) {
			LOGGER.info(" Update Failure ");
			response.setUpdateStatus(CommonConstant.FALSE);
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * M09
	 */
	private UserAccount getUserData(ProfileData profileData, UserAccount userAccount, Long userId, Hospital hospital,
			String userName) {
		String notificationFreq = RCUserUtil.getStringValue(profileData.getNotificationFrequency());
		if (profileData.getUploadImage() != null && !profileData.getUploadImage().isEmpty()) {
			userAccount
					.setImagePath(UploadImageUtil.uploadUserImage(userAccount, hospital, profileData.getUploadImage()));
		} else if (userAccount.getImagePath() == null) {
			userAccount.setImagePath(genderShow(userAccount.getGender()));
		}
		userAccount.setFirstName(profileData.getFirstName());
		userAccount.setLastName(profileData.getLastName());
		userAccount.setUserName(userName);
		userAccount.setEmail(RCUserUtil.getUserContactDetail(profileData.getEmail()));
		userAccount.setPhone(RCUserUtil.getUserContactDetail(profileData.getPhone()));
		userAccount.setDob(profileData.getDob());
		userAccount.setTeleCode(RCUserUtil.stringContains(profileData.getPhone())
				? RCUserUtil.getUserContactDetail(profileData.getTeleCode())
				: null);
		userAccount.setTeleCountryCode(RCUserUtil.stringContains(profileData.getPhone())
				? RCUserUtil.getUserContactDetail(profileData.getTeleCountryCode())
				: null);
		userAccount.setComType(RCUserUtil.getComType(profileData.getEmail(), profileData.getPhone()));
		userAccount.setNotificationFrequency(
				(notificationFreq == null || notificationFreq.isBlank()) ? userAccount.getNotificationFrequency() : notificationFreq);
		userAccount.setUserTitle(
				(profileData.getUserTitle() == null || profileData.getUserTitle().isBlank()) ? userAccount.getUserTitle() : profileData.getUserTitle());
		String willSendOnBoardWelcomeLink = willSendOnBoardWelcomeLink(userId, profileData.getEmail(),
				profileData.getPhone());
		userAccount = setUserAccComType(userAccount, profileData.getEmail(), profileData.getPhone(),
				userAccount.getComType());
		userAccount = UserValidationUtil.getUserAccOnboardLinkon(userAccount, willSendOnBoardWelcomeLink);
		userAccount.setRealTimeAlert(profileData.getRealTimeAlert());
		userAccount.setRealTimeMessage(profileData.getRealTimeMessage());
		userAccount.setPushNotification(profileData.getPushNotification());
		profileData = getOtherPhone(profileData);
		userAccount.setOtherPhone(profileData.getOtherPhone());
		userAccount.setOtherTeleCode(profileData.getTeleCodeOther());
		userAccount.setOtherTeleCountryCode(profileData.getTeleCountryCodeOther());
		userAccount = getPhoneType(profileData.getOtherPhone(), profileData.getOtherPhoneType(), userAccount);

		patientUpdate(userAccount);
		surgeonUpdate(userAccount);

		return userAccount;
	}

	/**
	 * M10
	 */
	private ResponseMessage sendNotificationAndLogTransactionForBothCPAndPatient(UserAccount userAccount,
			Long patientSWFId, Long hospitalId, ResponseMessage response) {
		Long patientId = 0l;
		List<NotifyReqData> notifyDatas = new ArrayList<>();

		if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.CARE_PARTNER)) {
			patientId = patientSWFRepo.findById(patientSWFId).orElse(null).getPatient().getPatientId();
		}
		if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)) {
			patientId = userAccount.getUserAccountKey();
		}
		NotifyReqData notifyData = new NotifyReqData();
		notifyData.setToUser(userAccount.getUserAccountId());
		notifyData.setHspId(hospitalId);
		notifyData.setPatientId(patientId);
		notifyDatas.add(notifyData);

		if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)) {
			PatientStageWorkflow patientSwf = patientSWFRepo.findPatientSWFIdByPatient_PatientId(patientId).stream()
					.findFirst().orElse(null);

			UserValidationUtil.deviceLoginAudit(patientSwf.getPatient().getPatientId(), patientSwf.getPatientSWFId(),
					"MYPROFILE", "Edit", STR_PATIET_PROFILE);
		} else if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.CARE_PARTNER)) {
			CarePartnerMap careMapList = careRepo
					.findByActiveIsTrueAndUserAccount_userAccountIdAndUserAccount_UserGroup_UserGroupId(
							userAccount.getUserAccountId(), userAccount.getUserGroup().getUserGroupId())
					.stream().findFirst().orElse(null);
			PatientStageWorkflow patientSwf = patientSWFRepo
					.findPatientSWFIdByPatient_PatientId(careMapList.getPatientId()).stream().findFirst().orElse(null);

			UserValidationUtil.deviceLoginAudit(patientSwf.getPatient().getPatientId(), patientSwf.getPatientSWFId(),
					"MYPROFILE", "Edit", STR_CAREPARTNER_PROFILE);
		}
		response.setNotifyData(notifyDatas);
		return response;
	}

	/**
	 * M11
	 */
	private void PatientHistory(UserAccount userAccount, ProfileData profileData) {
		if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)
				&& RCUserUtil.getUserContactDetail(profileData.getEmail()) == null
				&& RCUserUtil.getUserContactDetail(profileData.getPhone()) == null) {
			PatientOldDetail patOldDetail = new PatientOldDetail();
			patOldDetail.setEmail(RCUserUtil.getUserContactDetail(userAccount.getEmail()));
			patOldDetail.setPhoneWithTelecode(
					userAccount.getPhone() != null ? userAccount.getTeleCode() + userAccount.getPhone() : null);
			patOldDetail.setPatientUaId(userAccount.getUserAccountId());
			patOldDetail.setRemovedDate(new Date());
			patientOldDetailRepo.save(patOldDetail);
		}
	}

	/**
	 * M12
	 */
	private void ssoUpdate(ProfileData profileData, UserAccount userAccount) {
		SsoSyncData ssoData = new SsoSyncData();
		ssoData.setFirstName(profileData.getFirstName());
		ssoData.setLastName(profileData.getLastName());
		ssoData.setTitle(profileData.getUserTitle());
		ssoData.setUserName(RCUserUtil.rcEncrypt(profileData.getEmail()));
		ssoData.setTeleCode(profileData.getTeleCode());
		ssoData.setPhNum(profileData.getPhone());

		String ssoEnabled = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_ENABLED_STATUS);
		if (ssoEnabled.equalsIgnoreCase("Yes")) {
			otherPortalUpdate(userAccount, ssoData);
		}
	}

	/**
	 * M13
	 * 
	 * Onboard and hro other portal update
	 */
	private void otherPortalUpdate(UserAccount userAccount, SsoSyncData ssoData) {
		try {
			updateOnboardUserTitle(ssoData);
			updateProfileDataInHro(userAccount, ssoData);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M14
	 */
	private void updateOnboardUserTitle(SsoSyncData ssoData) {
		try {
			String obUrl = getSSOAPIURL(CasCommonConstant.ONBOARD);
			ssoUtil.updateProfileDetailsSSO(ssoData, obUrl);
		} catch (Exception e) {
			LOGGER.error("API Call for Onboard", e);
		}
	}

	/**
	 * M15
	 */
	private void updateProfileDataInHro(UserAccount userAccount, SsoSyncData ssoData) {
		if (Boolean.TRUE.equals(UserGroupCons.addUserCheck.contains(userAccount.getUserGroup().getUserGroupId()))) {
			try {
				String hroUrl = getSSOAPIURL(CasCommonConstant.HRO_LBL);
				ssoUtil.updateProfileDetailsSSO(ssoData, hroUrl);
			} catch (Exception e) {
				LOGGER.error("API Call for HRO", e);
			}
		}
	}

	/**
	 * M16
	 * 
	 * Update or Deactivate CarePartner
	 */
	private void updateOrDeactCp(UserAccount userAccount, ProfileData profileData) {
		if (RCUserUtil.getStringValue(profileData.getEmail()).isBlank()
				&& RCUserUtil.getStringValue(profileData.getPhone()).isBlank()
				&& userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.CARE_PARTNER)) {
			List<CarePartnerMap> carePartnerPatList = careRepo
					.findByActiveTrueAndUserAccount_UserAccountId(userAccount.getUserAccountId());
			carePartnerPatList.stream().forEach(cpMap -> {
				if (cpMap != null) {
					cpMap.setActive(false);
					careRepo.save(cpMap);
				}
			});
		}
	}

	/**
	 * M17
	 */
	private ProfileData getOtherPhone(ProfileData profileData) {
		if (profileData.getOtherPhone() == null || profileData.getOtherPhone().isEmpty()) {
			profileData.setOtherPhone(null);
			profileData.setTeleCodeOther(null);
			profileData.setTeleCountryCodeOther(null);
			profileData.setOtherPhoneType(null);
		}
		return profileData;
	}

	/**
	 * M18
	 * 
	 * Set Communication Type Based on Email And Phone
	 */
	private UserAccount setUserAccComType(UserAccount userAccount, String email, String phone, String comType) {
		if ((email !=null && !email.isBlank()) && !email.contains(CommonConstant.MYRECOVERYCOACH_MAIL) &&  (phone !=null && !phone.isBlank())) {
			return setComTypeforRCEmail(userAccount, comType);
		} else if ((email !=null && !email.isBlank()) && !email.contains(CommonConstant.MYRECOVERYCOACH_MAIL) && (phone==null || phone.isBlank())) {
			return setComTypeforRCEmail(userAccount, comType);
		} else if ((email !=null && !email.isBlank()) && email.contains(CommonConstant.MYRECOVERYCOACH_MAIL) && (phone !=null && !phone.isBlank())) {
			return setComTypeforRCEmail(userAccount, comType);
		} else if ((email !=null && !email.isBlank()) && email.contains(CommonConstant.MYRECOVERYCOACH_MAIL) && (phone==null || phone.isBlank())) {
			userAccount.setComType(CommonConstant.EMAIL);
		} else if ((email ==null || email.isBlank()) &&  phone!=null && !phone.isBlank()) {
			return setComTypeforRCEmail(userAccount, comType);
		} else {
			userAccount.setComType("NONE");
		}
		return userAccount;
	}

	/**
	 * M19
	 */
	private UserAccount setComTypeforRCEmail(UserAccount userAccount, String comType) {
		if (comType.equalsIgnoreCase(CommonConstant.EMAIL)) {
			userAccount.setComType(CommonConstant.EMAIL);
		} else if (comType.equalsIgnoreCase("SMS") || comType.equalsIgnoreCase("TEXT")) {
			userAccount.setComType("SMS");
		} else if (comType.equalsIgnoreCase("BOTH")) {
			userAccount.setComType("BOTH");
		} else {
			userAccount.setComType("NONE");
		}
		return userAccount;
	}

	/**
	 * M20
	 */
	private UserAccount getPhoneType(String otherPhone, String otherPhoneType, UserAccount userAccount) {
		if (otherPhone != null && otherPhoneType != null && !otherPhone.isEmpty() && !otherPhoneType.isEmpty()) {
			PhoneType phoneType = phoneTypeRepo.findById(Long.valueOf(otherPhoneType)).orElse(null);
			userAccount.setOtherPhoneType(phoneType);
		}
		return userAccount;
	}

	/**
	 * M21
	 * 
	 * willSendOnBoardWelcomeLink based on Condition
	 */
	@Override
	public String willSendOnBoardWelcomeLink(Long userAccountId, String newEmail, String newPhone) {
		UserAccount userAccount = null;
		try {
			userAccount = userAccountRepo.findById(userAccountId).orElse(null);
			if (userAccount != null && userAccount.getIsOnBoardLinkSent() && userAccount.getWelcomeFlag()) {
				return "Y";
			} else if (userAccount != null && userAccount.getIsOnBoardLinkSent() && !userAccount.getWelcomeFlag()) {
				return "P";
			} else {
				return checkOnBoardWelcomeLink(newEmail, newPhone);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);

			return e.getMessage();
		}
	}

	/**
	 * M22
	 */
	public String checkOnBoardWelcomeLink(String newEmail, String newPhone) {
		String returnValue;
		if (newEmail != null && newPhone != null && !newEmail.isEmpty() && !newPhone.isEmpty()) {
			returnValue = "Y";
		} else if (newEmail != null && !newEmail.isEmpty() && (newPhone == null || newPhone.isEmpty())) {
			if (!newEmail.contains(CommonConstant.MYRECOVERYCOACH_MAIL) && (newPhone == null || newPhone.isEmpty())) {
				returnValue = "Y";
			} else {
				returnValue = "N";
			}
		} else if ((newEmail == null || newEmail.isEmpty()) && newPhone != null && !newPhone.isEmpty()) {
			returnValue = "Y";
		} else {
			returnValue = "N";
		}
		return returnValue;
	}

	/**
	 * M23
	 * 
	 * Update UserProfile Account CC/Patient
	 */
	@Override
	public void updateUserProfileAccount(UserAccount userAccount, String oldEmailid, String oldPhone, boolean flag,
			String defaultUserName) {
		try {
			mergeAccountDetails(userAccount, oldEmailid, oldPhone);
			if (!RCUserUtil.getStringValue(userAccount.getEmail()).isEmpty()) {
				userAccount.setUserName(userAccount.getEmail());
			}
			userAccountRepo.save(userAccount);
			patientUpdate(userAccount);
			if (flag) {
				List<UserAccount> emailOrPhoneBasedUaList = fetchUserAccountListByEmailOrPhone(oldEmailid, oldPhone,
						userAccount);
				for (UserAccount iterateUserAcct : emailOrPhoneBasedUaList) {
					if (userAccount.getEmail() != null || userAccount.getPhone() != null) {
						executeOverallDraftsForUserProfileAccount(iterateUserAcct, userAccount, oldEmailid,
								defaultUserName);
						iterateUserAcct.setFirstName(userAccount.getFirstName());
						iterateUserAcct.setLastName(userAccount.getLastName());
						iterateUserAcct.setComType(userAccount.getComType());
						iterateUserAcct.setImagePath(userAccount.getImagePath());
						if (!RCUserUtil.getStringValue(userAccount.getEmail()).isEmpty()) {
							iterateUserAcct
									.setUserName(userAccount.getEmail() + "$$" + iterateUserAcct.getUserAccountId());
						}
						if (!userAccount.getWelcomeFlag()) {
							iterateUserAcct.setActivationDate(userAccount.getActivationDate());
							iterateUserAcct.setWelcomeFlag(userAccount.getWelcomeFlag());
							iterateUserAcct.setWrongPwdAttempt(userAccount.getWrongPwdAttempt());
							iterateUserAcct.setUserPwdCreatedOn(userAccount.getUserPwdCreatedOn());
						}
						iterateUserAcct.setUserPwd(userAccount.getUserPwd());
						userAccountRepo.save(iterateUserAcct);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M25
	 */
	private void patientUpdate(UserAccount userAccount) {
		if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)) {
			Patient patient = patientRepo.findById(userAccount.getUserAccountKey()).orElse(null);
			patient.setFirstName(userAccount.getFirstName());
			patient.setLastName(userAccount.getLastName());
			patient.setEmail(userAccount.getEmail());
			patient.setPhone(userAccount.getPhone());
			patient.setTeleCode(userAccount.getTeleCode());
			patient.setTeleCountryCode(userAccount.getTeleCountryCode());
			patient.setComType(userAccount.getComType());
			patient.setImagePath(userAccount.getImagePath());
			if (userAccount.getDob() != null) {
				patient.setDob(userAccount.getDob());
			}
			patientRepo.save(patient);
		}
	}

	/**
	 * M26
	 */
	private void surgeonUpdate(UserAccount userAccount) {
		if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.SURGEON)) {
			Surgeon surgeon = surgeonRepo.findById(userAccount.getUserAccountKey()).orElse(null);
			surgeon.setFirstName(userAccount.getFirstName());
			surgeon.setLastName(userAccount.getLastName());
			surgeon.setEmail(userAccount.getEmail());
			surgeon.setImagePath(userAccount.getImagePath());
			surgeon.setTitle(userAccount.getTitle());
			surgeonRepo.save(surgeon);
		}
	}

	/**
	 * M27
	 * 
	 * Merge UserAccount of Similar Email And Phone
	 */
	private void mergeAccountDetails(UserAccount userAccount, String oldEmailid, String oldPhone) {
		String fromEmail = RCUserUtil.getStringValue(userAccount.getEmail());
		String toEmail = RCUserUtil.getStringValue(oldEmailid);
		String fromPhone = RCUserUtil.getPhoneWithCode(userAccount);
		String toPhone = RCUserUtil.getStringValue(oldPhone);
		if (!fromEmail.equalsIgnoreCase(toEmail) || !fromPhone.equalsIgnoreCase(toPhone)) {
			List<UserAccount> UserAcctList = fetchUserAccountListByEmailOrPhone(userAccount.getEmail(),
					userAccount.getTeleCode() + "-" + userAccount.getPhone(), userAccount);
			if (!RCUserUtil.isNullOrEmptyList(UserAcctList)) {
				if (!UserAcctList.get(0).getWelcomeFlag()) {
					UserAccount tempUserAct = UserAcctList.get(0);
					userAccount.setActivationDate(tempUserAct.getActivationDate());
					userAccount.setWelcomeFlag(tempUserAct.getWelcomeFlag());
					userAccount.setUserPwd(tempUserAct.getUserPwd());
					userAccount.setWrongPwdAttempt(tempUserAct.getWrongPwdAttempt());
					userAccount.setUserPwdCreatedOn(tempUserAct.getUserPwdCreatedOn());
				}
				updateUserName(UserAcctList);
			}
		}
	}

	/**
	 * M28
	 */
	private void updateUserName(List<UserAccount> destUaList) {
		destUaList.stream().filter(a -> !RCUserUtil.getStringValue(a.getEmail()).isEmpty()).forEach(b -> {
			b.setUserName(b.getEmail() + "$$" + b.getUserAccountId());
			userAccountRepo.save(b);
		});
	}

	/**
	 * M29
	 * 
	 * Get UserAccount List of Similar Email and Phone Except Login User
	 */
	private List<UserAccount> fetchUserAccountListByEmailOrPhone(String oldEmailid, String oldPhone,
			UserAccount userAccount) {
		List<UserAccount> emailOrPhoneBasedUaList = new ArrayList<>();
		try {
			if ((oldEmailid == null || oldEmailid.isEmpty()) && (oldPhone != null && !oldPhone.isEmpty())) {
				emailOrPhoneBasedUaList = userAccountRepo.findByphoneWithTeleCodeAndUserAccountId(oldPhone,
						userAccount.getUserAccountId());
			} else if (oldEmailid != null && !oldEmailid.isEmpty()) {
				emailOrPhoneBasedUaList = userAccountRepo.findByEmailAndUserAccountIdNot(oldEmailid,
						userAccount.getUserAccountId());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return emailOrPhoneBasedUaList;
	}

	/**
	 * M30
	 */
	private void executeOverallDraftsForUserProfileAccount(UserAccount iterateUserAcct, UserAccount userAccount,
			String oldEmailid, String defaultUserName) {
		try {
			draftUserAccountForPhoneAndOtherPhone(iterateUserAcct, userAccount);
			if (iterateUserAcct.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)) {
				Long userAccountKey = userAccount.getUserAccountKey();
				userAccount.setUserAccountKey(iterateUserAcct.getUserAccountKey());
				patientUpdate(userAccount);
				userAccount.setUserAccountKey(userAccountKey);
				draftIterateUserAcctForPatient(iterateUserAcct, userAccount, oldEmailid, defaultUserName);
			} else {
				draftUserAccountOtherThanPatient(iterateUserAcct, userAccount, oldEmailid);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M31
	 */
	private void draftUserAccountForPhoneAndOtherPhone(UserAccount iterateUserAcct, UserAccount userAccount) {
		try {
			iterateUserAcct.setPhone(RCUserUtil.getUserContactDetail(userAccount.getPhone()));
			iterateUserAcct.setTeleCode(RCUserUtil.getString(userAccount.getTeleCode()));
			iterateUserAcct.setTeleCountryCode(RCUserUtil.getString(userAccount.getTeleCountryCode()));
			iterateUserAcct.setOtherPhone(RCUserUtil.getString(userAccount.getOtherPhone()));
			iterateUserAcct.setOtherTeleCode(RCUserUtil.getString(userAccount.getOtherTeleCode()));
			iterateUserAcct.setOtherTeleCountryCode(RCUserUtil.getString(userAccount.getOtherTeleCountryCode()));
			iterateUserAcct.setOtherPhoneType(userAccount.getOtherPhoneType());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M32
	 */
	private void draftIterateUserAcctForPatient(UserAccount iterateUserAcct, UserAccount userAccount, String oldEmailid,
			String defaultUserName) {
		try {
			if (userAccount.getDob() != null) {
				iterateUserAcct.setDob(userAccount.getDob());
			}
			iterateUserAcct.setEmail(userAccount.getEmail());
			if (userAccount.getEmail() != null && !userAccount.getEmail().equalsIgnoreCase(oldEmailid)) {
				boolean existFlag = false;
				String emailExistsAfter;
				if (userAccount.getEmail() != null) {
					emailExistsAfter = userAccountRepo.findByEmail(userAccount.getEmail()).isEmpty() ? "false" : "true";
					if (emailExistsAfter.equalsIgnoreCase("true")) {
						existFlag = true;
					}
				}
				draftIterateUserAcctForPatientUserName(iterateUserAcct, userAccount, oldEmailid, defaultUserName,
						existFlag);
			} else if (userAccount.getEmail() == null || userAccount.getEmail().isEmpty()) {
				iterateUserAcct.setUserName(defaultUserName);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M33
	 */
	private void draftUserAccountOtherThanPatient(UserAccount iterateUserAcct, UserAccount userAccount,
			String oldEmailid) {
		try {
			iterateUserAcct.setFirstName(userAccount.getFirstName());
			iterateUserAcct.setLastName(userAccount.getLastName());
			if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.CARE_PARTNER)
					&& userAccount.getDob() == null) {
				userAccount.setDob(userAccount.getDob());
				userAccountRepo.save(userAccount);
			}
			iterateUserAcct.setEmail(userAccount.getEmail());
			if (userAccount.getEmail() != null && !userAccount.getEmail().equalsIgnoreCase(oldEmailid)) {
				if (iterateUserAcct.getUserName().contains("@")) {
					iterateUserAcct
							.setUserName(iterateUserAcct.getUserName().replace(oldEmailid, userAccount.getEmail()));
				} else {
					iterateUserAcct.setUserName(userAccount.getEmail());
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M34
	 */
	private void draftIterateUserAcctForPatientUserName(UserAccount iterateUserAcct, UserAccount userAccount,
			String oldEmailid, String defaultUserName, boolean existFlag) {
		try {
			if (existFlag) {
				String updateString = iterateUserAcct.getEmail() + "$$" + iterateUserAcct.getUserAccountId();
				iterateUserAcct.setUserName(updateString);
			} else if (userAccount.getEmail() == null || userAccount.getEmail().isEmpty()) {
				iterateUserAcct.setUserName(defaultUserName);
			} else if (iterateUserAcct.getUserName().contains("@")) {
				iterateUserAcct.setUserName(iterateUserAcct.getUserName().replace(oldEmailid, userAccount.getEmail()));
			} else {
				iterateUserAcct.setUserName(userAccount.getEmail());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M35
	 * 
	 * Create CC/Surgeon Account in Admin
	 */
	@Override
	public ResponseMessage saveUser(SaveUserData userDetails, Long loginUserId) {
		ResponseMessage response = new ResponseMessage();
		String saveStatus = "true";
		String firstName = RCUserUtil.changeFirstLetterCaps(userDetails.getFirstName());
		String lastName = RCUserUtil.changeFirstLetterCaps(userDetails.getLastName());
		String userGroupName = userDetails.getUserGroupName();
		Date dob = userDetails.getDob();
		String gender = userDetails.getGender();
		String address = userDetails.getAddress();
		String city = userDetails.getCity();
		String state = userDetails.getState();
		String zip = userDetails.getZip();
		String email = userDetails.getEmail();
		String phone = RCUserUtil.getNonEmptyString(userDetails.getPhone());
		Long hospitalId = userDetails.getHospitalId();
		try {
			String defaultpwd = GenerateOTP.getAlphaNumericRandomPwd();
			Hospital hospital = hspRepo.findById(hospitalId).orElse(null);
			UserAccount checkUserAccount = userAccountRepo.findByUserName(email).stream().findFirst().orElse(null);
			if (checkUserAccount != null) {
				response.setUpdateStatus("false");
				response.setMessage("User already Exists");
				return response;
			}
			UserGroup selectedUserGroup = userGroupRepo.findByGroupName(userGroupName);
			UserAccount useraccount = new UserAccount();
			useraccount.setFirstName(firstName);
			useraccount.setLastName(lastName);
			useraccount.setUserName(email);
			useraccount.setEmail(email);
			useraccount.setDob(dob);
			useraccount.setDescription(selectedUserGroup.getGroupName());
			UserGroup userGrp = new UserGroup();
			userGrp.setUserGroupId(selectedUserGroup.getUserGroupId());
			useraccount.setUserGroup(userGrp);
			useraccount.setCreatedBy(loginUserId);
			useraccount.setCreatedDate(new Date());
			phone = setUserCountryAndTeleCode(useraccount, phone);
			useraccount.setPhone(phone);
			useraccount.setTitle(selectedUserGroup.getGroupName());
			useraccount.setGender(gender);
			useraccount.setActive(true);
			useraccount.setComType(
					phone != null && !phone.isEmpty() ? RCUserUtil.getComType(email, phone) : CommonConstant.EMAIL);
			useraccount.setAddress1(address);
			useraccount.setUserAccountKey(hospitalId);
			useraccount.setCity(city);
			useraccount.setState(state);
			useraccount.setZipcode(zip);
			useraccount.setDeIdFlag(true);
			useraccount.setUserPwd(new StringEncrypter("DES").encrypt(defaultpwd));
			useraccount.setUserPwdCreatedOn(new Date());
			useraccount.setIsOnBoardLinkSent(true);
			useraccount.setWelcomeFlag(getUserWelcomeFlag(useraccount, userDetails));
			useraccount.setUserActivationStatus(CommonConstant.NOT_YET_STARTED);
			useraccount.setWrongPwdAttempt(0);
			useraccount.setNotificationFrequency("None");
			useraccount.setIsdelete(false);
			String defaultImgPath = genderShow(gender);
			useraccount.setImagePath(defaultImgPath);
			List<ImageData> imageData = userDetails.getUploadImage();

			userAccountRepo.save(useraccount);
			if (imageData != null && imageData.get(0).getValue() != null) {
				String imagePath = UploadImageUtil.uploadUserImage(useraccount, hospital, imageData);
				useraccount.setImagePath(imagePath);
				LOGGER.info(imagePath);
			}
			userAccountRepo.save(useraccount);
			saveUserForUpdatingUserAccountForSurgeon(checkUserAccount, selectedUserGroup, useraccount, loginUserId,
					firstName, lastName, email);
			userAccountRepo.save(useraccount);
			LOGGER.info("USERACCOUNTID.." + useraccount.getUserAccountId());
			Long casUserId = null;
			if (Boolean.TRUE.equals(RCUserUtil.isPhoneNotNull(useraccount))) {
				contactPreValidation(useraccount);
			}
			Boolean casUserExist = false;
			Boolean obUserExists = false;
			String ssoEnabled = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_ENABLED_STATUS);
			if (ssoEnabled.equalsIgnoreCase("Yes")) {
				String hroUrl = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_HRO_SYNCURL);
				casUserExist = ssoUtil.checkUserExists(useraccount.getEmail(), hroUrl).getStatus();

				String onboardUrl = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_RCOB_SYNCURL);
				obUserExists = ssoUtil.checkUserExists(useraccount.getEmail(), onboardUrl).getStatus();

				if (Boolean.FALSE.equals(casUserExist) && Boolean.TRUE
						.equals(UserGroupCons.addUserCheck.contains(useraccount.getUserGroup().getUserGroupId())
								&& Boolean.FALSE.equals(obUserExists))) {
					LOGGER.debug(" casUserExist  -->{}", casUserExist);
					SsoSyncData obj = new SsoSyncData();
					obj.setUserName(new StringEncrypter("DES").encrypt(useraccount.getEmail()));
					obj.setFirstName(firstName);
					obj.setLastName(lastName);
					obj.setPhNum(phone);
					String ssoSecKey = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSOSECKEY);
					LOGGER.debug(" ssoSecKey ->> {}", ssoSecKey);
					obj.setSecretKey(ssoSecKey);
					obj.setUserPwd("");
					obj.setRcAccountId(useraccount.getUserAccountId());
					obj.setRcAccType(selectedUserGroup.getGroupName());
					obj.setRcHspId(useraccount.getUserAccountKey() + "");
					obj.setRcHspName(hospital.getName());
					obj.setWelcomeFlag(true);
					ssoUtil.createUser(obj, hroUrl);
				}
			}
			String randId = UUID.randomUUID().toString();
			UserSecTransAudit userSecTransAudit = new UserSecTransAudit();
			userSecTransAudit.setUserAccount(useraccount);
			userSecTransAudit.setIsActive(true);
			userSecTransAudit.setCreatedOn(new Date());
			userSecTransAudit.setRandomId(randId);
			userSecTransAudit.setMode("AddUser");

			UserPwdAudit userPwd = new UserPwdAudit();
			userPwd.setCreatedBy(loginUserId);
			userPwd.setCreatedDate(new Date());
			userPwd.setUserAccountId(useraccount);
			userPwd.setUserPwd(new StringEncrypter("DES").encrypt(defaultpwd));

			boolean userGroupCond = UserGroupCons.addUserCheck.contains(useraccount.getUserGroup().getUserGroupId());
			if (userGroupCond && useraccount.getEmail() != null) {
				LOGGER.info("18");
				udpateExistingCasInfoWithEmail(useraccount, casUserExist, userPwd, obUserExists, hospital);
				userPwdRepo.save(userPwd);
				sendStaffWelcomeInvite(useraccount, hospital, casUserId, randId, userSecTransAudit);
			}
		} catch (Exception e) {
			saveStatus = CommonConstant.FALSE;
			LOGGER.error(e.getMessage());
		}
		response.setUpdateStatus(saveStatus);
		response.setMessage(userGroupName + " Added Successfully");
		return response;
	}

	/**
	 * M36
	 * 
	 * Send Notification for CC/Surgeon for Welcome Invite
	 */
	private void sendStaffWelcomeInvite(UserAccount useraccount, Hospital hsp, Long casUserId, String randId,
			UserSecTransAudit userSecTransAudit) {
		String notifyType = NotificationConstant.WELCOMEINVITE;
		NotificationData notifyObj = new NotificationData();
		notifyObj.setToUser(useraccount.getUserAccountId());
		notifyObj.setHspId(hsp.getHospitalId());
		notifyObj.setNotificationType(notifyType);
		notifyObj.setRandID(randId);
		notifyObj.setPath(CommonConstant.USER_VALIDATE);
		String serverUrl = rs.getString(CommonConstant.STR_SERVER_URL);
		notifyObj.setServerUrl(serverUrl + CommonConstant.USER_VALIDATE);
		UserAccount obUserAccount = userAccountRepo.findByUserName(useraccount.getEmail()).stream().findFirst()
				.orElse(null);
		Long obUserId = obUserAccount != null ? obUserAccount.getUserAccountId() : null;
		List<CasSecDetails> userSecDetails = null;
		String portalName = "";
		if (casUserId != null) {
			// userSecDetails = CasUtil.getCASSecQuesAns(casUserId);
			portalName = "Stryker dashboard";
		}
		if ((userSecDetails == null || userSecDetails.isEmpty()) && obUserId != null) {
			// userSecDetails = OnBoardUtil.getOBSecQuesAns(obUserId);
			useraccount.setRcOnBoardId(obUserId);
			useraccount.setAllowOnboard(true);
			portalName = "RecoveryCOACH onboarding";
		}
		if (userSecDetails != null && !userSecDetails.isEmpty()) {
			notifyObj.setNotificationType(NotificationConstant.STAFFWELCOMEEMAILALREADYACTIVATED);
			notifyObj.setPortalName(portalName);
		}
		if (portalName.isEmpty()) {
			// sadUserService.saveUserSecTransAudit(userSecTransAudit);
		}
		// notificationUtil.sendNotification(notifyObj);
		notifyType = NotificationConstant.SMSDISCLAIMER;
		notifyObj.setNotificationType(notifyType);
		// notificationUtil.sendNotification(notifyObj);
	}

	/**
	 * M37
	 * 
	 * Update UserAccount in other portal if Email Already Exists
	 */
	private void udpateExistingCasInfoWithEmail(UserAccount useraccount, Boolean casUserExist, UserPwdAudit userPwd,
			Boolean obUserExists, Hospital hsp)
			throws com.seind.rc.services.user.util.StringEncrypter.EncryptionException {
		if (useraccount.getEmail() != null) {
			SsoSyncData ssoSyncDataob = null;
			CasSecDetails userSecDetails = null;
			try {
				LOGGER.debug(" casUserExist --> {} obUserExists --> {}", casUserExist, obUserExists);
				if (Boolean.TRUE.equals(casUserExist)) {
					updateUserIfActivatedInCAS(useraccount, userPwd);
				}
				if (Boolean.TRUE.equals(obUserExists)) {
					ssoSyncDataob = new SSOSyncUtil().getUserInfo(useraccount.getEmail(),
							getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.ONBOARD));
					useraccount.setRcOnBoardId(ssoSyncDataob.getRcAccountId());
					useraccount.setAllowOnboard(true);
					userAccountRepo.save(useraccount);
				}
				if (Boolean.FALSE.equals(casUserExist) && Boolean.TRUE.equals(obUserExists)) {
					useraccount.setUserPwd(ssoSyncDataob.getUserPwd());
					useraccount.setUserPwdCreatedOn(ssoSyncDataob.getUserPwdCreatedOn());
					activationModeSet(useraccount, ssoSyncDataob);
					userAccountRepo.save(useraccount);
					userSecDetails = getUserSecDetailsFromOB(ssoSyncDataob, useraccount, userPwd);
					createAsNewUserinCASIfAvailableInOB(useraccount, hsp, ssoSyncDataob, userSecDetails);
				}
			} catch (IOException e) {
				LOGGER.error(CommonConstant.EXCEPTION, e);
			}
		}
	}

	/**
	 * M38
	 * 
	 * Update UserAccount ActivationMode Based on SSO Sync
	 */
	private void activationModeSet(UserAccount useraccount, SsoSyncData ssoSyncDataob) {
		if (!ssoSyncDataob.isWelcomeFlag()) {
			useraccount.setActivationDate(ssoSyncDataob.getActivatedDate());
			useraccount.setActivationMode("OB");
			useraccount.setUserActivationStatus(CommonConstant.COMPLETED);
			useraccount.setWelcomeFlag(false);
		}
	}

	/**
	 * M39
	 * 
	 * Create User in Other Portal Using SSO
	 */
	private void createAsNewUserinCASIfAvailableInOB(UserAccount useraccount, Hospital hsp, SsoSyncData ssoSyncDataob,
			CasSecDetails userSecDetails)
			throws EncryptionException, com.seind.rc.services.user.util.StringEncrypter.EncryptionException {
		SsoSyncData ssoSyncData = new SsoSyncData();
		String ssoSecKey = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSOSECKEY);
		ssoSyncData.setUserName(new StringEncrypter("DES").encrypt(useraccount.getEmail()));
		ssoSyncData.setFirstName(useraccount.getFirstName());
		ssoSyncData.setLastName(useraccount.getLastName());
		ssoSyncData.setPhNum(useraccount.getPhone());
		ssoSyncData.setTeleCode(useraccount.getTeleCode());
		ssoSyncData.setSecretKey(ssoSecKey);
		ssoSyncData.setUserPwd(useraccount.getUserPwd());
		ssoSyncData.setRcAccountId(useraccount.getUserAccountId());
		ssoSyncData.setRcAccType(useraccount.getDescription());
		ssoSyncData.setRcHspId(useraccount.getUserAccountKey() + "");
		ssoSyncData.setRcHspName(hsp.getName());
		if (userSecDetails != null) {
			ssoSyncData.setQuesId1(userSecDetails.getQuestion1());
			ssoSyncData.setQuesId2(userSecDetails.getQuestion2());
			ssoSyncData.setQuesId3(userSecDetails.getQuestion3());
			ssoSyncData.setAns1(userSecDetails.getAnswer1());
			ssoSyncData.setAns2(userSecDetails.getAnswer2());
			ssoSyncData.setAns3(userSecDetails.getAnswer3());
		}
		ssoSyncData.setActivatedDate(ssoSyncDataob.getActivatedDate());
		ssoSyncData.setUserPwdCreatedOn(ssoSyncDataob.getUserPwdCreatedOn());
		ssoSyncData.setWelcomeFlag(useraccount.getWelcomeFlag() == true);
		LOGGER.debug("CAS OBJ---> {}", ssoSyncData);
		new SSOSyncUtil().createUser(ssoSyncData,
				getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.HRO_LBL));
	}

	/**
	 * M40
	 */
	private void updateUserIfActivatedInCAS(UserAccount userAccount, UserPwdAudit userPwdAudit) throws IOException {
		SsoSyncData ssoSyncDatahro = null;
		ssoSyncDatahro = ssoUtil.getUserInfo(userAccount.getEmail(),
				getSettingsValue(CasCommonConstant.SSOSYNC, CommonConstant.HRO_LBL));
		SSOServiceImpl ssoService = new SSOServiceImpl();
		if (ssoSyncDatahro.getActivatedDate() != null) {
			userAccount.setUserPwdCreatedOn(ssoSyncDatahro.getActivatedDate());
			userAccount.setWelcomeFlag(false);
			userAccount.setUserPwd(ssoSyncDatahro.getUserPwd());
			userAccount.setActivationMode("HR");
			userAccount.setActivationDate(ssoSyncDatahro.getActivatedDate());
			userAccount.setUserActivationStatus(CommonConstant.COMPLETED);
			userAccountRepo.save(userAccount);
			ssoService.disableAuditActive(userAccount, "AddUser");
			insertIntoUserSecResult(userAccount, ssoSyncDatahro);
			userPwdAudit.setUserPwd(ssoSyncDatahro.getUserPwd());

			PasswordHistory ph = new PasswordHistory();
			ph.setUserAccount(userAccount);
			ph.setUserPwd(userAccount.getUserPwd());
			ph.setCreatedDate(new Date());
			userSecTransService.savePasswordHistory(ph);
		}
	}

	/**
	 * M41
	 */
	private CasSecDetails getUserSecDetailsFromOB(SsoSyncData ssoSyncDataob, UserAccount useraccount,
			UserPwdAudit userPwd) {
		CasSecDetails userSecDetails = null;
		SSOServiceImpl ssoService = new SSOServiceImpl();
		if (!ssoSyncDataob.isWelcomeFlag()) {
			userSecDetails = SSOSyncUtil.getCASSecQuesAns(ssoSyncDataob);
			updatePasswordInOnboardForFailureAttempt(useraccount, userSecDetails);
			useraccount.setUserPwdCreatedOn(ssoSyncDataob.getUserPwdCreatedOn());
			userAccountRepo.save(useraccount);
			ssoService.disableAuditActive(useraccount, "AddUser");
			insertIntoUserSecResult(useraccount, ssoSyncDataob);
			userPwd.setUserPwd(ssoSyncDataob.getUserPwd());
			PasswordHistory ph = new PasswordHistory();
			ph.setUserAccount(useraccount);
			ph.setUserPwd(useraccount.getUserPwd());
			ph.setCreatedDate(new Date());
			userSecTransService.savePasswordHistory(ph);
		}
		return userSecDetails;
	}

	/**
	 * M42
	 */
	private void updatePasswordInOnboardForFailureAttempt(UserAccount userAccount, CasSecDetails userSecDetails) {
		OnBoardUtil obUtil = new OnBoardUtil();
		try {
			obUtil.insertOrUpdateSecQues(userAccount, userSecDetails.getQuestion1(), userSecDetails.getQuestion2(),
					userSecDetails.getQuestion3(), userSecDetails.getAnswer1(), userSecDetails.getAnswer2(),
					userSecDetails.getAnswer3());
			obUtil.updatePasswordInOnboardForFailureAttempt(userAccount.getUserName(), userAccount.getUserPwd());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M43
	 * 
	 * Insert UserSecurityQuestion Result For SSO Sync
	 */
	private void insertIntoUserSecResult(UserAccount useraccount, SsoSyncData ssoSyncData) {
		UserAccount check = userAccountRepo.findById(useraccount.getUserAccountId()).orElse(null);
		String email = check.getEmail();
		String phone = check.getPhone();
		List<Long> userAccountIds = new ArrayList<>();
		if (RCUserUtil.stringContains(email)) {
			userAccountIds = userAccountRepo.findByEmail(email).stream().map(UserAccount::getUserAccountId).toList();
		}
		if (RCUserUtil.stringContains(phone)) {
			userAccountIds = userAccountRepo.findByPhone(phone).stream().map(UserAccount::getUserAccountId).toList();
		}
		userAccountIds.add(useraccount.getUserAccountId());
		List<UserSecResultDetails> usersecResultDetalilsList = userSecResDetRepo.findByUserAccountIdIn(userAccountIds);
		UserSecResultDetails usersecResultDetalils = usersecResultDetalilsList.isEmpty() ? null
				: usersecResultDetalilsList.get(0);
		if (usersecResultDetalils == null) {
			usersecResultDetalils = new UserSecResultDetails();
		}
		usersecResultDetalils.setUserAccountId(useraccount.getUserAccountId());
		usersecResultDetalils.setQuestion1(ssoSyncData.getQuesId1());
		usersecResultDetalils.setQuestion2(ssoSyncData.getQuesId2());
		usersecResultDetalils.setQuestion3(ssoSyncData.getQuesId3());
		usersecResultDetalils.setAnswer1(ssoSyncData.getAns1());
		usersecResultDetalils.setAnswer2(ssoSyncData.getAns2());
		usersecResultDetalils.setAnswer3(ssoSyncData.getAns3());
		usersecResultDetalils.setCreatedOn(new Date());
		usersecResultDetalils.setIrrelevantAns("No");
		usersecResultDetalils.setWrongAnswerAttempts(ssoSyncData.getCount());
		usersecResultDetalils.setMode("Web");
		userSecResDetRepo.save(usersecResultDetalils);
	}

	/**
	 * M44
	 * 
	 * Save Surgeon Data in Surgeon/HospitalSurgeon
	 */
	private void saveUserForUpdatingUserAccountForSurgeon(UserAccount checkUserAccount, UserGroup selectedUserGroup,
			UserAccount useraccount, Long loginUserId, String firstName, String lastName, String email) {
		try {
			if (checkUserAccount == null && selectedUserGroup.getGroupName().equalsIgnoreCase("surgeon")) {
				Surgeon surgeon = new Surgeon();
				surgeon.setFirstName(firstName);
				surgeon.setLastName(lastName);
				surgeon.setEmail(email.trim());
				surgeon.setLogo(useraccount.getImagePath());
				surgeon.setActive(true);
				UserAccount acc = new UserAccount();
				acc.setUserAccountId(loginUserId);
				surgeon.setCreatedBy(acc);
				surgeon.setCreatedDate(new Date());
				surgeon.setSalutation("Dr. ");
				surgeonRepo.save(surgeon);
				HospitalSurgeon hspSurgeon = new HospitalSurgeon();
				hspSurgeon.setHospitalId(useraccount.getUserAccountKey());
				hspSurgeon.setSurgeon(surgeon);
				hspSurgeon.setCreatedBy(loginUserId);
				hspSurgeon.setCreatedDate(new Date());
				hspSurgeon.setActive(true);
				hspSurgeonRepo.save(hspSurgeon);
				useraccount.setUserAccountKey(surgeon.getSurgeonId());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M45
	 */
	private String setUserCountryAndTeleCode(UserAccount useraccount, String phone) {
		try {
			if (phone != null && !phone.isEmpty() && phone.contains("-")) {
				String[] telecodes = phone.split("-");
				if (telecodes.length > 1) {
					useraccount.setTeleCode(telecodes[0]);
					List<CountryCode> countryCode = countryCodeRepo.findByTeleCode(telecodes[0]);
					phone = telecodes[1];
					useraccount.setTeleCountryCode(countryCode.get(0).getCountryCode());
				} else {
					useraccount.setTeleCountryCode("USA");
					useraccount.setTeleCode("+1");
				}
			} else {
				useraccount.setTeleCountryCode("USA");
				useraccount.setTeleCode("+1");
			}
		} catch (Exception e) {
			useraccount.setTeleCountryCode("USA");
			useraccount.setTeleCode("+1");
		}
		return phone;
	}

	/**
	 * M46
	 */
	private Boolean getUserWelcomeFlag(UserAccount useraccount, SaveUserData saveData) {
		Boolean wc = false;
		if (useraccount.getUserGroup().getUserGroupId() == 26) {
			String userShow = saveData.getUserShow();
			if (userShow.equalsIgnoreCase("yes")) {
				wc = true;
			}
		} else {
			wc = true;
		}
		return wc;
	}

	/**
	 * M47
	 */
	public String genderShow(String gender) {
		String defaultImgPath = "";
		if (gender.equalsIgnoreCase("Male"))
			defaultImgPath = uriRB.getString(CommonConstant.DEFAULT_PATM_IMAGE);
		else
			defaultImgPath = uriRB.getString(CommonConstant.DEFAULT_PATF_IMAGE);
		return defaultImgPath;
	}

	/**
	 * M48
	 */
	@Override
	public ResponseMessage validateEmailorPhone(UserValidateModel mailorPhone) {
		Boolean isExists = false;
		ResponseMessage response = new ResponseMessage();
		if (StringUtils.isNotBlank(mailorPhone.getPhone()) && StringUtils.isNotBlank(mailorPhone.getTeleCode())) {
			isExists = userAccountRepo.findByTeleCodeAndPhone(mailorPhone.getTeleCode(), mailorPhone.getPhone())
					.isEmpty() ? false : true;
		} else if (StringUtils.isNotBlank(mailorPhone.getEmail())) {
			isExists = userAccountRepo.findByEmail(mailorPhone.getEmail()).isEmpty() ? false : true;
		}
		if (!isExists) {
			response.setMessage(CommonConstant.USERVALIDATIONCHECK2);
			response.setStatus(CommonConstant.FAILURE);
		} else {
			response.setStatus(CommonConstant.SUCCESS);
		}
		return response;
	}

	/**
	 * M49
	 * 
	 * Get UserAccount By Email And UserName
	 */
	@Override
	public UserAccount getUserAccountByUserNameAndEmail(String userName) {
		UserAccount userAccount;
		try {
			if (userName != null && !userName.isEmpty() && !userName.contains("@") && userName.contains("-")) {

				userAccount = userAccountRepo.findByphoneWithTeleCode(userName).stream().findFirst().orElse(null);
			} else {
				userAccount = userAccountRepo.findByUserName(userName).stream().findFirst().orElse(null);
				if (userAccount == null) {
					userAccount = userAccountRepo.findByEmail(userName).stream().findFirst().orElse(null);
				}
			}
			if (userAccount != null)
				return userAccount;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	/**
	 * M50
	 * 
	 * Validate UserName based on condition
	 */
	@Override
	public List<UserAccount> validateUserNew(String userName) {
		List<UserAccount> userAccount = new ArrayList<>();
		try {
			if (userName != null) {
				if ((userName.matches(rb.getString("VALID_PHONE_REGEX")) && !userName.contains("."))
						|| !userName.contains("@") && !userName.equals("0")) {
					String[] phoneWCodes = userName.split("-");
					String teleCode = phoneWCodes[0];
					String phoneNumber = phoneWCodes[1];

					teleCode = teleCode.replace("+", "");
					teleCode = "+" + teleCode;

					userAccount = userAccountRepo.findByPhoneAndTeleCode(phoneNumber, teleCode);
				} else {
					userAccount = userAccountRepo.findByUserName(userName);
					if (userAccount.isEmpty())
						userAccount = userAccountRepo.findByEmail(userName);
				}
			}
			if (userAccount != null)
				return userAccount;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}

		return null;
	}

	/**
	 * M51
	 * 
	 * Get UserAccountIds for same email or same phone
	 */
	@Override
	public List<Long> fetchUserAccountIdsForMultiUserLogin(Long userAccountId) {
		try {
			UserAccount userAccount = userAccountRepo.findById(userAccountId).orElse(null);
			String userEmail = userAccount.getEmail();
			String phone = userAccount.getPhone();
			List<UserAccount> userAccountIdList;
			List<Long> userAccountIds = new ArrayList<>();
			if (userEmail != null && !userEmail.trim().isEmpty()) {
				userAccountIdList = userAccountRepo.findByEmail(userEmail);
				for (int i = 0; i < userAccountIdList.size(); i++) {
					userAccountIds.add(userAccountIdList.get(i).getUserAccountId());
				}
				return userAccountIds;
			} else if (phone != null && !phone.trim().isEmpty()) {
				userAccountIdList = userAccountRepo.findByPhone(phone);
				for (int i = 0; i < userAccountIdList.size(); i++) {
					userAccountIds.add(userAccountIdList.get(i).getUserAccountId());
				}
				return userAccountIds;
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	/**
	 * M52
	 */
	@Override
	public String getLanguageCode(UserAccount userAccount) {
		Hospital hsp = null;
		String countryLangCode = "default";
		try {
			if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.SURGEON)) {
				countryLangCode = "default";
			} else {
				hsp = hospitalService.getHospitalIdForAnyUserAccount(userAccount);
				countryLangCode = hsp.getCountryCode().getLanguage();
			}
			if (countryLangCode.equalsIgnoreCase("en_us")) {
				countryLangCode = "default";
			}
		} catch (Exception e) {
			countryLangCode = "default";
		}
		return countryLangCode;
	}

	/**
	 * M53
	 */
	@Override
	public RKUserAccount rkValidate(String userInfoStr) {
		List<RKUserAccount> archivedUaList = null;
		if (userInfoStr != null && userInfoStr.contains("-") && !userInfoStr.contains(".")) {
			String[] userInfos = userInfoStr.split("-");
			String telCode = "+" + userInfos[0].replace("+", "");
			String phoneNumber = userInfos[1];
			archivedUaList = rkUserAccountRepo.findByTeleCodeAndPhoneAndLatestIsTrue(telCode, phoneNumber);
		} else {
			archivedUaList = rkUserAccountRepo.findByUserNameAndLatestIsTrue(userInfoStr);
		}
		if (!archivedUaList.isEmpty())
			return archivedUaList.get(0);
		return null;
	}

	/**
	 * M54
	 */
	@Override
	public List<UserAccount> getUsersByEmailId(String emailId, String phoneNumber) {
		List<UserAccount> userAcctList = new ArrayList<>();
		emailId = RCUserUtil.getStringValue(emailId);
		phoneNumber = RCUserUtil.getStringValue(phoneNumber);
//		boolean validEmail = emailId.matches(rb.getString("VALID_EMAIL_REGEX")) ? true : false;
//		boolean validPhone = phoneNumber.matches(rb.getString("VALID_PHONE_REGEX")) ? true : false;
		if (!emailId.isBlank() && !phoneNumber.isBlank()) {
			userAcctList = userAccountRepo.findByEmailOrPhoneWithTeleCodeOrderByUserGroup_UserGroupIdAsc(emailId,
					phoneNumber);
		} else {
			if (!emailId.isBlank()) {
				userAcctList = userAccountRepo.findByEmailOrderByUserGroup_UserGroupIdAsc(emailId);
			}
			if (!phoneNumber.isBlank()) {
				userAcctList = userAccountRepo.findByPhoneWithTeleCodeOrderByUserGroup_UserGroupIdAsc(phoneNumber);

			}
		}
		return userAcctList;
	}

	@Override
	public List<UserAccount> getUsersByEmailId(String emailId, String phoneNumber, Long userId) {
		List<UserAccount> userAcctList = new ArrayList<>();
		if ((emailId == null || emailId.isBlank()) && (phoneNumber == null || phoneNumber.isBlank())) {
			userAcctList.add(userAccountRepo.findById(userId).get());
		}

		emailId = RCUserUtil.getStringValue(emailId);
		phoneNumber = RCUserUtil.getStringValue(phoneNumber);
//		boolean validEmail = emailId.matches(rb.getString("VALID_EMAIL_REGEX")) ? true : false;
//		boolean validPhone = phoneNumber.matches(rb.getString("VALID_PHONE_REGEX")) ? true : false;
		if (!emailId.isBlank() && !phoneNumber.isBlank()) {
			userAcctList = userAccountRepo.findByEmailOrPhoneWithTeleCodeOrderByUserGroup_UserGroupIdAsc(emailId,
					phoneNumber);
		} else {
			if (!emailId.isBlank()) {
				userAcctList = userAccountRepo.findByEmailOrderByUserGroup_UserGroupIdAsc(emailId);
			}
			if (!phoneNumber.isBlank()) {
				userAcctList = userAccountRepo.findByPhoneWithTeleCodeOrderByUserGroup_UserGroupIdAsc(phoneNumber);

			}
		}
		return userAcctList;
	}

	/**
	 * M55
	 */
	@Override
	public void activationUpdate(Long userAccountId, String activationMode) {
		try {
			userAccountRepo.userAccountActivationModeAndDateUpdate(userAccountId, activationMode);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M56
	 */
	@Override
	public void updateUserAccountActivationStatusForBothSingleOrMultiRoleUaByEmailOrPhone(UserAccount userAcct) {
		try {
			List<UserAccount> userAccount = getUsersByEmailId(userAcct.getEmail(), userAcct.getTeleCodeWithPhone())
					.stream().map(a -> {
						a.setActive(userAcct.getActive());
						return a;
					}).collect(Collectors.toList());
			userAccountRepo.saveAll(userAccount);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M57
	 */
	@Override
	public void updateSecurityQuestnAttemptsBothSingleAndMultiRole(Long userAccountId, int count) {
		try {
			Long userSecId = getUserSecResultDetailsAlreadyExist(userAccountId);
			userSecResDetRepo.updateSecurityQuestionAttemptsBothSingleAndMultiRole(userSecId, count);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	/**
	 * M58
	 */
	@Override
	public List<PayorType> getPayorTypes(Long hospitalId) {
		try {
			Hospital hospital = hospitalService.getHospitalById(hospitalId);
			return hospital != null
					? payorTypeRepository.findByCountryCodeId(hospital.getCountryCode().getCountryCodeId())
					: Collections.emptyList();
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	/**
	 * M59
	 */
	@Override
	public List<UserDetails> getAllCnInSameHospital(UserRequestData data) {
		Long[] grupIds = { 18l, 19l, 20l };
		List<UserDetails> userDetails = null;
		try {
			List<UserAccount> users = userAccountRepo
					.findByUserAccountKeyAndUserGroup_UserGroupIdNotIn(data.getUserAccountKey(), grupIds);
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			userDetails = users.stream().map(user -> modelMap.map(user, UserDetails.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userDetails;
	}

	/**
	 * M60
	 */
	@Override
	public List<UserDetails> getUsersByStrykerAct() {
		List<UserDetails> userDetails = null;
		try {
			List<UserAccount> users = userAccountRepo.findByStrykerAct(true);
			modelMap.getConfiguration().setAmbiguityIgnored(true);
			userDetails = users.stream().map(user -> modelMap.map(user, UserDetails.class))
					.collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userDetails;
	}

	/**
	 * M61
	 */
	@Override
	public List<NotesPatientDashBoard> getPatientOrCCNameResponse(List<NotesPatientDashBoard> patNotesDataRespList) {
		try {
			for (NotesPatientDashBoard patNotesDataResp : patNotesDataRespList) {
				UserAccount userAct = userAccountRepo.findById(patNotesDataResp.getSentBy()).orElse(null);
				if (userAct != null) {
					if ((userAct.getUserGroup().getUserGroupId() == 1
							|| userAct.getUserGroup().getUserGroupId() == 25)) {
						patNotesDataResp.setPatientOrCcName("RC Team");
						patNotesDataResp.setSendByFirstName(userAct.getFirstName());
						patNotesDataResp.setSendByLastName(userAct.getLastName());
						patNotesDataResp.setCcUserAccountId(patNotesDataResp.getSentBy());
					} else if (userAct.getStrykerAct() && userAct.getHopcoAct()) {
						patNotesDataResp.setPatientOrCcName(userAct.getFirstName() + " (HOPCO admin)");
						patNotesDataResp.setSendByFirstName(userAct.getFirstName());
						patNotesDataResp.setSendByLastName(userAct.getLastName());
						patNotesDataResp.setCcUserAccountId(patNotesDataResp.getSentBy());
					} else if (userAct.getStrykerAct()) {
						patNotesDataResp.setPatientOrCcName(userAct.getFirstName() + " (stryker admin)");
						patNotesDataResp.setSendByFirstName(userAct.getFirstName());
						patNotesDataResp.setSendByLastName(userAct.getLastName());
						patNotesDataResp.setCcUserAccountId(patNotesDataResp.getSentBy());
					} else {
						patNotesDataResp.setPatientOrCcName(userAct.getFirstName() + " " + userAct.getLastName());
						patNotesDataResp.setSendByFirstName(userAct.getFirstName());
						patNotesDataResp.setSendByLastName(userAct.getLastName());
						patNotesDataResp.setCcUserAccountId(patNotesDataResp.getSentBy());
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return patNotesDataRespList;
	}

	/**
	 * M62
	 */
	@Override
	public boolean checkIfPatientEmailExists(Long patientId, String email) {
		List<UserAccount> userAccountList = null;
		try {
			if (patientId == 0l) {
				userAccountList = userAccountRepo.findByEmail(email);
				if (userAccountList != null && !userAccountList.isEmpty()) {
					return true;
				} else {
					return false;
				}
			} else {
				Long userGrpId = userAccountRepo.findById(patientId).get().getUserGroup().getUserGroupId();
				userAccountList = userAccountRepo.findByEmailAndUserGroup_UserGroupIdAndUserAccountIdNot(email,
						userGrpId, userGrpId);
				if (userAccountList != null && !userAccountList.isEmpty()) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return false;
	}

	/**
	 * M63
	 */
	@Override
	public String checkIfExistUserAndNewEmailSameForPatientId(Long userId, String email) {
		try {
			String oldEmail = userAccountRepo.findById(userId).get().getEmail();
			if (oldEmail != null && !oldEmail.isEmpty()) {
				if (oldEmail.equals(email))
					return "true";
				else
					return CommonConstant.FALSE;
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return CommonConstant.FALSE;
		}
		return CommonConstant.FALSE;
	}

	/**
	 * M64
	 */
	@Override
	public List<UserAccountData> getUserAccountByUserGroupIdAndUserAccountKey(Long userAccountKey,
			List<Long> userGroupIdIN) {
		List<UserAccountData> userAccountData = new ArrayList<>();
		try {
			List<UserAccount> userAccount = userAccountRepo
					.findByUserAccountKeyAndAndUserGroup_UserGroupIdIn(userAccountKey, userGroupIdIN);
			userAccountData = userAccount.stream().map(a -> mapToUserAccount(a)).toList();
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userAccountData;
	}

	/**
	 * M65
	 */
	private UserAccountData mapToUserAccount(UserAccount userAccount) {
		UserAccountData userAccountData = new UserAccountData();
		userAccountData = modelMap.map(userAccount, UserAccountData.class);
		userAccountData.setUserGroupId(userAccount.getUserGroup().getUserGroupId());
		userAccountData.setGroupType(userAccount.getUserGroup().getGroupType());
		userAccountData.setGroupName(userAccount.getUserGroup().getGroupName());
		return userAccountData;
	}

	/**
	 * M66
	 */
	@Override
	public List<CCpatientInfoForMessage> getCCPatientInfoForMessages(MessageReqData objvalue, String xUser) {
		List<CCpatientInfoForMessage> msg = new ArrayList<CCpatientInfoForMessage>();
		try {
			Long userId = Long.valueOf(xUser);
			UserAccount userAccount = null;
			if (!userId.equals(objvalue.getUserAccountId())) {
				CCpatientInfoForMessage mErr = new CCpatientInfoForMessage();
				mErr.setError(CommonConstant.ERROR);
				mErr.setMessage(CommonConstant.ACCESS_ERR_MSG);
				msg.add(mErr);
				return msg;

			}
			userAccount = userAccountRepo.findById(objvalue.getUserAccountId()).orElse(null);
			long loginUserAccountId = userAccount.getUserAccountId();

			Long userAccountKey = userAccount.getUserAccountKey();
			String userGroupName = userAccount.getUserGroup().getGroupName();
			Hospital hsp = hspRepo.findById(userAccountKey).orElse(null);
//			Long countryCodeId = hsp.getCountryCode().getCountryCodeId();
//			List<CountryDischargeMap> cdMpList = conDisMapService.getCounDischargeMapByCountryCodeId(countryCodeId);
//			if (cdMpList.isEmpty()) {
//				cdMpList = conDisMapService.getCounDischargeMapByCountryCodeId(1l);
//			}

			List<PatientStageWorkflow> allPatSWFList = patientSWFRepo.findAll();
			List<HospitalPractice> hspPrac = hspPracRepo.findAll();
			List<Long> hspPracticeIds = hspPrac.stream().map(ids -> ids.getHospitalPracticeId())
					.collect(Collectors.toList());
			/** service line mapping balance **/
			for (PatientStageWorkflow patSWF : allPatSWFList) {
				CCpatientInfoForMessage m = new CCpatientInfoForMessage();
				HospitalPractice hspPractice = patSWF.getHospitalPractice();
				Long hspPracticeId = hspPractice == null ? null : hspPractice.getHospitalPracticeId();

				if (!hspPracticeIds.contains(hspPracticeId)) {
					continue;
				}
//		System.out.println(patSWF.toString());
//		System.out.println(hspPractice.toString());
				UserAccount patUser = userAccountRepo.findByUserAccountKey(patSWF.getPatient().getPatientId()).stream()
						.findFirst().orElse(null);
				List<PracticeCoordinatorHSPMapping> pCHSPMap = new ArrayList<PracticeCoordinatorHSPMapping>();
				List<HospitalNavigatorSugMapping> hNSugMap = new ArrayList<HospitalNavigatorSugMapping>();
				Boolean hpStatus = false;
				Boolean userGroupNameStatus = false;
				if (userGroupName.equalsIgnoreCase(STR_PRAC_COORDINATOR)) {
					pCHSPMap = pCHspMapService
							.getPracticeCoordinatorHSPMappingByHspPracticeId(hspPractice.getHospitalPracticeId());
					pCHSPMap = pCHSPMap.stream().filter(map -> map.getPcUserid().equals(loginUserAccountId))
							.collect(Collectors.toList());
					userGroupNameStatus = true;
					hpStatus = (pCHSPMap != null && !pCHSPMap.isEmpty())
							&& hspPractice.getPracticeId().equals(userAccountKey) ? true : false;
				} else if (userGroupName.equalsIgnoreCase(STR_HSP_NAVIGATOR)) {
					hNSugMap = hNSugMapService.getHospitalNavigatorSugMappingBysurgeonAccId(patSWF.getHspSurgId());
					hNSugMap = hNSugMap.stream().filter(map -> map.getHNUserid().equals(loginUserAccountId))
							.collect(Collectors.toList());
					userGroupNameStatus = true;
					hpStatus = (hNSugMap != null && !hNSugMap.isEmpty())
							&& hspPractice.getHospitalId().equals(userAccountKey) ? true : false;
				} else if (userGroupName.equalsIgnoreCase(STR_CARE_OUTCOME_MANAGER)
						|| userGroupName.equalsIgnoreCase(STR_COMMERCIAL_CN)
						|| userGroupName.equalsIgnoreCase(STR_FINACIAL_CN)
						|| userGroupName.equalsIgnoreCase(STR_PRACTICE_ADMIN)
						|| userGroupName.equalsIgnoreCase(STR_PRAC_PAT_ENROLLER)) {
					hpStatus = hspPractice.getPracticeId().equals(userAccountKey) ? true : false;
//			System.out.println(hspPractice.toString());
					userGroupNameStatus = true;
				} else if (userGroupName.equalsIgnoreCase(STR_HSP_ADMIN)
						|| userGroupName.equalsIgnoreCase(CommonConstant.STR_CARE_COORDINATOR)
						|| userGroupName.equalsIgnoreCase(STR_HSP_PAT_ENROLLER)) {
					hpStatus = hspPractice.getHospitalId().equals(userAccountKey) ? true : false;
					userGroupNameStatus = true;
				} else if (userGroupName.equalsIgnoreCase(CommonConstant.STR_SURGEON)) {
					hpStatus = true;
					userGroupNameStatus = true;
				} else if (userGroupName.equalsIgnoreCase(STR_PERSONAL_ASST)) {
					Long hospitalPracticeId = 0l/* findHospitalPracticeIdForPaToCnOrCc(loginUa.getUserAccountId()) */;
					hspPractice = hspPractice.getHospitalPracticeId().equals(hospitalPracticeId) ? hspPractice : null;
					hpStatus = true;
					userGroupNameStatus = true;
				}

				if ((userGroupNameStatus && hpStatus) || !userGroupNameStatus) {
					Boolean cNSugProcStatus = false;
					Boolean userJoinStatus = false;
					Boolean CNReAsFromConfigStatus = false;
					Long cNUserId = objvalue.getCnUserId() == null ? 0 : objvalue.getCnUserId();
					if (cNUserId != null && cNUserId > 0) {
						List<CNSugProcPayer> cNSugProc = cNSugProcPayerService
								.getCNSugProcPayerBypayorAndtypeAndSurgeonUaIdAndpracticeid(patSWF, userAccountKey);
						if (!cNSugProc.isEmpty()) {
							for (CNSugProcPayer cnSug : cNSugProc) {
								Predicate<Boolean> checkcNSugProc = a -> (cnSug.getProceduretype()
										.equalsIgnoreCase(patSWF.getProcedureType())
										&& cnSug.getSurgeonUaId().equals(patSWF.getHspSurgId())
										&& cnSug.getPracticeid().equals(userAccountKey)
										&& ((cnSug.getCnUser().getUserAccountId().equals(cNUserId)
												&& patSWF.getCNReAsFromConfigCNUserId() == null)
												|| (cnSug.getCnUser().getUserAccountId().equals(cNUserId)
														&& patSWF.getCNReAsFromConfigCNUserId().equals(cNUserId))));
//								LOGGER.info("CheckcNSugProc -> " + checkcNSugProc.test(true));
								if (checkcNSugProc.test(true)) {
									if (hsp != null && hsp.getMode().equals("H"))
										cNSugProcStatus = hspPractice.getSecHospitalId()
												.equals(cnSug.getAssignedHspTo()) ? true : false;

									else
										cNSugProcStatus = hspPractice.getHospitalId().equals(cnSug.getAssignedHspTo())
												? true
												: false;
								}

								Predicate<Boolean> checkUserJoin = u -> ((patSWF.getCNReAsFromConfigId() == null
										&& patSWF.getCNReAsFromConfigCNUserId() == null)
										|| (patSWF.getCNReAsFromConfigId() == null
												&& patSWF.getCNReAsFromConfigCNUserId() != null)
										|| (patSWF.getCNReAsFromConfigId() != null
												&& patSWF.getCNReAsFromConfigCNUserId() != null
												&& (cnSug.getCnsugprocpayerid() > 0l
														|| (cnSug.getCnsugprocpayerid()
																.equals(patSWF.getCNReAsFromConfigId()))
														|| patSWF.getHspCCId().equals(cNUserId))
												&& (patSWF.getHspCCId().equals(cNUserId) || cnSug.getCnUser()
														.getUserAccountId().equals(patSWF.getCaseManagerId()))));

								if (userGroupName.equalsIgnoreCase(STR_HSP_PAT_ENROLLER)
										|| userGroupName.equalsIgnoreCase(STR_PRAC_PAT_ENROLLER)
										|| userGroupName.equalsIgnoreCase(STR_PRAC_COORDINATOR)
										|| userGroupName.equalsIgnoreCase(STR_HSP_NAVIGATOR)
										|| userGroupName.equalsIgnoreCase(STR_PRACTICE_ADMIN)
										|| userGroupName.equalsIgnoreCase(STR_HSP_ADMIN)
										|| userGroupName.equalsIgnoreCase(CommonConstant.STR_SURGEON)) {
									if (patSWF.getHspCCId() != null || cnSug.getCnUser().getUserAccountId() != null) {
										userJoinStatus = checkUserJoin.test(true);
									}
								} else {
									if (patSWF.getHspCCId() != null && patSWF.getHspCCId().equals(cNUserId)
											|| cnSug.getCnUser().getUserAccountId() != null
													&& patSWF.getHspCCId().equals(cNUserId)) {
										userJoinStatus = checkUserJoin.test(true);
									}
								}
							}
//							LOGGER.info("userJoinStatus -> " + userJoinStatus);
						} else {
							Predicate<Boolean> checkUserJoin1 = u1 -> ((patSWF.getCNReAsFromConfigId() == null
									&& patSWF.getCNReAsFromConfigCNUserId() == null)
									|| (patSWF.getCNReAsFromConfigId() == null
											&& patSWF.getCNReAsFromConfigCNUserId() != null)
									|| (patSWF.getCNReAsFromConfigId() != null
											&& patSWF.getCNReAsFromConfigCNUserId() != null
											&& (patSWF.getHspCCId().equals(cNUserId))));
							if (userGroupName.equalsIgnoreCase(STR_HSP_PAT_ENROLLER)
									|| userGroupName.equalsIgnoreCase(STR_PRAC_PAT_ENROLLER)
									|| userGroupName.equalsIgnoreCase(STR_PRAC_COORDINATOR)
									|| userGroupName.equalsIgnoreCase(STR_HSP_NAVIGATOR)
									|| userGroupName.equalsIgnoreCase(STR_PRACTICE_ADMIN)
									|| userGroupName.equalsIgnoreCase(STR_HSP_ADMIN)
									|| userGroupName.equalsIgnoreCase(CommonConstant.STR_SURGEON)) {

								if (patSWF.getHspCCId() != null || patSWF.getHspCCSecid() != null) {
									userJoinStatus = checkUserJoin1.test(true);
								}

							} else {

								if (patSWF.getHspCCId() != null && patSWF.getHspCCId().equals(cNUserId)
										|| patSWF.getHspCCSecid() != null && patSWF.getHspCCSecid().equals(cNUserId)) {
									userJoinStatus = checkUserJoin1.test(true);

								}
							}
//							LOGGER.info("userJoinStatus -> " + userJoinStatus);

						}

					}
					String dob = patSWF.getPatient() != null && patSWF.getPatient().getDob() != null
							? patSWF.getPatient().getDob().toString().split(" ")[0]
							: "";
					String dos = patSWF.getDos() != null ? patSWF.getDos().toString().split(" ")[0] : "";

					if (cNUserId > 0 && (cNSugProcStatus || userJoinStatus)) {
						m.setPatientSwfId(patSWF.getPatientSWFId());
						m.setPatientId(patSWF.getPatient().getPatientId());
						m.setFirstName(patSWF.getPatient().getFirstName());
						m.setLastName(patSWF.getPatient().getLastName());
						m.setDob(dob);
						m.setDos(dos);
						m.setCreatedBy(patSWF.getHspCCId());
						m.setUserAccountId(patUser != null ? patUser.getUserAccountId() : 0l);
						m.setFracture(patSWF.getFracture() ? "Y" : "N");
						m.setEnableMarkAsReadUnread(CNReAsFromConfigStatus);
						m.setImagePath(patSWF.getPatient().getImagePath());
						m.setServiceLine(null);
						m.setPswIsActive(patSWF.getPswIsActive());
//						m.setUnReadMsgCount(null);
						m.setUnReadTotalCount(0l);
						msg.add(m);
					} else if (!(cNUserId > 0)) {
						m.setPatientSwfId(patSWF.getPatientSWFId());
						m.setPatientId(patSWF.getPatient().getPatientId());
						m.setFirstName(patSWF.getPatient().getFirstName());
						m.setLastName(patSWF.getPatient().getLastName());
						m.setDob(dob);
						m.setDos(dos);
						m.setCreatedBy(patSWF.getHspCCId());
						m.setUserAccountId(patUser != null ? patUser.getUserAccountId() : 0l);
						m.setFracture(patSWF.getFracture() != null && patSWF.getFracture() ? "Y" : "N");
						m.setEnableMarkAsReadUnread(CNReAsFromConfigStatus);
						m.setImagePath(patSWF.getPatient().getImagePath());
						m.setServiceLine(null);
						m.setPswIsActive(patSWF.getPswIsActive());
//						m.setUnReadMsgCount(null);
						m.setUnReadTotalCount(0l);
//						m.setPatientId(patSWF.getPatient().getPatientId());
						msg.add(m);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return msg;
	}

	/**
	 * M67
	 */
	@Override
	public String getSSOAPIURL(String value) {
		String apiUrl = "";
		try {
			if (value.equalsIgnoreCase(CasCommonConstant.HRO_LBL))
				apiUrl = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_HRO_SYNCURL);
			else if (value.equalsIgnoreCase(CasCommonConstant.ONBOARD))
				apiUrl = getSettingsValue(CasCommonConstant.SSOSYNC, CasCommonConstant.SSO_RCOB_SYNCURL);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return apiUrl;
	}

	/**
	 * M68
	 */
	@Override
	public UserAccount getUserExistByUserNameGroupId(String userName, String format, Long userGroupId) {
		try {
			if (format.equalsIgnoreCase("EM")) {
				if (userGroupId.equals(20L)) {
					List<CarePartnerMap> carePartnerMap = careRepo.findByUserAccount_EmailAndActive(userName, true);
					List<UserAccount> userAccountList = carePartnerMap.stream().map(a -> a.getUserAccount())
							.collect(Collectors.toList());
					if (userAccountList != null && !userAccountList.isEmpty()) {
						UserAccount userAccount = userAccountList.get(0);
						return userAccount;
					}
				} else if (userGroupId.equals(19L)) {
					List<UserAccount> userAccountList = userAccountRepo
							.findByUserGroupUserGroupIdAndEmailLike(userGroupId, userName);

					if (userAccountList != null && !userAccountList.isEmpty()) {
						UserAccount userAccount = userAccountList.get(0);
						return userAccount;
					}
				}
			} else {
				if (userGroupId.equals(20L)) {
					List<CarePartnerMap> carePartnerMap = careRepo.findByUserAccount_PhoneAndActive(userName, true);
					List<UserAccount> userAccountList = carePartnerMap.stream().map(a -> a.getUserAccount())
							.collect(Collectors.toList());
					if (userAccountList != null && !userAccountList.isEmpty()) {
						UserAccount userAccount = userAccountList.get(0);
						return userAccount;
					}
				} else if (userGroupId.equals(19L)) {
					List<UserAccount> userAccountList = userAccountRepo
							.findByUserGroupUserGroupIdAndPhoneLike(userGroupId, userName);

					if (userAccountList != null && !userAccountList.isEmpty()) {
						return userAccountList.get(0);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}

	@Override
	public void updateSecurityQuestionAttempts(Long userAccountId, int count) {
		try {
			Long userSecId = getUserSecResultDetailsAlreadyExist(userAccountId);
			userSecResDetRepo.updateSecurityQuestionAttemptsBothSingleAndMultiRole(userSecId, count);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	@Override
	public UserAccount getUserByUserNameAndUserGroup(String userName, String userNameFormat, List<Long> groupIds) {
		UserAccount user = null;
		List<UserAccount> userList = null;
		try {
			if (userNameFormat.equalsIgnoreCase("EM")) {
				userList = userAccountRepo.findByUserGroup_UserGroupIdInAndEmailLike(groupIds, userName);
			} else if (userNameFormat.equalsIgnoreCase("PN")) {
				userList = userAccountRepo.findByUserGroup_UserGroupIdInAndPhoneLike(groupIds, userName);
			}
			if (!userList.isEmpty()) {
				user = userList.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return user;
	}

	@Override
	public String getCountryCodebyUseraccountKey(Long patientId) {
		CountryCode ccode = null;
		String countryCode = "";
		try {
			UserAccount userAccount = userAccountRepo.findByUserAccountKey(patientId).stream().findFirst().orElse(null);
			UserAccount userAccountCC = userAccountRepo.findById(userAccount.getCreatedBy()).orElse(null);
			ccode = hspRepo.findById(userAccountCC.getUserAccountKey()).orElse(null).getCountryCode();
			countryCode = ccode != null ? ccode.getCountryCode() : "";
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return countryCode;
	}

	@Override
	public void updateUserAccountActiveAndLastModifiedDate(Long userAccountId, boolean active) {
		try {
			userAccountRepo.updateUserAccountActiveAndLastModifiedDate(userAccountId, active);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}

	}

	@Override
	public Boolean checkIfPhoneNumExists(String teleCode, String phone) {
		Boolean isExists = false;
		try {
			if (StringUtils.isNotBlank(teleCode) && StringUtils.isNotBlank(phone))
				isExists = userAccountRepo.findByTeleCodeAndPhone(teleCode, phone).isEmpty() ? false : true;
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return isExists;
	}

	@Override
	public List<UserMsgRespData> getUsersInfoForMessage(MessageReqData objvalue) {
		List<UserMsgRespData> users = new ArrayList<UserMsgRespData>();
		try {
			PatientStageWorkflow patSWF = patientSWFRepo.findById(objvalue.getPatientSwfId()).orElse(null);
			Long patientId = patSWF.getPatient().getPatientId();
			UserAccount userAcc = userAccountRepo.findById(objvalue.getLoginUaId()).orElse(null);
			List<Long> userIds = new ArrayList<>(List.of(userAcc.getUserAccountId()));
			List<Long> userCFIds = getCareFamilyByMessageSent(patientId, objvalue.getLoginUaId(), userIds);
//			List<Long> userCFIds = list.getCareNavigatorDetails().stream().map(cf -> cf.getCnId())
//					.collect(Collectors.toList());
			UserMsgRespData userMsg = new UserMsgRespData();
			userMsg.setPatientSwfId(objvalue.getPatientSwfId());
			userMsg.setPatientId(patientId);	
			users = getPatientMessagesAllForPA(userAcc, userMsg, users);
			for (Long userAccountId : userCFIds) {
				userAcc = userAccountRepo.findById(userAccountId).orElse(null);

				if (userAcc.getUserGroup().getGroupName().equalsIgnoreCase(STR_CARE_OUTCOME_MANAGER)
						|| userAcc.getUserGroup().getGroupName().equalsIgnoreCase(STR_CARE_COORDINATOR)
						|| userAcc.getUserGroup().getGroupName().equalsIgnoreCase(STR_PRAC_COORDINATOR)
						|| userAcc.getUserGroup().getGroupName().equalsIgnoreCase(STR_HSP_NAVIGATOR)) {
					userMsg = new UserMsgRespData();
					userMsg.setName(userAcc.getFirstName() + " " + userAcc.getLastName());
					userMsg.setImagePath(userAcc.getImagePath());
					userMsg.setRole(userAcc.getUserGroup().getGroupName());
					userMsg.setCcUserAccountId(userAcc.getUserAccountId());
					userMsg.setPatUserId(userAccountRepo.findByUserAccountKey(patientId).get(0).getUserAccountId());
					userMsg.setUserTitle((userAcc.getUserTitle()) != null ? userAcc.getUserTitle() : "");
					userMsg.setType("self");
					userMsg.setPatientSwfId(objvalue.getPatientSwfId());
					userMsg.setPatientId(patientId);
					users.add(userMsg);
				}

			}
			userMsg = new UserMsgRespData();
			userAcc = userAccountRepo.findById(1L).orElse(null);
			userMsg.setName("RecoveryCOACH");
			userMsg.setImagePath(userAcc.getImagePath());
			userMsg.setRole("Team");
			userMsg.setCcUserAccountId(1L);
			userMsg.setPatUserId(userAccountRepo.findByUserAccountKey(patientId).get(0).getUserAccountId());
			userMsg.setUserTitle("");
			userMsg.setType("auto");
			userMsg.setPatientSwfId(objvalue.getPatientSwfId());
			userMsg.setPatientId(patientId);
			users.add(userMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return users;
	}

	private List<Long> getCareFamilyByMessageSent(Long patientId, Long loginUaId, List<Long> userIds) {
		try {
			List<PatientStageWorkflow> patSWFList = patientSWFRepo
					.findByPatient_PatientIdOrderByPatientSWFIdDesc(patientId);

			for (PatientStageWorkflow patientSWF : patSWFList) {
				List<Long> careFamilyList = getCareFamilyByMessageSentId(patientSWF, loginUaId, userIds);
				careFamilyList = getAllNavigatorList(loginUaId, patientSWF.getPatientSWFId(), patientSWF.getHspCCId(),
						careFamilyList);
				return careFamilyList;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	private List<Long> getAllNavigatorList(Long loginUserAccountId, Long patientSWFId, Long hspCCId,
			List<Long> careFamilyList) {
		UserAccount ccUserAcct = userAccountRepo.findById(hspCCId).orElse(null);
		Hospital hospital = hspRepo.findById(ccUserAcct.getUserAccountKey()).orElse(null);
		List<UserAccount> userAccList = getAllGroupBasedUserAccountListByPatientSwfId(hospital.getHospitalId(),
				loginUserAccountId, patientSWFId);
		if (userAccList.isEmpty()) {
			userAccList = userAccountRepo
					.findByUserAccountKeyAndCareFamilyShowTrueAndActiveTrue(hospital.getHospitalId());
		}
		if (!userAccList.isEmpty()) {
			for (UserAccount userAcct : userAccList) {
				if (userAcct.getUserGroup().getUserGroupId() == 32 || userAcct.getUserGroup().getUserGroupId() == 33) {
					boolean flag = findHNPCforCarefamily(patientSWFId, userAcct.getUserGroup().getUserGroupId());
					if (flag && !careFamilyList.contains(userAcct.getUserAccountId())) {
						careFamilyList.add(userAcct.getUserAccountId());
					}
				} else {
					if (RCUserUtil.userAllowedforList(careFamilyList, userAcct)) {
						careFamilyList.add(userAcct.getUserAccountId());
					}
				}
			}
		}
		return careFamilyList;
	}

	private List<Long> getCareFamilyByMessageSentId(PatientStageWorkflow patientSWF, Long loginUserAccountId,
			List<Long> userAccountIds) {
		try {
			UserAccount loginUserAccount = userAccountRepo.findById(loginUserAccountId).orElse(null);
			if (loginUserAccount.getUserGroup().getUserGroupId() == 20L
					|| loginUserAccount.getUserGroup().getUserGroupId() == 19L) {

				loginUserAccount = userAccountRepo.findById(patientSWF.getHspCCId()).orElse(null);
			}
			List<Long> groupBasedCn = cNSugProcPayerService
					.getCNSugProcPayerBypayorAndtypeAndSurgeonUaIdAndpracticeid(patientSWF,
							loginUserAccount.getUserAccountKey())
					.stream().map(CNSugProcPayer::getCnUser).map(UserAccount::getUserAccountId).toList();
			if (!groupBasedCn.isEmpty()) {
				userAccountIds.clear();
				userAccountIds = userAccountRepo.findDistinctByCareFamilyShowTrueAndUserAccountIdIn(groupBasedCn)
						.stream().map(UserAccount::getUserAccountId).toList();
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userAccountIds;
	}

	private List<UserAccount> getAllGroupBasedUserAccountListByPatientSwfId(Long hospitalId, Long userAccountId,
			Long patientSWFId) {

		List<UserAccount> userAccountList = null;
		try {
			userAccountList = new ArrayList<>();

			PatientStageWorkflow pswf = patientSWFRepo.findById(patientSWFId).orElse(null);

			List<Long> groupBasedCn = cNSugProcPayerService
					.getCNSugProcPayerBypayorAndtypeAndSurgeonUaIdAndpracticeid(pswf, hospitalId).stream()
					.map(CNSugProcPayer::getCnUser).map(UserAccount::getUserAccountId).toList();

			if (!groupBasedCn.isEmpty()) {

				userAccountList = userAccountRepo.findByUserAccountIdInAndCareFamilyShowTrue(groupBasedCn);
			} else {

				int cnMappingSize = cNSugProcPayerRepo.findTop1ByPracticeidAndAssignedHspTo(hospitalId, 0L).size();
				if (cnMappingSize > 0) {
					userAccountList = userAccountRepo.findByUserAccountIdInAndCareFamilyShowTrue(
							new ArrayList<>(Arrays.asList(pswf.getHspCCId())));
					addHNPCInCNMappingCase(hospitalId, userAccountList, pswf);
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userAccountList;

	}

	public boolean findHNPCforCarefamily(Long patientSWFId, Long userGroupId) {
		PatientStageWorkflow patientSWF = patientSWFRepo.findById(patientSWFId).orElse(null);
		if (userGroupId == 32) {
			List<PracticeCoordinatorHSPMapping> practiceHSPMap = praCCHspMappingRepository
					.findDistinctByHospitalPracticeIdAndActiveTrue(
							patientSWF.getHospitalPractice().getHospitalPracticeId());
			return !practiceHSPMap.isEmpty();

		} else if (userGroupId == 33) {
			List<HospitalNavigatorSugMapping> hspSugMap = hspNavSugMappingRepository
					.findDistinctBySurgeonAccountIdAndActiveTrue(patientSWF.getHspSurgId());
			return !hspSugMap.isEmpty();

		}
		return false;
	}

	private List<UserAccount> addHNPCInCNMappingCase(Long hospitalId, List<UserAccount> userAccountList,
			PatientStageWorkflow psw) {
		try {
			List<Long> userAccountIds = new ArrayList<>();
			Hospital hospital = hspRepo.findById(hospitalId).orElse(null);
			if (hospital != null && hospital.getMode().equalsIgnoreCase("H")) {
				userAccountIds = hspNavSugMappingRepository
						.findBySurgeonAccountIdAndHNUserAccount_CareFamilyShowTrueAndActiveTrue(psw.getHspSurgId())
						.stream().map(HospitalNavigatorSugMapping::getHNUserid).toList();
			} else if (hospital != null && hospital.getMode().equalsIgnoreCase("P")) {
				userAccountIds = praCCHspMappingRepository
						.findByHospitalPracticeIdAndPcUserAccount_CareFamilyShowTrueAndActiveTrue(
								psw.getHospitalPractice().getHospitalPracticeId())
						.stream().map(PracticeCoordinatorHSPMapping::getPcUserid).toList();
			}

			userAccountList.addAll(userAccountRepo.findByUserAccountIdIn(userAccountIds));

		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return userAccountList;
	}

	private List<UserMsgRespData> getPatientMessagesAllForPA(UserAccount userAcc, UserMsgRespData userMsg,
			List<UserMsgRespData> users) {
		try {
			if (userAcc.getUserGroup().getGroupName().equals("Personal Asst.")) {
				userMsg.setName(userAcc.getFirstName() + " " + userAcc.getLastName());
				userMsg.setImagePath(userAcc.getImagePath());
				userMsg.setRole(userAcc.getUserGroup().getGroupName());
				userMsg.setCcUserAccountId(userAcc.getUserAccountId());
				userMsg.setUserTitle((userAcc.getUserTitle()) != null ? userAcc.getUserTitle() : "");
				users.add(userMsg);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return users;
	}

	@Override
	public void contactPreValidation(UserAccount userAccount) {
		try {
			boolean validFlag = RCUserUtil.ValidatePhone(userAccount.getTeleCode() + userAccount.getPhone(),
					userAccount.getTeleCountryCode());
			userAccount.setPhoneValid(validFlag);
			userAccountRepo.save(userAccount);

		} catch (Exception e) {
			LOGGER.error("Phone Number Pre Validation - ", e);
		}
	}

	@Override
	public UserAccount getUserAccountByUserAccountKeyAndUserGroupId(Long userAccountKey, Long userGroupId) {
		List<UserAccount> userAccount = null;
		try {
			userAccount = userAccountRepo.findByUserAccountKeyAndUserGroupUserGroupId(userAccountKey, userGroupId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return !userAccount.isEmpty() ? userAccount.get(0) : null;
	}

	@Override
	public List<HospitalPracticeApptInfo> fetchMultiHosptialPracticeByHspId(UserAccountData user) {
		List<HospitalPracticeApptInfo> apptInfos = new ArrayList<HospitalPracticeApptInfo>();
		try {
			if (user != null && user.getGroupType().equalsIgnoreCase(CommonConstant.STR_HSP)) {
				apptInfos = hospitalService.fetchMultiHosptialPracticeByHspId(user.getUserAccountKey());
			} else {

				apptInfos = hospitalService.findHospitalByPractice(user);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return apptInfos;
	}

	@Override
	public Long getPhoneLength(String code) {
		Long length = 10l;
		if (code != null && !code.isEmpty()) {
			List<CountryCode> countryCode = countryCodeRepo.findByCountryCode(code);
			if (countryCode != null) {
				length = countryCode.get(0).getLength();
			}
		}
		return length;
	}

	@Override
	public CCMessageData getPPUnReadTotMsgCount(CCMessageData ccMessageData) {
		try {
			List<Long> sentByIds = new ArrayList<>();
			PatientStageWorkflow patientSWF = patientSWFRepo.findById(ccMessageData.getPatientSwfId()).orElse(null);
			UserAccount loginUserAccount = patientSWF.getCCUserAccount();
			List<Long> groupBasedCn = cNSugProcPayerService
					.getCNSugProcPayerBypayorAndtypeAndSurgeonUaIdAndpracticeid(patientSWF,
							loginUserAccount.getUserAccountKey())
					.stream().map(CNSugProcPayer::getCnUser).map(UserAccount::getUserAccountId).toList();

			if (!groupBasedCn.isEmpty() && patientSWF.getHspCCId() != null) {

				sentByIds = userAccountRepo.findByUserAccountIdInAndCareFamilyShowTrue(groupBasedCn).stream()
						.filter(a -> UserGroupCons.messageCheck.contains(a.getUserGroupId()))
						.map(UserAccount::getUserAccountId).collect(Collectors.toList());
			} else {

				sentByIds = userAccountRepo
						.findByUserAccountIdInAndCareFamilyShowTrue(new ArrayList<>(ccMessageData.getSentBy().keySet()))
						.stream().filter(a -> UserGroupCons.messageCheck.contains(a.getUserGroupId()))
						.map(UserAccount::getUserAccountId).collect(Collectors.toList());

			}
			sentByIds.forEach(a -> ccMessageData.getSentBy().remove(a));
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return ccMessageData;
	}

	@Override
	public CountryCodeData getPhoneNumber(CountryCodeInfo countryCodeInfo) {
		CountryCodeData countryCodeData = new CountryCodeData();
		try {
			List<CountryCode> countryCodeList = countryCodeRepo.findByCountryCode(countryCodeInfo.getCountryCode());
			for (CountryCode countryCode : countryCodeList) {
				countryCodeData.setCountryName(countryCode.getCountryName());
				countryCodeData.setLength(countryCode.getLength());
				countryCodeData.setPhoneFormat(countryCode.getPhoneFormat());
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return countryCodeData;
	}

	@Override
	public EmailUserData getUserByEmailorPhone(String userName, EmailUserData response) {

		try {

			UserAccount patua = getUserAccountByUserNameAndEmail(userName);
			if (patua == null) {
				response.setStatus(CommonConstant.FAILURE);
				response.setMessage("Requested User not found!");
				return response;
			} else {
				response = modelMap.map(patua, EmailUserData.class);
				response.setGroupName(patua.getUserGroup().getGroupName());
				if (patua.getUserGroupId().equals(UserGroupCons.PATIENT)) {
					Patient patient = patientRepo.findById(patua.getUserAccountKey()).orElse(null);
					response = modelMap.map(patua, EmailUserData.class);
					modelMap.map(patient, response);
				}
				response.setStatus(CommonConstant.SUCCESS);
				response.setMessage("Requested User found!");
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}

		return response;
	}

	@Override
	public SurgeonDetailsData getSurveyPartialResult(PatientSWFInfo pSWData) {
		SurgeonDetailsData surgeonData = new SurgeonDetailsData();
		UserAccount userAccount = null;
		Surgeon surgeon = null;
		try {
			PatientStageWorkflow patientSWF = patientSWFRepo.findById(pSWData.getPatientSwfId()).orElse(null);
			userAccount = patientSWF.getSurgeonUserAccount();
			surgeon = surgeonRepo.findById(userAccount.getSurgeon().getSurgeonId()).orElse(null);
			String salutation = "Dr. ";
			if (surgeon != null) {
				salutation = surgeon.getSalutation();
			}
			surgeonData.setName(salutation + userAccount.getFirstName() + " " + userAccount.getLastName());
			surgeonData.setUserImagePath(userAccount.getImagePath());
			surgeonData.setUserRole(userAccount.getUserGroup().getGroupName());
		} catch (Exception e) {
			surgeonData.setName("");
			surgeonData.setUserImagePath("");
			surgeonData.setUserRole("");
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return surgeonData;
	}

	@Override
	public List<UserAccountData> getCarePartnerList(Long patientId) {
		try {
			List<CarePartnerMap> list = careRepo.findByPatientId(patientId);
			return list.stream().map(a -> {
				UserAccountData ua = modelMap.map(a.getUserAccount(), UserAccountData.class);
				ua.setCpActive(a.getActive());
				ua.setRelationShip(a.getRelationShip());
				return ua;
			}).toList();
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	@Override
	public MessageApptData getUsersInfoForApptMsg(EpisodeAppointmentInfo apptInfo, String title) {
		MessageApptData msgData = new MessageApptData();
		try {
			PatientStageWorkflow psw = patientSWFRepo.findById(apptInfo.getPatientSWFId()).orElse(null);
			Boolean isOverlap = psw != null && psw.getHospitalPractice() != null
					&& psw.getHospitalPractice().getIsOverLap() != null ? psw.getHospitalPractice().getIsOverLap()
							: false;
			UserAccount ccUser = userAccountRepo.findById(psw.getHspCCId()).orElse(null);
			UserAccount surgUser = userAccountRepo.findById(psw.getHspSurgId()).orElse(null);
			UserAccount patUser = userAccountRepo.findByUserAccountKey(psw.getPatientId()).get(0);
			List<CarePartnerMap> cplist = careRepo.findByPatientId(psw.getPatientId()).stream()
					.filter(a -> a.getActive()).collect(Collectors.toList());
			List<Long> patUserIds = cplist.stream().map(a -> a.getUserAccount().getUserAccountId())
					.collect(Collectors.toList());
			patUserIds.add(patUser.getUserAccountId());
			msgData.setSentBy(ccUser.getUserAccountId());
			msgData.setHospitalId(ccUser.getUserAccountKey());
			msgData.setReceivedBy(patUser.getUserAccountId());

			ResourceBundle res = I18nUtil.getConfigResourceByLanguage(
					ccUser.getHospital() != null ? ccUser.getHospital().getCountryCode().getLanguage() : "");
			String content = title.equalsIgnoreCase("New") ? res.getString("newlyFixedAppmntMsgCenter")
					: res.getString("deletedFixedAppmntMsgCenter");
			msgData.setContent(content);
			title = title.equalsIgnoreCase("New") ? CommonConstant.NEW_SCH_MSGTITLE : CommonConstant.DEL_SCH_MSGTITLE;
			msgData.setTitle(title);
			msgData.setStrykerAdminId(apptInfo.getStrykerAdminId() != null ? apptInfo.getStrykerAdminId() : 0l);
			msgData.setPatientId(psw.getPatientId());
			msgData.setEpisodeId(psw.getCurrentEpisodeId());
			Boolean strykerProcess = apptInfo.getStrykerAdminId() != null && apptInfo.getStrykerAdminId() != 0l ? true
					: false;
			msgData.setStrykerProcess(strykerProcess);
			msgData.setPatientSwfId(apptInfo.getPatientSWFId());
			msgData.setDateFormat(CommonConstant.getDateFormatMap()
					.get(ccUser.getHospital() != null
							? ccUser.getHospital().getCountryCode().getDateFormat().toUpperCase()
							: "MMDDYYYY"));
			Boolean isApptOpted = ccUser.getHospital() != null ? ccUser.getHospital().getIsAppmntOpted() : false;
			msgData.setEnabled(isOverlap ? true : isApptOpted);
			List<NotifyReqData> notifyList = patUserIds.stream().map(id -> {
				NotifyReqData notReq = new NotifyReqData();
				notReq.setToUser(id);
				notReq.setHspId(ccUser.getUserAccountKey());
				notReq.setSurgeonId(surgUser.getUserAccountKey());
				notReq.setPatientId(psw.getPatientId());
				return notReq;
			}).collect(Collectors.toList());
			msgData.setNotifyDatas(notifyList);

		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return msgData;
	}
	
	@Override
	public List<ProfileQuestionsData> getBiograph(Long patientId) {
		List<ProfileQuestionsData> profileQuestionsData = new ArrayList<>();
		try {
			Optional<ProfileResultDetails> result = profileRDRepo.findByUserAccount_UserAccountKey(patientId);
			String[] asList = result.map(ProfileResultDetails::getAnswers).map(answers -> answers.split("##"))
					.orElse(null);
			List<ProfileQuestions> questionsList = profileQuesRepo.findAll();
			int i = 0;
			for (ProfileQuestions question : questionsList) {
				ProfileQuestionsData pd = new ProfileQuestionsData();
				pd.setQuestionId(question.getQuestionId());
				pd.setQuestionName(question.getQuestionName());
				if (asList != null && i < asList.length && asList[i] != null && !asList[i].isEmpty()) {
					pd.setAnswer(asList[i]);
					i++;
				}
				profileQuestionsData.add(pd);
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return profileQuestionsData;
	}
	
	private String getSettingsValue(String category, String name) {
		String value = "";
		try {
			value = rcUserUtil.getSettingValue(name, category);
			LOGGER.info(value);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return value;
	}

	private void updatePatientContactHsitory(UserAccount userAcc, String oldEmailId, String oldPhone, String email,
			String phone) {
		try {
			PatientOldDetail patOldDetail = new PatientOldDetail();
			if ((oldEmailId != null && oldPhone !=null && !oldPhone.isEmpty()) && (email != null && email.isEmpty())
					&& (phone != null && phone.isEmpty())) {
				patOldDetail.setEmail(userAcc.getEmail());
				patOldDetail.setPhoneWithTelecode(
						userAcc.getPhone() != null ? userAcc.getTeleCode() + userAcc.getPhone() : null);
				patOldDetail.setPatientUaId(userAcc.getUserAccountId());
				patOldDetail.setRemovedDate(new Date());
				patientOldDetailRepo.save(patOldDetail);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
	}

	public boolean checkPatientExist(String email, String oldEmailId, UserAccount userAccount) {
		boolean emailExistsFlag = false;
		if (email != null && !email.isEmpty() && !email.equals(oldEmailId)) {
			emailExistsFlag = checkIfPatientEmailExists(userAccount.getUserAccountId(), userAccount.getEmail());
		}
		return emailExistsFlag;
	}

	private void setComTypeOnUpdatePatientDetails(UserAccount userAcc, String phone, UserAccount existingUserAcc,
			String comType) {
		/*** 48 days plan issue **/
		if ((existingUserAcc != null && existingUserAcc.getPhone() == null && phone != null) || (existingUserAcc != null
				&& existingUserAcc.getPhone() != null && phone != null && !existingUserAcc.getPhone().equals(phone))) {
			userAcc.setComType(comType);
		}
	}

	private String updateMrnForPatientProfile(Patient patient, String mrnNo, Hospital hsp) {
		String saveStatus = "true";
		boolean mrnExists = false;
		String existingMrn = patient.getMrn();
		try {
			if (mrnNo != null && !mrnNo.isEmpty()) {
				mrnExists = checkMrnExists(mrnNo, hsp.getHospitalId(), 19l);
				if (!mrnExists) {
					patient.setMrn(mrnNo);
					patientRepo.save(patient);
				} else if ((existingMrn == null || existingMrn.isEmpty()) || !existingMrn.equalsIgnoreCase(mrnNo)) {
					saveStatus = "The MRN has already been registered";
				}
			} else {
				if (existingMrn != null && !existingMrn.isEmpty()) {
					patient.setMrn(mrnNo);
					patientRepo.save(patient);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return saveStatus;
	}

	public boolean checkMrnExists(String mrn, Long hospitalId, Long groupId) {
		boolean existFlag = false;
		List<Patient> patient = patientRepo.findByMrn(mrn);
		if (patient.size() > 0 ? true : false) {
			Long patientId = patient.stream().findFirst().get().getPatientUserAcct().getUserAccountKey();
			if (groupId.equals(UserGroupCons.PATIENT)) {
				int count = patientSWFRepo
						.findByPswIsActiveTrueAndPatientIdAndCCUserAccount_UserAccountKeyOrSECUserAccount_UserAccountKey(
								patientId, hospitalId, hospitalId)
						.size();
				if (count > 0) {
					existFlag = true;
				}
			} else {
				Long userAccountkey = patient.get(0).getCreatedByUa().getUserAccountKey();
				if ((userAccountkey + "").equalsIgnoreCase(hospitalId + "")) {
					existFlag = true;
				}
			}
			return existFlag;
		}
		return false;
	}

	private void updateHicForAllPsw(List<PatientStageWorkflow> patientSwfList, String hic) {
		List<PatientStageWorkflow> patientSWF = patientSwfList.stream().map(a -> {
			a.setHic(hic);
			return a;
		}).collect(Collectors.toList());
		patientSWFRepo.saveAll(patientSWF);
	}

	@Override
	public ResponseMessage updatePatientDetails(ProfileData profileData, Long loginUserId) {
		ResponseMessage response = new ResponseMessage();
		Patient patient = patientRepo.findById(profileData.getPatientId()).orElse(null);
		Hospital hospital = patient.getCreatedByUa().getHospital();

		UserAccount userAccount = userAccountRepo.findByUserAccountKey(patient.getPatientId()).get(0);
//		String willSendOnBoardWelcomeLink = null;
//		String existEmailAndNewEqual = null;

		String oldEmailId = userAccount.getEmail();
		String oldPhone = userAccount.getPhone();

		String email = profileData.getEmail();
		String phone = profileData.getPhone();
		String teleCode = profileData.getTeleCode();
		String saveStatus = null;
		try {
			updatePatientContactHsitory(userAccount, oldEmailId, oldPhone, email, phone);
			String teleCountryCode = profileData.getTeleCountryCode();
			String mrnNo = profileData.getMrnNo();
	//		String defaultUserName = GenerateOTP.getAlphaNumericForUserName();
			List<PatientStageWorkflow> patientSwfList = patientSWFRepo
					.findPatientSWFIdByPatient_PatientId(patient.getPatientId());

			updatePatientStatus(userAccount, email, phone, patientSwfList);
			
			String username = (email != null && !email.isBlank()) ? email : profileData.getPhoneWithTeleCode();
			UserAccount existingUserAcc = validateUserNew(username).stream().findFirst().orElse(null);
			
			List<UserAccount> userList = multiUserCheck(oldEmailId, oldPhone, userAccount.getTeleCode(),
					email, phone, teleCode);

			if (userList.size() > 1) {
				updateMultiUser(email, phone, profileData, userAccount, userList);
			} else {
				String userName = (email==null || email.isBlank()) ? GenerateOTP.getAlphaNumericForUserName() : email;
				userAccount = getUserData(profileData, userAccount, userAccount.getUserAccountId(), hospital, userName);
				userAccountRepo.save(userAccount);
			}
//			userAccount
//					.setImagePath(UploadImageUtil.uploadUserImage(userAccount, hospital, profileData.getUploadImage()));
//			updateUserName(userAccount, email, defaultUserName);
//			userAccount.setFirstName(profileData.getFirstName());
//			userAccount.setLastName(profileData.getLastName());
//			userAccount.setGender(profileData.getGender());
//			userAccount.setPhone(RCUserUtil.getUserContactDetail(phone));
//			userAccount.setTeleCode(RCUserUtil.getUserContactDetail(teleCode));
//			userAccount.setTeleCountryCode(RCUserUtil.getUserContactDetail(teleCountryCode));
//			userAccount.setPhoneValid(RCUserUtil.ValidatePhone(phone, teleCountryCode));
//
//			String comType = RCUserUtil.getComType(email, phone);
//			patient.setComType(comType);
//			userAccount.setComType(comType);
//
//			willSendOnBoardWelcomeLink = willSendOnBoardWelcomeLink(userAccount.getUserAccountId(), email, phone);
//			UserValidationUtil.getUserAccOnboardLinkon(userAccount, willSendOnBoardWelcomeLink);
//			existEmailAndNewEqual = checkIfExistUserAndNewEmailSameForPatientId(userAccount.getUserAccountId(),
//					RCUserUtil.getNonEmptyString(email));
//			userAccount.setEmail(RCUserUtil.getNonEmptyString(email));
//
//			String otherPhone = (RCUserUtil.getUserContactDetail(profileData.getPhoneOther()));
//			String otherTeleCode = (RCUserUtil.getUserContactDetail(profileData.getTeleCodeOther()));
//			String otherTeleCountryCode = (RCUserUtil.getUserContactDetail(profileData.getTeleCountryCodeOther()));
//			String otherPhoneType = (RCUserUtil.getUserContactDetail(profileData.getOtherPhoneType()));
//			userAccount = getPhoneType(otherPhone, otherPhoneType, userAccount);
//
//			userAccount.setOtherPhone(RCUserUtil.getNonEmptyString(otherPhone));
//			if (RCUserUtil.getNonEmptyString(otherPhone) != null && !otherPhone.isEmpty()) {
//				userAccount.setOtherTeleCode(otherTeleCode);
//				userAccount.setOtherTeleCountryCode(otherTeleCountryCode);
//			} else {
//				userAccount.setOtherTeleCode(null);
//				userAccount.setOtherTeleCountryCode(null);
//				userAccount.setOtherPhoneType(null);
//			}
//			userAccount.setDob(profileData.getDob());
//
//			boolean emailExistsFlag = checkPatientExist(email, oldEmailId, userAccount);
//			boolean phoneExists = false;
//			if (phone !=null && !phone.isBlank() && !teleCode.isEmpty()
//					&& !(userAccount.getTeleCode() + oldPhone).equals(teleCode + phone)) {
//				phoneExists = checkIfPhoneNumExists(teleCode, phone);
//			}
//			updateUserProfileAccount(userAccount, oldEmailId, oldPhone, true, defaultUserName);
//			if (emailExistsFlag) {
//				String userName = userAccount.getUserName() + "$$" + userAccount.getUserAccountId();
//				userAccount.setUserName(userName);
//				if (existingUserAcc != null && existingUserAcc.getWelcomeFlag().equals(false)) {
//					userAccount.setWelcomeFlag(false);
//					userAccount.setActivationDate(existingUserAcc.getActivationDate());
//					userAccount.setActivationMode(existingUserAcc.getActivationMode());
//					userAccount.setUserPwd(existingUserAcc.getUserPwd());
//					userAccount.setComType(existingUserAcc.getComType());
//				}
//			} else if (phoneExists && existingUserAcc != null && existingUserAcc.getWelcomeFlag().equals(false)) {
//				userAccount.setWelcomeFlag(false);
//				userAccount.setActivationDate(existingUserAcc.getActivationDate());
//				userAccount.setActivationMode(existingUserAcc.getActivationMode());
//				userAccount.setUserPwd(existingUserAcc.getUserPwd());
//				userAccount.setComType(existingUserAcc.getComType());
//			}
//			setComTypeOnUpdatePatientDetails(userAccount, phone, existingUserAcc, comType);

			patient.setFirstName(profileData.getFirstName());
			patient.setLastName(profileData.getLastName());
			patient.setEmail(RCUserUtil.getUserContactDetail(email));
			patient.setPhone(RCUserUtil.getUserContactDetail(phone));
			patient.setTeleCode(RCUserUtil.getUserContactDetail(teleCode));
			patient.setTeleCountryCode(RCUserUtil.getUserContactDetail(teleCountryCode));
			patient.setImagePath(userAccount.getImagePath());
			patient.setDob(profileData.getDob());

			saveStatus = updateMrnForPatientProfile(patient, mrnNo, hospital);

			patient.setGender(profileData.getGender());
			patient.setWeight(profileData.getWeight());
			patient.setHeight(profileData.getHeight());
			patient.setInch(profileData.getInch());
			patient.setBmi(profileData.getBmi());
			patient.setSsn(profileData.getSsn());
			patient.setHic(profileData.getHic());

			patientRepo.save(patient);
			updateHicForAllPsw(patientSwfList, profileData.getHic());

//			String existPhoneAndNewEqual = "true";
//			existEmailAndNewEqual = RCUserUtil.getExistEmailandUpdatedEmailEqual(willSendOnBoardWelcomeLink,
//					existEmailAndNewEqual, oldPhone, phone);
//			existPhoneAndNewEqual = RCUserUtil.getExistPhoneandUpdatedPhoneEqual(oldPhone, phone,
//					existPhoneAndNewEqual);
			RCUserUtil.inActiveMailSmsTrack(userAccount, oldEmailId, oldPhone, email, phone);
			// TODO log Device Transaction
			// TODO email Configuration
		} catch (Exception e) {
			saveStatus = CommonConstant.FALSE;
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		response.setUpdateStatus(saveStatus);
		return response;
	}

	private void updatePatientStatus(UserAccount userAccount, String email, String phone,
			List<PatientStageWorkflow> patientSwfList) {
		if ((phone == null || phone.isBlank()) && (email == null || email.isBlank())) {
			patientSwfList.forEach(a -> {
				a.setPatientStatus("Opted out");
				patientSWFRepo.save(a);
			});
		}
		else if (((phone != null && !phone.isBlank()) || (email != null && !email.isBlank())) && userAccount.getWelcomeFlag()) {
			patientSwfList.forEach(a -> {
				a.setPatientStatus("Invited");
				patientSWFRepo.save(a);
			});
		}
	}

	public void updateUserName(UserAccount userAccount, String email, String defaultUserName) {
		if (email != null && email.isBlank()) {
			if (userAccount.getUserName().contains("@")) {
				userAccount.setUserName(defaultUserName);
			}
		} else {
			userAccount.setUserName(email);
		}
	}

	@Override
	public DobValidationResponse getEmailWelcome(DobValidationReq dobValidationReq) {
		DobValidationResponse resp = new DobValidationResponse();
		try {
			UserSecTransAudit userSecTransAudit = userSecTransAuditRepository
					.findByRandomIdAndIsActive(dobValidationReq.getRandId(), true);
			if (userSecTransAudit != null) {
				UserAccount userAccount = userSecTransAudit.getUserAccount();
				SimpleDateFormat sdf = new SimpleDateFormat(CommonConstant.DateFormatRC.YYYY_MM_DD);
				String dobStr = sdf.format(userAccount.getDob());
				if (dobStr.equalsIgnoreCase(dobValidationReq.getDob())) {
					resp.setFirstName(userAccount.getFirstName());
					resp.setLastName(userAccount.getLastName());
					resp.setImagePath(userAccount.getImagePath());
					resp.setRandId(dobValidationReq.getRandId());
					setDobValidationDataRolebased(userAccount, resp);
					resp.setStatus(CommonConstant.SUCCESS);
				} else {
					resp.setMessage("Please enter the correct date of birth");
					resp.setStatus(CommonConstant.FAILURE);
				}
			} else {
				resp.setMessage("Unauthorized Access");
				resp.setStatus(CommonConstant.FAILURE);
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return resp;
	}

	@Override
	public DobValidationResponse validateuserbyrandid(DobValidationReq dobValidationReq) {
		DobValidationResponse resp = new DobValidationResponse();
		resp.setMessage("Unauthorized Access");
		resp.setStatus(CommonConstant.FAILURE);
		try {
			UserSecTransAudit userSecTransAudit = userSecTransAuditRepository
					.findByRandomIdAndIsActive(dobValidationReq.getRandId(), true);
			if (userSecTransAudit != null) {
				UserAccount userAccount = userSecTransAudit.getUserAccount();
				if (userAccount != null) {
					resp.setFirstName(userAccount.getFirstName());
					resp.setLastName(userAccount.getLastName());
					resp.setImagePath(userAccount.getImagePath());
					resp.setRandId(dobValidationReq.getRandId());
					setDobValidationDataRolebased(userAccount, resp);
					resp.setStatus(CommonConstant.SUCCESS);
					resp.setMessage(null);
				}
			}
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
		}
		return resp;
	}

	private void setDobValidationDataRolebased(UserAccount user, DobValidationResponse resp) {
		if (user.getUserGroupId() == 19L) {
			resp.setClientLogo(user.getCreatedByUa().getHospital().getLogo());
		} else if (user.getUserGroupId() == 20L) {
			Long patientId = user.getWhoseCarePartner();
			List<UserAccount> patientList = userAccountRepo.findByUserAccountKey(patientId);
			if (!patientList.isEmpty()) {
				Hospital hospital = patientList.get(0).getCreatedByUa().getHospital();
				resp.setClientLogo(hospital.getLogo());
			}
		} else if (user.getUserGroupId() == 18L) {
			List<HospitalSurgeon> list = hspSurgeonRepo.findBySurgeon_SurgeonId(user.getUserAccountKey());
			if (!list.isEmpty()) {
				Optional<Hospital> optHsp = hspRepo.findById(list.get(0).getHospitalId());
				if (optHsp.isPresent()) {
					resp.setClientLogo(optHsp.get().getLogo());
				}
			}
		} else {
			resp.setClientLogo(user.getHospital().getLogo());
		}
		String usernamevalue = "";
		if (user.getEmail() != null) {
			usernamevalue = user.getUserName();
		} else {
			if (user.getPhone() != null && user.getTeleCode() != null) {
				usernamevalue = (user.getTeleCode() != null && user.getTeleCode().contains("+"))
						? user.getTeleCode().replace("+", "") + "-" + user.getPhone()
						: user.getTeleCode();
			} else {
				usernamevalue = "";
			}
		}
		resp.setUserName(usernamevalue);
	}

	private void updateMultiUser(String newEmail, String newPhone, ProfileData profileData, UserAccount xUser,
			List<UserAccount> user) {

		List<UserAccount> list = user.stream().filter(a -> !a.getWelcomeFlag()).collect(Collectors.toList());

		for (UserAccount userAcc : user) {
			String userName = null;
			String randomGeneratedUserName = GenerateOTP.getAlphaNumericForUserName();
			if ((newPhone !=null && !newPhone.isBlank()) && (newEmail ==null || newEmail.isBlank())) {
				userName = randomGeneratedUserName;
				profileData.setEmail("");
				if (!userAcc.getUserAccountId().equals(xUser.getUserAccountId())) {
					profileData.setEmail(RCUserUtil.getString(userAcc.getEmail()));
					userName = userAcc.getUserName();
				}
			} else if ((newPhone ==null || newPhone.isBlank()) && (newEmail ==null || newEmail.isBlank())) {
				userName = randomGeneratedUserName;
				if (!userAcc.getUserAccountId().equals(xUser.getUserAccountId()))
					continue;
			} else if ((newEmail != null && !newEmail.isBlank()) && user.size() > 1) {
				userName = newEmail + "$$" + userAcc.getUserAccountId();
			} else {
				userName = newEmail;
			}
			Hospital hospital = hospitalService.getHospitalIdForAnyUserAccount(userAcc);
			userAcc = getUserData(profileData, userAcc, userAcc.getUserAccountId(), hospital, userName);
			if (!list.isEmpty()) {
				UserAccount userAccount = list.get(0);
				userAcc.setActivationDate(userAccount.getActivationDate());
				userAcc.setWelcomeFlag(userAccount.getWelcomeFlag());
				userAcc.setWrongPwdAttempt(userAccount.getWrongPwdAttempt());
				userAcc.setUserPwd(userAccount.getUserPwd());
				userAcc.setUserPwdCreatedOn(userAccount.getUserPwdCreatedOn());
			}
			userAccountRepo.save(userAcc);
		}

	}

	public List<UserAccount> multiUserCheck(String oldEmailId, String oldPhone, String oldTeleCode, String newEmail,
			String newPhone, String newTeleCode) {

		List<UserAccount> newEmailUser = RCUserUtil.getUserAccountsIfStringContains(newEmail,
				userAccountRepo::findByEmail);

		List<UserAccount> oldEmailUser = RCUserUtil.getUserAccountsIfStringContains(oldEmailId,
				userAccountRepo::findByEmail);

		List<UserAccount> newPhoneUser = RCUserUtil.getUserAccountsIfStringContains(newPhone,
				phone -> userAccountRepo.findByphoneWithTeleCode(newTeleCode + "-" + phone));

		List<UserAccount> oldPhoneUser = RCUserUtil.getUserAccountsIfStringContains(oldPhone,
				phone -> userAccountRepo.findByphoneWithTeleCode(oldTeleCode + "-" + phone));

		List<Long> emailUserGroupIds = newEmailUser.stream().map(UserAccount::getUserGroupId).toList();

		List<Long> phoneUserGroupIds = newPhoneUser.stream().map(UserAccount::getUserGroupId).toList();

		// replace multiuser change one to another
		oldEmailUser.removeIf(a -> emailUserGroupIds.contains(a.getUserGroupId()));
		oldPhoneUser.removeIf(a -> phoneUserGroupIds.contains(a.getUserGroupId()));

		List<UserAccount> user = Stream.of(newEmailUser, oldEmailUser, newPhoneUser, oldPhoneUser)
				.flatMap(Collection::stream).filter(RCUserUtil.distinctByKey(UserAccount::getUserAccountId))
				.collect(Collectors.toList());
		return user;
	}

	@Override
	public ClientInfo getClientDetails(ClientList client) {
		try {
			Optional<Hospital> hspInfo = hspRepo.findById(client.getClientId());
			return hspInfo.map(info -> modelMap.map(info, ClientInfo.class)).orElse(null);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return null;
		}
	}

	@Override
	public HospitalContactData getContactustemplate(ClientList client) {
		try {
			Optional<HospitalContact> hspContact = hspContactRepo.findByHospitalId(client.getClientId()).stream()
					.findFirst();
			return hspContact.map(contact -> modelMap.map(contact, HospitalContactData.class)).orElse(null);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return null;
		}

	}

	@Override
	public StatusMessage updateUserUploadImg(UserUploadImgData userUploadImgData) {
		StatusMessage message = new StatusMessage();
		try {
			Optional<UserAccount> optUser = userAccountRepo.findById(userUploadImgData.getUserAccountId());
			if (optUser.isPresent()) {
				UserAccount userAccount = optUser.get();
				if (userUploadImgData.getUploadImage() != null && !userUploadImgData.getUploadImage().isEmpty()) {
					Hospital hospital = hospitalService.getHospitalIdForAnyUserAccount(userAccount);
					userAccount.setImagePath(
							UploadImageUtil.uploadUserImage(userAccount, hospital, userUploadImgData.getUploadImage()));
				} else if (userAccount.getImagePath() == null) {
					userAccount.setImagePath(RCUserUtil.getDefaultImgPath(userAccount.getGender()));
				}
				userAccountRepo.save(userAccount);
				if (userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)) {
					Patient patient = patientRepo.findById(userAccount.getUserAccountKey()).orElse(null);
					patient.setImagePath(userAccount.getImagePath());
					patient.setIsImageUploadDone(true);
					patientRepo.save(patient);
				}
				message.setValue(userAccount.getImagePath());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			message.setStatus(false);
		}
		message.setStatus(true);
		return message;
	}

}