package com.seind.rc.services.user.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HospitalPracticeData {
	private Long hospitalPracticeId;
	private Long hospitalId;
	private Long stageworkflowId;
	private String name;
	private Integer admissionId;
	private Boolean directClient;
	private boolean overlap;
}
