package com.seind.rc.services.user.service;

import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Service;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

@Service
public class ApiCacheService {

	private static final Integer EXPIRE_MIN = 1;
	private LoadingCache<String, Integer> apiCache;

	public ApiCacheService() {
		super();
		apiCache = CacheBuilder.newBuilder().expireAfterWrite(EXPIRE_MIN, TimeUnit.MINUTES)
				.build(new CacheLoader<String, Integer>() {
					public Integer load(String key) {
						return 0;
					}
				});
	}

	public void setAttemptCount(String key, Integer ct) {
		apiCache.put(key, ct);
	}

	public Integer getAttemptCount(String key) {
		try {
			return apiCache.get(key);
		} catch (Exception e) {
			return 0;
		}
	}
}

