package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.seind.rc.services.user.data.TodoHospitalOverlapBean;
import com.seind.rc.services.user.data.TodoRAPracticeOverlapHospitalsData;
import com.seind.rc.services.user.entities.HNSurgMapToClient;

import feign.Param;

public interface HNSurgMapToClientRepository extends JpaRepository<HNSurgMapToClient, Long> {	
	
	@Query(value = "SELECT NEW com.seind.rc.services.user.data.TodoRAPracticeOverlapHospitalsData(h.hospitalId,h.name,p.name as practiceName,false as isOverLap,hp.secHospitalId)"
			+ " from  HospitalPractice hp "
			+ " join Hospital p on p.hospitalId = hp.practiceId and hp.isOverLap = false "
			+ " join Hospital h on h.hospitalId = hp.hospitalId and hp.practiceId = :useraccountkey "
			+ " and h.hospitalId not in (select hospitalId from PracticeCoordinatorHSPMapping) ")
	List<TodoRAPracticeOverlapHospitalsData> todoRAPracticeOverlapHospital(@Param("useraccountkey") Long useraccountkey);
	
	List<HNSurgMapToClient> findByHospitalId(Long hospitalId);
	
	@Query(value = " SELECT NEW com.seind.rc.services.user.data.TodoHospitalOverlapBean(ua.userAccountId,ua.firstName,ua.lastName,ua.userGroupId,ug.groupName,1 as isCareCoordinator, "
			+ " h.name) from HNSurgMapToClient hnsc "
			+ " join HospitalNavigatorSugMapping hn on hn.hnsugMappingid = hnsc.hNSurgMapId "
			+ " and hn.hNUserid in (select distinct hNUserid from HospitalNavigatorSugMapping where surgeonId in ("
			+ " select surgeonId from HospitalNavigatorSugMapping where hNUserid = :hNUserid )) "
			+ " join UserAccount ua on ua.userAccountId = hn.hNUserid and ua.userAccountKey = :userAccountKey "
			+ " join UserGroup ug on ug.userGroupId = ua.userGroupId and ug.userGroupId in (33) "
			+ " join Hospital h on h.hospitalId = hnsc.hospitalId  ")
	List<TodoHospitalOverlapBean> getHospitalOverlap(@Param("hNUserid") Long hNUserid,@Param("userAccountKey") Long userAccountKey );
}
