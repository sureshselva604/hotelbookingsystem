package com.seind.rc.services.user.entities;

import java.util.Date;

import org.hibernate.annotations.Formula;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
@Table(name = "UserAccount")
public class UserAccount {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserAccountId", unique = true, nullable = false)
	private Long userAccountId;
	private String userName;
	private String userPwd;
	private String firstName;
	private String lastName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zipcode;
	private String country;
	private String email;
	private String title;
	private String phone;
	private String imagePath;
	private Boolean active;
	private Long userGroupId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userGroupId", insertable = false, updatable = false)
	private UserGroup userGroup;
	private Long userAccountKey;
	private Boolean deIdFlag;
	private Date createdDate;
	private Long createdBy;
	private Date lastModifiedDate;
	private Long lastModifiedBy;
	private Boolean isdelete;
	private Long notificationId;
	private String description;
	private String comType;
	@Column(name = "DOB")
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date dob;
	private String gender;
	private String bloodGroup;
	private Long whoseCarePartner;
	private String randomId;
	private Boolean welcomeFlag;
	private String randId;
	private Long profileResultDetailId;
	private Integer wrongPwdAttempt;
	private Date userPwdCreatedOn;
	private String teleCode;
	private String teleCountryCode;
	private Boolean isOnBoardLinkSent;
	private Date onBoardLinkSentOn;
	@Column(name = "CCNotification")
	private String notificationFrequency;
	private Boolean primaryuser;
	private int reenroll;
	private Integer menuconfig = 0;
	private Boolean todoPrivilege;
	private Long rcOnBoardId = 0L;
	@JoinColumn(name = "PatientId")
	private Long patientId;
	private Boolean careFamilyShow = false;
	private Boolean realTimeAlert = false;
	private Boolean realTimeMessage = false;
	private Boolean demoSite;
	private Boolean strykerAct;
	private Boolean allowOnboard;
	private String userTitle;
	private Date pHIAckDate;
	private String otherPhone;
	private String otherTeleCode;
	private String otherTeleCountryCode;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "OtherPhoneType")
	private PhoneType otherPhoneType;
		

	private Boolean tempPasswordActive = false;
	private Date passwordResetSentOn;
	private String activationMode;
	private Date activationDate;
	private Boolean hopcoAct;
	private Boolean pushNotification = null;
	private Boolean credResetRequired;
	private String userActivationStatus;
	private Date lockedDate;

	private boolean isPhoneValid = false;
	private boolean isEmailValid = false;
	private Long wrongOTPAttempt = 0L;
	private Long wrongCaptchaAttempt = 0L;

	@Formula("concat(teleCode,'-',phone)")
	private String phoneWithTeleCode;

	@Transient
	private String teleCodeWithPhone;

	public String getTeleCodeWithPhone() {
		teleCodeWithPhone = teleCode + '-' + phone;
		return teleCodeWithPhone;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CreatedBy", insertable = false, updatable = false)
	private UserAccount createdByUa;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserAccountKey", referencedColumnName = "PatientId", insertable = false, updatable = false)
	private Patient patient;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserAccountKey", referencedColumnName = "hospitalId", insertable = false, updatable = false)
	private Hospital hospital;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UserAccountKey",  referencedColumnName = "surgeonId", insertable = false, updatable = false)
	private Surgeon surgeon;
	
	
	public String getOtherPhoneTypeName () {
		return this.otherPhoneType!=null ? this.otherPhoneType.getPhoneTypeDesc() : null;
	}
	
	
	
//	@OneToMany(cascade = CascadeType.ALL)
//	@JoinColumn(name = "email", insertable = false, updatable = false)
//	private List<UserAccount> multiUsers;
}
