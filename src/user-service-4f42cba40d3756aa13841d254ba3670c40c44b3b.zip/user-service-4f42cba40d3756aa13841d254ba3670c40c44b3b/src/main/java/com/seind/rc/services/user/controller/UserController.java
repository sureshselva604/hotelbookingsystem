package com.seind.rc.services.user.controller;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.ClientInfo;
import com.seind.rc.services.user.data.ClientList;
import com.seind.rc.services.user.data.CountryCodeMapData;
import com.seind.rc.services.user.data.HospitalContactData;
import com.seind.rc.services.user.data.HospitalPracticeApptInfo;
import com.seind.rc.services.user.data.HospitalRequestData;
import com.seind.rc.services.user.data.PatientRequestData;
import com.seind.rc.services.user.data.PatientSWFInfo;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SaveUserData;
import com.seind.rc.services.user.data.SurgeonDetailsData;
import com.seind.rc.services.user.data.UserAccountData;
import com.seind.rc.services.user.data.UserDetails;
import com.seind.rc.services.user.data.UserGroupPrivilegeData;
import com.seind.rc.services.user.data.UserRequestData;
import com.seind.rc.services.user.data.UserValidateModel;
import com.seind.rc.services.user.data.UsersData;
import com.seind.rc.services.user.entities.Cardstatus;
import com.seind.rc.services.user.entities.PayorType;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserGroup;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.service.ClientCountryCodeMapService;
import com.seind.rc.services.user.service.NightJobService;
import com.seind.rc.services.user.service.UserAccountService;
import com.seind.rc.services.user.service.UserGroupPrivilegeService;
import com.seind.rc.services.user.service.UserGroupService;
import com.seind.rc.services.user.util.UserValidationUtil;
import com.seind.rc.services.user.util.ZipFileUtil;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * C10
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
public class UserController {

	private static final Logger LOGGER = LogManager.getLogger(UserController.class);

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private UserGroupService userGroupService;

	@Autowired
	private UserGroupPrivilegeService userGroupPrivilegeService;

	@Autowired
	private ModelMapper modelMap;

	@Autowired
	private ClientCountryCodeMapService clientCtryCodeMapService;

	@Autowired
	private UserAccountRepository userRepo;

	@Autowired
	private NightJobService nightJobService;

	/**
	 * Get staff members list by hospital Id in admin portal
	 */
	@Operation(summary = "Get staff members list by hospital Id in admin portal")
	@PostMapping(value = "/getUsersByHospital")
	public List<UsersData> getUsersByHospital(@RequestBody HospitalRequestData payload) {
		List<UsersData> response = null;
		try {
			Long hospitalId = payload.getHospitalId();
			response = userAccountService.getUsersByHospital(hospitalId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Get userGroup list dropDown in admin portal
	 */
	@Operation(summary = "Get userGroup list dropDown in admin portal")
	@PostMapping(value = "/getusergrouplist")
	public List<UserGroup> getusergrouplist(@RequestBody HospitalRequestData payload) {
		List<UserGroup> userGroup = null;
		try {
			userGroup = userGroupService.findAllUserGroup(payload.getHospitalId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userGroup;
	}

	/**
	 * Insert User Tab By Practice/Hospital
	 */
	@Operation(summary = "Insert User Tab By Practice/Hospital")
	@PostMapping(value = "/saveUser")
	public ResponseMessage saveUser(@RequestBody SaveUserData userDetails, HttpServletRequest request) {
		ResponseMessage response = null;
		String loginId = request.getHeader("x-user");
		Long userId = Long.valueOf(loginId);
		try {
			response = userAccountService.saveUser(userDetails, userId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Get User Privileges for User Groups
	 */
	@Operation(summary = "Get user Group  By Group ID")
	@PostMapping(value = "/getUserGroupPrivelegeByGroupId")
	public List<UserGroupPrivilegeData> getUserGroupPrivelegeByGroupId(HttpServletRequest request) {
		String xUser = request.getHeader("x-user");
		Long userId = Long.valueOf(xUser);
		List<UserGroupPrivilegeData> PrivilegeList = null;
		try {
			PrivilegeList = userGroupPrivilegeService.getUserGroupPrivelegeByGroupId(userId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return PrivilegeList;
	}

	/**
	 * Get User Privileges for User Groups
	 */
	@Operation(summary = "Get user Group  By Group ID")
	@PostMapping(value = "/getUserAccountByUserGroupIdAndUserAccountKey")
	public List<UserAccountData> getUserAccountByUserGroupIdAndUserAccountKey(@RequestBody UserRequestData payload) {
		List<UserAccountData> userAccountData = null;
		try {
			userAccountData = userAccountService.getUserAccountByUserGroupIdAndUserAccountKey(
					payload.getUserAccountKey(), payload.getUserGroupIdIN());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userAccountData;
	}

	/**
	 * Check whether Phone or Email exists
	 */
	@Operation(summary = "Check whether Phone or Email exists")
	@PostMapping(value = "/checkPhoneOrEmailExists")
	public ResponseMessage checkPhoneOrEmailExists(@RequestBody UserValidateModel objData) {
		ResponseMessage response = new ResponseMessage();
		try {
			response = userAccountService.validateEmailorPhone(objData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * Save userAccount data using bean of other service data
	 */
//	@Operation(summary = "Save userAccount data using bean of other service data")
//	@PostMapping("/saveUserAccount")
//	public void saveUserAccount(@RequestBody UserAccountData userAccountData) {
//		UserAccount userAcc;
//		try {
//			modelMap.getConfiguration().setAmbiguityIgnored(true);
//			userAcc = modelMap.map(userAccountData, UserAccount.class);
//			userAccountService.saveUserAccountDetails(userAcc);
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//	}

	/**
	 * Display patient basic details
	 */
	@Operation(summary = "Display patient basic details")
	@PostMapping(value = "/getUserData")
	public UserValidateModel getUserData(@RequestBody PatientRequestData payload) {
		UserValidateModel userdata = null;
		try {
			UserAccount usercc = userRepo.findByUserAccountKey(payload.getPatientId()).stream().findFirst()
					.orElse(null);
			if (usercc != null) {
				userdata = modelMap.map(usercc, UserValidateModel.class);
				userdata.setAge(UserValidationUtil.getAgewithDOB(usercc.getDob(), usercc.getCreatedDate()) + " Years");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return userdata;
	}

	/**
	 * List users based on Role
	 */
	@Operation(summary = "List users based on Role")
	@PostMapping(value = "/userAccountType")
	public List<UserDetails> getUserAccountById(@RequestBody UserRequestData data) {
		List<UserDetails> response = null;
		try {
			response = userGroupService.getUsersByUserGroupId(data.getUserGroupId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	/**
	 * @param userAccountKey
	 * @return fetch CNs of the hospital
	 */
	@Operation(summary = "Fetch List of CN in Hospital")
	@PostMapping(value = "/fetchAllCnInSameHospital")
	public List<UserDetails> getAllCnInSameHospital(@RequestBody UserRequestData payload) {
		List<UserDetails> users = null;
		try {
			users = userAccountService.getAllCnInSameHospital(payload);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return users;
	}

	@Operation(summary = "Fetch List of Users By StrykerAct")
	@PostMapping(value = "/fetchUsersByStrykerAct")
	public List<UserDetails> getUsersByStrykerAct() {
		List<UserDetails> users = null;
		try {
			users = userAccountService.getUsersByStrykerAct();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return users;
	}

	@Operation(summary = "Fetch Multi Hosptial Practice By HspId")
	@PostMapping(value = "/fetchMultiHosptialPracticeByHspId")
	public List<HospitalPracticeApptInfo> fetchMultiHosptialPracticeByHspId(@RequestBody UserAccountData apptRequest) {
		List<HospitalPracticeApptInfo> apptInfos = new ArrayList<HospitalPracticeApptInfo>();
		try {
			apptInfos = userAccountService.fetchMultiHosptialPracticeByHspId(apptRequest);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return apptInfos;
	}

	@Operation(summary = "Update Review Status")
	@PostMapping(value = "/getassignedbydetails")
	public SurgeonDetailsData getSurveyPartialResult(@RequestBody PatientSWFInfo pSWData) {
		SurgeonDetailsData surgeonData = new SurgeonDetailsData();
		try {
			surgeonData = userAccountService.getSurveyPartialResult(pSWData);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return surgeonData;
	}

	/**
	 * Fetch the countryCode details using hospitalId/practiceId
	 * 
	 * @param hospitalData
	 * @return A list of {@link CountryCodeMapData} objects representing the details
	 *         of countryCode.
	 */
	@Operation(summary = "Get fetchCountryCodeByHspOrPracId List")
	@PostMapping(value = "/fetchCountryCodeByHspOrPracId")
	public List<CountryCodeMapData> fetchCountryCodeByHspOrPracId(@RequestBody HospitalRequestData hospitalData) {
		List<CountryCodeMapData> response = null;
		try {
			response = clientCtryCodeMapService.fetchCountryCodeByHspOrPracId(hospitalData.getHospitalId());
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return response;
	}

	/**
	 * Retrieves the details of care partners associated with a user account and a
	 * patient.
	 *
	 * @param useraccountId The ID of the user account.
	 * @param patientId     The ID of the patient.
	 * @return A list of {@link UserAccountData} objects representing the details of
	 *         care partners.
	 */
	@Operation(summary = "Get Care Partner list")
	@GetMapping(value = "/getCarePartnerList/{patientId}")
	public List<UserAccountData> getCarePartnerList(@PathVariable("patientId") Long patientId) {
		try {
			return userAccountService.getCarePartnerList(patientId);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	@Operation(summary = "Get Payor Type")
	@GetMapping(value = "/getPayorType/{hospitalId}")
	public List<PayorType> getPayorTypes(@PathVariable Long hospitalId) {
		try {
			return userAccountService.getPayorTypes(hospitalId);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION, e);
			return Collections.emptyList();
		}
	}

	@Operation(summary = "Get contact details of HSP PSG")
	@PostMapping(value = "/getClientDetails")
	public ClientInfo getClientDetails(@RequestBody ClientList client) {
		ClientInfo clientInfos = null;
		try {
			clientInfos = userAccountService.getClientDetails(client);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return clientInfos;
	}

	@Operation(summary = "Get Contact Text ")
	@PostMapping(value = "/getContactustemplate")
	public HospitalContactData getContactustemplate(@RequestBody ClientList client) {
		HospitalContactData contactInfo = new HospitalContactData();
		try {
			contactInfo = userAccountService.getContactustemplate(client);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return contactInfo;
	}

	@PostMapping(value = "/getCurrentPatientSwfIds")
	public ResponseEntity<?> getCurrentPatientSwfIds() {

		try {
			String allPatswfIds = nightJobService.getCurrentPatientSwfIds();
			File zipFile = ZipFileUtil.createZipFile(new File(allPatswfIds).getParentFile(), "Demo@123");
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION,
					String.format("attachment; filename=%s", zipFile.getName()));
			InputStreamResource resource = new InputStreamResource(new FileInputStream(zipFile));
			return ResponseEntity.ok().headers(httpHeaders).contentLength(zipFile.length())
					.contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.badRequest().build();
		}
	}

	@PostMapping(value = "/saveCardStatus")
	public ResponseEntity<?> saveCardStatus(HttpServletRequest request) {
		try {
			ServletInputStream inputStream = request.getInputStream();
			File tempFile = File.createTempFile("Cardstatus", ".zip");
			FileUtils.copyInputStreamToFile(inputStream, tempFile);
			ZipFileUtil.extratZipfile(tempFile, tempFile.getParent(), "Demo@123");
			String filePath = tempFile.getParent() + "/cardstatus/Cardstatus.json";
			ObjectMapper om = new ObjectMapper();
			List<Cardstatus> patientSwfIds = om.readValue(new File(filePath), new TypeReference<List<Cardstatus>>() {
			});
			nightJobService.saveCardStatus(patientSwfIds);
			return ResponseEntity.ok().build();
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.badRequest().build();
		}
	}
}
