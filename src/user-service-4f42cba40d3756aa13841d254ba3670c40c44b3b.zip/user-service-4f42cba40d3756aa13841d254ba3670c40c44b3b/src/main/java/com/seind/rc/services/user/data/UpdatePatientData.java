package com.seind.rc.services.user.data;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class UpdatePatientData {

//	private String projectPath;
//	private String resultFilePath;
//	private String hospitalCode;
	private Long patientId;
	private String isEditStatus;
	private String firstName;
	private String lastName;
	private String email;
	private Boolean active;
	private Long lastModifiedBy;
	private Date lastModifiedDate;
	private String comType;
//	private String code;
	private String password;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date dob;
//	private String randomId;
//	private Boolean hasCarePartner;
	private String gender;
//	private Long notificationId;
//	private String description;
	private Boolean pushNotification;
	private Boolean isImageUploadDone;
	private Boolean isProfileDone;
	private Boolean isSupportDone;
	private String imagePath;
	private String phone;
	private String teleCode;
	private String teleCountryCode;
	private String otherPhone;
	private String otherTeleCode;
	private String otherTeleCountryCode;
	private Long otherPhoneType;

}
