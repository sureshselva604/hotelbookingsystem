package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.UserRequestAudit;

public interface UserRequestAuditRepository extends JpaRepository<UserRequestAudit,Long>{

	List<UserRequestAudit> findByUserAccount_UserAccountIdAndModeAndStatus(Long userAccountId, String mode,
			String status);

}
