package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "SecurityDict")
public class SecurityDict {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long securityDictId;
	private String securityDictData;
	private Boolean isActive;
	private Long createdBy;
	private Date createdOn;
	private Long lastModifiedBy;
	private Date lastModifiedOn;
	
}
