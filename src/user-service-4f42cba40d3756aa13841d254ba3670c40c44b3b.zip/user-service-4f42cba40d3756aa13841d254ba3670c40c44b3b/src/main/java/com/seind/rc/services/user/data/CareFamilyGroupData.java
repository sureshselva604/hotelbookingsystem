package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class CareFamilyGroupData {
	
	public  List<CareFamilyGroup> careNavigatorDetails;
	public List<CareFamilyGroup> hospitalCareNavigatorDetails;
	
	@Data
	public static class CareFamilyGroup{
		
		private Long userAccountId;
		private Long patientStageWorkFlowId;
		private String firstName;
		private String lastName;
		private String clientname;
		private String imagePath;
		private String groupName; 
		private String userTitle; 
		private Integer sequenceNo;
		
	}

}

