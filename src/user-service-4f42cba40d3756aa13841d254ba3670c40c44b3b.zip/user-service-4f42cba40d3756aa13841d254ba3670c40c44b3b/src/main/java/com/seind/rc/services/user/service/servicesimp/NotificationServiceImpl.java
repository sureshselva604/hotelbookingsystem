package com.seind.rc.services.user.service.servicesimp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.constants.UserGroupCons;
import com.seind.rc.services.user.data.HospitalNotifyData;
import com.seind.rc.services.user.data.NotificationDTO;
import com.seind.rc.services.user.data.NotifyReqData;
import com.seind.rc.services.user.data.PSWFNotifyData;
import com.seind.rc.services.user.data.TokenListData;
import com.seind.rc.services.user.data.UserAccountNotifyData;
import com.seind.rc.services.user.entities.CarePartnerMap;
import com.seind.rc.services.user.entities.Hospital;
import com.seind.rc.services.user.entities.PatientStageWorkflow;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserSecTransAudit;
import com.seind.rc.services.user.repository.CarePartnerMapRepository;
import com.seind.rc.services.user.repository.PatientDeviceRepository;
import com.seind.rc.services.user.repository.PatientStageWorkflowRepository;
import com.seind.rc.services.user.repository.SettingsRepository;
import com.seind.rc.services.user.repository.UserAccountRepository;
import com.seind.rc.services.user.repository.UserSecTransAuditRepository;
import com.seind.rc.services.user.service.HospitalService;
import com.seind.rc.services.user.service.NotificationService;
import com.seind.rc.services.user.util.RCUserUtil;

@Service
public class NotificationServiceImpl implements NotificationService {
	
	private static final Logger LOGGER = LogManager.getLogger(NotificationServiceImpl.class);

   @Autowired
   private UserAccountRepository userRepo;
   
   @Autowired
   private CarePartnerMapRepository carePartnerMapRepo;
   
   @Autowired
   private PatientDeviceRepository patientDeviceRepo;
   
   @Autowired
   private PatientStageWorkflowRepository pswfRepo;
   
   @Autowired
   private ModelMapper modelMap;
   
   @Autowired
   private HospitalService hospitalService;
   
   @Autowired
   private SettingsRepository settingsRepo;
   
   @Autowired
   private UserSecTransAuditRepository userSecTransAuditRepository;
	
	@Override
	public List<TokenListData> getTokenListbyPatientorCpId(Long userAccountId) {
		try {

			UserAccount userAccount = userRepo.findById(userAccountId).orElse(null);
			List<UserAccount> emailCheck = new ArrayList<>();
			if(RCUserUtil.stringContains(userAccount.getEmail())) {
				emailCheck.addAll(userRepo.findByEmail(userAccount.getEmail()));
			}
			if(RCUserUtil.stringContains(userAccount.getPhone())&&RCUserUtil.stringContains(userAccount.getTeleCode())) {
				emailCheck.addAll(userRepo.findByPhoneAndTeleCode(userAccount.getPhone(),userAccount.getTeleCode()));

			}
			
			 List<Long> carePatnerId = carePartnerMapRepo.findByActiveIsTrueAndUserAccount_userAccountIdAndUserAccount_UserGroup_UserGroupId(userAccountId, UserGroupCons.CARE_PARTNER)
					                  .stream().map(CarePartnerMap::getUserAccount).map(UserAccount::getUserAccountId).collect(Collectors.toList());
			 carePatnerId.addAll(emailCheck.stream().filter(a->a.getUserAccountId()!=userAccount.getUserAccountId()&&a.getUserGroup().getUserGroupId().equals(UserGroupCons.CARE_PARTNER))
					                             .map(UserAccount::getUserAccountId).collect(Collectors.toList()));
			
			
			
			List<Long> patientId = emailCheck.stream().filter(a->a.getUserAccountId()!=userAccount.getUserAccountId()&&a.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT))
                    .map(UserAccount::getUserAccountKey).collect(Collectors.toList());

			if(userAccount.getUserGroup().getUserGroupId().equals(UserGroupCons.PATIENT)){
				patientId.add(userAccount.getUserAccountKey());
			}
			
			
			List<TokenListData> tokenIds = patientDeviceRepo.findByPatient_PatientIdInOrCarePartnerIdInAndValidToken(patientId,carePatnerId,1)
					                .stream().filter(a->RCUserUtil.stringContains(a.getTokenId()))
					                .map(a->{
					                	TokenListData data = new TokenListData();
					                	data.setTokenId(a.getTokenId());
					                	data.setDeviceId(a.getDeviceId());
					                	data.setSerialNumber(a.getSerialNumber());
					                	return data;
					                }).collect(Collectors.toList());
					                
			return tokenIds;
		}
		catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
			return Collections.emptyList();
		}
		
		
	}

	@Override
	public NotificationDTO getUsersData(NotifyReqData notifyReqData) {
		
		NotificationDTO notifyUserData = new NotificationDTO();
		try {
			
			UserAccount toUser = userRepo.findById(notifyReqData.getToUser()).orElse(null);
			notifyUserData.setToUser(toUser!=null?modelMap.map(toUser, UserAccountNotifyData.class):null);
			UserAccount cpUser = userRepo.findById(notifyReqData.getCpUserId()).orElse(null);
			notifyUserData.setCpUser(cpUser!=null?modelMap.map(cpUser, UserAccountNotifyData.class):null);
			UserAccount patUa = userRepo.findByUserAccountKey(notifyReqData.getPatientId()).stream().findFirst().orElse(null);
			notifyUserData.setPatient(patUa!=null&&patUa.getUserGroupId().equals(UserGroupCons.PATIENT)?modelMap.map(patUa, UserAccountNotifyData.class):null);
			UserAccount sugUa = userRepo.findByUserAccountKey(notifyReqData.getSurgeonId()).stream().findFirst().orElse(null);
			notifyUserData.setSurgeon(sugUa!=null&&sugUa.getUserGroupId().equals(UserGroupCons.SURGEON)?modelMap.map(sugUa, UserAccountNotifyData.class):null);
			UserAccount staffUser = userRepo.findById(notifyReqData.getStaffUser()).orElse(null);
			notifyUserData.setStaffUser(staffUser!=null?modelMap.map(staffUser, UserAccountNotifyData.class):null);
			Hospital hsp = hospitalService.getHospitalIdForAnyUserAccount(toUser);
		    notifyUserData.setHsp(hsp!=null?modelMapHSPData(hsp):null);
		    PatientStageWorkflow pswf = pswfRepo.findById(notifyReqData.getPatientSwfId()).orElse(null);
		    notifyUserData.setPatientSwf(pswf!=null?modelMap.map(pswf, PSWFNotifyData.class):null);	    
		    if(notifyReqData.getNotificationMode()!=null && notifyReqData.getNotificationMode().equalsIgnoreCase("PUSH")){
		    notifyUserData.setTokenData(getTokenListbyPatientorCpId(notifyUserData.getToUser().getUserAccountId()));
		    }
		   
		    Map<String,String> emailList = settingsRepo.findByCategory("ForgotPasswordEmail")
		    		                       .stream().collect(Collectors.toMap(
                                                 a->a.getName(),
                                                 a->a.getValue()));
		    notifyUserData.setEmailList(emailList);
		    
		    if(cpUser==null&&toUser!=null&&toUser.getUserGroupId().equals(19L)) {
		    	
		    	CarePartnerMap cpMap = carePartnerMapRepo.findByPatientIdAndActiveTrue(toUser.getUserAccountKey())
		    			               .stream().findFirst().orElse(null);
		    	
		    	cpUser = userRepo.findById(cpMap!=null?cpMap.getUserAccount().getUserAccountId():0L).orElse(null);
				notifyUserData.setCpUser(cpUser!=null?modelMap.map(cpUser, UserAccountNotifyData.class):null);
		    }
		    
		    if(hsp==null&&toUser!=null) {
		    	
				Hospital hospital= hospitalService.getHospitalIdForAnyUserAccount(toUser);
			    notifyUserData.setHsp(hospital!=null?modelMapHSPData(hospital):null);

		    	
		    }
		    
			List<UserSecTransAudit> list = userSecTransAuditRepository
					.findByUserAccount_UserAccountIdAndModeAndIsActive(toUser.getUserAccountId(), "AddUser", true);
			if(!list.isEmpty()) {
				UserSecTransAudit userSecTransAudit = list.get(0);
				notifyUserData.setRandID(userSecTransAudit.getRandomId());
			}
		}	
		catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		}
		return notifyUserData;
	}

	private HospitalNotifyData modelMapHSPData(Hospital hsp) {
		HospitalNotifyData hospitalNotifyData =  modelMap.map(hsp, HospitalNotifyData.class);
		hospitalNotifyData.setHelpDeskNo(hsp.getCountryCode().getHelpDeskNo());
		hospitalNotifyData.setDateFormat(hsp.getCountryCode().getDateFormat());
		hospitalNotifyData.setLanguage(hsp.getCountryCode().getLanguage());
		return hospitalNotifyData;
	}

	@Override
	public List<NotifyReqData> workflowNotificationData(Long patientSWFId) {
		List<NotifyReqData> notifyDatas = new ArrayList<>();
		try {
		
			Optional<PatientStageWorkflow> pswf = pswfRepo.findById(patientSWFId);
			Long patientId = pswf.map(PatientStageWorkflow::getPatientId).orElse(0L);
			Long activeCp = carePartnerMapRepo.findByPatientIdAndActiveTrue(patientId).map(CarePartnerMap::getUserAccount)
					        .map(UserAccount::getUserAccountId).orElse(0L);
			UserAccount patientUa = userRepo.findByUserAccountKey(patientId).stream().findFirst().orElse(null);
			Long patientUaId = userRepo.findByUserAccountKey(patientId).stream().findFirst().map(UserAccount::getUserAccountId).orElse(0L);
			Long hospitalId = hospitalService.getHospitalIdForAnyUserAccount(patientUa).getHospitalId();
			NotifyReqData notifyData = new NotifyReqData();
			notifyData.setSurgeonId( pswf.map(PatientStageWorkflow::getSurgeonUserAccount).map(UserAccount::getUserAccountKey).orElse(0L));			
			notifyData.setToUser(patientUaId);	
			notifyData.setHspId(hospitalId);
			notifyDatas.add(notifyData);
			if(activeCp!=0) {
				notifyData = new NotifyReqData();
				notifyData.setToUser(activeCp);
				notifyData.setHspId(hospitalId);
				notifyData.setPatientId(patientId);
				notifyDatas.add(notifyData);
			}
			
		}
		
		catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION,e);
		} 
		
		return notifyDatas;
	}


}
