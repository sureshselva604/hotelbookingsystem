package com.seind.rc.services.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Cardstatus {
	@Id
	private Long PatientSwfId;
	private Integer ontrack;
}
