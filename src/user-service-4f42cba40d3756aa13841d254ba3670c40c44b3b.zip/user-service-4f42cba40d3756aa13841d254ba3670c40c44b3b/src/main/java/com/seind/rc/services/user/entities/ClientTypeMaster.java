package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ClientTypeMaster")
public class ClientTypeMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ClientTypeMasterId", unique = true, nullable = false)
	private Long clientTypeMasterId;
	private String clientType;
	private boolean bundleDisplay;
	private boolean bundleEndDateDisplay;
	private boolean isActive;
	private Date CreatedBy;
	private Date CreatedOn;
	private Date ModifiedBy;
	private Date ModifiedOn;

}
