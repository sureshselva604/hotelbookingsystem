package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class PatientSWFInfo {
	private Long patientSwfId;
}
