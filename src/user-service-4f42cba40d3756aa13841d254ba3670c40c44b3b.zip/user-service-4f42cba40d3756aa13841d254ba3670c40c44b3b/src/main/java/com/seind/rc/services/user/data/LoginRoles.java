package com.seind.rc.services.user.data;


import lombok.Data;

@Data
public class LoginRoles {
	private Long loginAccountId;
	private Long userGroupId;
	private String userGroupName;
	private Long majorGroupId;
	private String majorGroupName;
	private Boolean isBodypartavailable;
	private String firstName;
	private String lastName;
	private Long patientId;
	private Long patientAccountId;
	private String imagePath;
	private Long patientStageWorkflowId;
	private String procedure;
	private String hospitalName;
	private Long hospitalId;
	private Long mappingId;
	private Boolean verified;
//	private JsonObject workflow;
	private String cid;
	private String cname;
	private String dos;
	private String surgeonName;
}
