package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class ImageData {
	
	private String fileName;
	private String fileType;
	private String value;

}
