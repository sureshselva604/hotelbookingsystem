package com.seind.rc.services.user.data;

import java.util.Date;

import lombok.Data;

@Data
public class PatientReadmissionShowData {
	
	private Long patientSWFId; 
	private Long useAccountId;
	private Long hospitalId;
	private String mode;
	private Date dos;
	private Integer admissionId;

}
