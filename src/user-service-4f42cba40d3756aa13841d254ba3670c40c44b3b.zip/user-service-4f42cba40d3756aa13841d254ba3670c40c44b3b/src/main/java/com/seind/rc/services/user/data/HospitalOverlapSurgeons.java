package com.seind.rc.services.user.data;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "HospitalOverlapSurgeons")
public class HospitalOverlapSurgeons {
	
	@Id
	
	private Long surgeonId;
	
	private Long userAccountId;
	
	private String firstName;
	
	private String  lastName;

	private String salutation;
	
	private String oLPracName;
	
	private String oLHspName;
	
	private Integer isOverLap;
	
	private Long practiceId;
	
	private Long hospitalId	;
	
	private Long userAccountKey;

}
