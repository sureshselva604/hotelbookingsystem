package com.seind.rc.services.user.entities;


import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "PatientDevice")
public class PatientDevice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long deviceId;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="patientId")
	private Patient patient;
	private String code;
	private String name;
	private String description;
	private String serialNumber;
	private String deviceKey;
	private String handshakeKey;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	private Long createdBy;
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastModifiedDate;
	private Long lastModifiedBy;
	private Long statusId;
	private String unlockKey;
	private Boolean epubStatus;
	private String ePubMasterId;
	private Boolean formConfig;
	private Boolean surveyConfig;
	private Boolean videoConfig;
	private Long carePartnerId;
	private Boolean epubConfig;
	private String mode;
	private String tokenId;
	private Integer validToken;
	private Boolean isMaintenanceSync;
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastMaintenanceSyncDate;
	private String deviceType;
	private String osVersion;
	private String appVersion;
}

