package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class LambdaProSurveyBean {
	
	private Long patientId;
	private String pat_email;
	private String pat_phone;
	private String comType;
	private String teleCode;
	private Long patientSWFId;
	private String firstName;
	private String lastName;
	private String patientStatus;
	private Long currentEpisodeId;
	private Long hospitalPracticeId;
	private String procedureType;
	private Long hospitalId;
	private String hospitalName;
	private String hospitalCode;
	private Boolean allowPatNotification;
	private Long hSP_CC_Id;
	private Long patUaId;
	private Long hSP_Surg_Id;
	private String surgFirstName;
	private String surgLastName;
	private String surgGender;
	private String salutation;
	private Long cpaccountid;
	private String cpfirstname;
	private String cplastname;
	private String cpemail;
	private Long zoneId;
}