package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class UpdateUserDeviceData {
	
	private Boolean isEditStatus;
	private String dob;
	private Long whoseCarePartner;
	private String imagePath;
	private Boolean active;
	private String otherPhone;
	private Long otherPhoneType;
	private String title;
	private String teleCountryCode;
	private String password;
	//private String description;          
	private Boolean pushNotification;
	private Long userAccountId;
	private String lastName;
	private String comType;
	private String email;
	private String randomId;
	private String firstName;
	private String otherTeleCode;
	private Long createdBy;
	private String userName;
	private String gender;      
	private String TeleCode;
	private String phone;
	private String userGroupName;
	private Long userGroup;
	private String otherTeleCountryCode;
	//private String resultFilePath;
	//private String projectPath;	

}
