package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.ProfileQuestionsDetails;
import com.seind.rc.services.user.data.ProfileQuestionsList;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.StatusResponse;
import com.seind.rc.services.user.entities.ProfileResultDetails;

public interface ProfileResultDetailsService {
	
	//ProfileResultDetails getProfileResultDetailsById(Long profileResultDetailId);

	//void saveOrUpdate(ProfileResultDetails profileResult);

	//ProfileResultDetails getProfileResultDetailsByUserAccountId(Long userAccountId);

	ResponseMessage updateProfileAboutMe(ProfileQuestionsList profileQues, Long loginUserId);

	ProfileQuestionsList getUserProfileQuestionsList(Long patientId);

	//String getBiographyQuestionAnswerInfoByPatientId(Long patientId);

	List<ProfileResultDetails> getProfileResultDetailsByPatientId(Long userAccountId);

}
