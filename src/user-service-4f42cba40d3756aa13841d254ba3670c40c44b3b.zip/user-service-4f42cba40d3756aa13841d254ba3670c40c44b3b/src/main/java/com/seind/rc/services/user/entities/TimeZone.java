package com.seind.rc.services.user.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "TimeZone")
public class TimeZone {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long zoneId;
	@Column(nullable = false)
	private String zoneName;
	@Column(nullable = false)
	private String zoneCode;
	@Column(nullable = false)
	private String displayName;
	@Column(nullable = false)
	private String uTCCode;
	@Column(nullable = false)
	private Boolean dayLightSaving;
	@Column(nullable = false)
	private String offset;

}
