package com.seind.rc.services.user.service.servicesimp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.repository.UserSecCodeAuditRepository;
import com.seind.rc.services.user.service.UserSecCodeAuditService;

@Service
public class UserSecCodeAuditServiceImpl implements UserSecCodeAuditService {

	private static final Logger LOGGER = LogManager.getLogger(UserSecCodeAuditServiceImpl.class);

	@Autowired
	private UserSecCodeAuditRepository userSecCodeRepo;

	@Override
	public void resetUserSecCodeAudit(Long userAccountId) {
		try {
			userSecCodeRepo.userSecCodeAuditUpdate(false, userAccountId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

	}

}
