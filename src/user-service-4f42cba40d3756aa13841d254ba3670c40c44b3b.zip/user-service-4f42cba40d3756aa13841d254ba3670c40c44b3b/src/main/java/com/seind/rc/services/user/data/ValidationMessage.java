package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class ValidationMessage {

	private boolean checkAllowed = true;
	private String Message;
}
