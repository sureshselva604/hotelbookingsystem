package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class UserRequestData {
	
	private Long userGroupId;
	private Long userAccountKey;
	private String userName;
	private String emailId;
	private List<Long> userGroupIdIN;

}
