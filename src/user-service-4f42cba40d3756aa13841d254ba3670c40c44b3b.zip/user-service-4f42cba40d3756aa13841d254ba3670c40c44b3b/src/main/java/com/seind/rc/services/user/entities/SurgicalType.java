package com.seind.rc.services.user.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "SurgicalType")
public class SurgicalType {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long surgicalTypeId;
	private String surgicalTypeName;
	private String description;
	private Date createdDate;

}
