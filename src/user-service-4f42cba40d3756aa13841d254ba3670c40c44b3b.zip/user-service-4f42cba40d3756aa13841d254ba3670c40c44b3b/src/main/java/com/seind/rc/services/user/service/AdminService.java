package com.seind.rc.services.user.service;

import com.seind.rc.services.user.data.ClientDashboardData;

public interface AdminService {

	ClientDashboardData clientDashboardData(Long hospitalId);

	ClientDashboardData getDashBoardCount();

}
