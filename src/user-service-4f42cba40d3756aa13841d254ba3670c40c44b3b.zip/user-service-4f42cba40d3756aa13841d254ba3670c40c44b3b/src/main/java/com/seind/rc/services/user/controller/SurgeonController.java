package com.seind.rc.services.user.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.data.SurgeonData;
import com.seind.rc.services.user.service.SurgeonService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

/**
 * C08
 */
@CrossOrigin
@RestController
@RequestMapping("/api/v1/surgeon")
@RequiredArgsConstructor
public class SurgeonController {

	private static final Logger LOGGER = LogManager.getLogger(SurgeonController.class);

	@Autowired
	private SurgeonService surgeonService;

//	@Autowired
//	private UserAccountService userAccountService;

//	/**
//	 * Get surgeon list for hospital
//	 */
//	@Operation(summary = "Get surgeon list for hospital")
//	@PostMapping(value = "/getSurgeonList")
//	public List<SurgeonData> getSurgeonList(@RequestBody HospitalRequestData objData) {
//		List<SurgeonData> surgeonData = null;
//		try {
//			surgeonData = surgeonService.getSurgeonList(objData.getHospitalId());
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return surgeonData;
//	}

	/**
	 * Surgeon data for device sync
	 */
//	@Operation(summary = "Surgeon data for device sync")
//	@PostMapping(value = "/getSurgeonInfoByPatientId")
//	public List<String> getSurgeonInfoByPatientId(@RequestBody CommonObjectData objData) {
//		UserAccount userAccount = null;
//		Surgeon surgeon = null;
//		List<String> response = new ArrayList<String>();
//		try {
//			for (Long sugId : objData.getSurgeonUserAccountId()) {
//				userAccount = userAccountService.getUserAccountByUserAccountId(sugId);
//				Long userAccountkey = userAccount.getUserAccountKey();
//				surgeon = surgeonService.getSurgeonById(userAccountkey);
//				response.add(surgeon.toString());
//			}
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage());
//		}
//		return response;
//	}

	/**
	 * Retrieves a list of surgeons associated with the given hospital ID.
	 *
	 * @param hospitalId The unique identifier of the hospital.
	 * @return A List of SurgeonData objects representing surgeons associated with
	 *         the hospital.
	 */
	@Operation(summary = "Get surgeon list for hospital Id")
	@GetMapping(value = "/getSurgeonsByHospitalId/{hospitalId}")
	public List<SurgeonData> getSurgeonList(@PathVariable("hospitalId") Long hospitalId) {
		List<SurgeonData> surgeonData = null;
		try {
			surgeonData = surgeonService.getSurgeonList(hospitalId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return surgeonData;
	}

}
