package com.seind.rc.services.user.data;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserGroupPrivilegeData {

	private Long sequenceNo;
	private Integer menuId;
	private String name;
	private String refName;
	private Boolean status;
	private Boolean isView;
	private Boolean isEdit;

}
