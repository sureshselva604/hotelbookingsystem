package com.seind.rc.services.user.data;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserCcDashBoard {
	private Long userAccountId;
	private Long hospitalId;
	private Long patientId;
	private Long useraccountkey;
	private Long userId;
	private String stykerAdminId;
	private Long patientSwfId;
}

