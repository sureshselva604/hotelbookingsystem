package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class CareServiceData {
	
	
	private List<Long>patientIds;
	private Long cpPatientId;
	

}
