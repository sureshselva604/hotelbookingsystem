package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.seind.rc.services.user.entities.UserSecTransAudit;

import jakarta.transaction.Transactional;

@Transactional
public interface UserSecTransAuditRepository extends JpaRepository<UserSecTransAudit, Long> {

	List<UserSecTransAudit> findTop1ByModeAndUserAccount_UserAccountIdOrderByUserSecTransAuditIdDesc(String mode,
			Long userAccountId);

	List<UserSecTransAudit> findUserAccountByRandomIdAndModeAndIsActive(String randId, String mode, Boolean active);

	List<UserSecTransAudit> findByUserAccount_UserAccountIdAndModeAndIsActive(Long userAccountId, String mode,
			Boolean active);

	UserSecTransAudit findByRandomIdAndIsActive(String randId, boolean isActive);

	@Modifying
	@Query(value = "update UserSecTransAudit set isactive=0 where UserAccountId = :userAccountId and mode In :mode ", nativeQuery = true)
	int userSecTransAuditActiveUpdate(@Param("userAccountId") Long userAccountId, @Param("mode") List<String> mode);

	@Modifying
	@Query(value = "update UserSecTransAudit set RandomId = :randomId  where UserAccountId = :userAccountId and mode = :mode and isactive = 1", nativeQuery = true)
	int userSecTransAuditRandomIdUpdate(@Param("randomId") String randomId, @Param("userAccountId") Long userAccountId,
			@Param("mode") String mode);

	UserSecTransAudit findByRandomId(String randId);

	List<UserSecTransAudit> findByUserAccount_UserAccountIdAndModeAndIsActive(Long userAccountId, String mode,
			boolean isActive);

	@Modifying
	@Query(value = "update UserSecTransAudit set isactive=0 where UserSecTransAuditId = :userSecTransAuditId ", nativeQuery = true)
	int userSecTransAuditActiveUpdate2(@Param("userSecTransAuditId") Long userSecTransAuditId);

	List<UserSecTransAudit> findByRandomIdAndModeAndIsActive(String randId, String mode, boolean b);

	List<UserSecTransAudit> findByUserAccount_UserAccountIdAndMode(Long userAccountId, String mode);

	List<UserSecTransAudit> findByUserAccount_UserAccountIdOrderByCreatedOnDesc(Long userId);

	@Modifying
	@Query(value = "update UserSecTransAudit set isActive=0 where userAccountId= :userAccountId and mode= :mode", nativeQuery = true)
	void updateUserSecTransAudit(@Param("userAccountId") Long userAccountId, @Param("mode") String mode);
	
	@Modifying
	@Query(value = "update UserSecTransAudit set isactive=0 where UserAccountId = :userAccountId ", nativeQuery = true)
	void updateUserSecTransAuditActiveByUserId(@Param("userAccountId") Long userAccountId);
	
	@Modifying
	@Query(value = "update UserSecTransAudit set isactive= :active where UserAccountId = :userAccountId and mode = :mode and Otp = :otp", nativeQuery = true)
	void updateUserSecTransAuditActiveByModeAndOtp(@Param("active") Boolean active,
			@Param("userAccountId") Long userAccountId, @Param("mode") String mode, @Param("otp") String otp);

}
