package com.seind.rc.services.user.data;

import java.util.Date;

public class DashboardCareplanDetail {
	private Long patientPacMasterMapId;
	private Long exactPatientPacId;

	private int id;
	private String caseManager;
	private String dos;

	private String status;
	private boolean serverdata;

	private boolean isHospitalStay;
	private String hospitalName;

	private Date anonymousDischargeDate;
	private Date anonymousSnfDischargeDate;

	private Date anonymousAdmissionDateFm;
	private Date anonymousSnfDischargeDateFm;

	private Long anonymousDischargeId;
	private Long anonymousDischargeHospitalMasterId;

	private String anonymousDischargePhone;
	private String anonymousDischargeTeleCode;
	private String anonymousDischargeTeleCountryCode;
	private String anonymousDischargeLocContact;

	private int anonymousLos;
	private String dischargeTo;
	private String dischargeType;
	private String patientDbScore;

	/** public List<NonDayBasedDischargeFacility> nonDayBasedDiscFacility; **/

	private Date anonymousAdmissionDate;

	private String anonymousVisit;
	private String anonymousOtherSelectedName;

	private String anonymousDischargeTypeForOther;

	private boolean trackActualVisible;
	private boolean pacFinished;

	private boolean tab;
	private boolean isAutoSortDateValid;

	private boolean visitShown;

	private boolean isAnonymousOtherPacTurnedOn = true;
	private Long anonymousHospitalOtherPacMapId = 0l;
	private String anonymousOtherPacContact;
	private String anonymousOtherPacTeleCode;
	private String anonymousOtherPacTeleCountryCode;
	private String anonymousOtherPacPhone;
	private String anonymousOtherFreeText;
	private Long anonymousOtherPacMasterId;

	private Long createdBy;
	private Date createdDate;

	private String message;

	private boolean anonymouseventTypeRedAlert = false;
	private boolean anonymousfacilitynameRedAlert = false;
	private boolean anonymousstartdateRedAlert = false;
	private boolean anonymousenddateRedAlert = false;

	private String plannedHospitalDischargeName;
	private String actualHospitalDischargeName;
	private String plannedDischargeType;
	private String actualDischargeType;

	private Long readmissionId;
	private String raReason;
	private String raOtherReason;
	private boolean raUpComingClear;
	private boolean isHospitalRA;
	private String todoCarePlanIds;
	private String raOtherHspName;
	private String anonymousHtOtherHspName;

	private int plannedLosDiff;
	private int actualLosDiff;

	private boolean existingRaChanged;
	private String existingReadmissionDate;

	private String raIdentity;
	private String anonymousPrevDiscTypeId;

	private Long actualPacDoneBy;
	private Date actualPacDoneOn;
	private boolean edvisitFlag;

	public DashboardCareplanDetail() {
	}

	public DashboardCareplanDetail(DashboardCareplanDetail dashboardCareplanDetail) {
		super();
		this.patientPacMasterMapId = dashboardCareplanDetail.patientPacMasterMapId;
		this.exactPatientPacId = dashboardCareplanDetail.exactPatientPacId;
		this.id = dashboardCareplanDetail.id;
		this.caseManager = dashboardCareplanDetail.caseManager;
		this.dos = dashboardCareplanDetail.dos;
		this.status = dashboardCareplanDetail.status;
		this.serverdata = dashboardCareplanDetail.serverdata;
		this.isHospitalStay = dashboardCareplanDetail.isHospitalStay;
		this.hospitalName = dashboardCareplanDetail.hospitalName;
		this.anonymousDischargeDate = dashboardCareplanDetail.anonymousDischargeDate;
		this.anonymousSnfDischargeDate = dashboardCareplanDetail.anonymousSnfDischargeDate;
		this.anonymousAdmissionDateFm = dashboardCareplanDetail.anonymousAdmissionDateFm;
		this.anonymousSnfDischargeDateFm = dashboardCareplanDetail.anonymousSnfDischargeDateFm;
		this.anonymousDischargeId = dashboardCareplanDetail.anonymousDischargeId;
		this.anonymousDischargeHospitalMasterId = dashboardCareplanDetail.anonymousDischargeHospitalMasterId;
		this.anonymousDischargePhone = dashboardCareplanDetail.anonymousDischargePhone;
		this.anonymousDischargeTeleCode = dashboardCareplanDetail.anonymousDischargeTeleCode;
		this.anonymousDischargeTeleCountryCode = dashboardCareplanDetail.anonymousDischargeTeleCountryCode;
		this.anonymousDischargeLocContact = dashboardCareplanDetail.anonymousDischargeLocContact;
		this.anonymousLos = dashboardCareplanDetail.anonymousLos;
		this.dischargeTo = dashboardCareplanDetail.dischargeTo;
		this.dischargeType = dashboardCareplanDetail.dischargeType;
		this.patientDbScore = dashboardCareplanDetail.patientDbScore;

		this.anonymousAdmissionDate = dashboardCareplanDetail.anonymousAdmissionDate;
		this.anonymousVisit = dashboardCareplanDetail.anonymousVisit;
		this.anonymousOtherSelectedName = dashboardCareplanDetail.anonymousOtherSelectedName;
		this.anonymousDischargeTypeForOther = dashboardCareplanDetail.anonymousDischargeTypeForOther;

		this.trackActualVisible = dashboardCareplanDetail.trackActualVisible;
		this.pacFinished = dashboardCareplanDetail.pacFinished;
		this.tab = dashboardCareplanDetail.tab;
		this.isAutoSortDateValid = dashboardCareplanDetail.isAutoSortDateValid;
		this.visitShown = dashboardCareplanDetail.visitShown;
		this.isAnonymousOtherPacTurnedOn = dashboardCareplanDetail.isAnonymousOtherPacTurnedOn;
		this.anonymousHospitalOtherPacMapId = dashboardCareplanDetail.anonymousHospitalOtherPacMapId;
		this.anonymousOtherPacContact = dashboardCareplanDetail.anonymousOtherPacContact;
		this.anonymousOtherPacTeleCode = dashboardCareplanDetail.anonymousOtherPacTeleCode;
		this.anonymousOtherPacTeleCountryCode = dashboardCareplanDetail.anonymousOtherPacTeleCountryCode;
		this.anonymousOtherPacPhone = dashboardCareplanDetail.anonymousOtherPacPhone;
		this.anonymousOtherFreeText = dashboardCareplanDetail.anonymousOtherFreeText;
		this.anonymousOtherPacMasterId = dashboardCareplanDetail.anonymousOtherPacMasterId;
		this.createdBy = dashboardCareplanDetail.createdBy;
		this.createdDate = dashboardCareplanDetail.createdDate;
		this.message = dashboardCareplanDetail.message;
		this.anonymouseventTypeRedAlert = dashboardCareplanDetail.anonymouseventTypeRedAlert;
		this.anonymousfacilitynameRedAlert = dashboardCareplanDetail.anonymousfacilitynameRedAlert;
		this.anonymousstartdateRedAlert = dashboardCareplanDetail.anonymousstartdateRedAlert;
		this.anonymousenddateRedAlert = dashboardCareplanDetail.anonymousenddateRedAlert;
		this.plannedHospitalDischargeName = dashboardCareplanDetail.plannedHospitalDischargeName;
		this.actualHospitalDischargeName = dashboardCareplanDetail.actualHospitalDischargeName;
		this.plannedDischargeType = dashboardCareplanDetail.plannedDischargeType;
		this.actualDischargeType = dashboardCareplanDetail.actualDischargeType;
		this.readmissionId = dashboardCareplanDetail.readmissionId;
		this.raReason = dashboardCareplanDetail.raReason;
		this.raOtherReason = dashboardCareplanDetail.raOtherReason;
		this.raUpComingClear = dashboardCareplanDetail.raUpComingClear;
		this.isHospitalRA = dashboardCareplanDetail.isHospitalRA;
		this.todoCarePlanIds = dashboardCareplanDetail.todoCarePlanIds;
		this.raOtherHspName = dashboardCareplanDetail.raOtherHspName;
		this.anonymousHtOtherHspName = dashboardCareplanDetail.anonymousHtOtherHspName;
		this.plannedLosDiff = dashboardCareplanDetail.plannedLosDiff;
		this.actualLosDiff = dashboardCareplanDetail.actualLosDiff;
		this.existingRaChanged = dashboardCareplanDetail.existingRaChanged;
		this.existingReadmissionDate = dashboardCareplanDetail.existingReadmissionDate;
		this.raIdentity = dashboardCareplanDetail.raIdentity;
		this.anonymousPrevDiscTypeId = dashboardCareplanDetail.anonymousPrevDiscTypeId;
		this.actualPacDoneBy = dashboardCareplanDetail.actualPacDoneBy;
		this.actualPacDoneOn = dashboardCareplanDetail.actualPacDoneOn;
		this.edvisitFlag = dashboardCareplanDetail.edvisitFlag;
	}
}