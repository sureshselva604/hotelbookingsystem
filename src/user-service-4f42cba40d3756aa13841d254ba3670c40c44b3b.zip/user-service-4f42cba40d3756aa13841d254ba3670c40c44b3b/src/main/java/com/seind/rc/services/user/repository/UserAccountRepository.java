package com.seind.rc.services.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.seind.rc.services.user.data.TodoHospitalOverlapBean;
import com.seind.rc.services.user.entities.UserAccount;

import feign.Param;
import jakarta.transaction.Transactional;

@Transactional
public interface UserAccountRepository extends JpaRepository<UserAccount, Long> {

	List<UserAccount> findByUserAccountKey(Long userAccountKey);

	UserAccount findByUserAccountIdAndUserGroupUserGroupId(Long userAccountId, Long userGroupId);

	List<UserAccount> findByUserName(String userName);

	List<UserAccount> findByPhone(String phone);

	List<UserAccount> findByEmail(String email);

	List<UserAccount> findByphoneWithTeleCodeAndUserAccountId(String oldPhone, Long UserAccountId);

	List<UserAccount> findByEmailAndUserAccountIdNot(String email, Long userAccountId);

	List<UserAccount> findByEmailAndUserGroup_UserGroupIdAndUserAccountIdNot(String email, Long userGroupId,
			Long userId);

	List<UserAccount> findUserAccountIdByEmail(String email);

	List<UserAccount> findByTeleCodeAndPhone(String teleCode, String phone);

	UserAccount findByUserAccountIdAndUserGroup_UserGroupId(Long userAccountId, Long userGroupId);

	UserAccount findByUserGroup_UserGroupIdAndEmailLike(Long userGroupId, String email);

	UserAccount findByUserGroup_UserGroupIdAndPhoneLike(Long userGroupId, String phone);

	List<UserAccount> findByPhoneAndTeleCode(String phone, String telecode);

	Optional<UserAccount> findUserAccountIdByUserNameOrEmail(String userName, String email);

	List<UserAccount> findByUserNameOrEmailAndUserGroup_UserGroupIdNotIn(String userName, String userName2,
			Long[] grpId);

	List<UserAccount> findByUserGroup_UserGroupId(Long userGroupId);

	List<UserAccount> findByUserAccountKeyIn(List<Long> userAccountKeys);
	
	int countByUserAccountKeyIn(List<Long> userAccountKeys);

	List<UserAccount> findByWhoseCarePartner(Long patientId);

	UserAccount findByUserAccountKeyAndUserGroup_GroupType(Long userAccountKey, String userGroupType);

	@Modifying
	@Query(nativeQuery = true, value = "update UserAccount set activationmode= :activationMode ,activationDate=getdate() where UserAccountId = :userAccountId")
	void userAccountActivationModeAndDateUpdate(@Param("userAccountId") Long userAccountId,
			@Param("activationMode") String activationMode);

	List<UserAccount> findByEmailOrPhoneAndTeleCode(String email, String phone, String teleCode);

	Optional<UserAccount> findByEmailAndUserGroup_UserGroupId(String email, Long carePartner);

	List<UserAccount> findByUserAccountKeyAndUserGroup_UserGroupIdNotIn(Long userAccountKey, Long[] grupIds);

	List<UserAccount> findByStrykerAct(boolean stykAct);

	List<UserAccount> findByUserAccountKeyAndAndUserGroup_UserGroupIdIn(Long userAccountKey, List<Long> userGroupIdIN);

	Optional<UserAccount> findByUserAccountKeyAndUserGroup_UserGroupId(Long patientId, Long userGroupId);

	List<UserAccount> findByUserGroupUserGroupIdAndEmailLike(Long userGroupId, String email);

	List<UserAccount> findByUserGroupUserGroupIdAndPhoneLike(Long userGroupId, String phone);

	List<UserAccount> findByUserAccountIdInAndCareFamilyShowTrue(List<Long> groupBasedCn);

	List<UserAccount> findByUserAccountIdIn(List<Long> userAccountIds);

	List<UserAccount> findByUserAccountKeyAndCareFamilyShowTrueAndActiveTrue(Long userAccountKey);

	List<UserAccount> findByUserAccountIdInOrUserAccountIdIn(List<Long> hspccId, List<Long> hspSecId);

	List<UserAccount> findByUserAccountIdInAndUserGroup_UserGroupId(List<Long> hospitalIds, Long userGroupId);

	List<UserAccount> findByUserAccountIdAndUserGroup_UserGroupIdIn(Long psgId, List<Long> asList);

	List<UserAccount> findByUserAccountKeyInAndUserGroup_UserGroupId(List<Long> hospitalIds, Long userGroupId);

	@Modifying
	@Query(nativeQuery = true, value = "update UserAccount set Active= :active ,LastModifiedDate=getdate() where UserAccountId = :userAccountId")
	void updateUserAccountActiveAndLastModifiedDate(@Param("userAccountId") Long userAccountId,
			@Param("active") Boolean active);

	List<UserAccount> findByUserAccountKeyAndCareFamilyShowTrue(Long userAccountKey);

	List<UserAccount> findByEmailOrPhone(String email, String phone);

	List<UserAccount> findByRandomId(String randomId);

	List<UserAccount> findByUserGroup_UserGroupIdInAndEmailLike(List<Long> groupIds, String userName);

	List<UserAccount> findByUserGroup_UserGroupIdInAndPhoneLike(List<Long> groupIds, String userName);

	List<UserAccount> findDistinctByCareFamilyShowTrueAndUserAccountIdIn(List<Long> userAccountId);

	List<UserAccount> findByPhoneAndOtherPhoneAndUserAccountIdNot(String phone, String otherPhone, Long userId);

	List<UserAccount> findByEmailOrPhoneWithTeleCode(String email, String phoneNumber);

	List<UserAccount> findByUserAccountKeyAndUserGroup_UserGroupIdIn(Long psgId, List<Long> asList);

	List<UserAccount> findByUserAccountKeyAndUserGroupUserGroupId(Long userAccountKey, Long userGroupId);

	List<UserAccount> findByPhoneAndUserAccountIdNot(String newPhoneNo, Long userId);

	@Query(value = "SELECT NEW com.seind.rc.services.user.data.TodoHospitalOverlapBean(ua.userAccountId,ua.firstName,ua.lastName,ua.userGroupId,ug.groupName,0 as isCareNavigator,h.name) "
			+ " from  UserAccount ua join  HospitalPractice hp on hp.practiceId = ua.userAccountKey "
			+ " join UserGroup ug on ug.userGroupId = ua.userGroupId "
			+ " join Hospital h  on hp.practiceId=h.hospitalId and hp.isOverLap =true and ua.userGroupId in (17) "
			+ " where hp.practiceId = :practiceId and hp.hospitalId = :hospitalId ")
	List<TodoHospitalOverlapBean> practiceOverlap(@Param("practiceId") Long practiceId,@Param("hospitalId") Long hospitalId);
	
	@Query(value = "select ua.userAccountId,ua.firstName,ua.lastName ,ua.userGroupId,ug.groupName,1 as isCareNavigator,h.name "
			+ "	from PracticeCoordinatorHSPMapping pchs "
			+ "	join UserAccount ua on ua.userAccountId = pchs.pcUserid and pchs.pcUserid in ( "
			+ "	select distinct pcUserid from PracticeCoordinatorHSPMapping where hospitalId in ( "
			+ "	select hospitalId from PracticeCoordinatorHSPMapping where pcUserid = :loginUaId )) "
			+ "	join UserGroup ug  on ug.userGroupId = ua.userGroupId  "
			+ "	join hospital h on h.hospitalId = pchs.hospitalId  	order by  isCareNavigator desc ")
	List<Object[]> practiceOverlapUsergrpNotEqual(@Param("loginUaId") Long loginUaId);

	List<UserAccount> findByphoneWithTeleCode(String newPhone);

	List<UserAccount> findByEmailOrPhoneWithTeleCodeOrderByUserGroup_UserGroupIdAsc(String emailId,
			String phoneNumber);

	List<UserAccount> findByEmailOrderByUserGroup_UserGroupIdAsc(String emailId);

	List<UserAccount> findByUserNameContains(String string);

	List<UserAccount> findByPhoneWithTeleCodeOrderByUserGroup_UserGroupIdAsc(String phoneNumber);

	List<UserAccount> findByPhoneAndUserGroup_UserGroupIdAndUserAccountIdNot(String newPhoneNo, Long userGroupId, Long userId);
	
	List<UserAccount> findByEmailAndUserGroup_UserGroupIdNotAndUserAccountIdNot(String email, Long userGroupId,
			Long userId);

	int countByActiveTrue();
	
	List<UserAccount> findByUserAccountIdInAndActiveTrue(List<Long> userAccIds);

	List<UserAccount> findByActiveTrueAndUserPwdCreatedOnNotNullAndIsdeleteFalseAndWelcomeFlagFalseAndUserNameIsNotLikeAndComTypeAndHospital_AllowPatNotificationTrueAndHospital_TimeZoneZoneId(
			String userName, String comType, Long zoneId);
	
	List<UserAccount> findDistinctByUserAccountKeyAndUserGroup_UserGroupId(Long userAccKey,Long userGroupId);
	
	List<UserAccount> findByUserGroupIdAndUserAccountKey(Long usergroupId, Long useraccountkey);

	Optional<UserAccount> findByphoneWithTeleCodeAndUserGroup_UserGroupId(String phoneNo, Long groupId);

}
