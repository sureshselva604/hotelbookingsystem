package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class DownloadPacDocPatientData {

	private PatientStageWorkflowData patientStageWorkflowData;
	private PatientData patientData;
	private UserAccountData ccUserAccountdata;
	private UserAccountData sugUserAccountdata;
	private HospitalData hospitalData;
	private String laterity;
	private String hospitalName;
	private UserAccountData patUAccount;
	private List<CountryDischargeMapData> CountryDischargeMapList;
	private HospitalPraticeData hospitalPractice;
	private PatientDetails carePatnerDetails;
	private String realPath;


}
