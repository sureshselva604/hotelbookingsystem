package com.seind.rc.services.user.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.data.DownloadCareplanBean;
import com.seind.rc.services.user.data.LambdaBean;
import com.seind.rc.services.user.data.LambdaCcTodoCountBean;
import com.seind.rc.services.user.data.LambdaProSurveyBean;
import com.seind.rc.services.user.data.LambdaWelcomeMailData;
import com.seind.rc.services.user.data.NotifyAllPatsGoodByeMsgBean;
import com.seind.rc.services.user.data.PatDataforActivityNotifyBean;
import com.seind.rc.services.user.data.PdfLambdaBean;
import com.seind.rc.services.user.data.RemainderNotificaitonData;
import com.seind.rc.services.user.service.BatchNotificationService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/user/batchnotify")
@RequiredArgsConstructor
@CrossOrigin
public class BatchNotificationController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchNotificationController.class);

	private final BatchNotificationService batchNotificationService;

	@PostMapping("/fetchAllPatientsOneDayBeforeAppointmentsUserList")
	public List<LambdaBean> fetchAllPatientsOneDayBeforeAppointmentsUserList(@RequestBody List<Long> patientswfIdList) {
		List<LambdaBean> appointmentsUserList = new ArrayList<>();
		try {
			return appointmentsUserList = batchNotificationService
					.fetchAllPatientsOneDayBeforeAppointmentsUserList(patientswfIdList);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return appointmentsUserList;
	}

	@PostMapping("/fetchCareCardNotificationUserData")
	public List<LambdaBean> fetchCareCardNotificationUserData(@RequestBody List<Long> patientswfIdList) {
		List<LambdaBean> lambdaBeanList = new ArrayList<>();
		try {
			return lambdaBeanList = batchNotificationService.fetchCareCardNotificationUserData(patientswfIdList);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return lambdaBeanList;
	}

	@PostMapping("/fetchExerciseVideoUserData")
	List<LambdaBean> fetchExerciseVideoUserData(@RequestBody List<Long> patientswfIdList) {
		List<LambdaBean> execiseVideoList = new ArrayList<>();
		try {
			return execiseVideoList = batchNotificationService.fetchExerciseVideoUserData(patientswfIdList);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return execiseVideoList;
	}
	
	@PostMapping("/fetchCareCardEngaementUserData")
	List<LambdaBean> fetchCareCardEngaementUserData(@RequestBody List<Long> patientswfIdList, Integer timeZoneId) {
		try {
			return batchNotificationService.fetchCareCardEngaementUserData(patientswfIdList, timeZoneId);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return null;
	}
	
	@PostMapping("/fetchDownLoadFullVersion")
	public List<PdfLambdaBean> fetchDownLoadFullVersion(@RequestBody DownloadCareplanBean downloadCareplanBean) {
		List<PdfLambdaBean> pdfLambdaBeanList = new ArrayList<>();
		try {
			return pdfLambdaBeanList = batchNotificationService.fetchDownLoadFullVersion(downloadCareplanBean);
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return pdfLambdaBeanList;
	}
	
	/** GoodByeMessgae **/
	@PostMapping("/executeGoodByeMessageNotification/{timeZoneId}")
	public List<NotifyAllPatsGoodByeMsgBean> executeGoodByeMessageNotification(
			@PathVariable("timeZoneId") Long timeZoneId) {
		List<NotifyAllPatsGoodByeMsgBean> notifyAllPatsGoodByeMsgBean = new ArrayList<>();
		try {
			notifyAllPatsGoodByeMsgBean = batchNotificationService.executeGoodByeMessageNotification(timeZoneId);
			return notifyAllPatsGoodByeMsgBean;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return notifyAllPatsGoodByeMsgBean;
	}
	
	@PostMapping("/updateGoodByeFlagForDeActivatedPatients/{deactivatedPatientSWFIdList}")
	public void updateGoodByeFlagForDeActivatedPatients(
			@PathVariable("deactivatedPatientSWFIdList") List<Long> deactivatedPatientSWFIdList) {
		try {
			batchNotificationService.updateGoodByeFlagForDeActivatedPatients(deactivatedPatientSWFIdList);
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
	}

	/** ActivityData **/
	@PostMapping("/getactivityDataNotification/{countryCodeId}/{timeZone}")
	public List<PatDataforActivityNotifyBean> getactivityDataNotification(
			@PathVariable("countryCodeId") Long countryCodeId, @PathVariable("timeZone") Long timeZone) {
		List<PatDataforActivityNotifyBean> patDataforActivityNotifyBeanList = new ArrayList<>();
		try {
			patDataforActivityNotifyBeanList = batchNotificationService.getactivityDataNotification(countryCodeId,
					timeZone);
			return patDataforActivityNotifyBeanList;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return patDataforActivityNotifyBeanList;
	}

	/** WELCOMEMAIL **/
	@PostMapping("/welcomeMailGenerator/{timeZoneId}/{createddaysdifference}")
	public List<LambdaWelcomeMailData> welcomeMailGenerator(@PathVariable("timeZoneId") Long timeZoneId,
			@PathVariable("createddaysdifference") String createddaysdifference) {
		try {
			List<LambdaWelcomeMailData> lambdaWelcomeMailDataList = batchNotificationService
					.welcomeMailGenerator(timeZoneId, createddaysdifference);
			return lambdaWelcomeMailDataList;
		} catch (Exception e) {
			LOGGER.info(CommonConstant.EXCEPTION);
		}
		return null;
	}
	
	/** REMINDER NOTIFICATION **/
	@PostMapping("/remainderNotificaiton/{timeZoneId}")
	public List<RemainderNotificaitonData> remainderNotificaiton(@PathVariable("timeZoneId") Long timeZoneId) {
		try {
			List<RemainderNotificaitonData> remainderNotificaitonData = batchNotificationService
					.remainderNotificaiton(timeZoneId);
			return remainderNotificaitonData;
		} catch (Exception e) {
			e.getMessage();
		}
		return null;
	}
	
	/** LAMBDA TODO **/
	@PostMapping("/fetchLambdaCCList/{timeZoneId}")
	public LambdaCcTodoCountBean fetchLambdaCCList(@PathVariable("timeZoneId") Long timeZoneId) {
		try {
			LambdaCcTodoCountBean LambdaCcTodoCountBean = batchNotificationService.fetchLambdaCCList(timeZoneId);
			return LambdaCcTodoCountBean;
		} catch (Exception e) {
			e.getMessage();
		}
		return null;
	}
	
	/** LAMBDA PROSERVEY **/
	@PostMapping("/fetchAllPatientsTodoPROSurveyReminder/{timeZoneId}")
	public List<LambdaProSurveyBean> fetchAllPatientsTodoPROSurveyReminder(@PathVariable("timeZoneId") Long timeZoneId){
		try {
			List<LambdaProSurveyBean> lambdaProSurveyBeanList = batchNotificationService.fetchAllPatientsTodoPROSurveyReminder(timeZoneId);
			return lambdaProSurveyBeanList;
		}catch (Exception e) {
			e.getMessage();
		}
		return null;
	}
}
