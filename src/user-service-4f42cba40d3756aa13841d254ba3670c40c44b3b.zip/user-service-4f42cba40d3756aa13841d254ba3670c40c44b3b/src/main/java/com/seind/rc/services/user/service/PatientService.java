package com.seind.rc.services.user.service;

import com.seind.rc.services.user.entities.UserAccount;

public interface PatientService {

	int activeBodypart(Long patientId);

	int activePatientBodypartforCP(Long userAccountId);

	UserAccount getPatientUserAccountByPatientSWFId(Long patientswfId);

	UserAccount getUserAccountDetailsByPatientIdAndUserGroupId(Long patientId);

}
