package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.seind.rc.services.user.entities.UserSecResultDetails;

import jakarta.transaction.Transactional;

@Transactional
public interface UserSecResDetRepository extends JpaRepository<UserSecResultDetails, Long>{

	List<UserSecResultDetails> findByUserAccountIdOrderByUserSecResultDetailsIdDesc(Long userAccountId);
	
	List<UserSecResultDetails> findByUserAccountId(Long userAccountId);

	List<UserSecResultDetails> findByUserAccountIdIn(List<Long> userAccountIds);
	
	@Modifying
	@Query(value = "UPDATE UserSecResultDetails SET wrongAnswerAttempts = :count WHERE userSecResultDetailsId = :userSecId", nativeQuery = true)
	Integer updateSecurityQuestionAttemptsBothSingleAndMultiRole(@Param("userSecId") Long userSecId,
			@Param("count") int count);
	
	@Modifying
	@Query(value = "UPDATE UserSecResultDetails SET wrongAnswerAttempts = :count WHERE userAccountId = :userAccountId", nativeQuery = true)
	Integer updateSecurityQuesAttempts(@Param("userAccountId") Long userAccountId,
			@Param("count") int count);
	
	
	
}
