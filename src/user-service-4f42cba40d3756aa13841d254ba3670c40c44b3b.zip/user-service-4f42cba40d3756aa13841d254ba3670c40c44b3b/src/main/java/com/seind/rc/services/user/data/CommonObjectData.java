package com.seind.rc.services.user.data;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
public class CommonObjectData {

	private Long userAccountId;
	private Long cnUserId;
	private String userName;
	private Long patientId;
	private Long hospitalId;
	private Long userGroupId;
	private Long carePartnerId;
	private Long userAccountKey;
	private Long cnAccountId;
	private List<Long> surgeonUserAccountId;
	private String mode;
	private int superClientId;
	private String emailId;
	private String userPassword;
	private String encodedSecurityDict;
    private String randId;
    private String newPassword;	
	private Long questionId;
	private String answer;
    private String wrongUserSecQuestionId;
    private List<String> tokenIds;
	private List<Long> patientSwfIdList;


}
