package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class SeqQuesSyncModel {
	
	private String questionOne;
	private String questionTwo;
	private String questionThree;
	
	private Long quesIdOne;
	private Long quesIdTwo;
	private Long quesIdThree;
	
	private String ansOne;
	private String ansTwo;
	private String ansThree;
}
