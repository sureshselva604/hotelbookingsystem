package com.seind.rc.services.user.service.servicesimp;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seind.rc.services.user.constants.CommonConstant;
import com.seind.rc.services.user.entities.UserAccount;
import com.seind.rc.services.user.entities.UserRequestAudit;
import com.seind.rc.services.user.repository.UserRequestAuditRepository;
import com.seind.rc.services.user.service.UserRequestAuditService;

@Service
public class UserRequestAuditServiceImpl implements UserRequestAuditService {

	private static final Logger LOGGER = LogManager.getLogger(UserRequestAuditServiceImpl.class);

	@Autowired
	private UserRequestAuditRepository userReqRepo;

	/**
	 * M01
	 */
	@Override
	public Long saveForgotSecurityAnsLinkDetails(UserAccount userAccount, String mode) {
		try {
			List<UserRequestAudit> userRequestAuditList = userReqRepo
					.findByUserAccount_UserAccountIdAndModeAndStatus(userAccount.getUserAccountId(), mode, "Pending");

			if (userRequestAuditList == null || userRequestAuditList.isEmpty()) {
				UserRequestAudit userRequestAudit = new UserRequestAudit();
				userRequestAudit.setUserAccount(userAccount);
				userRequestAudit.setMode(mode);
				userRequestAudit.setStatus("Pending");
				userRequestAudit.setCreatedOn(new Date());
				userReqRepo.save(userRequestAudit);
				return userRequestAudit.getUserRequestAuditId();
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstant.EXCEPTION, e);
		}
		return 0L;
	}

}
