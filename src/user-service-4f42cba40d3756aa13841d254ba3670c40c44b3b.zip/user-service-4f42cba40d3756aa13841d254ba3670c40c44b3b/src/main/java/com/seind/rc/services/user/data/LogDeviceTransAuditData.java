package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class LogDeviceTransAuditData {
	
	private Long patientId;
	private Long patientSwfId;
	private String moduleName;
	private String type;
	private String events;
	

}
