package com.seind.rc.services.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.UserPrivilege;

public interface UserPrivilegeRepository extends JpaRepository<UserPrivilege, Long>{
	
	List<UserPrivilege> findByUserId(Long userId);

}
