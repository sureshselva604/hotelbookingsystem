package com.seind.rc.services.user.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "HNSurgMapToClient")
public class HNSurgMapToClient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HNSurgMapToClientId", unique = true, nullable = false)
	private Long hNSurgMapToClientId;
	@Column(name = "HNSurgMapId")
	private Long hNSurgMapId;
	@Column(name = "HospitalId")
	private Long hospitalId;

}