package com.seind.rc.services.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seind.rc.services.user.entities.ShortURL;

public interface ShortURLRepository extends JpaRepository<ShortURL, Long> {

	ShortURL findByShortKey(String shortKey);

}
