package com.seind.rc.services.user.data;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ContactData {
	private String oldEmail;
	private String oldPhone;
	private String newEmail;
	private String newPhone;

}
