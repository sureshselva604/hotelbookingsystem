package com.seind.rc.services.user.data;

import java.util.List;

import lombok.Data;

@Data
public class PatientStatusDeviceData {

	private Long patientId;
	private String handshakekey;
	private List<PatientVitalData> patVitalData;

}
