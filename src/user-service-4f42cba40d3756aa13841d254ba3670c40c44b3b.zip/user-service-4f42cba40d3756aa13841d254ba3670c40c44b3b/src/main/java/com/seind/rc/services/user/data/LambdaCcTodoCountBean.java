package com.seind.rc.services.user.data;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class LambdaCcTodoCountBean {

	private List<LambdaCcListBean> LambdaCcListBeanList;
	
	private Map<String, List<Long>> cnTodoCountMap;
	}