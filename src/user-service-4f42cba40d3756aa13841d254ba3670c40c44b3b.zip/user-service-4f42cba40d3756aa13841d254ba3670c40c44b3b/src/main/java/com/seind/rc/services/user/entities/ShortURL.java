package com.seind.rc.services.user.entities;

import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ShortURL")
public class ShortURL {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long shortUrlId;
	private String longURL;
	private String shortKey;
	@Column(name = "UserAccountId", nullable = false)
	private Long userAccountId;
	private Date createdDate;

}
