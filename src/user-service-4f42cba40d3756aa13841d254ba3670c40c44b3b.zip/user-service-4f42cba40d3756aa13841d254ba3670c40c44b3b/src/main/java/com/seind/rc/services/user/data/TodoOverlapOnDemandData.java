package com.seind.rc.services.user.data;

import lombok.Data;

@Data
public class TodoOverlapOnDemandData {
	private OverlapViewOnDemandData overLapPatientDetail;
	private NonOverlapViewOnDemandData nonOverLapPatientDetail ;
	private String mode;
}
