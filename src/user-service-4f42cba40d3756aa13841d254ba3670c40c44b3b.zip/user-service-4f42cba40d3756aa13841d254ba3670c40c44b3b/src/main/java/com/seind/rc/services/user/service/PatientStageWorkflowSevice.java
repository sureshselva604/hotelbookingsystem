package com.seind.rc.services.user.service;

import java.util.List;

import com.seind.rc.services.user.data.PatientStageWorkflowData;
import com.seind.rc.services.user.entities.PatientStageWorkflow;

public interface PatientStageWorkflowSevice {

	PatientStageWorkflow getPatientStageWorkflowByPatientSWFId(Long patientSWFId);

	List<PatientStageWorkflow> getPatientStageWorkflowByPatientId(Long patientId);

	public List<PatientStageWorkflowData> getPatientStageWorkflowByPatientIdForDownLoad(Long patientId);
}
