package com.seind.rc.services.user.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@JsonIgnoreProperties({ "practiceId" })
@Entity
@Table(name = "Menu")
public class Menu {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "menuId", unique = true, nullable = false)
	private Integer menuId;
	private String name;
	private String refName;
	private String scrXhref;
	private String iconXhref;
	private Long sequenceNo;
	private Long userGroupId;

}
