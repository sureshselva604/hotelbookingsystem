package com.seind.rc.services.user.service;

import java.util.List;

import com.google.gson.JsonObject;
import com.seind.rc.services.user.data.CareFamilyGroupData;
import com.seind.rc.services.user.data.CareFamilyMessageData;
import com.seind.rc.services.user.data.CarePartnerMapData;
import com.seind.rc.services.user.data.CarePartnerMapRequestData;
import com.seind.rc.services.user.data.DeviceActivationData;
import com.seind.rc.services.user.data.DeviceLoginData;
import com.seind.rc.services.user.data.FcmTokenData;
import com.seind.rc.services.user.data.ForgotAttemptData;
import com.seind.rc.services.user.data.ForgotSecQuesData;
import com.seind.rc.services.user.data.HospitalDeviceData;
import com.seind.rc.services.user.data.MenuConfigData;
import com.seind.rc.services.user.data.PhoneTypeData;
import com.seind.rc.services.user.data.ProfileQuestionsData;
import com.seind.rc.services.user.data.ProfileResultDetailsData;
import com.seind.rc.services.user.data.ResetPatPassReq;
import com.seind.rc.services.user.data.ResponseMessage;
import com.seind.rc.services.user.data.SecurityCredentialData;
import com.seind.rc.services.user.data.TimeZoneData;
import com.seind.rc.services.user.data.UpdateCarePartnerMapData;
import com.seind.rc.services.user.data.UpdatePatientData;
import com.seind.rc.services.user.data.UpdateUserDeviceData;
import com.seind.rc.services.user.data.UserDeviceData;
import com.seind.rc.services.user.data.UserGroupData;
import com.seind.rc.services.user.data.UserSecAnsData;

import jakarta.servlet.http.HttpServletRequest;

public interface DeviceService {

	List<ProfileQuestionsData> getBiographyQuestionData();

	List<ProfileResultDetailsData> getBiographyQuestionAnswerData(Long ptientId);

	HospitalDeviceData getHopsitalDetailsByPatientId(Long patientId);

	List<PhoneTypeData> getPhoneType();

	List<TimeZoneData> getTimeZone();

	List<UserGroupData> getAllUserGroup();

	List<CarePartnerMapData> getActiveCarePartnerMap(Boolean isCarePartner, Long carePartnerId, Long patientId);

	CareFamilyGroupData getCareFamilyGroup(Long patientId, Long loginUserAccountId);

	boolean findHNPCforCarefamily(Long patientSWFId, Long userGroupId);

	CareFamilyMessageData getCareFamilyByMessageSent(CarePartnerMapRequestData carePartnerData);

	List<UserDeviceData> getUsersInfoByPatientId(Long patientId);

	ResponseMessage setForgetSucessAnswer(ForgotSecQuesData forgotData);

	ResponseMessage setForgotattemptFailed(ForgotAttemptData forgotData);

	ResponseMessage saveUserLoginAudit(DeviceLoginData deviceLoginData);

	ResponseMessage saveUserSecTransAudit(DeviceActivationData deviceActivationData);

	String getDeviceVersion(JsonObject json, HttpServletRequest request);

	ResponseMessage saveProfileResultDetails(List<ProfileResultDetailsData> profileResDataList);

	ResponseMessage setForgotattemptFailedUnregisteredUSer(List<ForgotAttemptData> forgotAttemtDataList);

	ResponseMessage resetPatientPassword(ResetPatPassReq patPassReq);

	ResponseMessage saveLoginAuditForLater(DeviceActivationData deviceActivationData);

	ResponseMessage getPassWordUpdatebyPatient(UserSecAnsData userSecAnsData);

	ResponseMessage saveFcmToken(FcmTokenData fcmToken);

	ResponseMessage updateUserDataDeviceSync(List<UpdateUserDeviceData> userData);

	ResponseMessage updateCarePartnerMap(UpdateCarePartnerMapData updateCP);

	ResponseMessage deactivateSecurityCredentialsByMode(SecurityCredentialData secCredential);

	ResponseMessage updatePatient(List<UpdatePatientData> updatePatient);
	
	String getContactUsHtml(Long patientId);
	
	List<MenuConfigData> getContactUsJson(Long patientId);

}
