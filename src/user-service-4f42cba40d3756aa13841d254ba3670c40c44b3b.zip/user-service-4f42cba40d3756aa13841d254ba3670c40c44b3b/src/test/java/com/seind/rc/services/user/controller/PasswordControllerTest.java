/**
 * 
 */
package com.seind.rc.services.user.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 */
@SpringBootTest
@AutoConfigureMockMvc
class PasswordControllerTest {

	@Autowired
	MockMvc mockMvc;

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#getForgotSecurityAnswerByUser(com.seind.rc.services.user.data.UpdatePwdData)}.
	 * 
	 * @throws Exception
	 */
	@Test
	void testForgotSecurityAnswerByUser() throws Exception {
		testForgotSecurityAnswerByUserNotDeleted();
		testForgotSecurityAnswerByUserDeleted();
	}

	@Test
	@Transactional
	@Rollback
	void testForgotSecurityAnswerByUserNotDeleted() throws Exception {
		String uri = "/api/v1/password/getForgotSecurityAnswerByUser";
		String request = "{\"randId\":\"652ef2dc-753f-495f-82bf-dcdbc428e147\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.success").value("Please Contact to CSR Team"));
	}

	@Test
	void testForgotSecurityAnswerByUserDeleted() throws Exception {
		String uri = "/api/v1/password/getForgotSecurityAnswerByUser";
		String request = "{\"randId\":\"66c956a9-275d-4fad-9c41-48afd139ab8e\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.fail").value("Account De-Activated"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#isValidSecurityDict(com.seind.rc.services.user.data.UpdatePwdData)}.
	 */
	@Test
	void testIsValidSecurityDict() throws Exception {
		testIsValidSecurityDictSuccess();
		testInValidSecurityDict();
	}

	void testIsValidSecurityDictSuccess() throws Exception {
		String uri = "/api/v1/password/isValidSecurityDict";
		String request = "{\"encodedSecurityDict\":\"RGF2ZUAxMQ==\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.message").value("Valid Security Dict"))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Success"));
	}

	void testInValidSecurityDict() throws Exception {
		String uri = "/api/v1/password/isValidSecurityDict";
		String request = "{\"encodedSecurityDict\":\"RGVtb0AxMjM=\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.message").value("Please try a Different Password"))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Failure"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#isLastUsedPassword(com.seind.rc.services.user.data.PasswordRequestData, jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	void testIsLastUsedPassword() throws Exception {
		testPasswordNotUsedRecent();
		testPasswordusedRecent();
	}

	void testPasswordNotUsedRecent() throws Exception {
		String uri = "/api/v1/password/isLastUsedPassword";
		String request = "{\"userAccountId\":35,\"userPassword\":\"U3RhdGljQDg4NjY0NA==\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.message").value("Password can be used."))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Success"));

	}

	void testPasswordusedRecent() throws Exception {
		String uri = "/api/v1/password/isLastUsedPassword";
		String request = "{\"userAccountId\":35,\"userPassword\":\"U3RhdGljQDEyMw==\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value(
						"This password was recently used. Please create a password that is different from your last 5 passwords."))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Failure"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#savePasswordHistory(com.seind.rc.services.user.data.PasswordRequestData, jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testSavePasswordHistory() throws Exception {
		String uri = "/api/v1/password/savePwdHistory";
		String request = "{\"userAccountId\":36,\"userPassword\":\"RGF2ZUAxMjM=\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Success"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#resetPassword(com.seind.rc.services.user.data.UserRequestData)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testResetPassword() {
		testResetPasswordEmailEmpty();
		testResetPasswordInvalidEmail();
		testResetPasswordPatientPswIsActiveFalse();
		testResetPasswordUserAccountIsActiveFalse();
		testResetPasswordUserAccountIsDeletedTrue();
		testResetPasswordUserAccountWelcomeFlagTrue();
		testResetPasswordUserAccountWelcomeFlagFalse();
	}

	@Test
	void testResetPasswordEmailEmpty() {
		try {
			String uri = "/api/v1/password/resetpassword";
			String req = "{\"emailId\":\"\"}";
			String res = "{\"message\":\"Email Required\",\"status\":\"Failure\"}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk()).andExpect(content().string(res));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void testResetPasswordInvalidEmail() {
		try {
			String uri = "/api/v1/password/resetpassword";
			String req = "{\"emailId\":\"Lori1@mail.com\"}";
			String res = "{\"message\":\"Invalid email address!\",\"status\":\"Failure\"}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk()).andExpect(content().string(res));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void testResetPasswordPatientPswIsActiveFalse() {
		try {
			String uri = "/api/v1/password/resetpassword";
			String req = "{\"emailId\":\"test11@rc.in\"}";
			String res = "{\"message\":\"Your account has been deactivated. If you have any questions, please contact patient care.\",\"status\":\"Failure\"}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk()).andExpect(content().string(res));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@Transactional
	@Rollback
	void testResetPasswordUserAccountIsActiveFalse() {
		try {
			String uri = "/api/v1/password/resetpassword";
			String req = "{\"emailId\":\"Debra@mail.com\"}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk())
					.andExpect(jsonPath("$.message").value(
							"Your account has been locked. Please email patientcare@myrecoverycoach.com or call (833) 419-2509 to unlock your account."))
					.andExpect(jsonPath("$.status").value("Success"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@Transactional
	@Rollback
	void testResetPasswordUserAccountIsDeletedTrue() {
		try {
			String uri = "/api/v1/password/resetpassword";
			String req = "{\"emailId\":\"Noah1@mail.com\"}";
			String res = "{\"message\":\"Account De-Activated\",\"status\":\"Failure\"}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk()).andExpect(content().string(res));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@Transactional
	@Rollback
	void testResetPasswordUserAccountWelcomeFlagTrue() {
		try {
			String uri = "/api/v1/password/resetpassword";
			String req = "{\"emailId\":\"George@mail.com\"}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$.userName").value("George@mail.com"))
					.andExpect(jsonPath("$.status").value("Success"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@Transactional
	@Rollback
	void testResetPasswordUserAccountWelcomeFlagFalse() {
		try {
			String uri = "/api/v1/password/resetpassword";
			String req = "{\"emailId\":\"Andrew@mail.com\"}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk())
					.andExpect(jsonPath("$.message").value("Showing Security Questions & Answers By User"))
					.andExpect(jsonPath("$.status").value("Success")).andExpect(jsonPath("$.randId").isString())
					.andExpect(jsonPath("$.userName").value("Andrew@mail.com"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#getSelectedQuestnListByUser(com.seind.rc.services.user.data.UpdatePwdData)}.
	 */
	@Test
	void testGetSelectedQuestnListByUser() {
		try {
			String uri = "/api/v1/password/getSelectedQuestnListByUser";
			String req = "{\"randId\":\"71022808-5afd-4bbb-a3b5-28468feba0f2\",\"wrongUserSecQuestionId\":[2,16]}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$[0].userAccountId").value(10709))
					.andExpect(jsonPath("$[0].questionId").isNumber()).andExpect(jsonPath("$[0].question").isString())
					.andExpect(jsonPath("$[0].ans").isEmpty());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#UpdateUserPassWord(com.seind.rc.services.user.data.UpdatePwdData)}.
	 */
	@Test
	void testUpdateUserPassWord() throws Exception {
		testUpdateUserPassWordRandIdIsValid();
		testUpdateUserPassWordRandIdIsInvalid();
	}

	/**
	 * Case 1
	 * 
	 * When RandId is Valid
	 */
	@Test
	@Rollback
	@Transactional
	void testUpdateUserPassWordRandIdIsValid() throws Exception {
		try {
			String uri = "/api/v1/password/updateUserPassWord";
			String request = "{\"randId\":\"73c8a2ed-fd62-4da7-b550-e69446687b80\",\"newPassword\":\"cGFzc3dvcmRAMTI\"}";
			String response = "{\"userAccountId\":51,\"userGroupId\":19,\"userEmail\":\"giiiivvv@rc.in\",\"userName\":\"test nantha\",\"surgeonName\":\"Dr.Mishti one\",\"surgeonImage\":\"/dam/common/user_default.png\",\"surUserGroup\":\"Surgeon\",\"message\":\"True\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Case 2
	 * 
	 * When RandId is Invalid
	 */
	@Test
	void testUpdateUserPassWordRandIdIsInvalid() throws Exception {
		try {
			String uri = "/api/v1/password/updateUserPassWord";
			String request = "{\"randId\":\"13c8a30ad-aj62-3da7-b130-v69446687b30\",\"newPassword\":\"aVFzc3dvcmkAJTI\"}";
			String response = "{\"message\":\"Unauthorized Access\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#isAccountActiveORBlocked(com.seind.rc.services.user.data.UpdatePwdData)}.
	 */
	@Test
	void testIsAccountActiveORBlocked() throws Exception {
		testIsAccountNotDeletedAndActive();
		testIsAccountIsDeleted();
		testIsAccountNotDeletedAndBlocked();
	}

	void testIsAccountNotDeletedAndActive() throws Exception {
		String uri = "/api/v1/password/isAccountActiveORBlocked";
		String request = "{\"randId\":\"b88af019-f417-4e25-96a6-06283206fe8d\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Active")).andExpect(status().isOk())
				.andExpect(jsonPath("$.mode").value("ForgetPassword"));

	}

	void testIsAccountIsDeleted() throws Exception {
		String uri = "/api/v1/password/isAccountActiveORBlocked";
		String request = "{\"randId\":\"66c956a9-275d-4fad-9c41-48afd139ab8e\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Account De-Activated"))
				.andExpect(status().isOk()).andExpect(jsonPath("$.mode").value("ForgetPassword"));
	}

	void testIsAccountNotDeletedAndBlocked() throws Exception {
		String uri = "/api/v1/password/isAccountActiveORBlocked";
		String request = "{\"randId\":\"097895e2-03ca-46df-b447-fb398b0943ed\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Blocked")).andExpect(status().isOk())
				.andExpect(jsonPath("$.mode").value("ForgetPassword"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#validateSelectedQuestnAnsByUser(com.seind.rc.services.user.data.SecurityQuestionAnswerData)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testValidateSelectedQuestnAnsByUser() throws Exception {
		String uri = "/api/v1/password/validateSelectedQuestnAnsByUser";
		String request = "{\"randId\":\"e415c87f-88ab-47b1-9930-eb2cb5230b72\",\"questionId\":1,\"answer\":\"test\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.message").value("validation success"))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Success")).andExpect(status().isOk())
				.andExpect(jsonPath("$.randId").value("e415c87f-88ab-47b1-9930-eb2cb5230b72"));
	}

	@Test
	@Transactional
	@Rollback
	void testValidateSelectedQuestnAnsByUserWrongAns1() throws Exception {
		String uri = "/api/v1/password/validateSelectedQuestnAnsByUser";
		String request = "{\"randId\":\"e415c87f-88ab-47b1-9930-eb2cb5230b72\",\"questionId\":1,\"answer\":\"tes\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Answer is incorrect. You have 2 attempt(s) remaining"))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("WrongAnswer"));
	}

	@Test
	@Transactional
	@Rollback
	void testValidateSelectedQuestnAnsByUserWrongAns2() throws Exception {
		String uri = "/api/v1/password/validateSelectedQuestnAnsByUser";
		String request = "{\"randId\":\"56dd8040-7de0-4791-bc9a-91b9b939a787\",\"questionId\":13,\"answer\":\"test1\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Answer is incorrect. You have 1 attempt remaining"))
				.andExpect(jsonPath("$.status").value("WrongAnswer"));
	}

	@Test
	@Transactional
	@Rollback
	void testValidateSelectedQuestnAnsByUserWrongAns3() throws Exception {
		String uri = "/api/v1/password/validateSelectedQuestnAnsByUser";
		String request = "{\"randId\":\"92f74cf5-4f73-46f6-b5de-f428be8154c1\",\"questionId\":2,\"answer\":\"abd\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.message").value("Blocked"))
				.andExpect(jsonPath("$.status").value("WrongAnswer"));
	}

	@Test
	void testValidateSelectedQuestnAnsByUserAccountBlocked() throws Exception {
		String uri = "/api/v1/password/validateSelectedQuestnAnsByUser";
		String request = "{\"randId\":\"5e37c4cb-493a-40bd-b50d-79f1520213d3\",\"questionId\":18,\"answer\":\"DS\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value(
						"Your account has been locked. Please email patientcare@myrecoverycoach.com or call (833) 419-2509 to unlock your account."))
				.andExpect(jsonPath("$.status").value("Account Blocked"));
	}

	@Test
	void testValidateSelectedQuestnAnsByUserAccountDeleted() throws Exception {
		String uri = "/api/v1/password/validateSelectedQuestnAnsByUser";
		String request = "{\"randId\":\"66c956a9-275d-4fad-9c41-48afd139ab8e\",\"questionId\":1,\"answer\":\"hello\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.message").value("Account De-Activated"))
				.andExpect(jsonPath("$.status").value("Account De-Activated"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#saveSecurityQuestions(com.seind.rc.services.user.data.UserSecQuesObjData)}.
	 */
	@Test
	void testSaveSecurityQuestions() {
//		testSaveSecurityQuestionsScenario1();
		testSaveSecurityQuestionsScenario2();
	}

	/**
	 * case Scenario when randid use or update 1st time Return Success
	 * 
	 * @throws Exception
	 */
//	@Test
//	@Rollback
//	@Transactional
//	void testSaveSecurityQuestionsScenario1() {
//		try {
//			String saveSeQuesData = "{\"randId\":\"0e844455-ec42-4e8d-80a2-056caa79d40d\",\"activation\":true,\"secQuestionOne\":\"1\",\"secQuestionTwo\":\"3\",\"secQuestionThree\":\"2\",\"secQusAnswerOne\":\"hello\",\"secQusAnswerTwo\":\"java\",\"secQusAnswerThree\":\"spring\",\"activationMode\":\"AB\"}";
//			mockMvc.perform(post("/api/v1/password/saveSecurityQuestions").contentType(MediaType.APPLICATION_JSON)
//					.content(saveSeQuesData).accept(MediaType.APPLICATION_JSON))
//					.andExpect(jsonPath("$.status").value("Success"));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	/**
	 * case Scenario2 when randid already used or updated Return Failure
	 * 
	 * @throws Exception
	 */
//	@Test
	@Rollback
	@Transactional
	void testSaveSecurityQuestionsScenario2() {
		try {
			String saveSeQuesData = "{\"randId\":\"0e844455-ec42-4e8d-80a2-056caa79d40d\",\"activation\":true,\"secQuestionOne\":\"1\",\"secQuestionTwo\":\"3\",\"secQuestionThree\":\"2\",\"secQusAnswerOne\":\"hello\",\"secQusAnswerTwo\":\"java\",\"secQusAnswerThree\":\"spring\",\"activationMode\":\"AB\"}";
			mockMvc.perform(post("/api/v1/password/saveSecurityQuestions").contentType(MediaType.APPLICATION_JSON)
					.content(saveSeQuesData).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.status").value("Failure")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#getForgotPasswordInfo(com.seind.rc.services.user.data.UserRequestData)}.
	 */
	@Test
	void testGetForgotPasswordInfo() {
		testGetForgotPasswordInfoScenario1();
		testGetForgotPasswordInfoScenario2();
	}

	/**
	 * case Scenario1 when valid userName
	 * 
	 * @throws Exception
	 */
	@Test
	void testGetForgotPasswordInfoScenario1() {
		try {
			String pwdInfo = "{\"userName\":\"rr@rrj.co\"}";
			mockMvc.perform(post("/api/v1/password/getForgotPasswordInfo").contentType(MediaType.APPLICATION_JSON)
					.content(pwdInfo).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.status").value("Success"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * case Scenario2 when not valid userName
	 * 
	 * @throws Exception
	 */
	@Test
	void testGetForgotPasswordInfoScenario2() {
		try {
			String pwdInfo = "{\"userName\":\"rr@rj.co\"}";
			mockMvc.perform(post("/api/v1/password/getForgotPasswordInfo").contentType(MediaType.APPLICATION_JSON)
					.content(pwdInfo).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.status").value("Failure"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.PasswordController#changePassword(com.seind.rc.services.user.data.ChangePasswordData)}.
	 */
	@Test
	@Rollback
	@Transactional
	void testChangePassword() {
		testChangePasswordCase1();
		testChangePasswordCase2();
		testChangePasswordCase3();
		testChangePasswordCase4();
		testChangePasswordCase5();
		testChangePasswordCase6();
	}

	void testChangePasswordCase1() {
		try {
			String pwdInfo = "{\"oldPassword\":\"RGVtb0A1NTY2MTI=\",\"newPassword\":\"RGVtb0A1NTY2MTIz\",\"confirmPassword\":\"RGVtb0A1NTY2MTIz\"}";
			mockMvc.perform(post("/api/v1/password/changePassword").header("x-user", "459")
					.contentType(MediaType.APPLICATION_JSON).content(pwdInfo).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.message").value("Password changed successfully!"))
					.andExpect(jsonPath("$.status").value("Success")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void testChangePasswordCase2() {
		try {
			String pwdInfo = "{\"oldPassword\":\"RGVtb0AxMjM=\",\"newPassword\":\"RGVtb0A0NDU1\",\"confirmPassword\":\"RGVtb0A0NDU1\"}";
			mockMvc.perform(post("/api/v1/password/changePassword").header("x-user", "247")
					.contentType(MediaType.APPLICATION_JSON).content(pwdInfo).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.message").value("Account De-Activated"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void testChangePasswordCase3() {
		try {
			String pwdInfo = "{\"oldPassword\":\"RGVtb0AxMjM0\",\"newPassword\":\"RGVtb0A0NDU1\",\"confirmPassword\":\"RGVtb0A0NDU1\"}";
			mockMvc.perform(post("/api/v1/password/changePassword").header("x-user", "43")
					.contentType(MediaType.APPLICATION_JSON).content(pwdInfo).accept(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.message").value("Old password mismatch!"))
			.andExpect(jsonPath("$.status").value("Failure")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
   void testChangePasswordCase4() {
	   try {
			String pwdInfo = "{\"oldPassword\":\"RGVtb0AxMjM=\",\"newPassword\":\"RGVtb0AxMjM=\",\"confirmPassword\":\"RGVtb0A0NDU1\"}";
			mockMvc.perform(post("/api/v1/password/changePassword").header("x-user", "43")
					.contentType(MediaType.APPLICATION_JSON).content(pwdInfo).accept(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.message").value("New password does not match with confirm password!"))
			.andExpect(jsonPath("$.status").value("Failure")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
   }
   
   void testChangePasswordCase5() {
	   try {
			String pwdInfo = "{\"oldPassword\":\"RGVtb0AxMjM=\",\"newPassword\":\"RGVtb0AxMjM=\",\"confirmPassword\":\"RGVtb0AxMjM=\"}";
			mockMvc.perform(post("/api/v1/password/changePassword").header("x-user", "10686")
					.contentType(MediaType.APPLICATION_JSON).content(pwdInfo).accept(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.message").value("New password should not be same as old password!"))
			.andExpect(jsonPath("$.status").value("Failure")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
   }
   
   void testChangePasswordCase6() {
	   try {
			String pwdInfo = "{\"oldPassword\":\"RGVtb0AxMjM=\",\"newPassword\":\"RGVtb0A0NDU1\",\"confirmPassword\":\"RGVtb0A0NDU1\"}";
			mockMvc.perform(post("/api/v1/password/changePassword").header("x-user", "0")
					.contentType(MediaType.APPLICATION_JSON).content(pwdInfo).accept(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.message").value("UnAuthorzied Access"))
			.andExpect(jsonPath("$.status").value("Failure")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
   }
}
