/**
 * 
 */
package com.seind.rc.services.user.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 */
@SpringBootTest
@AutoConfigureMockMvc
class MyProfileControllerTest {

	@Autowired
	MockMvc mockMvc;

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#getQuestions()}.
	 */
	@Test
	void testGetQuestions() {
		try {
			String uri = "/api/v1/myprofile/getSecurityQuestionList";
			String response = "[{\"userSecQuestionsId\":1,\"question\":\"What is the first and last name of your first boyfriend or girlfriend?\"},{\"userSecQuestionsId\":2,\"question\":\"Which phone number do you remember most from your childhood?\"},{\"userSecQuestionsId\":3,\"question\":\"What was your favorite place to visit as a child?\"},{\"userSecQuestionsId\":4,\"question\":\"Who is your favorite actor, musician, or artist?\"},{\"userSecQuestionsId\":5,\"question\":\"What is the name of your favorite pet?\"},{\"userSecQuestionsId\":6,\"question\":\"In what city were you born?\"},{\"userSecQuestionsId\":7,\"question\":\"What high school did you attend?\"},{\"userSecQuestionsId\":8,\"question\":\"What is the name of your first school?\"},{\"userSecQuestionsId\":9,\"question\":\"What is your favorite movie?\"},{\"userSecQuestionsId\":10,\"question\":\"What is your mother's maiden name?\"},{\"userSecQuestionsId\":11,\"question\":\"What street did you grow up on?\"},{\"userSecQuestionsId\":12,\"question\":\"What was the make of your first car?\"},{\"userSecQuestionsId\":13,\"question\":\"When is your anniversary?\"},{\"userSecQuestionsId\":14,\"question\":\"What is your favorite color?\"},{\"userSecQuestionsId\":15,\"question\":\"What is your father's middle name?\"},{\"userSecQuestionsId\":16,\"question\":\"What is the name of your first-grade teacher?\"},{\"userSecQuestionsId\":17,\"question\":\"What was your high school mascot?\"},{\"userSecQuestionsId\":18,\"question\":\"Which is your favorite web browser?\"}]";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(""))
					.andDo(print()).andExpect(status().isOk()).andExpect(content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#getSecQuesAns(jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	void testGetSecQuesAns() {
		try {
			String uri = "/api/v1/myprofile/getSecQuesAns";
			String res = "[{\"questionId\":4,\"question\":\"Who is your favorite actor, musician, or artist?\",\"ans\":\"new\"},{\"questionId\":16,\"question\":\"What is the name of your first-grade teacher?\",\"ans\":\"service\"},{\"questionId\":14,\"question\":\"What is your favorite color?\",\"ans\":\"micro\"}]";
			mockMvc.perform(post(uri).header("x-user", "13").contentType(MediaType.APPLICATION_JSON).content(""))
					.andDo(print()).andExpect(status().isOk()).andExpect(content().string(res));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#getProfile(jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	void testGetProfile() throws Exception {
		testGetProfileOnPatient();
		testGetProfileOnCareCoordinator();
		testGetProfileOnCarePartner();
		testGetProfileXuserInvalid();
	}

	/**
	 * Case 1
	 * 
	 * Patient Profile
	 */
	void testGetProfileOnPatient() throws Exception {
		String uri = "/api/v1/myprofile/getProfile";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).header("x-user", 43))
				.andDo(print()).andExpectAll(status().isOk()).andExpect(jsonPath("$.userName").value("testt@rrc.com"))
				.andExpect(jsonPath("$.title").value("Patient")).andExpect(jsonPath("$.gender").value("Male"))
				.andDo(print());
	}

	/**
	 * Case 2
	 * 
	 * CareCoordinator Profile
	 */
	void testGetProfileOnCareCoordinator() throws Exception {
		String uri = "/api/v1/myprofile/getProfile";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).header("x-user", 28))
				.andDo(print()).andExpectAll(status().isOk()).andExpect(jsonPath("$.userName").value("Adam@mail.com"))
				.andExpect(jsonPath("$.title").value("Care Coordinator")).andExpect(jsonPath("$.gender").value("M"))
				.andDo(print());
	}

	/**
	 * Case 3
	 * 
	 * CarePartner Profile
	 */
	void testGetProfileOnCarePartner() throws Exception {
		String uri = "/api/v1/myprofile/getProfile";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).header("x-user", 289))
				.andExpectAll(status().isOk()).andExpect(jsonPath("$.userName").value("fghfh@mail.com"))
				.andExpect(jsonPath("$.relationship").value("Parent"))
				.andExpect(jsonPath("$.groupName").value("Care Partner")).andExpect(jsonPath("$.onBehalf").value(true))
				.andDo(print());
	}

	/**
	 * Case 4
	 * 
	 * When x-user is Invalid
	 */
	void testGetProfileXuserInvalid() {
		try {
			String uri = "/api/v1/myprofile/getProfile";
			String response = "";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).header("x-user", 1330)).andDo(print())
					.andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#updateAboutMe(com.seind.rc.services.user.data.ProfileQuestionsList, jakarta.servlet.http.HttpServletRequest)}.
	 * check the all answers save or updated in db
	 */
	@Test
	void testUpdateAboutMe() throws Exception {
		String profileData = "{\"profileQuestions\": [{\"questionId\": \"1\",\"question\": \"What does your care team need to know about you in order to provide better care?\",\"answer\": \"hi\" }, {\"questionId\": \"2\",\"question\": \"What are some of the things that define who you are as a person?\",\"answer\": \"Hello\" }, {\"questionId\": \"3\",\"question\": \"What do you like to do for fun?\",\"answer\": \"\" }, {\"questionId\": \"4\",\"question\": \"What do you need in order to feel comfortable?\",\"answer\": \"Welcome\" }]}";
		mockMvc.perform(post("/api/v1/myprofile/updateprofilequestions").contentType(MediaType.APPLICATION_JSON)
				.header("x-user", 63l).content(profileData).accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.status").value("Success")).andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#getUserProfileQuestionsList(jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	void testGetUserProfileQuestionsList() {
		testGetUserProfileQuestionsListScenario1();
		testGetUserProfileQuestionsListScenario2();
	}

	/**
	 * ProfileresultId in userAccount if NOT_NULL get all ANSWERs
	 * 
	 * @throws Exception
	 */
	@Test
	void testGetUserProfileQuestionsListScenario1() {
		try {
			mockMvc.perform(post("/api/v1/myprofile/getUserProfileQuestionsList")
					.contentType(MediaType.APPLICATION_JSON).header("x-user", 12l).accept(MediaType.ALL)).andDo(print())
					.andExpect(jsonPath("$.profileQuestions[0].questionId").value("1"))
					.andExpect(jsonPath("$.profileQuestions[0].answer").value("rf")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * ProfileresultId in userAccount if NULL ANSWER all returns Blank
	 * 
	 * @throws Exception
	 */
	@Test
	void testGetUserProfileQuestionsListScenario2() {
		try {
			mockMvc.perform(post("/api/v1/myprofile/getUserProfileQuestionsList")
					.contentType(MediaType.APPLICATION_JSON).header("x-user", 14l).accept(MediaType.ALL)).andDo(print())
					.andExpect(jsonPath("$.profileQuestions[0].answer").value(""))
					.andExpect(jsonPath("$.profileQuestions[1].answer").value("")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#updateProfile(jakarta.servlet.http.HttpServletRequest, com.seind.rc.services.user.data.ProfileData)}.
	 */

	@Test
	@Transactional
	@Rollback
	void testProfileUpdatePatient() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request="{\"firstName\":\"pat\",\"lastName\":\"one\",\"dob\":\"2001-02-28\",\"email\":\"Pateint1.one@mail.com\",\"code\":\"+1,USA\",\"phone\":\"\",\"otherPhoneType\":1,\"comType\":\"EMAIL\",\"codeOther\":\"+1,USA\",\"phoneOther\":\"\",\"pushNotification\":false,\"bpci\":\"No\",\"teleCode\":\"\",\"teleCodeOther\":\"\",\"teleCountryCode\":\"\",\"teleCountryCodeOther\":\"\",\"uploadImage\":[],\"patientSWFId\":371808}";		
		mockMvc.perform(post(uri).header("x-user", "10045").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.updateStatus").value("true"))
				.andExpect(jsonPath("$.sendEmailUpdateNotifiCation").value("false"))
				.andExpect(jsonPath("$.sendPhoneUpdateNotifiCation").value("false"));
	}

	@Test
	@Transactional
	@Rollback
	void testProfileUpdateCC() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request="{\"firstName\":\"Test\",\"lastName\":\"Cn\",\"userTitle\":\"CareCoordinator\",\"dob\":\"2017-05-24\",\"email\":\"cnone@rc.in\",\"code\":\"+1,USA\",\"phone\":\"8999988999\",\"comType\":\"BOTH\",\"realTimeAlert\":false,\"realTimeMessage\":false,\"phoneOther\":\"\",\"teleCode\":\"+1\",\"teleCountryCode\":\"USA\",\"teleCodeOther\":\"\",\"teleCountryCodeOther\":\"\",\"otherPhoneType\":\"\"}";
		mockMvc.perform(post(uri).header("x-user", "28").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.updateStatus").value("true"))
				.andExpect(jsonPath("$.sendEmailUpdateNotifiCation").value("false"))
				.andExpect(jsonPath("$.sendPhoneUpdateNotifiCation").value("false"));
	}

	@Test
	@Transactional
	@Rollback
	void testProfileUpdateCarePartner() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request = "{\"firstName\":\"chandran\",\"lastName\":\"subramani\",\"dob\":\"01/12/1999 00:00:00.000\",\"email\":\"chandran122250@gmail.com\",\"code\":\"\",\"phone\":\"2132132132\",\"comType\":\"BOTH\",\"uploadImage\":[],\"otherPhone\":\"2132132131\",\"teleCode\":\"+1\",\"teleCountryCode\":\"USA\",\"teleCodeOther\":\"+1\",\"teleCountryCodeOther\":\"USA\",\"otherPhoneType\":1,\"codeOther\":\"\",\"bpci\":\"Yes\",\"patientSWfId\":\"322884\"}";
		mockMvc.perform(post(uri).header("x-user", "575").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.updateStatus").value("true"))
				.andExpect(jsonPath("$.sendEmailUpdateNotifiCation").value("false"))
				.andExpect(jsonPath("$.sendPhoneUpdateNotifiCation").value("false"));
	}

	@Test
	@Transactional
	@Rollback
	void testProfileUpdateSurgeon() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request = "{\"firstName\":\"Ryan\",\"lastName\":\"one1\",\"userTitle\":\"Surgeon\",\"dob\":\"01/11/1998 00:00:00.000\",\"email\":\"Ryan@mail.com\",\"phone\":\"\",\"comType\":\"EMAIL\",\"notificationfrequency\":\"false\",\"realTimeAlert\":false,\"realTimeMessage\":false,\"uploadImage\":[],\"otherPhone\":\"\",\"teleCode\":\"\",\"teleCountryCode\":\"\",\"teleCodeOther\":\"\",\"teleCountryCodeOther\":\"\",\"otherPhoneType\":\"\"}";
		mockMvc.perform(post(uri).header("x-user", "8").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.updateStatus").value("true"))
				.andExpect(jsonPath("$.sendEmailUpdateNotifiCation").value("false"))
				.andExpect(jsonPath("$.sendPhoneUpdateNotifiCation").value("false"));
	}

	@Test
	@Transactional
	@Rollback
	void testProfileUpdatePhoneExists() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request = "{\"firstName\":\"care\",\"lastName\":\"co\",\"userTitle\":\"CareCoordinator\",\"dob\":\"09/11/1999 00:00:00.000\",\"email\":\"care@coo.com\",\"phone\":\"9876543210\",\"comType\":\"EMAIL\",\"notificationfrequency\":\"false\",\"realTimeAlert\":false,\"realTimeMessage\":true,\"otherPhone\":\"\",\"teleCode\":\"+1\",\"teleCountryCode\":\"USA\",\"teleCodeOther\":\"\",\"teleCountryCodeOther\":\"\",\"otherPhoneType\":\"\"}";
		mockMvc.perform(post(uri).header("x-user", "471").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.updateStatus").value("Phone aldready exists"));
	}

	@Test
	@Transactional
	@Rollback
	void testProfileUpdateEmailExists() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request = "{\"firstName\":\"care\",\"lastName\":\"co\",\"userTitle\":\"CareCoordinator\",\"dob\":\"09/11/1999 00:00:00.000\",\"email\":\"alan@mail.com\",\"phone\":\"5763146555\",\"comType\":\"EMAIL\",\"notificationfrequency\":\"false\",\"realTimeAlert\":false,\"realTimeMessage\":true,\"otherPhone\":\"\",\"teleCode\":\"+1\",\"teleCountryCode\":\"USA\",\"teleCodeOther\":\"\",\"teleCountryCodeOther\":\"\",\"otherPhoneType\":\"\"}";
		mockMvc.perform(post(uri).header("x-user", "471").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.updateStatus").value("Email address already exists"));
	}

	@Test
	@Transactional
	@Rollback
	void testProfileUpdateInvalidEmail() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request = "{\"firstName\":\"care\",\"lastName\":\"co\",\"userTitle\":\"CareCoordinator\",\"dob\":\"09/11/1999 00:00:00.000\",\"email\":\"care@cc\",\"phone\":\"\",\"comType\":\"EMAIL\",\"notificationfrequency\":\"false\",\"realTimeAlert\":false,\"realTimeMessage\":true,\"otherPhone\":\"\",\"teleCode\":\"+1\",\"teleCountryCode\":\"USA\",\"teleCodeOther\":\"\",\"teleCountryCodeOther\":\"\",\"otherPhoneType\":\"\"}";
		mockMvc.perform(post(uri).header("x-user", "471").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.updateStatus").value("Email has not valid characters"));
	}

	@Test
	@Transactional
	@Rollback
	void testProfileUpdateInvalidPhone() throws Exception {
		String uri = "/api/v1/myprofile/profileUpdate";
		String request = "{\"firstName\":\"care\",\"lastName\":\"co\",\"userTitle\":\"CareCoordinator\",\"dob\":\"09/11/1999 00:00:00.000\",\"email\":\"care@coo.com\",\"phone\":\"2355566\",\"comType\":\"EMAIL\",\"notificationfrequency\":\"false\",\"realTimeAlert\":false,\"realTimeMessage\":true,\"otherPhone\":\"\",\"teleCode\":\"+1\",\"teleCountryCode\":\"USA\",\"teleCodeOther\":\"\",\"teleCountryCodeOther\":\"\",\"otherPhoneType\":\"\"}";
		mockMvc.perform(post(uri).header("x-user", "471").contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.updateStatus").value("Phone number has not valid characters"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#getPhoneNumber(com.seind.rc.services.user.data.CountryCodeInfo)}.
	 */
	@Test
	void testGetPhoneNumber() throws Exception {
		testGetPhoneNumberCountryCodeIsvalid();
		testGetPhoneNumberCountryCodeIsInvalid();
	}

	/**
	 * Case 1
	 * 
	 * When country code is valid
	 */
	@Test
	void testGetPhoneNumberCountryCodeIsvalid() throws Exception {
		String uri = "/api/v1/myprofile/getphonebycountrycode";
		String request = "{\"countryCode\":\"USA\"}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(jsonPath("$.countryName").value("United States")).andExpect(jsonPath("$.length").value(10))
				.andDo(print());
	}

	/**
	 * Case 2
	 * 
	 * When country code is Invalid
	 */
	@Test
	void testGetPhoneNumberCountryCodeIsInvalid() throws Exception {
		String uri = "/api/v1/myprofile/getphonebycountrycode";
		String request = "{\"countryCode\":\"USJ\"}";
		String response = "{}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andDo(print()).andExpectAll(status().isOk(), content().string(response));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#getBiograph(com.seind.rc.services.user.data.PatientRequestData)}.
	 */
	@Test
	void testGetBiograph() throws Exception {

		String uri = "/api/v1/myprofile/getBioGraph";
		String request = "{\"patientId\":600049}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$[0].questionId").value(1))
				.andExpect(jsonPath("$[0].questionName")
						.value("What does your care team need to know about you in order to provide better care?"))
				.andExpect(jsonPath("$[0].answer").value("asdad")).andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MyProfileController#saveSecurityQuestionAnswer(jakarta.servlet.http.HttpServletRequest, com.seind.rc.services.user.data.SaveSecQuesAnsData)}.
	 */
	@Test
	@Rollback
	@Transactional
	void testSaveSecurityQuestionAnswer() throws Exception {
		String uri = "/api/v1/myprofile/saveSecQuesAns";
		String request = "{\"secQuestionOne\":3,\"secQuestionTwo\":7,\"secQuestionThree\":13,\"secAnswerOne\":\"god\",\"secAnswerTwo\":\"is\",\"secAnswerThree\":\"great\"}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).header("x-user", 2).contentType(MediaType.APPLICATION_JSON)
				.content(request)).andDo(print()).andExpect(jsonPath("$.status").value("Success"))
				.andExpect(status().isOk()).andDo(print());
	}

}
