/**
 * 
 */
package com.seind.rc.services.user.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.seind.rc.services.user.data.HospitalPracticeApptInfo;
import com.seind.rc.services.user.data.UserDetails;
import com.seind.rc.services.user.data.UsersData;

@SpringBootTest
@AutoConfigureMockMvc
class UserControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.UserController#getUsersByHospital(com.seind.rc.services.user.data.HospitalRequestData)}.
	 */
	@Test
	void testGetUsersByHospital() throws Exception {
		String uri = "/api/v1/user/getUsersByHospital";
		String req = "{\"hospitalId\":100008}";
		String userDataString = mockMvc.perform(
				post(uri).contentType(MediaType.APPLICATION_JSON).content(req).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse().getContentAsString();
		List<UsersData> userData = objectMapper.readValue(userDataString, new TypeReference<List<UsersData>>() {
		});
		assertEquals(true, userData.size() > 0);

	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.UserController#getUserGroupPrivelegeByGroupId(com.seind.rc.services.user.data.UserRequestData, jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	void testGetUserGroupPrivelegeByGroupId() {
		testGetUserGroupPrivelegeByGroupIdIsValid();
		testGetUserGroupPrivelegeByGroupIdIsInvalidAndXuserIsInvalid();
	}

	/**
	 * Case 1
	 * 
	 * UserGroupId Is Valid
	 */
	void testGetUserGroupPrivelegeByGroupIdIsValid() {
		try {
			String uri = "/api/v1/user/getUserGroupPrivelegeByGroupId";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).header("x-user", 50))
					.andExpect(jsonPath("$[0].sequenceNo").isNumber()).andExpect(jsonPath("$[0].menuId").isNumber())
					.andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Case 2
	 * 
	 * UserGroupId Is InValid and x-user Is Invalid
	 */
	void testGetUserGroupPrivelegeByGroupIdIsInvalidAndXuserIsInvalid() {
		try {
			String uri = "/api/v1/user/getUserGroupPrivelegeByGroupId";
			String response = "[]";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).header("x-user", 5647)).andDo(print())
					.andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * check email EXISTS
	 * 
	 * @throws Exception
	 */
	@Test
	void testCheckPhoneOrEmailExists() throws Exception {
		testCheckPhoneOrEmailExistsScenario1();
		testCheckPhoneOrEmailExistsScenario2();
		testCheckPhoneOrEmailExistsScenario3();
	}

	/**
	 * check email EXISTS
	 * 
	 * @throws Exception
	 *
	 *                   Test method for
	 *                   {@link com.seind.rc.services.user.controller.UserController#checkPhoneOrEmailExists(com.seind.rc.services.user.data.UserValidateModel)}.
	 */
	@Test
	void testCheckPhoneOrEmailExistsScenario1() throws Exception {
		String emailPhValidation = "{\"email\": \"Jean@mail.com\"}";
		mockMvc.perform(post("/api/v1/user/checkPhoneOrEmailExists").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.status").value("Success")).andDo(print());
	}

	/**
	 * check phone and telecode EXISTS
	 * 
	 * @throws Exception
	 *
	 */
	@Test
	void testCheckPhoneOrEmailExistsScenario2() throws Exception {
		String emailPhValidation = "{\"phone\":\"6875465222\",\"teleCode\":\"+1\"}";
		mockMvc.perform(post("/api/v1/user/checkPhoneOrEmailExists").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.status").value("Success")).andDo(print());
	}

	/**
	 * check email or phone NOTEXISTS
	 * 
	 * @throws Exception
	 *
	 */
	@Test
	void testCheckPhoneOrEmailExistsScenario3() throws Exception {
		String emailPhValidation = "{\"phone\":\"68754622\",\"teleCode\":\"+1\"}";
		String emailPhValidResponse = "{\"message\":\"Email or PhoneNumber Already Exists\",\"status\":\"Failure\"}";
		mockMvc.perform(post("/api/v1/user/checkPhoneOrEmailExists").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().string(emailPhValidResponse)).andDo(print());
	}

	/**
	 * check valid user datas
	 * 
	 * @throws Exception
	 *
	 *                   Test method for
	 *                   {@link com.seind.rc.services.user.controller.UserController#getUserData(com.seind.rc.services.user.data.PatientRequestData)}.
	 */
	@Test
	void testGetUserData() throws Exception {
		String userInfoData = "{\"patientId\": \"600047\"}";
		mockMvc.perform(post("/api/v1/user/getUserData").contentType(MediaType.APPLICATION_JSON).content(userInfoData)
				.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.userName").value("uuuuu@rc.com"))
				.andExpect(jsonPath("$.firstName").value("Gwer")).andDo(print());
	}

	/**
	 * check valid cn by the count
	 * 
	 * @throws Exception
	 *
	 *                   Test method for
	 *                   {@link com.seind.rc.services.user.controller.UserController#getAllCnInSameHospital(com.seind.rc.services.user.data.UserRequestData)}.
	 */
	@Test
	void testGetAllCnInSameHospital() throws Exception {
		String cnData = "{\"userAccountKey\":\"100002\"}";
		String userDataString = mockMvc
				.perform(post("/api/v1/user/fetchAllCnInSameHospital").contentType(MediaType.APPLICATION_JSON)
						.content(cnData).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse().getContentAsString();
		List<UserDetails> userData = objectMapper.readValue(userDataString, new TypeReference<List<UserDetails>>() {
		});
		assertEquals(2, userData.size());
//		assert userData.size()==2 || userData.size()==3;
	}

	/**
	 * check valid strykerAct user by the count
	 * 
	 * @throws Exception
	 */

	@Test
	void testGetUsersByStrykerAct() throws Exception {
		String userDataString = mockMvc
				.perform(post("/api/v1/user/fetchUsersByStrykerAct").accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andReturn().getResponse().getContentAsString();
		List<UserDetails> userData = objectMapper.readValue(userDataString, new TypeReference<List<UserDetails>>() {
		});
		assertEquals(7, userData.size());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.UserController#saveUser(com.seind.rc.services.user.data.SaveUserData, jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testSaveUser() {
		testSaveUserWithExistingEmail();
		testSaveUserNewUser();

	}

	@Test
	void testSaveUserWithExistingEmail() {

		try {
			String uri = "/api/v1/user/saveUser";
			String req = "{\"firstName\":\"CC\",\"lastName\":\"RC02\",\"userGroupName\":\"Care Coordinator\",\"dob\":\"1985-02-07\",\"gender\":\"Male\",\"address\":\"Chennai\",\"city\":\"Velachery\",\"state\":\"Chennai\",\"zip\":600117,\"phone\":\"+1-9087786789\",\"email\":\"solvedgeCCtest02@solvedge.in\",\"hospitalId\":100008}";
			String res = "{\"updateStatus\":\"false\",\"message\":\"User already Exists\"}";
			mockMvc.perform(post(uri).header("x-user", "1").contentType(MediaType.APPLICATION_JSON).content(req))
					.andDo(print()).andExpect(status().isOk()).andExpect(content().string(res));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	@Transactional
	@Rollback
	void testSaveUserNewUser() {

		try {
			String uri = "/api/v1/user/saveUser";
			String req = "{\"firstName\":\"CC\",\"lastName\":\"RC06\",\"userGroupName\":\"Care Coordinator\",\"dob\":\"1985-02-07\",\"gender\":\"Male\",\"address\":\"Chennai\",\"city\":\"Velachery\",\"state\":\"Chennai\",\"zip\":600117,\"phone\":\"+1-9087786789\",\"email\":\"solvedgeCCtest07@solvedge.in\",\"hospitalId\":100008}";
			String res = "{\"updateStatus\":\"true\",\"message\":\"Care Coordinator Added Successfully\"}";
			mockMvc.perform(post(uri).header("x-user", "1").contentType(MediaType.APPLICATION_JSON).content(req))
					.andDo(print()).andExpect(status().isOk()).andExpect(content().string(res));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.UserController#getusergrouplist(com.seind.rc.services.user.data.HospitalRequestData)}.
	 */
	@Test
	void testGetusergrouplist() {
		try {
			String uri = "/api/v1/user/getusergrouplist";
			String req = "{\"hospitalId\":100002}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$[0].userGroupId").isNumber());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for <<<<<<< HEAD
	 * {@link com.seind.rc.services.user.controller.UserController#getSurveyPartialResult(com.seind.rc.services.user.data.PatientSWFInfo)}.
	 */
	@Test
	void testGetSurveyPartialResult() throws Exception {
		testGetSurveyPartialResultValidPatientSWFId();
		testGetSurveyPartialResultInvalidPatientSWFId();
	}

	/**
	 * Case 1
	 * 
	 * When PatientSWFId Is Valid
	 */
	@Test
	void testGetSurveyPartialResultValidPatientSWFId() throws Exception {
		String uri = "/api/v1/user/getassignedbydetails";
		String request = "{\"patientSwfId\":\"322555\"}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(jsonPath("$.name").value("Dr.Ryan one")).andExpect(jsonPath("$.userRole").value("Surgeon"))
				.andDo(print());
	}

	/**
	 * Case 2
	 * 
	 * When PatientSWFId Is Invalid
	 */
	@Test
	void testGetSurveyPartialResultInvalidPatientSWFId() throws Exception {
		String uri = "/api/v1/user/getassignedbydetails";
		String request = "{\"patientSwfId\":\"32255513\"}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(jsonPath("$.name").value("")).andExpect(jsonPath("$.userRole").value("")).andDo(print());
	}

	/**
	 * 
	 * {@link com.seind.rc.services.user.controller.UserController#fetchCountryCodeByHspOrPracId(com.seind.rc.services.user.data.HospitalRequestData)}.
	 */
	@Test
	void testFetchCountryCodeByHspOrPracId() throws Exception {
		testFetchCountryCodeByHspOrPracIdPresent();
		testFetchCountryCodeByHspOrPracIdEmpty();
	}
	@Test
	void testFetchCountryCodeByHspOrPracIdPresent() {
		try {
			String uri = "/api/v1/user/fetchCountryCodeByHspOrPracId";
			String request = "{\"hospitalId\":100008}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$[0].countryCodeId").isNumber());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void testFetchCountryCodeByHspOrPracIdEmpty() {
		try {
			String uri = "/api/v1/user/fetchCountryCodeByHspOrPracId";
			String request = "{\"hospitalId\":10000}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$[0].countryCodeId").doesNotHaveJsonPath());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void testFetchMultiHosptialPracticeByHspId() throws Exception {
			String uri = "/api/v1/user/fetchMultiHosptialPracticeByHspId";
			String request = "{\"userAccountKey\":100030,\"groupType\":\"PRACTICE\",\"userGroupId\":17}";
			String multiHspPrac = mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$[0].code").value("OvrHSP"))
					.andReturn().getResponse().getContentAsString();
			List<HospitalPracticeApptInfo> apptInfos = objectMapper.readValue(multiHspPrac, new TypeReference<List<HospitalPracticeApptInfo>>() {
			});
			assertEquals(7, apptInfos.size());
	}
}
