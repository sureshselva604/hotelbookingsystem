
package com.seind.rc.services.user.controller;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@AutoConfigureMockMvc
class DeviceControllerTest {

	@Autowired
	private MockMvc mockMvc;


	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getPhoneType()}.
	 * 
	 */
	@Test
	void testGetPhoneTypeList() throws Exception {
		String uri = "/api/v1/device/getPhoneTypeList";
		mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_JSON).content("")).andDo(print())
				.andExpect(jsonPath("$[0].phoneTypeId").isNumber()).andExpect(jsonPath("$[0].active").isBoolean());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getTimeZone()}.
	 */
	@Test
	void testGetTimeZoneList() throws Exception {
		String uri = "/api/v1/device/getTimeZone";
		mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_JSON).content("")).andDo(print())
				.andExpect(jsonPath("$[0].zoneId").isNumber());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getAllUserGroup()}.
	 */
	@Test
	void testGetAllUserGroup() throws Exception {
		String uri = "/api/v1/device/getAllUserGroup";
		mockMvc.perform(get(uri).contentType(MediaType.APPLICATION_JSON).content("")).andDo(print())
				.andExpect(jsonPath("$[0].userGroupId").isNumber());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getActiveCarePartnerMap(com.seind.rc.services.user.data.CarePartnerMapRequestData)}.
	 */
	@Test
	void testGetActiveCarePartnerMap() throws Exception {
		testGetActiveCarePartnerMapTrue();
		testGetActiveCarePartnerMapFalse();

	}

	void testGetActiveCarePartnerMapTrue() throws Exception {
		String uri = "/api/v1/device/getCarePartnerMap";
		String request = "{\"carePartnerId\":0,\"patientId\":600134,\"isCarePartner\":true}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$[0].carePartnerMapId").isNumber())
				.andExpect(jsonPath("$[0].verified").isBoolean());
	}

	void testGetActiveCarePartnerMapFalse() throws Exception {
		String uri = "/api/v1/device/getCarePartnerMap";
		String request = "{\"carePartnerId\":555,\"patientId\":600369,\"isCarePartner\":false}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$[0].carePartnerMapId").doesNotHaveJsonPath());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getBiographyQuestionData()}.
	 */
	@Test
	void testGetBiographyQuestionData() throws Exception {
		String uri = "/api/v1/device/getBiographyQuestionData";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content("")).andExpect(status().isOk())
				.andDo(print()).andExpect(jsonPath("$[0].questionId").value(1))
				.andExpect(jsonPath("$[0].questionName")
						.value("What does your care team need to know about you in order to provide better care?"))
				.andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getBiographyQuestionAnswerData(com.seind.rc.services.user.data.PatientRequestData)}.
	 */
	@Test
	void testGetBiographyQuestionAnswerData() throws Exception {
		String uri = "/api/v1/device/getBiographyQuestionAnswerData";
		String request = "{\"patientId\": 600049}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$[0].profileResultDetailId").value(10))
				.andExpect(jsonPath("$[0].userAccountId").value(25)).andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getHopsitalDetailsByPatientId(com.seind.rc.services.user.data.PatientRequestData)}.
	 */
	@Test
	void testGetHopsitalDetailsByPatientId() throws Exception {
		String uri = "/api/v1/device/getHopsitalDetailsByPatientId";
		String request = "{\"patientId\": 600043}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$.hospitalId").value(100002))
				.andExpect(jsonPath("$.name").value("Health Care Prac")).andExpect(jsonPath("$.admissionId").value(1))
				.andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#patientStatus(com.seind.rc.services.user.data.PatientStatusDeviceData)}.
	 */
	@Test
	void testPatientStatus() throws Exception {
		String uri = "/api/v1/device/patientStatus";
		String request = "{\"patientId\": 600115,\"handshakekey\":\"3766FDF8-7CCF-4BC9-89B0-09D835BE52BD72e92725d1\"}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$.isPatient").value(true))
				.andExpect(jsonPath("$.isCarePartner").value(false)).andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#forgotAttempt(com.seind.rc.services.user.data.ForgotAttemptData)}.
	 */
	@Test
	void testForgotAttempt() throws Exception {
		String uri = "/api/v1/device/forgotAttempt";
		String request = "{\"userAccountId\":7,\"forgotattemptFailed\": 1,\"accountBlocked\":1}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$.status").value("Success"))
				.andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#forgotSecurityQuestion(com.seind.rc.services.user.data.ForgotSecQuesData)}.
	 */
	@Test
	void testForgotSecurityQuestion() throws Exception {
		String uri = "/api/v1/device/forgotSecurityQuestion";
		String request = "{\"patientId\":600041,\"isForgotSecurityQuest\":true}";
		mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$.status").value("Success"))
				.andDo(print());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getCareFamilyMapping(com.seind.rc.services.user.data.CarePartnerMapRequestData)}.
	 */
	@Test
	void testGetCareFamilyMapping() throws Exception {
		testGetCareFamilyMappingCase1();
		testGetCareFamilyMappingCase2();

	}

	private void testGetCareFamilyMappingCase1() throws Exception {
		String uri = "/api/v1/device/getCareFamilyGroup";
		String request = "{\"patientId\":600041,\"loginUserAccountId\":5}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.careNavigatorDetails[0].userAccountId").isNumber())
				.andExpect(jsonPath("$.hospitalCareNavigatorDetails[0].userAccountId").isNumber());

	}

	private void testGetCareFamilyMappingCase2() throws Exception {
		String uri = "/api/v1/device/getCareFamilyGroup";
		String request = "{\"patientId\":60004,\"loginUserAccountId\":5}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.careNavigatorDetails[0].userAccountId").doesNotExist())
				.andExpect(jsonPath("$.hospitalCareNavigatorDetails[0].userAccountId").doesNotExist());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getCareFamilyByMessageSent(com.seind.rc.services.user.data.CarePartnerMapRequestData)}.
	 */
	@Test
	void testGetCareFamilyByMessageSent() throws Exception {
		String uri = "/api/v1/device/getCareFamilyByMessage";
		String request = "{\"patientId\":600308,\"loginUserAccountId\":506,\"userAccountIds\":[24,34]}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.careNavigatorDetails[0].cnId").isNumber())
				.andExpect(jsonPath("$.careNavigatorDetails[0].patientSWfId").isNumber());

	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#saveUserLoginAudit(com.seind.rc.services.user.data.DeviceLoginData)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testSaveUserLoginAudit() throws Exception {
		String uri = "/api/v1/device/deviceLogin";
		String request = "{\"carePartnerId\":208,\"patientId\":600115,\"modeOfLogin\":\"login\",\"isLoginTime\":\"2024-02-12T00:00:00.000Z\",\"appVersion\":\"\",\"OSVersion\":\"\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.message").value("Success"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#saveUserSecTransAudit(com.seind.rc.services.user.data.DeviceActivationData)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testSaveUserSecTransAudit() throws Exception {
		String uri = "/api/v1/device/deviceActivation";
		String request = "{\"carePartnerId\":54,\"userAccountId\":51,\"isDeviceActivation\":true,\"activationMode\":\"M\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.status").value("Success"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#resetPatientPassword(com.seind.rc.services.user.data.ResetPatPassReq)}.
	 */
	@Test
	void testResetPatientPassword() throws Exception {

		testResetPatientPasswordValidData();
		testResetPatientPasswordInvalidData();

	}

	@Test
	void testResetPatientPasswordValidData() throws Exception {
		String uri = "/api/v1/device/resetPatientPassword";
		String req = "{\"userName\":\"demo@123.com\",\"randomId\":\"dde6cfce-de78-4158-879e-61cb53cde07b\",\"password\":\"Demo@12345\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("success"));
	}

	@Test
	void testResetPatientPasswordInvalidData() throws Exception {
		String uri = "/api/v1/device/resetPatientPassword";
		String req = "{\"userName\":\"\",\"randomId\":\"dde6cfce-de78-4158-879e-61cb53cde07b\",\"password\":\"Demo@12345\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.message")
						.value("You have entered an incorrect username. Please try your email or phone number"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#saveLoginAuditForLater(com.seind.rc.services.user.data.DeviceActivationData)}.
	 */
	@Test
	void testSaveLoginAuditForLater() throws Exception {

		testSaveLoginAuditForLaterValidData();
		testSaveLoginAuditForLaterInValidData();
	}

	@Test
	void testSaveLoginAuditForLaterValidData() throws Exception {
		String uri = "/api/v1/device/getpasswordbypatient/deviceActivation";
		String req = "{\"isDeviceActivation\":true,\"userAccountId\":192,\"activationMode\":\"A\",\"appVersion\":\"28\",\"OSVersion\":\"6.4\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("success"));

	}

	@Test
	void testSaveLoginAuditForLaterInValidData() throws Exception {
		String uri = "/api/v1/device/getpasswordbypatient/deviceActivation";
		String req = "{\"isDeviceActivation\":true,\"userAccountId\":1924567,\"activationMode\":\"A\",\"appVersion\":\"28\",\"OSVersion\":\"6.4\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Failure"));

	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getPassWordUpdatebyPatient(com.seind.rc.services.user.data.UserSecAnsData)}.
	 */
	@Test
	void testGetPassWordUpdatebyPatient() throws Exception {
		testGetPassWordUpdatebyPatientValidData();
		testGetPassWordUpdatebyPatientInvalidData();
	}

	@Test
	void testGetPassWordUpdatebyPatientValidData() throws Exception {
		String uri = "/api/v1/device/getpasswordbypatient/userSecAnswer";
		String req = "{\"userPassword\":\"Static@1234\",\"isCarePartner\":true,\"userAccountId\":192}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("success"));
	}

	@Test
	void testGetPassWordUpdatebyPatientInvalidData() throws Exception {
		String uri = "/api/v1/device/getpasswordbypatient/userSecAnswer";
		String req = "{\"userPassword\":\"Static@1234\",\"isCarePartner\":true,\"userAccountId\":192456}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Failure"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#saveFcmToken(com.seind.rc.services.user.data.FcmTokenData)}.
	 */
	@Test
	void testSaveFcmToken() throws Exception {
		testSaveFcmTokenValidData();
		testSaveFcmTokenInvalidData();
	}

	@Test
	void testSaveFcmTokenValidData() throws Exception {
		String uri = "/api/v1/device/device/getpatientresultfilesyncPatientId/fcmToken";
		String req = "{\"fcmToken\":\"B7031219C5603F79EC1BD6FEE765F370F3F4C4EC78E40C54017CF9065522D670\",\"handShakeKey\":\"3766FDF8-7CCF-4BC9-89B0-09D835BE52BD72e92725d1\",\"appVersion\":\"28\",\"OSVersion\":\"6.4\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("success"));
	}

	@Test
	void testSaveFcmTokenInvalidData() throws Exception {
		String uri = "/api/v1/device/device/getpatientresultfilesyncPatientId/fcmToken";
		String req = "{\"fcmToken\":\"B7031219C5603F79EC1BD6FEE765F370F3F4C4EC78E40C54017CF9065522D671\",\"handShakeKey\":\"3766FDF8-7CCF-4BC9-89B0-09D835BE52BD72e92725d1\",\"appVersion\":\"28\",\"OSVersion\":\"6.4\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Failure"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#updateCarePartnerMap(com.seind.rc.services.user.data.UpdateCarePartnerMapData)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testUpdateCarePartnerMap() throws Exception {
		String uri = "/api/v1/device/carePartnerMap";
		String request = "{\"carePartnerId\":208,\"userAccountId\":208,\"patientId\":600115,\"verified\":true}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.status").value("Success"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#deactivateSecurityCredentials(com.seind.rc.services.user.data.SecurityCredentialData)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testDeactivateSecurityCredentials() throws Exception {
		testDeactivateSecurityCredentialsCase1();
		testDeactivateSecurityCredentialsCase2();
	}

	void testDeactivateSecurityCredentialsCase2() throws Exception {
		String uri = "/api/v1/device/deactivateSecurityCredentialsByMode";
		String request = "{\"handShakeKey\":\"FB10995F5FB09A862491A6B3B6D0019Ef64ddc82cd\",\"userAccountId\":89}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.status").value("Success"));
	}

	void testDeactivateSecurityCredentialsCase1() throws Exception {
		String uri = "/api/v1/device/deactivateSecurityCredentialsByMode";
		String request = "{\"handShakeKey\":\"FB10995F5FB09A862491A6B3B6D0019Ef64ddc82\",\"userAccountId\":89}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.status").value("Failure"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#updatePatient(com.seind.rc.services.user.data.UpdatePatientData)}.
	 */
	@Test
	@Transactional
	@Rollback
	void testUpdatePatient() throws Exception {
		String uri = "/api/v1/device/updatePatient";
		String request = "{\"patientId\":600041,\"isEditStatus\":\"true\",\"firstName\":\"Karol\",\"lastName\":\"two\",\"lastModifiedBy\":\"\",\"comType\":\"NONE\",\"code\":\"\",\"dob\":\"12/01/1999 00:00:00.000\",\"randomId\":\"\",\"hasCarePartner\":false,\"gender\":\"Male\",\"imagePath\":\"\",\"phone\":\"\",\"teleCode\":\"\",\"teleCountryCode\":\"\",\"otherPhone\":\"\",\"otherTeleCode\":\"\",\"otherTeleCountryCode\":\"\",\"otherPhoneType\":\"\"}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
				.andExpect(jsonPath("$.updateStatus").value("Success"));
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getUsersInfoByPatientId(com.seind.rc.services.user.data.CheckPatient)}.
	 */
	@Test
	void testGetUsersInfoByPatientId() throws Exception {
		String uri = "/api/v1/device/getUsersInfoByPatientId";
		String req = "{\"patientId\":600115}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$[0].userAccountId").isNumber())
				.andExpect(jsonPath("$[0].active").isBoolean()).andExpect(jsonPath("$[0].userGroupId").isNumber());
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getHospitalListInfoByPatientId(com.seind.rc.services.user.data.CheckPatient)}.
	 */
	@Test
	void testgetHospitalListInfoByPatientId() throws Exception {

		String uri = "/api/v1/device/getHospitalListInfoByPatientId";
		String req = "{\"patientId\":600125}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(jsonPath("$[0].admissionId").isNumber()).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].hospitalId").isNumber());

	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getSurgeonInfoByPatientId(com.seind.rc.services.user.data.CheckPatient)}.
	 */
	@Test
	void testGetSurgeonInfoByPatientId() throws Exception {
		testGetSurgeonInfoByPatientIdValidData();
		testGetSurgeonInfoByPatientIdInvaildData();
	}

	@Test
	void testGetSurgeonInfoByPatientIdValidData() throws Exception {
		String uri = "/api/v1/device/getSurgeonInfoByPatientId";
		String req = "{\"patientId\":600115}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$[0].surgeonId").isNumber());

	}

	@Test
	void testGetSurgeonInfoByPatientIdInvaildData() throws Exception {
		String uri = "/api/v1/device/getSurgeonInfoByPatientId";
		String req = "{\"patientId\":60011}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$").isEmpty());

	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.DeviceController#getHospitalSurgeonInfoByPatientId(com.seind.rc.services.user.data.CheckPatient)}.
	 */
	@Test
	void GetHospitalSurgeonInfoByPatientId() throws Exception {

		GetHospitalSurgeonInfoByPatientIdValidData();
		GetHospitalSurgeonInfoByPatientIdInvalidData();
	}

	@Test
	void GetHospitalSurgeonInfoByPatientIdValidData() throws Exception {

		String uri = "/api/v1/device/getHospitalSurgeonInfoByPatientId";
		String req = "{\"patientId\":600115}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$.hospitalSurgeonId").isNumber())
				.andExpect(jsonPath("$.hospitalId").isNumber()).andExpect(jsonPath("$.surgeonId").isNumber());

	}

	@Test
	void GetHospitalSurgeonInfoByPatientIdInvalidData() throws Exception {

		String uri = "/api/v1/device/getHospitalSurgeonInfoByPatientId";
		String req = "{\"patientId\":60011}";
		mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(req)).andDo(print())
				.andExpect(status().isOk()).andExpect(jsonPath("$").isEmpty());

	}

	@Test
	void testPatientOrCarepartnerCheckStatusScenario1() throws Exception {
		String emailPhValidation = "{\"userName\": \"ss@rc.in\",\"password\":\"Demo@123\",\"deviceName\":\"iPhone\",\"serialNo\":\"3766FDF8-7CCF-4BC9-89B0-09D835BE52BD\",\"version\":\"m5\"}";
		mockMvc.perform(post("/api/v1/device/patientOrCarepartnerCheckStatus").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(jsonPath("$.status").value("Success")).andExpect(jsonPath("$.deviceKey").value("9bf771a8ff"))
				.andExpect(jsonPath("$.isOfficeStaff").value(false));

	}

	@Test
	void testPatientOrCarepartnerCheckStatusScenario2() throws Exception {
		String emailPhValidation = "{\"userName\": \"fghfh@mail.com\",\"password\":\"Demo@123\",\"deviceName\":\"M2003J15SC\",\"serialNo\":\"67C677AF0FE5406571FC3C2481A104C4\",\"version\":\"m5\"}";
		mockMvc.perform(post("/api/v1/device/patientOrCarepartnerCheckStatus").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(jsonPath("$.status").value("Success")).andExpect(jsonPath("$.deviceKey").value("357051e164"))
				.andExpect(jsonPath("$.isOfficeStaff").value(false));

	}

	@Test
	void testActiveBodyPartListforCarePartner() throws Exception {
		String emailPhValidation = "{\"userAccountId\": \"556\"}";
		mockMvc.perform(post("/api/v1/device/activeBodyPartListforCarePartner").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(jsonPath("$[0].loginAccountId").value("458"))
				.andExpect(jsonPath("$[0].firstName").value("jill"))
				.andExpect(jsonPath("$[0].userGroupName").value("Patient"))
				.andExpect(jsonPath("$[1].loginAccountId").value("551"))
				.andExpect(jsonPath("$[1].firstName").value("qatest"))
				.andExpect(jsonPath("$[1].userGroupName").value("Care Partner"));
	}

	@Test
	void testValidateOtp() throws Exception {
		String emailPhValidation = "{\"userAccountId\": \"10665\",\"otp\":\"238555\",\"mode\":\"activation-otp\"}";
		mockMvc.perform(post("/api/v1/device/validateOtpDev").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(jsonPath("$.status").value("Failure"))
				.andExpect(jsonPath("$.message").value("OTP is Expired."));
	}

	@Test
	void testGetEmailorPhExistsFlagByPatient() throws Exception {
		String emailPhValidation = " {\"patVitalData\": [{\"handshakekey\": \"19810ED01FC7A819E51A1692B2AD4A61d29719da9b\",\"isEmailUpdate\": true,\"isPhoneUpdate\": false,\"patId\": 600060,\"patEmail\": \"giiiivvv@rc.in\",\"patPhone\": \"6875465222\",\"isOtherUser\": \"\"}],  \"handshakekey\": \"19810ED01FC7A819E51A1692B2AD4A61d29719da9b\"}";
		mockMvc.perform(post("/api/v1/device/getEmailExistsFlag").contentType(MediaType.APPLICATION_JSON)
				.content(emailPhValidation).accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.isEmailorPhone").value("Update Sucessfully")).andDo(print());
	}

}
