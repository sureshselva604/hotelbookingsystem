/**
 * 
 */
package com.seind.rc.services.user.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class CarePartnerControllerTest {

	@Autowired
	private MockMvc mockMvc;

	/**
	 * 
	 * {@link com.seind.rc.services.user.controller.CarePartnerController#checkPatient(com.seind.rc.services.user.data.CheckPatient)}.
	 */
	@Test
	void testCheckPatient() throws Exception {
		testCheckPatientAndDobExists();
		testCheckPatientAndDobNotExists();
	}
	@Test
	void testCheckPatientAndDobExists() {
		try {
			String uri = "/api/v1/care/checkPatient";
			String request = "{\"dob\":\"2000-10-10\",\"patientId\":600060,\"mappingId\":20098}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Success"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void testCheckPatientAndDobNotExists() {
		try {
			String uri = "/api/v1/care/checkPatient";
			String request = "{\"dob\":\"2001-10-10\",\"patientId\":600061,\"mappingId\":20098}";
			mockMvc.perform(post(uri).contentType(MediaType.APPLICATION_JSON).content(request)).andDo(print())
					.andExpect(status().isOk()).andExpect(jsonPath("$.status").value("Failure"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
