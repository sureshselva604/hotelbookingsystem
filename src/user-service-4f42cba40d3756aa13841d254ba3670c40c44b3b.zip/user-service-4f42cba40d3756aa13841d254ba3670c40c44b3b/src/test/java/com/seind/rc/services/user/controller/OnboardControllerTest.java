/**
 * 
 */
package com.seind.rc.services.user.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

/**
 * 
 */
@SpringBootTest
@AutoConfigureMockMvc
class OnboardControllerTest {

	@Autowired
	private MockMvc mockMvc;

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.OnboardController#checkUserValidation(com.seind.rc.services.user.data.UserRequestData)}.
	 */
	@Test
	void testCheckUserValidation() {
		testCheckUserValidationUserNameIsValid();
		testCheckUserValidationUserNameIsNull();
		testCheckUserValidationAccountNotActive();
		testCheckUserValidationValidUserNameButUserAlreadyDeleted();
		testCheckUserValidationUserAlreadyActivated();
	}

	/**
	 * Case 1
	 * 
	 * When UserName Is Valid
	 */
	@Test
	void testCheckUserValidationUserNameIsValid() {
		try {
			String uri = "/api/v1/onboard/checkvalidation";
			String request = "{\"userName\":\"fghfh@mail.com\"}";
			String response = "{\"statusCode\":200,\"status\":true,\"randId\":\"b4e42c79-83f1-4b7f-9cb3-ff24c152e8b8\",\"userGroupId\":20}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Case 2
	 * 
	 * When UserName Is null
	 */
	@Test
	void testCheckUserValidationUserNameIsNull() {
		try {
			String uri = "/api/v1/onboard/checkvalidation";
			String request = "{\"userName\":\"\"}";
			String response = "{\"statusCode\":401,\"status\":false,\"error\":\"Entered username is not enrolled in RecoveryCOACH. So Please contact your healthcare provider.\",\"message\":\"Entered username is not enrolled in RecoveryCOACH. So Please contact your healthcare provider.\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Case 3
	 * 
	 * When Account Not Active
	 *
	 */
	@Test
	void testCheckUserValidationAccountNotActive() {
		try {
			String uri = "/api/v1/onboard/checkvalidation";
			String request = "{\"userName\":\"care1pat@cc.in\"}";
			String response = "{\"statusCode\":401,\"status\":true,\"error\":\" Your account is no longer active. So Please contact your healthcare provider or administrator for details.\",\"message\":\" Your account is no longer active. So Please contact your healthcare provider or administrator for details.\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Case 4
	 * 
	 * When Valid UserName But User Already Deleted
	 */
	@Test
	void testCheckUserValidationValidUserNameButUserAlreadyDeleted() {
		try {
			String uri = "/api/v1/onboard/checkvalidation";
			String request = "{\"userName\":\"microOneFour@solvedge.in\"}";
			String response = "{\"statusCode\":401,\"status\":false,\"error\":\"Your account is deactivated.\",\"message\":\"Your account has been deactivated. If you have any questions, please contact patient care.\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Case 5
	 * 
	 * User Already Activated
	 */
	@Test
	void testCheckUserValidationUserAlreadyActivated() {
		try {
			String uri = "/api/v1/onboard/checkvalidation";
			String request = "{\"userName\":\"Andrew@mail.com\"}";
			String response = "{\"statusCode\":401,\"status\":false,\"error\":\"Your Account is already Activated.\",\"message\":\"Your Account is already Activated.\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk(), content().string(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.OnboardController#getPatientWelcomeInfo(com.seind.rc.services.user.data.UpdatePwdData)}.
	 */
	@Test
	void testGetPatientWelcomeInfo() {
		testGetPatientWelcomeInfoStatusIsSuccess();
		testGetPatientWelcomeInfoStatusIsFailure();
	}

	/**
	 * Case 1
	 * 
	 * When Status is Success
	 */
	void testGetPatientWelcomeInfoStatusIsSuccess() {
		try {
			String uri = "/api/v1/onboard/getPatientWelcomeInfo";
			String request = "{\"randId\": \"cb23073e-636b-4bde-8c3f-5475c932cc98\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andDo(print()).andExpectAll(status().isOk())
					.andExpect(jsonPath("$.patientName").value("Hyatt one"))
					.andExpect(jsonPath("$.userAccountId").isNumber()).andExpect(jsonPath("$.status").value("Success"))
					.andExpect(jsonPath("$.message").value("Success")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Case 2
	 * 
	 * When Status is Failure
	 */
	void testGetPatientWelcomeInfoStatusIsFailure() {
		try {
			String uri = "/api/v1/onboard/getPatientWelcomeInfo";
			String request = "{\"randId\":\"e3e876e1-d80d-4bf1-ba4a-0196a71330dc\"}";
			mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(request))
					.andExpect(jsonPath("$.status").value("Failure"))
					.andExpect(jsonPath("$.message").value(
							"Your email has been updated. Please click on the activation link sent to this updated email address to get started with your journey in RecoverCOACH."))
					.andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
