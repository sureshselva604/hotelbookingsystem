/**
 * 
 */
package com.seind.rc.services.user.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.seind.rc.services.user.data.UserMsgRespData;

@SpringBootTest
@AutoConfigureMockMvc
class MessageControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * check the response patientCCname is correct
	 * 
	 * @throws Exception
	 */
	@Test
	void testGetPatientOrCCNameResponseScenarion1() {
		try {
			String notesPatientDashBoard = "[{\"sentBy\": 14}]";
			mockMvc.perform(post("/api/message/getPatientOrCCNameResp").contentType(MediaType.APPLICATION_JSON)
					.content(notesPatientDashBoard).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$[0].patientOrCcName").value("Kay one")).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * check the response patientCCname is correct
	 * 
	 * @throws Exception
	 */
	@Test
	void testGetPatientOrCCNameResponseScenario2() {
		try {
			String notesPatientDashBoard = "[{\"sentBy\": 12}]";
			mockMvc.perform(post("/api/message/getPatientOrCCNameResp").contentType(MediaType.APPLICATION_JSON)
					.content(notesPatientDashBoard).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$[0].patientOrCcName").value(null)).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for
	 * {@link com.seind.rc.services.user.controller.MessageController#getCCPatientInfoForMessages(com.seind.rc.services.user.data.MessageReqData, jakarta.servlet.http.HttpServletRequest)}.
	 */
	@Test
	void testGetCCPatientInfoForMessages() {
		testGetCCPatientInfoForMessagesScenario1();
		testGetCCPatientInfoForMessagesScenario2();
	}

	/**
	 * case Scenario1 when Check the login user and given userId MATCH
	 * 
	 * @throws Exception
	 */
//	@Test
	void testGetCCPatientInfoForMessagesScenario1() {
		try {
			String msgReqData = "{\"cnUserId\":0, \"userAccountId\":39}";
			mockMvc.perform(post("/api/message/ccPatientInfoForMessages").contentType(MediaType.APPLICATION_JSON)
					.content(msgReqData).header("x-user", 39).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$[0].error").doesNotExist()).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * case Scenario2 when Check the login user and given userId NOT MATCH
	 * 
	 * @throws Exception
	 */
//	@Test
	void testGetCCPatientInfoForMessagesScenario2() {
		try {
			String msgReqData = "{\"cnUserId\":0, \"userAccountId\":39}";
			mockMvc.perform(post("/api/message/ccPatientInfoForMessages").contentType(MediaType.APPLICATION_JSON)
					.content(msgReqData).header("x-user", 14).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$[0].error").exists()).andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void testGetUsersInfoForMessage() {
		try {
			String msgrequest = "{\"patientSwfId\":322797,\"loginUaId\":39}";
			String infoListStr = mockMvc.perform(post("/api/message/getUsersInfoForMessage").contentType(MediaType.APPLICATION_JSON)
					.content(msgrequest).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$[0].name").value("Sara one")).andDo(print()).andReturn().getResponse().getContentAsString();
			List<UserMsgRespData> infoList = objectMapper.readValue(infoListStr, new TypeReference<List<UserMsgRespData>>() {
			});
			assertEquals(4, infoList.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void testGetUsersInfoForApptMsg() {
		try {
			String msgrequest = "{\"patientSWFId\":322627,\"appointmentId\":35996,\"appointmentName\":\"\",\"strykerAdminId\":0}";
			mockMvc.perform(post("/api/message/getUsersInfoForApptMsg").contentType(MediaType.APPLICATION_JSON)
					.content(msgrequest).accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.userAccountId").value(152l)).andDo(print())
					.andExpect(jsonPath("$.patUserId").value(164l))
					.andExpect(jsonPath("$.enabled").value(true))
					.andExpect(jsonPath("$.patientId").value(600112l));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
